export default {
    /**
     * @description 配置显示在浏览器标签的title
     */
    title: 'erp',
    /**
     * @description token在Cookie中存储的天数，默认1天
     */
    cookieExpires: 1,
    /**
     * @description 是否使用国际化，默认为false
     *              如果不使用，则需要在路由中给需要在菜单中展示的路由设置meta: {title: 'xxx'}
     *              用来在菜单中显示文字
     */
    useI18n: false,
    /**
     * @description api请求基础路径
     */
    baseUrl: {
        dev: '',
        test: '/erp/',
        pro: '/erp_api/'
    },
    /**
     * @description 查看文件地址
     */
    fileUrl: {
        dev: '//47.92.170.226:8060/document/public/download/',
        test: '/erp/document/public/download/',
        pro: '/erp_api/document/public/download/'
    },
    /**
     * @description 路由base
     */
    routeBase: {
        dev: '',
        test: '',
        pro: '/erp/'
    },
    /**
     * @description 库存初始化导入模板
     */
    inventoryInitUpload: {
        dev: '/inventory/init/record/import',
        test: '/erp/inventory/init/record/import',
        pro: '/erp_api/inventory/init/record/import/'
    },
    /**
     * @description 库存初始化下载模板
     */
    inventoryInitDownload: {
        dev: '//47.92.170.226:8060/inventory/init/record/public/template/download',
        test: '/erp/inventory/init/record/public/template/download',
        pro: '/erp_api/inventory/init/record/public/template/download'
    },
    /**
     * @description 打印无价
     */
    printDeliverGoodsNoPrice: {
        dev: '/print_deliveryNotice',
        test: '/print_deliveryNotice',
        pro: '/erp/print_deliveryNotice'
    },
    /**
     * @description 打印有价
     */
    printDeliverGoodsPrice: {
        dev: '/print_deliveryNotice_price',
        test: '/print_deliveryNotice_price',
        pro: '/erp/print_deliveryNotice_price'
    },
    /**
     * @description 默认打开的首页的路由name值，默认为home
     */
    homeName: 'home',
    /**
     * @description 需要加载的插件
     */
    plugin: {
        'error-store': {
            showInHeader: true, // 设为false后不会在顶部显示错误日志徽标
            developmentOff: true // 设为true后在开发环境不会收集错误信息，方便开发中排查错误
        }
    }
};
