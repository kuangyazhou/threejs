/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-08 17:31:52
 * @LastEditTime: 2019-08-15 22:27:01
 * @LastEditors: Please set LastEditors
 */
import {
    packageList,
    getRadioData,
    materialUpload
} from '@/api/material/materialadd';

import {
    getBeforeBaseInfo,
    materialChangeDel,
    materialChangeSubmit,
    getBeforePackage,
    materialChangePass,
    getBeforeFile
} from '@/api/material/materialchange';

import { getCheckName } from '@/api/materialManage/checkName.js';

import { resetObj } from '@/libs/tools';
export default {
    data () {
        return {
            typeList: [
                { label: '采购发起', value: 0 },
                { label: '质管录入', value: 1 },
                { label: '审批中', value: 2 },
                { label: '审批通过', value: 3 },
                { label: '打回', value: 4 }
            ],
            statusList: [
                { label: '待发起', value: 0 },
                { label: '审批中', value: 1 },
                { label: '审核通过', value: 2 },
                { label: '打回', value: 3 }
            ],
            readonly: false,
            brandNameArr: [], // 物料品牌
            commodityTypeNameArr: [], // 药品剂型
            deviceClassifyTypeArr: [], // 器械类别
            deviceClassifyCodeArr: [], // 器械分类
            coldChainMarkIdArr: [], // 冷链标识
            Level1Arr: [], // 分类一级
            Level2Arr: [], // 分类二级,
            packageArr: [], // 包装单位列表数据
            currentRow: {}, // 当前选中行
            radioData: [], // 资料上传单选框数据
            uploadTable: [], // 上传资料list数据
            oldPackageArr: [], // 变更前包装信息
            oldUploadArr: [], // 变更前上传资料
            unitArr: [], // 包装单位数据
            accountArr: [], // 核算名称数据源
            specialGroupArr: [], // 专业分组数据源
            commodityId: '',
            isImport: false,
            formAttr: {
                commodityCode: '',
                commodityNumber: '',
                classifyIdLevel1: '',
                commodityName: '',
                brandId: '',
                brandName: '',
                commoditySpec: '',
                commodityType: '',
                commodityTypeName: '',
                isSimplelevy: '',
                registerName: '',
                registerNumber: '',
                hasSet: '',
                storageCondition: '',
                coldChainMarkId: '',
                deviceClassifyType: '',
                deviceClassifyCode: '',
                effectiveDays: '',
                effectiveDaysShow: '',
                manufacturerId: '',
                manufacturerName: '',
                productionLicense: '',
                classifyIdLevel2: '',
                specializedGroupId: '',
                accountingOne: '',
                accountingMl: '',
                accountingId: '',
                isImported: '',
                remark: '',
                id: '',
                status: '',
                deviceClassifyId: ''
            }
        };
    },
    methods: {
        // 点击单行选中
        currentChange (row) {
            this.currentId = row.id;
            this.currentRow = row;
        },
        // 检验是否选择数据
        validCurrent () {
            let temp = false;
            if (!this.currentId) {
                this.$Message.error('请单击选择数据');
                temp = false;
            } else {
                temp = true;
            }
            return temp;
        },

        // 物料关闭
        materialModalCancel () {
            this.modalShowFlag = false;
            this.modalImport = false;
            this.readonly = false;
            this.currentId = null;
            this.oldBaseInfo = {};
            resetObj(this.formAttr, 1);
            this.tabIndex = 0;
            this.$nextTick(() => {
                this.$refs['baseInfoForm'].$refs['formValidate'].resetFields();
                this.$refs.managerTable.clearCurrentTableRow();
            });
        },

        // 获取资料上传单选框数据
        async getRadioArr () {
            const res = await getRadioData();
            if (res.status === this.code) {
                this.radioData = res.content;
            }
        },

        // 获取上传资料list数据
        async uploadList (e) {
            const params = {
                dataType: e || null,
                commodityId: this.commodityId
            };
            const res = await materialUpload(params);
            if (res.status === this.code) {
                this.uploadTable = res.content;
            }
        },

        // 编辑
        edit () {
            let valid = this.validCurrent();
            if (!valid) return false;
            if (this.currentRow.status === 2) {
                this.$Message.error('已审核状态无法编辑');
                return;
            }
            // 设置物料id和current;
            this.commodityId = this.currentRow.commodityId;
            this.readonly = false;
            this.getAllSelectData();
            this.editTableData({ row: this.currentRow }, '修改物料');
            this.getOldBase({
                taskInstanceId: this.currentId
            });
        },

        // 物料发起审批
        async approve () {
            let valid = this.validCurrent();
            if (!valid) return false;
            const params = {
                id: this.currentRow.id
            };
            const res = await materialChangeSubmit(params);
            if (res.status === this.code) {
                this.$Message.success(res.msg);
                this.currentId = null;
                this.getTableList();
            }
        },
        // 删除物料
        async del () {
            let valid = this.validCurrent();
            if (!valid) return false;
            const params = {
                id: this.currentRow.id
            };
            const res = await materialChangeDel(params);
            if (res.status === this.code) {
                this.$Message.success('删除成功');
                this.tableComAttr.pageNo = 1;
                this.currentId = null;
                this.getTableList();
            }
        },
        // 物料变更审核通过
        async auditPass (row) {
            const params = { id: row.id };
            const res = await materialChangePass(params);
            if (res.status === this.code) {
                this.todoOver(res.msg);
            }
        },

        // 获取下拉框数据
        getAllSelectData () {
            this.getFieldValuesData('commodity_band', 'brandNameArr');
            this.getFieldValuesData(
                'commodity_medicinal_type',
                'commodityTypeNameArr'
            );
            this.getFieldValuesData(
                'device_classify_type',
                'deviceClassifyTypeArr'
            );
            this.getFieldValuesData(
                'commodity_cold_chain_mark',
                'coldChainMarkIdArr'
            );
            this.getFieldValuesData('commodity_classify_level1', 'Level1Arr');
            this.getFieldValuesData('commodity_classify_level2', 'Level2Arr');
            this.getFieldValuesData('package_unit', 'unitArr');
            this.getFieldValuesData('specialty_group', 'specialGroupArr');
            this.getAccountName();
        },

        // 获取包装信息列表
        async getPackageList () {
            const params = {
                commodityId: this.commodityId
            };
            const res = await packageList(params);
            if (res.status === this.code) {
                this.packageArr = res.content;
                this.changeLoading();
            }
        },

        // 获取核算名称列表
        async getAccountName () {
            const params = {
                status: 1
            };
            const res = await getCheckName(params);
            if (res.status === this.code) {
                this.accountArr = res.content;
            }
        },

        // 获取集团下的物料基础信息
        async getOldBaseInfo () {
            const params = {
                id: this.commodityId
            };
            const res = await getBeforeBaseInfo(params);
            if (res.status === this.code) {
                this.formAttr = res.content;
                // this.commodityId = res.content.id;
                this.formAttr.id = null;
            }
        },
        // 设置变更前基础信息
        async getOldBase (params) {
            // const params = {
            //     id: this.commodityId
            // };
            const res = await getBeforeBaseInfo(params);
            if (res.status === this.code) {
                this.oldBaseInfo = res.content;
            }
        },

        // 获取变更前物料包装信息
        async getOldPackage () {
            const params = {
                taskInstanceId: this.currentId
            };
            const res = await getBeforePackage(params);
            if (res.status === this.code) {
                this.oldPackageArr = res.content;
            }
        },
        async getOldUpload () {
            const params = {
                taskInstanceId: this.currentId
            };
            const res = await getBeforeFile(params);
            if (res.status === this.code) {
                this.oldUploadArr = res.content;
            }
        }
    }
};
