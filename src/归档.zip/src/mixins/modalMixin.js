import { resetObj } from '@/libs/tools';
export default {
    data () {
        return {
            modalShowFlag: false, // modal显示开关
            modalTitle: '', // modal标题
            modelLoading: true, // 点击确定按钮时，确定按钮是否显示 loading 状态 modalShowFlag: false,
            maskClosable: false, // 点击遮罩层不允许关闭modal
            currentId: null,
            code: 10000
        };
    },
    methods: {
        // 处理modal确认异步
        changeLoading () {
            this.modelLoading = false;
            this.$nextTick(() => {
                this.modelLoading = true;
            });
        },
        /**
         * 编辑当前行表格数据
         * @param params
         */
        editTableData (row, modalTitle, callBack) {
            this.modalTitle = modalTitle;
            this.currentId = row.id;
            this.modalShowFlag = true;
            for (let key in this.formAttr) {
                this.formAttr[key] = row[key];
            }
            if (callBack) callBack(row);
        },
        // modal 关闭
        modalCancel (callBack) {
            this.currentId = null;
            this.$refs['formValidate'] &&
                this.$refs['formValidate'].resetFields();
            this.formAttr && resetObj(this.formAttr);
            if (this.modalShowFlag) this.modalShowFlag = false;
            if (typeof callBack === 'function') callBack();
        },
        /**
         * modal 确认
         * @param msg
         */
        todoOver (msg) {
            this.modalShowFlag = false; // 关闭弹窗
            this.$Message.success(msg); // 提示消息
            this.modalCancel(); // 执行取消操作重置信息
        },
        /**
         * 新增
         * @param modalTitle
         */
        addItem (modalTitle) {
            this.modalShowFlag = true;
            this.modalTitle = modalTitle;
        },

        // 判断column是否为新增
        // 使用metaId进行判断，metaId为源id 没有则说明为新增项
        // 判断item是否为修改
        findUpdate (source, row, key) {
            if (!source.length || !row.metaId) return false;
            let result = source.filter(item => {
                return row.metaId === item.id;
            });
            if (!result.length) return false;
            if (result[0][key] !== row[key]) return true;
        },

        // 判断checkbox新增和取消
        isAdd (source, checkedArr, id, key) {
            let old = source.filter(item => {
                return item[key] === id;
            });
            let cur = checkedArr.includes(id);
            return !old.length && cur;
        },
        isDel (source, checkedArr, id, key) {
            let old = source.filter(item => {
                return item[key] === id;
            });
            let cur = checkedArr.includes(id);
            return old.length && !cur;
        }
    }
};
