import {
    getInfoType,
    getContactList,
    getUserAddress,
    getCustomerLicense,
    setInvalid,
    reStart,
    back,
    getSelectMaterial,
    getSelectMachine
} from '@/api/masterData/customer';
import {
    auditDel,
    startAudit,
    changeAuditPass
} from '@/api/masterData/userchange';

import { getMachineList } from '@/api/dataSet/companyMachine.js';

import { resetObj } from '@/libs/tools';
export default {
    data () {
        return {
            selectedMaterial: [],
            selectedMachine: [],
            currentRow: {
                status: null
            },
            typeList: [
                { label: '临时', value: 0 },
                { label: '客管审核', value: 1 },
                { label: '质管专员', value: 2 },
                { label: '质管经理审核', value: 3 },
                { label: '质管终审', value: 4 },
                { label: '集团审核', value: 5 },
                { label: '审核通过', value: 6 },
                { label: '无效', value: 7 }
            ], // 客户申请单状态
            customerAreaArr: [], // 客户区域数组
            customerTypeArr: [], // 客户类型数组
            customerClassifyArr: [], // 客户分类数组
            saleMethodArr: [], // 销售方式数组
            saleModeArr: [], // 销售模式数组
            saleDepartmentArr: [], // 销售部门数组
            customerLevelArr: [], // 客户等级数组
            customerAddressList: [], // 客户收货地址列表
            customerContactList: [], // 客户联系人列表
            materialList: [], // 器械分类物料数据
            machineList: [], // 器械分类器械数据
            infoData: [], // 上传资料数据
            uploadTable: [], // 上传资料表格数据,
            taskInstanceId: null, // 实例ID
            tempData: [],
            formAttr: {
                customerName: '',
                customerCode: '',
                customerArea: '',
                customerType: '',
                customerClassify: '',
                contractPaymentMonth: '',
                saleMethod: '',
                saleMode: '',
                parentId: '',
                parentName: '',
                saleDepartment: '',
                customerLevel: '',
                licenseRegistrationCode: '',
                customerAddress: '',
                unifiedSocialCreditCode: '',
                dutyParagraph: '',
                bankName: '',
                bankCode: '',
                bankAccount: '',
                bankType: '',
                invoiceDescription: '',
                invoiceAddress: '',
                customerDescription: '',
                warehouseAddress: '',
                id: ''
            },
            tabIndex: 0,
            noNormal: false, // 引入客户和子客户的只读控制
            firstImport: false, // 引入客户时传true
            firstSub: false, // 新增子客户时传true
            isPass: false // 判断是否审核通过
        };
    },
    methods: {
        // 点击单行选中
        currentChange (row) {
            this.currentId = row.id;
            this.currentRow = row;
            // 判断是否引入客户
            this.firstImport = !!row.isImport;
            // 判断是否子客户
            this.firstSub = !!row.parentId;

            // 判断是否审核通过
            this.isPass = row.status === 6;
        },
        // 获取收货地址列表
        async getCustomerAddressList () {
            const params = {
                taskInstanceId: this.taskInstanceId
                    ? this.taskInstanceId : this.currentId
            };
            const res = await getUserAddress(params);
            this.customerAddressList = res.content;
        },
        // 获取联系人列表
        async getCustomerContactList () {
            const params = {
                taskInstanceId: this.taskInstanceId
                    ? this.taskInstanceId : this.currentId
            };
            const res = await getContactList(params);
            this.customerContactList = res.content;
        },
        // 获取器械分类选择框数据
        getMachineCheckbox () {
            this.getFieldValuesData('commodity_type', 'materialList'); // 获取物料大类
            this.getMachineType();
        },
        // 获取上传资料按钮数据
        async getInfoRadio () {
            const params = {
                taskInstanceId: this.taskInstanceId
                    ? this.taskInstanceId : this.currentId
            };
            const res = await getInfoType(params);
            if (res.status === this.code) {
                this.infoData = res.content;
            }
        },
        // 获取已上传资料表格数据
        async getUploadTabe (e) {
            const params = {
                taskInstanceId: this.taskInstanceId
                    ? this.taskInstanceId : this.currentId,
                dataType: e || null
            };
            const res = await getCustomerLicense(params);
            if (res.status === this.code) {
                this.uploadTable = res.content;
            }
        },
        async submitFn (call) {
            let valid = this.validCurrent();
            if (!valid) return false;
            this.$refs.managerTable.clearCurrentTableRow();
            call(res => {
                if (res.status === this.code) {
                    this.$Message.success('提交成功');
                    this.currentId = null;
                    this.getTableList();
                }
            });
        },
        // 置为无效
        async inValid () {
            let valid = this.validCurrent();
            if (!valid) return false;
            this.$refs.managerTable.clearCurrentTableRow();
            const params = {
                id: this.currentId
            };
            const res = await setInvalid(params);
            if (res.status === this.code) {
                this.$Message.success('已置为无效');
                this.tableComAttr.pageNo = 1;
                this.currentId = null;
                this.getTableList();
            }
        },
        // 重新启用
        async reStart () {
            let valid = this.validCurrent();
            if (!valid) return false;
            this.$refs.managerTable.clearCurrentTableRow();
            const params = {
                id: this.currentId
            };
            const res = await reStart(params);
            if (res.status === this.code) {
                this.$Message.success('已重新启用');
                this.tableComAttr.pageNo = 1;
                this.currentId = null;
                this.getTableList();
            }
        },
        // 退回
        async backUp (cur) {
            let valid = this.validCurrent();
            if (!valid) return false;

            // 判断此数据的状态是否为当前可退回
            const step = Number(cur) - Number(this.currentRow.status);
            if (step) {
                this.$Message.error(`无法退回当前数据`);
                return false;
            }
            // 清空当前选中行
            this.$refs.managerTable.clearCurrentTableRow();
            const params = {
                id: this.currentId
            };
            const res = await back(params);
            if (res.status === this.code) {
                this.$Message.success('已退回');
                this.tableComAttr.pageNo = 1;
                this.currentId = null;
                this.getTableList();
            }
        },
        // 审批记录删除
        async delAudit () {
            let valid = this.validCurrent();
            if (!valid) return false;
            const params = {
                id: this.currentId
            };
            const res = await auditDel(params);
            if (res.status === this.code) {
                this.$Message.success('删除成功');
                this.tableComAttr.pageNo = 1;
                this.currentId = null;
                this.getTableList();
            }
        },
        // 检验是否选择数据
        validCurrent () {
            let temp = false;
            if (!this.currentId) {
                this.$Message.error('请单击选择数据');
                temp = false;
            } else {
                temp = true;
            }
            return temp;
        },
        // 客户弹窗关闭
        customerModalCancel () {
            setTimeout(() => {
                this.$refs['baseInfoForm'].$refs['formValidate'].resetFields();
            }, 500);
            this.currentId = null;
            resetObj(this.formAttr, 1);
            this.tabIndex = 0;
        },
        // 获取该页面所有下拉框数据
        getAllSelectData () {
            this.getFieldValuesData('customer_area', 'customerAreaArr');
            this.getFieldValuesData('customer_type', 'customerTypeArr');
            this.getFieldValuesData('customer_classify', 'customerClassifyArr');
            this.getFieldValuesData('sale_method', 'saleMethodArr');
            this.getFieldValuesData('sale_mode', 'saleModeArr');
            this.getFieldValuesData('sale_department', 'saleDepartmentArr');
            this.getFieldValuesData('customer_level', 'customerLevelArr');
        },
        async getMachineType () {
            const params = { enterpriseId: this.currentDepartment.id };
            const res = await getMachineList(params);
            // console.log(res);
            if (res.status === this.code) {
                this.machineList = res.content;
            }
        },
        // 获取客户选中的物料类型
        async getSelectedMaterial () {
            const params = {
                taskInstanceId: this.taskInstanceId
                    ? this.taskInstanceId : this.currentId
            };
            const res = await getSelectMaterial(params);
            if (res.status === this.code) {
                let temp = [];
                res.content.forEach(item => {
                    temp.push(item.commodityType);
                });
                this.selectedMaterial = temp;
            }
        },
        // 获取客户选中的器械分类
        async getSelectedMachine () {
            const params = {
                taskInstanceId: this.taskInstanceId
                    ? this.taskInstanceId : this.currentId
            };
            const res = await getSelectMachine(params);
            if (res.status === this.code) {
                let temp = [];
                res.content.forEach(item => {
                    temp.push(item.deviceClassifyId);
                });
                this.selectedMachine = temp;
            }
        },
        // 状态变化搜索
        searchStatus (val) {
            if (val.join() !== this.tableQueryAttr.status) {
                this.tableQueryAttr.status = val.join();
                this.search();
            }
        },
        // 变更发起审批
        async sendAudit () {
            let valid = this.validCurrent();
            if (!valid) return false;
            // 判断是否保存
            if (!this.currentId) {
                return this.$Message.error('请先点击保存再发起审批');
            }
            const params = {
                id: this.currentId
            };
            const res = await startAudit(params);
            if (res.status === this.code) {
                this.$Message.success('发起审批成功');
                this.getTableList();
            }
        },
        // 变更申请审批通过
        async changePass () {
            let valid = this.validCurrent();
            if (!valid) return false;
            // 判断是否保存
            if (!this.currentId) {
                return this.$Message.error('请先点击保存再发起审批');
            }
            const params = {
                id: this.currentId
            };
            // const res = await changeAuditPass(params);
            const res = await startAudit(params);
            if (res.status === this.code) {
                this.$Message.success('审批通过');
                this.getTableList();
            }
        },

        // 钉钉审批通过流程
        async auditPass () {
            let valid = this.validCurrent();
            if (!valid) return false;
            // 判断是否保存
            if (!this.currentId) {
                return this.$Message.error('请先点击保存再发起审批');
            }
            const params = {
                id: this.currentId
            };
            const res = await changeAuditPass(params);
            if (res.status === this.code) {
                this.todoOver(res.msg);
            }
        }
    }
};
