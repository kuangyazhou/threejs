import {
    getSupplierDataTypeList,
    getSupplierContactList,
    getOldSupplierContactList,
    getSupplierLicenseList,
    getOldSupplierLicenseList,
    getSupplierProductionInfoList,
    getSupplierManagementInfoList,
    getOldSupplierProductionInfoList,
    getOldSupplierManagementInfoList,
    getOldSupplierData
} from '@/api/masterData/supplier';
import { getMachineList } from '@/api/dataSet/companyMachine';
import { resetObj } from '@/libs/tools';
export default {
    data () {
        return {
            selectedMachineManagement: [],
            oldSelectedMachineManagement: [],
            selectedMachineProduction: [],
            oldSelectedMachineProduction: [], // 更改前
            currentRow: {},
            typeList: [
                { label: '待发起', value: 0 },
                { label: '审批中', value: 1 },
                { label: '审批通过', value: 2 },
                { label: '打回', value: 3 }
            ], // 供应商申请单状态
            specialtyGroupAllArr: [], // 全部的专业分组
            supplierNatureArr: [], // 供应商性质数组
            supplierClassifyArr: [], // 供应商分类数组
            supplierCategoryArr: [], // 供应商类别数组
            supplierTypeArr: [], // 供应商种类数组
            supplierLevelArr: [], // 供应商等级数组
            supplierContactList: [], // 供应商联系人列表
            oldSupplierContactList: [], // 供应商变更前联系人列表
            machineList: [], // 器械分类器械数据
            infoData: [], // 上传资料数据
            tempData: [],
            uploadTable: [], // 上传资料表格数据
            oldUploadTable: [], // 变更前上传资料表格数据
            formAttr: {
                supplierName: '',
                supplierAbbreviation: '',
                supplierCode: '',
                supplierClassify: '',
                supplierNature: '',
                supplierLevel: '',
                unifiedSocialCreditCode: '',
                parentId: '',
                parentSupplierName: '',
                supplierAddress: '',
                warehouseAddress: '',
                supplierType: '',
                supplierCategory: '',
                specialtyGroup: '',
                payCondition: '',
                negotiator: '',
                bankName: '',
                bankAccount: '',
                bankCode: '',
                mainBrand: '',
                supplierDescription: '',
                isImport: '',
                supplierId: '',
                id: '',
                taskStatus: '',
                supplierStatus: ''
            },
            oldFormAttr: {}, // 供应商原始数据
            tabIndex: 0,
            supplierStatusArr: [], // 供应商状态数据
            mainBrand: '',
            formDisabled: false // 禁止组件编辑
        };
    },
    created () {
        this.getFieldValuesData('supplier_status', 'supplierStatusArr');
    },
    methods: {
        // 点击单行选中
        currentChange (row) {
            this.currentId = row.id;
            this.currentRow = row;
            if (
                this.currentRow.taskStatus === 1 ||
                this.currentRow.taskStatus === 2
            ) { this.formDisabled = true; }
        },
        // 获取联系人列表
        async getSupplierContactList () {
            const params = {
                taskInstanceId: this.currentId
            };
            const res = await getSupplierContactList(params);
            this.supplierContactList = res.content;
        },
        // 获取变更前联系人列表
        async getOldSupplierContactList () {
            const params = {
                taskInstanceId: this.currentId
            };
            const res = await getOldSupplierContactList(params);
            this.oldSupplierContactList = res.content;
        },
        // 获取上传资料按钮数据
        async getInfoRadio () {
            const params = {
                taskInstanceId: this.currentId
            };
            const res = await getSupplierDataTypeList(params);
            if (res.status === this.code) {
                this.infoData = res.content;
            }
        },
        // 获取已上传资料表格数据
        async getUploadTable (e) {
            const params = {
                taskInstanceId: this.currentId,
                dataType: e || null
            };
            const res = await getSupplierLicenseList(params);
            if (res.status === this.code) {
                this.uploadTable = res.content;
            }
        },
        // 获取变更前的资料表格数据
        async getOldUploadTable (e) {
            const params = {
                taskInstanceId: this.currentId,
                dataType: e || null
            };
            const res = await getOldSupplierLicenseList(params);
            if (res.status === this.code) {
                this.oldUploadTable = res.content;
            }
        },
        async submitFn (call) {
            this.$refs.managerTable.clearCurrentTableRow();
            let valid = this.validCurrent();
            if (!valid) return false;
            call(res => {
                if (res.status === this.code) {
                    this.$Message.success('提交成功');
                    this.currentId = null;
                    this.getTableList();
                }
            });
        },
        // 检验是否选择数据
        validCurrent () {
            let temp = false;
            if (!this.currentId) {
                this.$Message.error('请单击选择数据');
                temp = false;
            } else {
                temp = true;
            }
            return temp;
        },
        // 供应商弹窗关闭
        supplierModalCancel () {
            this.$refs['baseInfoForm'].resetBaseForm();
            this.currentId = null;
            resetObj(this.formAttr, 1);
            this.tabIndex = 0;
            this.formDisabled = false;
            if (this.modalShowFlag) this.modalShowFlag = false;
        },
        // 获取该页面所有下拉框数据
        getAllSelectData () {
            this.getFieldValuesData('supplier_level', 'supplierLevelArr');
            this.getFieldValuesData('supplier_nature', 'supplierNatureArr');
            this.getFieldValuesData('supplier_classify', 'supplierClassifyArr');
            this.getFieldValuesData('supplier_category', 'supplierCategoryArr');
            this.getFieldValuesData('specialty_group', 'specialtyGroupAllArr');
            this.getFieldValuesData('supplier_type', 'supplierTypeArr');
            this.getAllMachineProduction();
        },
        // 获取该公司全部器械分类
        async getAllMachineProduction () {
            const params = {
                enterpriseId: this.currentDepartment.id
            };
            const res = await getMachineList(params);
            if (res.status === this.code) {
                this.machineList = res.content;
            }
        },
        // 获取供应商选中的器械生产分类
        async getSelectedMachineProduction () {
            const params = {
                taskInstanceId: this.currentId
            };
            const res = await getSupplierProductionInfoList(params);
            if (res.status === this.code) {
                this.selectedMachineProduction = res.content.map(item => {
                    return item.deviceClassifyId;
                });
            }
        },
        // 获取供应商改变前选中的器械生产分类
        async getOldSelectedMachineProduction () {
            const params = {
                taskInstanceId: this.currentId
            };
            const res = await getOldSupplierProductionInfoList(params);
            if (res.status === this.code) {
                this.oldSelectedMachineProduction = res.content.map(item => {
                    return item.deviceClassifyId;
                });
            }
        },
        // 获取供应商选中的器械运营分类
        async getSelectedMachineManagement () {
            const params = {
                taskInstanceId: this.currentId
            };
            const res = await getSupplierManagementInfoList(params);
            if (res.status === this.code) {
                this.selectedMachineManagement = res.content.map(item => {
                    return item.deviceClassifyId;
                });
            }
        },
        // 获取供应商更改前选中的器械运营分类
        async getOldSelectedMachineManagement () {
            const params = {
                taskInstanceId: this.currentId
            };
            const res = await getOldSupplierManagementInfoList(params);
            if (res.status === this.code) {
                this.oldSelectedMachineManagement = res.content.map(item => {
                    return item.deviceClassifyId;
                });
            }
        },
        // 状态变化搜索
        searchStatus (val) {
            if (val.join() !== this.tableQueryAttr.status) {
                this.tableQueryAttr.status = val.join();
                this.search();
            }
        },
        // 获取变更前的供应商基础信息数据
        async getOldSupplierData () {
            if (!this.currentId) return;
            const params = {
                id: this.currentId
            };
            const res = await getOldSupplierData(params);
            if (res.status === this.code) {
                this.oldFormAttr = res.content;
            }
        }
    }
};
