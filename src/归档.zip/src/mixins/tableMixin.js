/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-09 16:25:22
 * @LastEditTime: 2019-08-15 11:05:07
 * @LastEditors: Please set LastEditors
 */
import { hasOneOf, resetObj } from '@/libs/tools';
import { getFieldValues } from '@/api/common';
import { mapActions, mapGetters } from 'vuex';

export default {
    data () {
        return {
            tableWidth: 0, // 表格宽度
            tableComAttr: {
                pageNo: 1,
                pageSize: 10
            }, // 表格公用参数
            erpTableData: [], // 表格数据展示
            tableLoading: false, // 加载表格loading
            total: 0, // 表格总条数
            code: 10000, // 请求正常状态码
            statusList: [{
                             name: '有效',
                             value: 1,
                             label: '有效'
                         },
                         {
                             name: '无效',
                             value: 0,
                             label: '无效'
                         }
            ], // 状态数组
            modalShowFlag: false, // modal显示开关
            modalTitle: '', // modal标题
            modelLoading: true, // 点击确定按钮时，确定按钮是否显示 loading 状态
            currentId: null, // 当前编辑数据的id，没有则代表是新增
            tableSelectValue: [], // 表格选择value
            tableSelectList: [], // 表格选择完整
            maskClosable: false, // 点击遮罩层不允许关闭modal
            btnRightList: {
                resourceCreate: 'resource/create',
                resourceUpdate: 'resource/update',
                resourceDel: 'resource/delete',
                organizationCreate: 'organization/create',
                organizationUpdate: 'organization/update',
                platfromUserCreate: 'platform/user/create',
                platfromUserUpdate: 'platform/user/update',
                platfromUpdateOrg: 'platform/user/updateUserOrganization',
                roleAdd: 'role/create',
                roleEdit: 'role/update',
                roleDel: 'role/delete',
                roleGrant: 'role/grant',
                departmentAdd: 'department/add',
                departmentEdit: 'department/update',
                departmentDel: 'department/deleteOne',
                sUserAdd: 'organization/user/create',
                sUserEdit: 'organization/user/update',
                sUserResetPassword: 'organization/user/password/reset',
                customerCardEdit: 'license/type/update', // 客户证照设置
                customerInfoSave: 'task/instance/customer/save', // 引入新增修改客户资料
                customerFirstSubmit: 'task/instance/customer/temp/submit', // 提交客管审核
                customerFirstRestart: 'task/instance/customer/enable/submit', // 重新启用
                customerGoodsTypeSave: 'customer/commodity/type/save', // 保存客户物料类型
                customerClassifySave: 'customer/device/classify/save', // 保存客户器械分类
                customerLicenseAdd: 'customer/license/save', // 新增客户证照
                customerLicenseEdit: 'customer/license/update', // 修改客户证照
                customerLicenseDel: 'customer/license/delete', // 删除客户证照
                customerAddressAdd: 'customer/address/save', // 新增客户地址
                customerAddressEdit: 'customer/address/update', // 修改客户地址
                customerAddressDel: 'customer/address/delete', // 删除客户地址
                customerContactAdd: 'customer/contact/save', // 新增客户联系人
                customerContactEdit: 'customer/contact/update', // 修改客户联系人
                customerContactDel: 'customer/contact/delete', // 删除客户联系人
                customerSecondSubmit: 'task/instance/customer/qualification/submit', // 客管提交下一步
                customerInValid: 'task/instance/customer/disable/submit', // 无效
                customerBackUp: 'task/instance/customer/return/submit', // 客户退回
                customerThirdSubmit: 'task/instance/customer/manager/submit', // 质管专员提交下一步
                documentUpload: 'document/upload', // 文件上传
                documentDelete: 'document/delete', // 文件删除
                customerFourthSubmit: 'task/instance/customer/final/submit', // 质管经理提交下一步
                customerFifthSubmit: 'task/instance/customer/organization/submit', // 质管负责人提交下一步
                customerSixthSubmit: 'task/instance/customer/approve/submit', // 集团提交下一步
                companyMachineImport: 'enterprise/device/classify/import', // 器械分类-公司 引入操作
                companyMachineDel: 'enterprise/device/classify/delete', // 器械分类-公司 删除
                groupMachineAdd: 'device/classify/save', // 器械分类-集团 新增
                groupMachineUpdate: 'device/classify/update', // 器械分类-集团 编辑,
                saleChangeAdd: 'customer/enterprise/list', // 客户变更-销售-新增
                saleChangeAudit: 'task/instance/change/customer/submit', // 客户变更-销售-发起审批
                saleChangeDel: 'task/instance/change/customer/delete', // 客户变更-销售-删除
                saleChangeUpdate: 'task/instance/change/customer/save', // 客户变更-销售-修改
                qualityChangeBack: 'task/instance/change/customer/return', // 客户变更-质管-回退
                qualityChangePass: 'task/instance/change/customer/approve', // 客户变更-质管-通过
                qualityChangeDel: 'task/instance/change/customer/delete', // 客户变更-质管-删除
                qualityChangeUpdate: 'task/instance/change/customer/delete', // 客户变更-质管-编辑
                supplierInfoAdd: 'supplier/task/save', // 引入新增供应商
                supplierInfoEdit: 'supplier/task/update', // 编辑供应商基本信息
                supplierAddSubmit: 'supplier/task/submit/approve', // 发起新增供应商
                supplierApplyDel: 'supplier/task/delete', // 删除新增供应商申请
                supplierLicenseAdd: 'supplier/license/save', // 新增供应商证照
                supplierLicenseEdit: 'supplier/license/update', // 编辑供应商证照
                supplierLicenseDel: 'supplier/license/delete', // 删除供应商证照
                supplierOldLicenseDel: 'supplier/change/delete/license', // 假删除供应商旧证照
                supplierOldLicenseRevert: 'supplier/change/revert/license', // 恢复删除的供应商旧证照
                supplierProductionSave: 'supplier/production/device/classify/save', // 保存器械生产信息
                supplierManageSave: 'supplier/manage/device/classify/save', // 保存器械经营信息
                supplierContactAdd: 'supplier/contact/save', // 新增供应商联系人
                supplierContactEdit: 'supplier/contact/update', // 编辑供应商联系人
                supplierContactDel: 'supplier/contact/delete', // 删除供应商联系人
                supplierOldContactDel: 'supplier/change/contact/delete', // 假删除供应商旧联系人
                supplierOldContactRevert: 'supplier/change/contact/revert', // 恢复删除的供应商旧联系人
                supplierPurChangeAdd: 'supplier/purchase/change/task/save', // 采购新增变更单
                supplierPurChangeEdit: 'supplier/purchase/change/task/update', // 采购修改变更单基本信息
                supplierPurChangeSubmit: 'supplier/purchase/change/submit', // 发起变更供应商审批
                supplierPurChangeDel: 'supplier/purchase/change/task/delete', // 删除供应商变更
                supplierQcChangeAdd: 'supplier/qc/change/task/save', // 质管新增变更单
                supplierQcChangeEdit: 'supplier/qc/change/task/update', // 质管修改变更单基本信息
                supplierQcChangeSubmit: 'supplier/qc/change/submit', // 质管发起变更供应商审批
                supplierQcChangeDel: 'supplier/qc/change/task/delete', // 删除供应商变更,
                materialClassifyAdd: 'commodity/classify/save', // 物料分类新增
                materialClassifyUpdate: 'commodity/classify/update', // 物料分类修改
                checkNameAdd: 'accounting/name/save', // 核算名称新增
                checkNameUpdate: 'accounting/name/update', // 核算名称修改
                checkNameDel: 'accounting/name/delete', // 核算名称删除
                checkNameAudit: 'accounting/name/approve', // 核算名称审核
                checkNameCancel: 'accounting/name/unapprove', // 核算名称取消审核
                materialAdd: 'commodity/task/save', // 物料新增&&保存
                materialDel: 'commodity/task/save/delete', // 物料删除
                materialNext: 'commodity/task/save/submit', // 物料审核下一步
                packageAdd: 'commodity/package/save', // 包装单位新增
                packageUpdate: 'commodity/package/update', // 包装单位修改
                packageDel: 'commodity/package/delete', // 包装单位删除
                packageDefault: 'commodity/package/default/set', // 包装单位默认
                packageStandard: 'commodity/package/standard/set', // 包装单位标准
                materialAddAudit: 'commodity/task/save/qualification/sumbit', // 物料新增-质管审批
                materialBackUp: 'commodity/task/save/return/sumbit', // 物料新增-质管 打回
                materialPass: 'commodity/task/save/approve/sumbit', // 物料新增-质管 通过
                materialQualitySave: 'commodity/task/save/qualification', // 物料质管保存
                materialAddInfo: 'commodity/license/save', // 资料新增
                materialChangeAdd: 'commodity/task/change/save', // 新增变更单
                materialChangeDel: 'commodity/task/change/delete', // 变更单删除
                materialChangeAudit: 'commodity/task/change/submit', // 变更单发起审核
                materialChangePass: 'commodity/task/change/approve/submit', // 变更单审核通过
                materialChangeBackUp: 'commodity/task/change/return/submit', // 变更单审核打回
                firstMaterialApplyAdd: 'init/commodity/save', // 新增首营物料申请
                firstMaterialApplyInquiryBat: 'init/commodity/start/inquiryBat', // 首营物料批量询价
                firstMaterialApplyUpdate: 'init/commodity/update', // 首营物料编辑
                firstMaterialApplyDelete: 'init/commodity/delete', // 首营物料删除
                firstMaterialApplyStartInquiry: 'init/commodity/start/inquiry', // 首营物料发起询价
                firstMaterialApplyResultGet: 'inquiry/result/get', // 首营物料查看询价
                firstMaterialApplyTaskSubmit: 'init/commodity/task/submit', // 申请首营物料
                warehouseSave: 'warehouse/save', // 新增仓库
                warehouseUpdate: 'warehouse/update', // 编辑仓库
                saleOrgaAdd: 'sale/organization/save', // 销售组织新增
                saleOrgaEdit: 'sale/organization/update', // 销售组织修改
                purchaseOrgaAdd: 'purchase/organization/save', // 采购组织新增
                purchaseOrgaEdit: 'purchase/organization/update', // 采购组织修改
                saleGroupAdd: 'sale/group/save', // 销售组新增
                saleGroupEdit: 'sale/group/update', // 销售组修改
                saleGroupDel: 'sale/group/delete', // 销售组删除
                salesmanAdd: 'sale/group/saler/save', // 销售员新增
                salesmanDel: 'sale/group/saler/delete', // 销售员删除
                multipleAdd: 'customer/commodity/saveBat', // 客户物料信息批量添加
                singleAdd: 'customer/commodity/save', // 客户物料信息单个添加,
                materialInfoSave: 'customer/commodity/update', // 客户物料信息保存
                materialInfoSubmit: 'customer/commodity/submit', // 客户物料信息提交审核
                materialInfoReturn: 'customer/commodity/unapprove', // 客户物料信息打回
                materialInfoPass: 'customer/commodity/approve', // 客户物料信息审核通过
                materialInfoSubmitMul: 'customer/commodity/submitBat', // 客户物料信息批量提交
                materialInfoReturnMul: 'customer/commodity/unapproveBat', // 客户物料信息批量撤回
                materialInfoPassMul: 'customer/commodity/approveBat', // 客户物料信息批量审核通过
                addSupplier: 'customer/commodity/addSuppliers', // 添加供应商,
                materilMoneyAdd: 'sale/price/save', // 客户物料价格新增
                materilMoneyUpdate: 'sale/price/update', // 客户物料价格编辑
                materilMoneySubmit: 'sale/price/submit', // 客户物料价格提交
                materilMoneyAudit: 'sale/price/approve', // 客户物料价格审批
                materilMoneyReturn: 'sale/price/unapprove', // 客户物料价格打回
                materilMoneySubmitMul: 'sale/price/submitBat', // 客户物料价格批量提交
                materilMoneyAuditMul: 'sale/price/approveBat', // 客户物料价格批量审批
                materilMoneyReturnMul: 'sale/price/unapproveBat', // 客户物料价格批量打回
                salersAdd: 'sale/saler/saveBat', // 新增销售员
                salersUnitCustomer: 'saler/customer/addCustomers', // 销售员关联客户
                salersSetEnable: 'sale/saler/enable', // 销售员设置有效
                salersSetDisable: 'sale/saler/disable', // 销售员设置无效
                purchaseGroupAdd: 'purchase/group/save', // 采购组新增
                purchaseGroupEdit: 'purchase/group/update', // 采购组修改
                purchaseGroupDel: 'purchase/group/delete', // 采购组删除
                purchaseGroupBuyerAdd: 'purchase/group/addMember', // 采购组采购员新增
                purchaseGroupBuyerDel: 'purchase/group/deleteMember', // 采购组采购员删除
                buyerAdd: 'purchase/purchaser/save', // 新增采购员
                buyerUnitGroup: 'purchaser/professional/addProfessionalGroups', // 采购员关联专业分组
                buyerUnitSupplier: 'purchaser/supplier/addSuppliers', // 采购员关联供应商
                buyerSetEnable: 'purchase/purchaser/enable', // 采购员设置有效
                buyerSetDisable: 'purchase/purchaser/disable', // 采购员设置无效
                channelPriceAdd: 'purchase/price/save', // 新增渠道价格
                channelPriceEdit: 'purchase/price/update', // 新增渠道价格
                channelPriceSubmit: 'purchase/price/submit', // 提交渠道价格
                channelPriceApprove: 'purchase/price/approve', // 审核渠道价格
                channelPriceUnapprove: 'purchase/price/unapprove', // 反审核渠道价格
                inquiryTaskReceive: 'inquiry/receive', // 分配询价任务
                inquiryTaskReturn: 'inquiry/return', // 退回询价任务
                inquiryTaskChange: 'inquiry/change', // 转交询价任务
                inquiryTaskReject: 'inquiry/reject', // 驳回询价任务
                inquiryTaskRelationCommodity: 'inquiry/relation/commodity', // 询价任务关联物料
                inquiryTaskRelationInquiry: 'inquiry/relation/inquiry', // 询价任务关联询价
                inquiryOrderAdd: 'inquiry/order/save', // 新增询价单
                inquiryOrderEdit: 'inquiry/order/update', // 编辑询价单
                inquiryOrderDel: 'inquiry/order/delete', // 删除询价单
                inquiryOrderSubmit: 'inquiry/order/submit', // 提交询价单
                inquiryOrderCancel: 'inquiry/order/cancel', // 退回询价单
                inquiryTaskEdit: 'inquiry/commodity/update', // 编辑询价任务
                inquiryTaskComplete: 'inquiry/complete', // 完成询价任务
                inquiryRecordAdd: 'purchase/negotiation/record/save', // 新增谈判记录
                inquiryRecordDel: 'purchase/negotiation/record/delete', // 删除询价单
                firstRelationCustomer: 'init/commodity/handle/relation/customer', // 首营准备关联客户
                firstRelationMaterial: 'init/commodity/handle/relation/commodity', // 首营准备关联物料
                firstRelationSupplier: 'init/commodity/handle/relation/supplier', // 首营准备关联供应商
                firstCampHandle: 'init/commodity/handle/complete', // 首营处理
                inventoryOrgaAdd: 'inventory/organization/save', // 库存组织新增
                inventoryOrgaEdit: 'inventory/organization/update', // 库存组织修改
                systemFieldAdd: 'system/field/value/save', // 系统字段值新增
                systemFieldEdit: 'system/field/value/update', // 系统字段值编辑
                systemFieldDel: 'system/field/value/delete', // 系统字段值删除
                inventoryInitImport: 'inventory/init/record/import', // 库存初始化批量导入
                inventoryInitDownload: 'inventory/init/record/public/template/download', // 库存初始化下载模板
                inventoryInitSave: 'inventory/init/record/save', // 库存初始化保存
                inventoryInitSubmit: 'inventory/init/record/submit', // 库存初始化提交
                inventoryInitComplete: 'inventory/init/record/complete', // 库存初始化完成
                salePlanSetSave: 'sale/plan/setting/save', // 销售计划参数设置
                salePlanSetUpdate: 'sale/plan/setting/update', // 销售计划参数更新
                salePlanSetDel: 'sale/plan/setting/delete', // 销售计划参数删除
                salePlanValid: 'sale/plan/setting/valid', // 销售计划参数生效
                salePlanInValid: 'sale/plan/setting/invalid', // 销售计划参数失效
                salePlanUpdate: 'sale/plan/update', // 销售计划编制保存
                salePlanSubmit: 'sale/plan/submit', // 销售计划提交
                salePlanReturn: 'sale/plan/revocation', // 销售计划撤回
                goodsDel: 'shipment/notice/delete', // 发货通知单删除
                goodsUpdate: 'shipment/notice/update', // 发货通知单更新
                goodsSubAndReturn: 'shipment/notice/submit', // 发货通知单提交&&撤销
                goodsAudit: 'shipment/notice/audit', // 发货通知单审批
                goodsSave: 'shipment/notice/save', // 发货通知单保存
                employeeAdd: 'employee/save', // 单个新增仓储人员
                employeeEdit: 'employee/update', // 编辑仓储人员
                employeeBatchAdd: 'employee/batch/save', // 批量新增仓储人员
                invoiceAdd: 'sale/invoice/add', // 保存销售开票
                invoiceSubmit: 'sale/invoice/submit', // 提交销售开票
                invoiceRevocation: 'sale/invoice/revocation', // 撤回销售开票
                invoiceAudit: 'sale/invoice/audit', // 审核销售开票
                invoiceUpdate: 'sale/invoice/update', // 编辑销售开票
                makeGoldenFile: 'demo', // 生成金税文件
                purchaseOrderSave: 'purchase/order/save', // 采购订单保存
                purchaseOrderSubmit: 'purchase/order/submit', // 采购订单提交
                purchaseOrderReturn: 'purchase/order/return', // 采购订单撤回
                purchaseOrderPass: 'purchase/order/approve', // 采购订单通过
                purchaseRedSave: 'purchase/order/red/save', // 采购订单红字保存
                purchaseOrderDel: 'purchase/order/delete', // 采购订单删除
                purchaseRefundAdd: 'purchase/refund/order/save', // 新增采购退货
                purchaseRefundEdit: 'purchase/refund/order/update', // 编辑采购退货
                purchaseRefundSubmit: 'purchase/refund/order/submit', // 提交采购退货
                purchaseRefundCancel: 'purchase/refund/order/cancel', // 撤回采购退货
                purchaseRefundApprove: 'purchase/refund/order/approve', // 审核采购退货
                matchAuto: 'shipment/notice/item/try/match/auto', // 发货通知试算一键匹配
                matchRemove: 'shipment/notice/item/try/match/remove', // 发货通知试算重置试算
                matchGenerate: 'shipment/notice/item/try/match/generate', // 生成发货通知
                noticeTrySave: 'shipment/notice/item/try/save', // 发货通知试算选择
                noticeTryRemove: 'shipment/notice/item/try/remove', // 发货通知试算移除
                acceptRequirement: 'purchase/requirement/accept', // 接受效期反馈
                feedbackRequirement: 'purchase/requirement/feedback', // 反馈效期反馈
                feedbackConfirm: 'purchase/requirement/confirm', // 确认效期反馈
                salesRefundAdd: 'sale/return/order/add', // 新增销售退货
                salesRefundEdit: 'sale/return/order/update', // 编辑销售退货
                salesRefundSubmit: 'sale/return/order/submit', // 提交销售退货
                salesRefundCancel: 'sale/return/order/revocation', // 撤回销售退货
                salesRefundApprove: 'sale/return/order/audit', // 审核销售退货
                salesRefundDel: 'sale/return/order/delete', // 删除销售退货明细
                purchaseReqMatch: 'purchase/requirement/match/inventory', // 采购需求处理-匹配
                purchaseReqOrder: 'purchase/requirement/generate/purchase/order', // 采购需求处理-生成订单
                saleOrderSave: 'sale/order/save', // 销售订单保存
                saleOrderSubmit: 'sale/order/submit', // 销售订单提交
                saleOrderSubmitMul: 'sale/order/submitBat', // 销售订单批量提交
                saleOrderReturn: 'sale/order/return', // 销售订单撤回
                saleOrderReturnMul: 'sale/order/returnBat', // 销售批量撤回
                saleOrderPass: 'sale/order/approve', // 销售订单通过
                saleOrderPassMul: 'sale/order/approveBat', // 销售订单批量通过
                saleOrderRedSave: 'sale/order/red/save', // 销售订单红单保存
                saleOrderDel: 'sale/order/delete', // 销售订单删除
                saleOrderDelMul: 'sale/order/deleteBat', // 销售订单批量删除
                saleOrderLicAdd: 'sale/order/attach/save', // 销售订单新增凭证
                saleOrderLicUpdate: 'sale/order/attach/update', // 销售订单凭证更新
                saleOrderLicDel: 'sale/order/attach/delete', // 销售订单凭证删除
                changePassword: 'user/pwd/modify' // 修改登录密码
            } // 所有按钮的权限地址(新增的按钮地址请加到最后)
        };
    },
    created () {
        this.getTableList();
    },
    computed: {
        ...mapGetters([
            'getAccess',
            'getUserName',
            'currentOrganization',
            'currentDepartment'
        ])
    },
    methods: {
        ...mapActions(['refreshToken']),
        /**
         * 改变页码
         * @param value
         */
        pageNoChange (value) {
            this.tableComAttr.pageNo = value;
            this.getTableList();
        },
        /**
         * 改变每页条数
         */
        pageSizeChange (value) {
            this.tableComAttr.pageNo = 1;
            this.tableComAttr.pageSize = value;
            this.getTableList();
        },
        // 处理modal确认异步
        changeLoading (load) {
            if (load) {
                this[load] = false;
                this.$nextTick(() => {
                    this[load] = true;
                });
            } else {
                this.modelLoading = false;
                this.$nextTick(() => {
                    this.modelLoading = true;
                });
            }
        },
        /**
         * 多选改变
         * @param value
         */
        selectionChange (value) {
            this.tableSelectValue = value.map(item => {
                return item.id;
            });
            this.tableSelectList = value;
        },
        /**
         * 编辑当前行表格数据
         * @param params
         */
        editTableData (params, modalTitle, callBack) {
            this.modalTitle = modalTitle;
            this.currentId = params.row.id;
            for (let key in this.formAttr) {
                this.formAttr[key] = params.row[key];
            }
            setTimeout(() => {
                this.modalShowFlag = true;
            }, 200);
            if (callBack) callBack(params.row);
        },
        // modal 关闭
        modalCancel (callBack) {
            if (this.modalShowFlag) this.modalShowFlag = false;
            setTimeout(() => {
                this.currentId = null;
                this.taskInstanceId = null;
                this.$refs['formValidate'] && this.$refs['formValidate'].resetFields();
                this.formAttr && resetObj(this.formAttr);
                if (typeof callBack === 'function') callBack();
            }, 300);
        },
        /**
         * modal 确认
         * @param msg
         */
        todoOver (msg) {
            this.modalShowFlag = false; // 关闭弹窗
            this.$Message.success(msg); // 提示消息
            this.modalCancel(); // 执行取消操作重置信息
            this.tableComAttr.pageNo = 1;
            this.getTableList();
        },
        /**
         * 新增
         * @param modalTitle
         */
        addItem (modalTitle) {
            this.modalShowFlag = true;
            this.modalTitle = modalTitle;
        },
        // 删除前的检查
        delCheck (msg) {
            if (!this.tableSelectValue.length) {
                this.$Message.error({
                    content: msg || '删除至少勾选一项',
                    duration: 3
                });
                return false;
            } else {
                return true;
            }
        },
        /**
         * 重置
         * @param todoFlag  获取table前需要执行的开关
         */
        reset (todoFlag) {
            this.tableComAttr.pageNo = 1;
            resetObj(this.tableQueryAttr, 1);
            this.getTableList(todoFlag);
            this.$refs.filter && this.$refs.filter.setQuery(null);
        },
        /**
         * 搜索
         * @param todoFlag  获取table前需要执行的开关
         */
        search (todoFlag) {
            this.tableComAttr.pageNo = 1;
            this.getTableList(todoFlag);
        },
        // 单选下拉框搜索
        selectSearch (val) {
            if (val || val === 0) this.search();
        },
        /**
         * 获取table列表
         * @param getList 具体逻辑单独写
         * @param cb 导出excel
         */
        getTableListFn (getList, cb) {
            this.tableLoading = true;
            getList(res => {
                this.tableLoading = false;
                if (res.status === this.code) {
                    this.erpTableData = res.content.list || res.content;
                    if (cb) {
                        cb(res);
                    }
                    this.total = res.content.total;
                }
            });
        },
        // 判断权限按钮
        judgeBtnRight (key) {
            return hasOneOf(this.getAccess, this.btnRightList[key]);
        },
        // 获取系统字段的值
        async getFieldValuesData (fieldCode, arr, callBack) {
            if (this[arr].length) return;
            const params = {
                fieldCode
            };
            const res = await getFieldValues(params);
            if (res.status === this.code) {
                this[arr] = res.content;
                if (callBack) callBack(res.content);
            }
        }
    }
};
