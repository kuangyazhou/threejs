import {
    editInitPassword,
    getUserInfo,
    login,
    logout,
    switchOrganization,
    refreshToken
} from '@/api/user';
import {
    getToken,
    setToken,
    setSSOToken,
    sessionStorageSave,
    sessionStorageRead
} from '@/libs/util';

export default {
    state: {
        userName: '',
        realName: '',
        userId: '',
        avatarImgPath: '',
        token: getToken(),
        access: '',
        hasGetInfo: false,
        unreadCount: 0,
        messageUnreadList: [],
        messageReadedList: [],
        messageTrashList: [],
        messageContentStore: {},
        organizationsList: [],
        currentOrganization: '',
        currentDepartment: '',
        salerId: '',
        purchaserId: '',
        inventoryOrganizationId: '',
        purchaseOrganizationId: '', // 采购组织id
        saleOrganizationId: '' // 销售组织id
    },
    getters: {
        getUserName: state => state.userName,
        realName: state => state.realName,
        organizationsList: state => state.organizationsList,
        currentOrganization: state => state.currentOrganization,
        getAccess: state => state.access,
        currentDepartment: state => state.currentDepartment,
        salerId: state => state.salerId,
        purchaserId: state => state.purchaserId,
        inventoryOrganizationId: state => state.inventoryOrganizationId,
        userId: state => state.userId,
        purchaseOrganizationId: state => state.purchaseOrganizationId,
        saleOrganizationId: state => state.saleOrganizationId
    },
    mutations: {
        setAvatar (state, avatarPath) {
            state.avatarImgPath = avatarPath;
        },
        setUserId (state, id) {
            state.userId = id;
        },
        setUserName (state, name) {
            state.userName = name;
        },
        setRealName (state, name) {
            state.realName = name;
        },
        setAccess (state, access) {
            state.access = access;
        },
        setToken (state, token) {
            state.token = token;
            setToken(token);
        },
        setHasGetInfo (state, status) {
            state.hasGetInfo = status;
        },
        setOrganizationsList (state, organizationsList) {
            state.organizationsList = organizationsList;
        },
        setCurrentOrganization (state, currentOrganization) {
            state.currentOrganization = currentOrganization;
        },
        setCurrentDepartment (state, currentDepartment) {
            state.currentDepartment = currentDepartment;
        },
        setSaleId (state, id) {
            state.salerId = id;
        },
        setPurchaserId (state, id) {
            state.purchaserId = id;
        },
        setInventoryOrganizationId (state, id) {
            state.inventoryOrganizationId = id;
        },
        setPurchaseOrg (state, id) {
            state.purchaseOrganizationId = id;
        },
        setSaleOrganizationId (state, id) {
            state.saleOrganizationId = id;
        }
    },
    actions: {
        // 登录
        handleLogin ({ commit }, { userName, password }) {
            userName = userName.trim();
            return new Promise((resolve, reject) => {
                login({
                    userName,
                    password
                })
                    .then(res => {
                        if (res.status === 10000) {
                            commit('setToken', res.content.accessToken);
                            setSSOToken(res.content.ssoToken);
                        }
                        resolve(res);
                    })
                    .catch(err => {
                        reject(err);
                });
            });
        },
        // 如果账号为修改初始密码，请修改
        editInitPasssWord ({ userPwd, reUserPwd }) {
            return new Promise((resolve, reject) => {
                try {
                    editInitPassword({
                        userPwd,
                        reUserPwd
                    })
                        .then(res => {
                            resolve(res);
                        })
                        .catch(err => {
                            reject(err);
                    });
                } catch (error) {
                    reject(error);
                }
            });
        },
        // 退出登录
        handleLogOut ({ state, commit }) {
            return new Promise((resolve, reject) => {
                logout(state.token)
                    .then(res => {
                        commit('setToken', '');
                        commit('setAccess', []);
                        commit('setRouters', []);
                        commit('setHasGetInfo', false);
                        commit('setHasGetRouter', false);
                        commit('setOrganizationsList', '');
                        commit('setCurrentOrganization', '');
                        commit('setCurrentDepartment', '');
                        commit('setSaleId', '');
                        commit('setPurchaserId', '');
                        commit('setPurchaseOrg', '');
                        commit('setSaleOrganizationId', '');
                        window.sessionStorage.clear();
                        window.localStorage.clear();
                        resolve(res);
                    })
                    .catch(err => {
                        reject(err);
                });
            });
        },
        // 获取用户相关信息
        getUserInfo ({ state, commit }) {
            return new Promise((resolve, reject) => {
                try {
                    getUserInfo(state.token)
                        .then(res => {
                            if (res.status === 10000) {
                                const data = res.content;
                                setSSOToken(res.content.ssoToken);
                                commit('setUserName', data.userName);
                                commit('setRealName', data.realName);
                                commit('setUserId', data.id);
                                commit('setAccess', data.resources);
                                commit(
                                    'setSaleId',
                                    data.saleId ? data.saleId : ''
                                );
                                commit(
                                    'setPurchaserId',
                                    data.purchaserId ? data.purchaserId : ''
                                );
                                commit(
                                    'setInventoryOrganizationId',
                                    data.inventoryOrganizationId ? data.inventoryOrganizationId : ''
                                );
                                commit('setHasGetInfo', true);
                                commit(
                                    'setOrganizationsList',
                                    data.organizations
                                );
                                commit('setPurchaseOrg', data.purchaseOrganizationId ? data.purchaseOrganizationId : '');
                                commit(
                                    'setSaleOrganizationId',
                                    data.saleOrganizationId ? data.saleOrganizationId : ''
                                );
                                if (data.currentEnterprise.id) {
                                    commit(
                                        'setCurrentDepartment',
                                        data.currentEnterprise
                                    );
                                }
                                if (!state.currentOrganization) {
                                    let currentOrganization = sessionStorageRead(
                                        'currentOrganization'
                                    );
                                    if (currentOrganization) {
                                        commit(
                                            'setCurrentOrganization',
                                            JSON.parse(currentOrganization)
                                        );
                                    } else {
                                        commit(
                                            'setCurrentOrganization',
                                            data.currentOrganization
                                        );
                                    }
                                }
                            }
                            resolve(res);
                        })
                        .catch(err => {
                            reject(err);
                    });
                } catch (error) {
                    reject(error);
                }
            });
        },
        // 更换当前组织
        changeCurrentOrganization ({ commit }, item) {
            return new Promise((resolve, reject) => {
                try {
                    const params = {
                        organizationId: item.id
                    };
                    switchOrganization(params)
                        .then(res => {
                            commit('setCurrentOrganization', item);
                            sessionStorageSave(
                                'currentOrganization',
                                JSON.stringify(item)
                            );
                            commit('setHasGetInfo', false);
                            commit('setHasGetRouter', false);
                            resolve(res);
                        })
                        .catch(err => {
                            reject(err);
                    });
                } catch (error) {
                    reject(error);
                }
            });
        },
        // 刷新当前用户token信息
        refreshToken ({ state, commit }) {
            return new Promise((resolve, reject) => {
                try {
                    refreshToken()
                        .then(res => {
                            if (res.status === 10000) {
                                const data = res.content;
                                setSSOToken(res.content.ssoToken);
                                commit('setToken', data.accessToken);
                                commit('setUserName', data.userName);
                                commit('setRealName', data.realName);
                                commit('setUserId', data.id);
                                commit('setAccess', data.resources);
                                commit(
                                    'setSaleId',
                                    data.saleId ? data.saleId : ''
                                );
                                commit(
                                    'setPurchaserId',
                                    data.purchaserId ? data.purchaserId : ''
                                );
                                commit(
                                    'setInventoryOrganizationId',
                                    data.inventoryOrganizationId ? data.inventoryOrganizationId : ''
                                );
                                commit('setHasGetInfo', true);
                                commit(
                                    'setOrganizationsList',
                                    data.organizations
                                );
                                commit('setPurchaseOrg', data.purchaseOrganizationId);
                                commit(
                                    'setSaleOrganizationId',
                                    data.saleOrganizationId ? data.saleOrganizationId : ''
                                );
                                if (data.currentEnterprise.id) {
                                    commit(
                                        'setCurrentDepartment',
                                        data.currentEnterprise
                                    );
                                }
                                if (!state.currentOrganization) {
                                    let currentOrganization = sessionStorageRead(
                                        'currentOrganization'
                                    );
                                    if (currentOrganization) {
                                        commit(
                                            'setCurrentOrganization',
                                            JSON.parse(currentOrganization)
                                        );
                                    } else {
                                        commit(
                                            'setCurrentOrganization',
                                            data.currentOrganization
                                        );
                                    }
                                }
                            }
                            resolve(res);
                        })
                        .catch(err => {
                            reject(err);
                    });
                } catch (error) {
                    reject(error);
                }
            });
        }
    }
};
