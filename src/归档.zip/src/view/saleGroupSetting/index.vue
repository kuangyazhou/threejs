<template>
    <div class="erp-content" ref="erp">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.saleGroupName"
                        @on-search="search"
                        search
                        placeholder="销售组名称"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        placeholder="销售组织"
                        @on-change="search"
                        remote
                        v-model="tableQueryAttr.saleOrganizationId"
                    >
                        <Option
                            v-for="item in salesOrganizationArr"
                            :label="item.saleOrganizationName"
                            :value="item.id"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                销售组列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button v-has="btnRightList.saleGroupAdd" @click="add" icon="md-add">新增</Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>
        <!--        新增销售组弹窗-->
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel"
        >
            <div>
                <Form
                    :model="formAttr"
                    :rules="ruleValidate"
                    ref="formValidate"
                    :label-width="120"
                >
                    <Row>
                        <Col span="12">
                            <FormItem
                                label="销售组织"
                                prop="saleOrganizationId"
                            >
                                <Select
                                    placeholder="请选择销售组织"
                                    remote
                                    v-model="formAttr.saleOrganizationId"
                                >
                                    <Option
                                        v-for="item in salesOrganizationArr"
                                        :label="item.saleOrganizationName"
                                        :value="item.id"
                                        :key="item.id"
                                    ></Option>
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="销售组名称" prop="saleGroupName">
                                <Input
                                    v-model="formAttr.saleGroupName"
                                    placeholder="请输入销售组名称"
                                ></Input>
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="md-list"></Icon>
                        销售组成员列表
                    </p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button v-has="btnRightList.salesmanAdd" @click="openGroupBuyer">新增</Button>
                        </ButtonGroup>
                    </div>
                    <Table
                        border
                        :columns="salesTableTitle"
                        :data="salesTableData"
                        :tableLoading="salesTableLoading"
                    ></Table>
                </Card>
            </div>
        </Modal>
        <!--        销售员列表弹窗-->
        <Modal
            v-model="salesmanShowFlag"
            width="700"
            title="选择销售员"
            :loading="salesmanModelLoading"
            :mask-closable="maskClosable"
            @on-ok="salesmanModalOk"
            @on-cancel="salesmanModalCancel"
        >
            <div>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="ios-search"></Icon>
                        查询条件
                    </p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button @click="salesmanSearch" icon="md-search"
                                >搜索
                            </Button>
                            <Button @click="salesmanReset" icon="md-refresh"
                                >重置
                            </Button>
                        </ButtonGroup>
                    </div>
                    <Row :gutter="16">
                        <Col span="12" class="maxWidth">
                            <Input
                                v-model="salesmanTableQuery.salerName"
                                @on-search="salesmanSearch"
                                search
                                placeholder="名称"
                            >
                                <Button
                                    @click="salesmanSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                        <Col span="12">
                            <Input
                                v-model="salesmanTableQuery.departmentName"
                                @on-search="salesmanSearch"
                                search
                                placeholder="部门"
                            >
                                <Button
                                    @click="salesmanSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                    </Row>
                </Card>
                <Table
                    border
                    @on-selection-change="selectionBuyer"
                    :columns="salesmanTableTitle"
                    :data="salesmanTableData"
                    height="320"
                    :tableLoading="salesmanTableLoading"
                ></Table>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        getSalesGroupList,
        getCompanySalesOrganizationList,
        addSalesGroup,
        getSalesGroupDetail,
        editSalesGroup,
        getCompanySalesmanList,
        salesGroupAddBuyer,
        salesGroupDeleteBuyer,
        delSalesGroup
    } from '@/api/saleManage/saleGroup';
    import { resetObj } from '@/libs/tools';

    export default {
        name: 'saleGroupSetting',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    saleGroupName: '',
                    saleOrganizationId: ''
                }, // 表格查询条件
                formAttr: {
                    saleOrganizationId: '',
                    saleGroupName: '',
                    salerIds: []
                }, // modal 值对象
                ruleValidate: {
                    saleOrganizationId: [
                        {
                            required: true,
                            type: 'number',
                            message: '销售组织不能为空',
                            trigger: 'change'
                        }
                    ],
                    saleGroupName: [
                        {
                            required: true,
                            message: '销售组名称不能为空',
                            trigger: 'blur'
                        }
                    ]
                }, // modal 表单验证
                erpTableTitle: [
                    {
                        title: '销售组织',
                        align: 'center',
                        minWidth: 140,
                        key: 'saleOrganizationName'
                    },
                    {
                        title: '销售组名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'saleGroupName'
                    },
                    {
                        title: '组内成员',
                        align: 'center',
                        minWidth: 200,
                        key: 'salerNames'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        minWidth: 120,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        style: {
                                            marginRight: '5px'
                                        },
                                        on: {
                                            click: () => {
                                                this.currentId = params.row.id;
                                                this.modalTitle = '编辑销售组';
                                                this.formAttr.saleOrganizationId =
                                                    params.row.saleOrganizationId;
                                                this.formAttr.saleGroupName =
                                                    params.row.saleGroupName;
                                                this.getSalesGroupDetail();
                                                this.modalShowFlag = true;
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.saleGroupEdit
                                            }
                                        ]
                                    },
                                    '编辑'
                                ),
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'error',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.delSalesGroup(params.row.id);
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.saleGroupDel
                                            }
                                        ]
                                    },
                                    '删除'
                                )
                            ]);
                        }
                    }
                ], // 表格标题
                salesOrganizationArr: [], // 当前公司的销售组织
                salesTableTitle: [
                    {
                        type: 'index',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '姓名',
                        align: 'center',
                        minWidth: 100,
                        key: 'salerName'
                    },
                    {
                        title: '性别',
                        align: 'center',
                        minWidth: 90,
                        render: (h, params) => {
                            const sex = params.row.sex ? '女' : '男';
                            return h('span', {}, sex);
                        }
                    },
                    {
                        title: '客户数',
                        align: 'center',
                        minWidth: 90,
                        key: 'countCustomer'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 90,
                        render: (h, params) => {
                            const status =
                                params.row.status === 3 ? '有效' : '无效';
                            return h('span', {}, status);
                        }
                    },
                    {
                        title: '操作',
                        minWidth: 100,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'error',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                if (!params.row.id) {
                                                    this.salesTableData.splice(
                                                        params.index,
                                                        1
                                                    );
                                                    return;
                                                }
                                                this.delGroupSaler(params.row.id);
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.salesmanDel
                                            }
                                        ]
                                    },
                                    '删除'
                                )
                            ]);
                        }
                    }
                ], // 销售组成员栏目
                salesTableData: [], // 销售组成员列表
                salesTableLoading: false,
                salesmanShowFlag: false, // 销售员弹窗开关
                salesmanModelLoading: false,
                salesmanTableQuery: {
                    salerName: '',
                    departmentName: ''
                },
                curSalerId: [], // 选中的销售员id
                curSalesList: [],
                salesmanTableTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '姓名',
                        align: 'center',
                        minWidth: 100,
                        key: 'salerName'
                    },
                    {
                        title: '性别',
                        align: 'center',
                        minWidth: 90,
                        render: (h, params) => {
                            const sex = params.row.sex ? '女' : '男';
                            return h('span', {}, sex);
                        }
                    },
                    {
                        title: '公司',
                        align: 'center',
                        minWidth: 100,
                        key: 'enterpriseName'
                    },
                    {
                        title: '部门',
                        align: 'center',
                        minWidth: 90,
                        key: 'departmentName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 90,
                        render: (h, params) => {
                            const status =
                                params.row.status === 3 ? '有效' : '无效';
                            return h('span', {}, status);
                        }
                    }
                ], // 销售员列表栏目
                salesmanTableData: [],
                salesmanTableLoading: false
            };
        },
        created () {
            this.getCompanySalesOrganizationList();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getSalesGroupList(params);
                    getListMixin(res);
                });
            },
            // 新增编辑确认按钮
            modalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res;
                    const params = this.currentId
                        ? Object.assign({}, this.formAttr, {
                            id: this.currentId
                        })
                        : Object.assign({}, this.formAttr);
                    if (this.currentId) {
                        res = await editSalesGroup(params);
                    } else {
                        res = await addSalesGroup(params);
                    }
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    } else {
                        this.changeLoading();
                    }
                });
            },
            add () {
                this.salesTableData = [];
                this.addItem('新增销售组');
            },
            // 获取当前公司的销售组织
            async getCompanySalesOrganizationList () {
                const res = await getCompanySalesOrganizationList({});
                if (res.status === this.code) {
                    this.salesOrganizationArr = res.content;
                }
            },
            // 获取当前公司所有销售员
            async getCompanySalesmanList () {
                this.salesmanTableLoading = true;
                const params = this.currentId
                    ? Object.assign({}, this.salesmanTableQuery, {
                        notSaleGroupId: this.currentId
                    })
                    : Object.assign({}, this.salesmanTableQuery);
                const res = await getCompanySalesmanList(params);
                this.salesmanTableLoading = false;
                if (res.status === this.code) {
                    this.salesmanTableData = res.content;
                }
            },
            // 确认选中销售员
            async salesmanModalOk () {
                if (this.curSalerId.length === 0) {
                    this.$Message.error('请先勾选销售员');
                    this.changeLoading('salesmanModelLoading');
                    return;
                }
                if (!this.currentId) {
                    const salerIds = this.salesTableData.map(item => {
                        return item.salerId;
                    });
                    this.formAttr.salerIds = this.curSalerId;
                    this.curSalesList.forEach(item => {
                        if (!salerIds.includes(item.id)) {
                            this.salesTableData.push({
                                salerId: item.id,
                                salerName: item.salerName,
                                sex: item.sex,
                                countCustomer: item.countCustomer,
                                status: item.status
                            });
                        }
                    });
                    this.changeLoading('salesmanModelLoading');
                    this.salesmanModalCancel();
                } else {
                    const params = {
                        saleGroupId: this.currentId,
                        salerIds: this.curSalerId
                    };
                    const res = await salesGroupAddBuyer(params);
                    this.changeLoading('salesmanModelLoading');
                    if (res.status === this.code) {
                        this.$Message.success(res.msg);
                        this.salesmanModalCancel();
                        this.getSalesGroupDetail();
                    }
                }
            },
            // 关闭销售员弹窗
            salesmanModalCancel () {
                this.salesmanTableData = [];
                this.curSalerId = [];
                this.curSalesList = [];
                this.salesmanShowFlag = false;
            },
            // 搜索销售员列表
            salesmanSearch () {
                this.getCompanySalesmanList();
            },
            // 重置销售员搜索
            salesmanReset () {
                resetObj(this.salesmanTableQuery);
                this.getCompanySalesmanList();
            },
            // 选中销售员
            selectionBuyer (value) {
                this.curSalesList = value;
                this.curSalerId = value.map(item => {
                    return item.id;
                });
            },
            // 打开销售员弹窗
            openGroupBuyer () {
                this.getCompanySalesmanList();
                this.salesmanShowFlag = true;
            },
            // 获取当前销售组成员
            async getSalesGroupDetail () {
                const params = {
                    saleGroupId: this.currentId
                };
                const res = await getSalesGroupDetail(params);
                if (res.status === this.code) {
                    this.salesTableData = res.content;
                }
            },
            // 删除关联的销售员
            delGroupSaler (id) {
                this.$Modal.confirm({
                    title: '确认删除该销售员吗？',
                    onOk: async () => {
                        const params = {
                            id: id
                        };
                        const res = await salesGroupDeleteBuyer(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getSalesGroupDetail();
                            this.getTableList();
                        }
                    }
                });
            },
            // 删除销售组
            delSalesGroup (id) {
                this.$Modal.confirm({
                    title: '确认删除该销售组吗？',
                    onOk: async () => {
                        const params = {
                            id
                        };
                        const res = await delSalesGroup(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getTableList();
                        }
                    }
                });
            }
        }
    };
</script>

<style scoped lang="less"></style>
