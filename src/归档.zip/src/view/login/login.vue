<style lang="less">
    @import './login.less';
</style>
<style lang="less">
    .login-show {
        width: 500px;
        height: 600px;
        float: left;
        background: url('https://tyche-fe.oss-cn-beijing.aliyuncs.com/thalys/cms/cms_login_left.png') no-repeat center;
        background-size: cover;
        position: relative;

        img {
            width: 360px;
            /*margin: 32px 0 0 32px;*/
        }
        .txt {
            margin-top: 20px;
            text-align: center;
            font-size: 28px;
            font-weight: bold;
        }
        h1 {
            font-size: 24px;
            font-weight: bold;
            color: #fff;
            position: relative;
            z-index: 1;
        }
        p {
            font-size: 90px;
            font-weight: bold;
            color: rgba(14, 75, 229, 1);
            position: relative;
            top: 50px;
        }
        .pos {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
    }

    .login-todo {
        float: right;
        width: 600px;
        height: 600px;
        background: #fff;
        padding: 110px 140px !important;
    }
</style>
<template>
    <div class="login">
        <div class="login-con clearfix">
            <div class="login-show">
                <div class="pos">
                    <img
                        src="https://tyche-fe.oss-cn-beijing.aliyuncs.com/thalys/cms/cms_logo.png"
                        alt=""
                    />
                    <div class="txt">
                        <h1>供应链管理平台</h1>
                    </div>
                </div>
            </div>
            <div class="login-todo form-con">
                <login-form @on-success-valid="handleSubmit"></login-form>
            </div>
        </div>
        <Modal
            v-model="editPwdFlag"
            title="密码为初始密码，请重置"
            :loading="modelLoading"
            @on-ok="ok"
            @on-cancel="cancel"
        >
            <div class="wrapper">
                <Form
                    ref="editForm"
                    :model="form"
                    :rules="rules"
                    :label-width="120"
                >
                    <FormItem prop="userPwd" label="密码">
                        <Input
                            v-model="form.userPwd"
                            placeholder="请输入密码"
                        ></Input>
                    </FormItem>
                    <FormItem prop="reUserPwd" label="确认密码">
                        <Input
                            v-model="form.reUserPwd"
                            placeholder="请再次输入密码"
                        ></Input>
                    </FormItem>
                </Form>
            </div>
        </Modal>
    </div>
</template>

<script>
    import LoginForm from '_c/login-form';
    import { mapActions } from 'vuex';

    export default {
        data () {
            const validateReUserPwd = (rule, value, callback) => {
                if (value === '' || value === null) {
                    callback(new Error('确认密码不能为空'));
                } else if (value !== this.form.userPwd) {
                    callback(new Error('两次密码不一致'));
                } else {
                    callback();
                }
            };
            return {
                editPwdFlag: false,
                form: {
                    userPwd: '',
                    reUserPwd: ''
                },
                rules: {
                    userPwd: {
                        required: true,
                        message: '密码不能为空',
                        trigger: 'blur'
                    },
                    reUserPwd: {
                        required: true,
                        validator: validateReUserPwd,
                        trigger: 'blur'
                    }
                },
                modelLoading: true
            };
        },
        components: {
            LoginForm
        },
        methods: {
            ...mapActions(['handleLogin', 'getUserInfo', 'editInitPasssWord']),
            handleSubmit ({ userName, password }) {
                this.handleLogin({ userName, password }).then((res) => {
                    if (res.status === 10000) {
                        this.getUserInfo().then(() => {
                            this.$router.push({
                                name: this.$config.homeName
                            });
                        });
                    }
                });
            },
            changeLoading () {
                this.modelLoading = false;
                this.$nextTick(() => {
                    this.modelLoading = true;
                });
            },
            ok () {
                this.$refs.editForm.validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    const res = await this.editInitPasssWord({ ...this.form });
                    if (res.status === 10000) {
                        this.$Message.success(res.msg);
                        this.$router.push({
                            name: this.$config.homeName
                        });
                    } else {
                        this.$Message.error(res.msg);
                    }
                });
            },
            cancel () {
                this.handleLogOut();
            }
        }
    };
</script>

<style></style>
