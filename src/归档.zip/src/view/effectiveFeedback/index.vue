<template>
    <div class="effectiveFeedback">
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.bizType"
                        @on-change="selectSearch"
                        filterable ref="filter"
                        placeholder="业务类型"
                    >
                        <Option
                            v-for="(item, index) in bizTypeList"
                            :value="item.value"
                            :key="index"
                            :label="item.label"
                        ></Option>
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.supplierEnableCode"
                        @on-change="selectSearch"
                        filterable ref="filter"
                        placeholder="供应商"
                    >
                        <Option
                            v-for="(item, index) in supplierList"
                            :value="item.value"
                            :key="index"
                            :label="item.label"
                        >
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.commodityName"
                        placeholder="物料名称"
                        @on-search="search"
                        search
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        @on-change='search'
                        v-model="tableQueryAttr.confirmStatus"
                        placeholder="全部状态"
                    >
                        <Option :value="''">全部状态</Option>
                        <Option :value="1">待确认</Option>
                        <Option :value="2">已反馈</Option>
                        <Option :value="3">已确认</Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title"><Icon type="md-list"></Icon> 采购需求列表</p>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
            ></erp-table>
        </Card>

        <Modal
            width="1000"
            v-model="modalShowFlag"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-cancel="modalCancelCst"
            @on-ok="modalOk"
        >
            <div class="erp-modal-content">
                <Form
                    :model="formAttr"
                    :rules="ruleValidate"
                    ref="formValidate"
                    :label-width="120">
                    <Row>
                        <Col span="11">
                            <FormItem
                                label="客户名称"
                            >
                                <Input
                                    disabled
                                    v-model="currentOrder.customerName"
                                    placeholder="客户名称"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="13">
                            <FormItem
                                label="物料名称"
                            >
                                <Input
                                    disabled
                                    v-model="currentOrder.commodityName"
                                    placeholder="物料名称"
                                ></Input>
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span="11">
                            <FormItem
                                label="规格"
                            >
                                <Input
                                    disabled
                                    v-model="currentOrder.commoditySpec"
                                    placeholder="规格"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="13">
                            <FormItem
                                label="品牌"
                            >
                                <Input
                                    disabled
                                    v-model="currentOrder.brandName"
                                    placeholder="品牌"
                                ></Input>
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span="11">
                            <FormItem
                                label="数量"
                            >
                                <Input
                                    disabled
                                    v-model="currentOrder.confirmQuantity"
                                    placeholder="数量"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="13">
                            <FormItem
                                label="要求效期"
                            >
                                <Input
                                    disabled
                                    :value="currentOrder.effectiveDate | formatDate"
                                    placeholder="要求效期"
                                ></Input>
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span="11">
                            <FormItem
                                label="供应商"
                                prop="supplierEnableCode"
                            >
                                <Select
                                    v-model="formAttr.supplierEnableCode"
                                    @on-change="chooseFormAttrSupplierEnableCode"
                                    filterable ref="filter"
                                    placeholder="请选择供应商"
                                    remote>
                                    <Option v-for="(item, index) in modalSupplierList" :label="item.label"
                                            :value="item.value"
                                            :key="index"></Option>
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span="13">
                            <FormItem
                                label="参考效期"
                            >
                                <Input
                                    disabled
                                    :value="formAttr.effectiveDate | formatDate"
                                    placeholder="无参考"
                                ></Input>
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span="11">
                            <FormItem
                                label="反馈效期"
                                prop="feedBackEffectiveDate"
                            >
                                <DatePicker v-model="formAttr.feedBackEffectiveDate" @on-change="modalDatePicker"
                                            type="date" placeholder="请选择反馈效期" style="width: 100%"></DatePicker>
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
            </div>
        </Modal>

        <Modal
            v-model="chooseModalShowFlag"
            width="450"
            title="接受效期"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="chooseModalOk"
            @on-cancel="chooseModalCancel"
        >
            <Form
                :model="chooseFormAttr"
                :rules="chooseRuleValidate"
                ref="chooseFormValidate"
                :label-width="120">
                <FormItem
                    label="供应商"
                    prop="supplierEnableCode"
                >
                    <Select
                        v-model="chooseFormAttr.supplierEnableCode"
                        filterable ref="filter"
                        placeholder="请选择供应商"
                    >
                        <Option
                            v-for="(item, index) in modalSupplierList"
                            :value="item.value"
                            :key="index"
                            :label="item.label"
                        >
                        </Option
                        >
                    </Select>
                </FormItem>
            </Form>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { acceptRequirement, feedbackRequirement, getModalSupplierList, getRequirementList } from '@/api/effective';
    import { getSaveSupplierList } from '@/api/purchaseManage/buyer';
    import { getDate, resetObj } from '@/libs/tools';

    export default {
        name: 'effectiveFeedback',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                erpTableTitle: [
                    {
                        title: '来源类型',
                        align: 'center',
                        minWidth: 210,
                        key: 'sourceTypeName'
                    },
                    {
                        title: '业务类型',
                        align: 'center',
                        minWidth: 110,
                        key: 'bizType'
                    },
                    {
                        title: '来源编号',
                        align: 'center',
                        minWidth: 210,
                        key: 'sourceOrderNo'
                    },
                    {
                        title: '物料编码',
                        align: 'center',
                        minWidth: 210,
                        key: 'commodityCode'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 210,
                        key: 'commodityName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 210,
                        key: 'registerNumber'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 110,
                        key: 'specializedGroupName'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 110,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 110,
                        key: 'brandName'
                    },
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 110,
                        key: 'customerName'
                    },
                    {
                        title: '原数量',
                        align: 'center',
                        minWidth: 110,
                        key: 'quantity'
                    },
                    {
                        title: '确认数量',
                        align: 'center',
                        minWidth: 110,
                        key: 'confirmQuantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 110,
                        key: 'unitName'
                    },
                    {
                        title: '要求效期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.effectiveDate)
                            );
                        }
                    },
                    {
                        title: '到货日期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.arriveDate)
                            );
                        }
                    },
                    {
                        title: '生成时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            const txt = () => {
                                switch (params.row.confirmStatus) {
                                    case 1:
                                        return '待确认';
                                    case 2:
                                        return '已反馈';
                                    case 3:
                                        return '已确认';
                                }
                            };
                            return h(
                                'span',
                                {},
                                txt()
                            );
                        }
                    },
                    {
                        title: '反馈人',
                        align: 'center',
                        minWidth: 110,
                        key: 'feedBackUserName'
                    },
                    {
                        title: '反馈效期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.feedBackEffectiveDate)
                            );
                        }
                    },
                    {
                        title: '反馈时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.feedBackDate, 'long')
                            );
                        }
                    },
                    {
                        title: '确认状态',
                        align: 'center',
                        minWidth: 110,
                        key: 'isAgreeName'
                    },
                    {
                        title: '确认人',
                        align: 'center',
                        minWidth: 110,
                        key: 'confirmUserName'
                    },
                    {
                        title: '确认时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.confirmDate, 'long')
                            );
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 170,
                        fixed: 'right',
                        render: (h, params) => {
                            const acceptFlag = params.row.confirmStatus === 1;
                            const feedbackFlag = params.row.confirmStatus === 1;
                            return h('div', [
                                acceptFlag ? h('Button', {
                                    props: {
                                        type: 'success',
                                        size: 'small'
                                    },
                                    style: {
                                        marginRight: '6px'
                                    },
                                    on: {
                                        click: () => {
                                            this.chooseModalShowFlag = true;
                                            this.currentOrder = params.row;
                                            this.getModalSupplierList(params.row.id);
                                        }
                                    },
                                    directives: [
                                        {
                                            name: 'has',
                                            value: this.btnRightList.acceptRequirement
                                        }
                                    ]
                                }, '接受') : null,
                                feedbackFlag ? h('Button', {
                                    props: {
                                        type: 'warning',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            this.addItem('反馈效期');
                                            this.currentOrder = params.row;
                                            this.getModalSupplierList(params.row.id);
                                        }
                                    },
                                    directives: [
                                        {
                                            name: 'has',
                                            value: this.btnRightList.feedbackRequirement
                                        }
                                    ]
                                }, '反馈') : null
                            ]);
                        }
                    }
                ],
                supplierList: [], // 表单查询供应商
                modalSupplierList: [], // 效期反馈供应商
                bizTypeList: [
                    {
                        label: '销售计划',
                        value: '销售计划'
                    },
                    {
                        label: '销售订单',
                        value: '销售订单'
                    },
                    {
                        label: '定向订单',
                        value: '定向订单'
                    },
                    {
                        label: '测试订单',
                        value: '测试订单'
                    },
                    {
                        label: '借货订单',
                        value: '借货订单'
                    },
                    {
                        label: '赠送订单',
                        value: '赠送订单'
                    },
                    {
                        label: '投放订单',
                        value: '投放订单'
                    },
                    {
                        label: '领用订单',
                        value: '领用订单'
                    }
                ],
                tableQueryAttr: {
                    bizType: '', // 来源类型
                    supplierEnableCode: '', // 供应商编码
                    commodityName: '', // 物料名称
                    confirmStatus: ''
                },
                formAttr: {
                    feedBackEffectiveDate: '',
                    recommandEffectiveDateType: '',
                    supplierEnableCode: '',
                    effectiveDate: ''
                },
                currentOrder: {}, // 当前操作的采购订单
                ruleValidate: {
                    supplierEnableCode: [
                        {
                            required: true,
                            message: '供应商不能为空',
                            trigger: 'change'
                        }
                    ],
                    feedBackEffectiveDate: [
                        {
                            required: true,
                            message: '反馈效期不能为空'
                        }
                    ]
                },
                chooseRuleValidate: {
                    supplierEnableCode: [
                        {
                            required: true,
                            message: '供应商不能为空',
                            trigger: 'change'
                        }
                    ]
                },
                chooseModalShowFlag: false, // 接受弹框开关
                chooseFormAttr: {
                    supplierEnableCode: ''
                }
            };
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getSaveSupplierList();
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getRequirementList(params);
                    getListMixin(res);
                });
            },
            async getSaveSupplierList () {
                const res = await getSaveSupplierList({ purchaserId: this.$store.getters.purchaserId });
                console.log(res);
                if (res.status === this.code) {
                    const arr = res.content || [];
                    this.supplierList = arr.map(item => {
                        return {
                            label: item.supplierName,
                            value: item.supplierEnableCode
                        };
                    });
                }
            },
            // modal 供应商下拉列表
            async getModalSupplierList (id) {
                const res = await getModalSupplierList({ id });
                console.log(res);
                if (res.status === this.code) {
                    const arr = res.content.list || res.content || [];
                    this.modalSupplierList = arr.map(item => {
                        return {
                            label: item.supplierName,
                            value: item.supplierEnableCode,
                            recommandEffectiveDateType: item.recommandEffectiveDateType,
                            effectiveDate: item.effectiveDate
                        };
                    });
                }
            },
            modalDatePicker (value) {
                console.log(value);
                console.log(this.formAttr.feedBackEffectiveDate);
            },
            // modal 供应商下拉
            chooseFormAttrSupplierEnableCode (value) {
                console.log(value);
                this.modalSupplierList.some(item => {
                    if (item.value === value) {
                        console.log(item);
                        this.formAttr.effectiveDate = item.effectiveDate || '';
                        this.formAttr.recommandEffectiveDateType = item.recommandEffectiveDateType;
                    }
                });
            },
            modalOk () {
                this.$refs.formValidate.validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    const params = Object.assign({}, {
                        id: this.currentOrder.id
                    }, this.formAttr, {
                        feedBackEffectiveDate: new Date(this.formAttr.feedBackEffectiveDate).getTime(),
                        recommandEffectiveDate: new Date(this.formAttr.effectiveDate).getTime()
                    });
                    console.log(params);
                    const res = await feedbackRequirement(params);
                    if (res.status === this.code) {
                        this.$Message.success(res.msg);
                        this.modalCancelCst();
                        this.getTableList();
                    } else {
                        this.changeLoading();
                    }
                });
            },
            modalCancelCst () {
                if (this.modalShowFlag) this.modalShowFlag = false;
                setTimeout(() => {
                    this.$refs['formValidate'] && this.$refs['formValidate'].resetFields();
                    this.formAttr && resetObj(this.formAttr);
                }, 300);
            },
            chooseModalOk () {
                this.$refs.chooseFormValidate.validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    const res = await acceptRequirement({
                        id: this.currentOrder.id,
                        supplierEnableCode: this.chooseFormAttr.supplierEnableCode
                    });
                    if (res.status === this.code) {
                        this.$Message.success(res.msg);
                        this.chooseModalCancel();
                        this.getTableList();
                    } else {
                        this.changeLoading();
                    }
                });
            },
            chooseModalCancel () {
                this.chooseModalShowFlag = false;
                setTimeout(() => {
                    this.$refs.filter && this.$refs.filter.setQuery(null);
                    this.chooseFormAttr.supplierEnableCode = '';
                    this.$refs['chooseFormValidate'] && this.$refs['chooseFormValidate'].resetFields();
                }, 300);
            }
        },
        filters: {
            formatDate (value) {
                if (!value) return '';
                return getDate(value);
            }
        }
    };
</script>

<style scoped lang="less">

</style>
