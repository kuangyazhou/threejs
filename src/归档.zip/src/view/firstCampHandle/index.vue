<template>
    <div class="erp-content" ref="erp">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="4" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.customerName"
                        @on-search="search"
                        search
                        placeholder="客户名称"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="4" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.createName"
                        @on-search="search"
                        search
                        placeholder="创建人员"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="4" class="maxWidth">
                    <DatePicker
                        :editable="false"
                        v-model="tableQueryAttr.startDate"
                        format="yyyy-MM-dd"
                        type="date"
                        @on-change="startDateChange"
                        placeholder="创建时间开始"
                    ></DatePicker>
                </Col>
                <Col span="4" class="maxWidth">
                    <DatePicker
                        :editable="false"
                        v-model="tableQueryAttr.endDate"
                        format="yyyy-MM-dd"
                        type="date"
                        @on-change="endDateChange"
                        placeholder="创建时间结束"
                    ></DatePicker>
                </Col>
                <Col span="4" class="maxWidth">
                    <Select
                        placeholder="状态"
                        @on-change="selectSearch"
                        remote
                        v-model="tableQueryAttr.handleStatus"
                    >
                        <Option
                            v-for="item in handleStatusArr"
                            :label="item.label"
                            :value="item.value"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                首营任务列表
            </p>
            <div slot="extra">
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="900"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-cancel="modalCancel"
        >
            <Tabs v-model="tabIndex" type="card" @on-click="tabsBind">
                <TabPane label="申请信息">
                    <first-apply
                        ref="firstApply"
                        :disabled="onlyReady"
                        :customerNameArr="customerNameArr"
                        :outboundMethodNameArr="outboundMethodNameArr"
                        :deliveryMethodNameArr="deliveryMethodNameArr"
                        :purchaseOrganizationArr="purchaseOrganizationArr"
                        :formAttr="formAttr"></first-apply>
                </TabPane>
                <TabPane label="询价结果">
                    <Inquiry-result
                        :inquiryResult="inquiryResult"
                        :disabled="onlyReady"
                        :inquiryResultTitle="inquiryResultTitle"
                    ></Inquiry-result>
                </TabPane>
                <TabPane label="首营准备">
                    <first-ready
                        @changeFormInfo="getFirstCampInfo"
                        :formAttr="firstReadyForm"
                        :disabled="Boolean(handleStatus)"
                    ></first-ready>
                </TabPane>
                <template v-if="Boolean(handleStatus)">
                <TabPane label="客户物料">
                    <customer-material
                        :formAttr="customerMaterialForm"
                        :saleTableData="saleTableData"
                    ></customer-material>
                </TabPane>
                    <TabPane label="渠道价格">
                        <Table
                            border
                            :data="channelTableData"
                            :columns="channelTableTitle"
                        ></Table>
                    </TabPane>
                </template>
            </Tabs>
            <div slot="footer">
                <Button @click="modalCancel">取消</Button>
                <Button v-if="handleStatus === 1" @click="firstHandle" type="primary">首营处理</Button>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import FirstApply from '@/components/firstMaterialApply/firstApply';
    import InquiryResult from '@/components/firstMaterialApply/inquiryResult';
    import FirstReady from '@/components/firstMaterialApply/firstReady';
    import CustomerMaterial from '@/components/firstMaterialApply/customerMaterial';
    import { getCompanyPurchaseOrganizationList } from '@/api/purchaseManage/purchaseGroup';
    import {
        getInquiryResult
    } from '@/api/saleManage/firstMaterialApply';
    import {
        getCustomerInfo
    } from '@/api/customerMaterial/materialInfo';
    import {
        salePriceList
    } from '@/api/customerMaterial/materialMoney';
    import {
        distributionInquiryTask,
        getFirstCampHandleList,
        getInquiryTaskFirstInfo,
        getFirstCampInfo,
        firstCampHandle
    } from '@/api/purchaseManage/inquiryTask';
    import {
        getChannelPriceList
    } from '@/api/purchaseManage/channelPrice';
    import { getDate } from '@/libs/tools';

    export default {
        name: 'firstCampHandle',
        mixins: [tableMixin],
        components: {
            ErpTable, FirstApply, InquiryResult, FirstReady, CustomerMaterial
        },
        data () {
            return {
                tableQueryAttr: {
                    handleStatus: '',
                    customerName: '',
                    createName: '',
                    startDate: '',
                    endDate: ''
                }, // 表格查询条件
                formAttr: {
                    customerName: '', // 客户名称
                    commodityName: '', // 物料名称
                    commodityBrand: '', // 物料品牌
                    commoditySpecializedGroupId: '', // 专业分组id
                    instrumentName: '', // 仪器名称
                    manufacturer: '', // 生产厂家
                    outboundMethodId: '', // 出库方式
                    deliveryMethodId: '', // 发货方式
                    commoditySpec: '', // 物料规格
                    commodityNumber: '', // 货号
                    commodityUnitName: '', // 物料单位
                    price: 0, // 销售价格
                    yearOrderNumber: 0, // 年订单量
                    yearTestNumber: 0, // 年测试数
                    metaSupplier: '', // 原供应商
                    purchaseOrganizationId: '', // 采购组织
                    writeDescription: '' // 录入摘要
                }, // modal 值对象
                ruleValidate: {
                }, // modal 表单验证
                erpTableTitle: [
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 140,
                        key: 'customerName'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 150,
                        key: 'commodityName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroupName'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityBrand'
                    },
                    {
                        title: '仪器名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'instrumentName'
                    },
                    {
                        title: '出库方式',
                        align: 'center',
                        minWidth: 100,
                        key: 'outboundMethodName'
                    },
                    {
                        title: '发货方式',
                        align: 'center',
                        minWidth: 100,
                        key: 'deliveryMethodName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'statusDescription'
                    },
                    {
                        title: '创建人员',
                        align: 'center',
                        minWidth: 100,
                        key: 'createName'
                    },
                    {
                        title: '创建时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 200,
                        align: 'center',
                        fixed: 'right',
                        render: (h, params) => {
                            const handleStatus = params.row.handleStatus;
                            if (handleStatus) {
                                const statusName = handleStatus === 1 ? '首营处理' : '查看首营';
                                return h('div', [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'info',
                                                size: 'small'
                                            },
                                            style: {},
                                            on: {
                                                click: () => {
                                                    this.handleStatus = handleStatus;
                                                    this.currentId = params.row.id;
                                                    this.taskId = params.row.inquiryId;
                                                    this.tabIndex = 2;
                                                    this.addItem('首营处理');
                                                    this.getFirstCampInfo();
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList.firstCampHandle
                                                }
                                            ]
                                        },
                                        statusName
                                    )
                                ]);
                            } else {
                                return h('div', [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'primary',
                                                size: 'small'
                                            },
                                            style: {
                                                marginRight: '5px'
                                            },
                                            on: {
                                                click: () => {
                                                    this.handleStatus = params.row.handleStatus;
                                                    this.currentId = params.row.id;
                                                    this.taskId = params.row.inquiryId;
                                                    this.tabIndex = 2;
                                                    this.addItem('首营准备');
                                                    this.getFirstCampInfo();
                                                }
                                            }
                                        },
                                        '首营准备'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'info',
                                                size: 'small'
                                            },
                                            style: {},
                                            on: {
                                                click: () => {
                                                    this.handleStatus = 1;
                                                    this.currentId = params.row.id;
                                                    this.taskId = params.row.inquiryId;
                                                    this.tabIndex = 2;
                                                    this.addItem('首营处理');
                                                    this.getFirstCampInfo();
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList.firstCampHandle
                                                }
                                            ]
                                        },
                                        '首营处理'
                                    )
                                ]);
                            }
                        }
                    }
                ], // 表格标题
                handleStatusArr: [
                    {
                        id: 1,
                        label: '待处理',
                        value: 0
                    },
                    {
                        id: 2,
                        label: '处理中',
                        value: 1
                    },
                    {
                        id: 3,
                        label: '已结束',
                        value: 2
                    }
                ], // 状态数组
                tabIndex: 0,
                onlyReady: true,
                customerNameArr: [], // 物料专业分组下拉
                outboundMethodNameArr: [], // 出库方式下拉
                deliveryMethodNameArr: [], // 发货方式下拉
                purchaseOrganizationArr: [], // 采购组织下拉
                inquiryResultTitle: [
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '包装单位 ',
                        align: 'center',
                        minWidth: 100,
                        key: 'unitName'
                    },
                    {
                        title: '税率',
                        align: 'center',
                        minWidth: 90,
                        key: 'taxRate'
                    },
                    {
                        title: '市场指导价',
                        align: 'center',
                        minWidth: 120,
                        key: 'marketPrice'
                    },
                    {
                        title: '币种',
                        align: 'center',
                        minWidth: 90,
                        key: 'currencyName'
                    },
                    {
                        title: '询价时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.inquiryTime, 'long')
                            );
                        }
                    },
                    {
                        title: '供应商选择',
                        type: 'selection',
                        align: 'center',
                        width: 60
                    }
                ],
                inquiryResult: {}, // 询价结果
                taskId: null, // 询价任务id
                firstReadyForm: {}, // 首营准备
                handleStatus: 0,
                saleTableData: [], // 销售价格列表
                customerMaterialForm: {}, // 客户物料
                channelTableTitle: [
                    {
                        title: '采购组织',
                        align: 'center',
                        minWidth: 120,
                        key: 'selectPurchaseOrganizationName'
                    },
                    {
                        title: '物料常用名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityName'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 80,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 90,
                        key: 'brandName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 120,
                        key: 'specializedGroupName'
                    },
                    {
                        title: '包装单位',
                        align: 'center',
                        minWidth: 100,
                        key: 'unitName'
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '采购价格',
                        align: 'center',
                        minWidth: 100,
                        key: 'purchasePrice'
                    },
                    {
                        title: '币种',
                        align: 'center',
                        minWidth: 80,
                        key: 'currencyName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 80,
                        key: 'statusDescription'
                    }
                ], // 渠道价格栏目
                channelTableData: [] // 渠道价格
            };
        },
        created () {
            this.getAllSelectData();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    if (!this.tableQueryAttr.handleStatus) this.tableQueryAttr.handleStatus = 0;
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getFirstCampHandleList(params);
                    getListMixin(res);
                });
            },
            // 新增编辑确认按钮
            modalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    const params = Object.assign({}, this.formAttr, {
                        inquiryIds: this.tableSelectValue
                    });
                    const res = await distributionInquiryTask(params);
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                        this.tableSelectValue = [];
                    } else {
                        this.changeLoading();
                    }
                });
            },
            getAllSelectData () {
                this.getFieldValuesData(
                    'commodity_specialized_group',
                    'customerNameArr'
                );
                this.getFieldValuesData('outbound_method', 'outboundMethodNameArr');
                this.getFieldValuesData('delivery_method', 'deliveryMethodNameArr');
                this.getCompanyPurchaseOrganizationList();
            },
            // 获取当前公司的采购组织
            async getCompanyPurchaseOrganizationList () {
                const res = await getCompanyPurchaseOrganizationList();
                if (res.status === this.code) {
                    this.purchaseOrganizationArr = res.content;
                }
            },
            // 开始时间格式化
            startDateChange (val) {
                this.tableQueryAttr.startDate = val;
                this.getTableList();
            },
            // 结束时间格式化
            endDateChange (val) {
                this.tableQueryAttr.endDate = val;
                this.getTableList();
            },
            // tab点击
            tabsBind (name) {
                switch (name) {
                    case 0:
                        this.getInquiryTaskFirstInfo();
                        break;
                    case 1:
                        this.getInquiryResult();
                        break;
                    case 2:
                        this.getFirstCampInfo();
                        break;
                    case 3:
                        this.getCustomerMaterialInfo();
                        this.getSalesPrice();
                        break;
                    case 4:
                        this.getChannelPriceList();
                        break;
                }
            },
            // 获取询价任务首营信息
            async getInquiryTaskFirstInfo () {
                const params = {
                    id: this.taskId
                };
                const res = await getInquiryTaskFirstInfo(params);
                if (res.status === this.code) {
                    const formAttr = res.content;
                    for (let key in formAttr) {
                        this.formAttr[key] = formAttr[key];
                    }
                }
            },
            // 获取询价任务的询价结果
            async getInquiryResult () {
                const res = await getInquiryResult(this.taskId);
                if (res.status === this.code) {
                    if (res.content) {
                        if (Array.isArray(res.content.items)) {
                            this.inquiryResult = {
                                ...res.content,
                                items: res.content.items.map(item => {
                                    return {
                                        ...item,
                                        _checked: item.isChecked === 1,
                                        _disabled: true
                                    };
                                })
                            };
                        }
                    }
                }
            },
            // 获取首营准备信息
            async getFirstCampInfo () {
                const params = {
                    id: this.currentId
                };
                const res = await getFirstCampInfo(params);
                if (res.status === this.code) {
                    let content = res.content || {};
                    content.id = this.currentId;
                    content.items = res.content.items.map(item => {
                        return {
                            ...item,
                            _checked: item.isChecked === 1,
                            _disabled: true
                        };
                    });
                    this.firstReadyForm = content;
                }
            },
            // 首营处理
            async firstHandle () {
                const params = {
                    id: this.currentId
                };
                const res = await firstCampHandle(params);
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.getCustomerMaterialInfo();
                    this.getSalesPrice();
                }
            },
            // 获取客户物料
            async getCustomerMaterialInfo () {
                const params = {
                    initCommodityHandleId: this.currentId
                };
                const res = await getCustomerInfo(params);
                if (res.status === this.code) {
                    this.customerMaterialForm = res.content.length ? res.content[0] : {};
                }
            },
            // 获取销售价格
            async getSalesPrice () {
                const params = {
                    initCommodityHandleId: this.currentId
                };
                const res = await salePriceList(params);
                if (res.status === this.code) {
                    this.saleTableData = res.content;
                }
            },
            // 获取渠道价格列表
            async getChannelPriceList () {
                const params = {
                    initCommodityHandleId: this.currentId
                };
                const res = await getChannelPriceList(params);
                if (res.status === this.code) {
                    this.channelTableData = res.content;
                }
            }
        }
    };
</script>

<style scoped lang="less">
.erp-modal-content {
    overflow-y: visible;
}
</style>
