<template>
    <div class="firstMaterialApply">
        <!-- <h1>核算名称设置</h1> -->
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon> 查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.customerName"
                        placeholder="客户名称"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <!-- <Input placeholder="全部状态"></Input> -->
                    <Select
                        v-model="tableQueryAttr.inquiryTaskStatus"
                        placeholder="全部询价状态"
                        @on-change="search"
                    >
                        <Option label="全部询价状态" :value="''"></Option>
                        <Option label="未提交" :value="0"></Option>
                        <Option label="询价中" :value="1"></Option>
                        <Option label="询价结束" :value="2"></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card :border="false">
            <p slot="title"><Icon type="md-list"></Icon> 首营物料申请</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button icon="md-add" @click="add" v-has="btnRightList.firstMaterialApplyAdd"
                    >新增
                    </Button>
                    <Button
                        icon="md-checkbox"
                        @click="togetherMakePrice"
                        v-has="btnRightList.firstMaterialApplyInquiryBat"
                    >批量询价
                    </Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-selection-change="selectionChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="checkNameTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
            ></erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            fullscreen
            @on-cancel="modalCancelCst"
        >
            <Tabs
                :value="tabsName"
                v-if="modalIsFirstMaterialApply"
                type="card"
                @on-click="handleClickTabs"
            >
                <TabPane :name="SHENQING_TXT" label="申请信息">
                    <first-apply
                        ref="firstApply"
                        :disabled="hasInquiryTask || disabledFlag"
                        :customerNameArr="customerNameArr"
                        :outboundMethodNameArr="outboundMethodNameArr"
                        :deliveryMethodNameArr="deliveryMethodNameArr"
                        :purchaseOrganizationArr="purchaseOrganizationArr"
                        :formAttr="formAttr"></first-apply>
                </TabPane>
                <TabPane v-if="hasInquiryTaskResult" :name="XUNJIA_TXT" label="询价结果">
                    <Inquiry-result
                        ref="inquiry"
                        @on-selection-change="selectionChangeSupplier"
                        :inquiryResult="inquiryResult"
                        disabled
                        :inquiryResultTitle="inquiryResultTitle"
                    ></Inquiry-result>
                </TabPane>
                <TabPane v-if="hasInquiryTaskResult"   :name="FANKUI_TXT" label="反馈信息">
                    <first-apply
                        ref="firstApplyInner"
                        :disabled="true"
                        :customerNameArr="customerNameArr"
                        :outboundMethodNameArr="outboundMethodNameArr"
                        :deliveryMethodNameArr="deliveryMethodNameArr"
                        :purchaseOrganizationArr="purchaseOrganizationArr"
                        :formAttr="formAttrInquiryInfo"></first-apply>
                </TabPane>
            </Tabs>
            <first-apply
                ref="firstApply"
                v-if="!modalIsFirstMaterialApply"
                :customerNameArr="customerNameArr"
                :outboundMethodNameArr="outboundMethodNameArr"
                :deliveryMethodNameArr="deliveryMethodNameArr"
                :purchaseOrganizationArr="purchaseOrganizationArr"
                :formAttr="formAttr"></first-apply>

            <div slot="footer">
                <Button @click="modalCancelCst">{{
                    modalIsFirstMaterialApply ? '关闭' : '取消'
                    }}
                </Button>
                <Button
                    v-if="!currentId && !modalIsFirstMaterialApply"
                    @click="modalOk"
                    type="info"
                >保存
                </Button>
                <Button
                    v-if="!currentId && !modalIsFirstMaterialApply"
                    @click="modalOkAgain"
                    type="primary"
                >保存后再新增
                </Button>
                <Button
                    v-if="currentId && !modalIsFirstMaterialApply"
                    @click="modalOk"
                    type="primary"
                >保存编辑
                </Button>
                <Button
                    v-if="modalIsFirstMaterialApply && !(hasInquiryTask || hasInquiryTaskResult)"
                    @click="modalOkInquiry"
                    :disabled="hasInquiryTask"
                    type="primary"
                >{{hasInquiryTask ? '询价中' :'发起询价'}}
                </Button>
                <Button
                    v-if="supplierShowFlag"
                    @click="modalOkSupplier"
                    :disabled="!supplierArr.length"
                    type="primary"
                >确认供应商勾选
                </Button>
            </div>
        </Modal>

        <!-- 客户选择Modal -->
        <Modal
            v-model="customerModal"
            width="650"
            title="选择客户"
            :loading="modelLoading"
            :mask-closable="false"
            footer-hide
        >
            <Row :gutter="16" class="search-container">
                <Col span="8">
                    <Input
                        v-model="subCustomerName"
                        placeholder="客户名称"
                    ></Input>
                </Col>
                <Col span="8">
                    <Button @click="getCustomer">搜索</Button>
                </Col>
            </Row>
            <Table
                :loading="modelLoading"
                style="margin-top: 20px"
                :columns="cusColumns"
                :data="cusData"
                border
            ></Table>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import FirstApply from '@/components/firstMaterialApply/firstApply';
    import InquiryResult from '@/components/firstMaterialApply/inquiryResult';
    import { getDate, resetObj } from '@/libs/tools';
    import {
        addCommodityTask,
        deleteCommodityTask,
        getCommodityTaskList,
        getInquiryInfo,
        getInquiryResult,
        startInquiry,
        startInquiryBat,
        submitCommodityTask,
        supplierChecked,
        updateCommodityTask
    } from '@/api/saleManage/firstMaterialApply';
    import { getPurchaseOrganizationList } from '@/api/purchaseManage/purchaseGroup';
    import { salesChangeList } from '@/api/masterData/userchange';

    export default {
        components: { ErpTable, FirstApply, InquiryResult },
        mixins: [tableMixin],
        data () {
            return {
                formAttr: {
                    customerName: '', // 客户名称
                    commodityName: '', // 物料名称
                    commodityBrand: '', // 物料品牌
                    commoditySpecializedGroupId: '', // 专业分组id
                    instrumentName: '', // 仪器名称
                    manufacturer: '', // 生产厂家
                    outboundMethodId: '', // 出库方式
                    deliveryMethodId: '', // 发货方式
                    commoditySpec: '', // 物料规格
                    commodityNumber: '', // 货号
                    commodityUnitName: '', // 物料单位
                    price: 0, // 销售价格
                    yearOrderNumber: 0, // 年订单量
                    yearTestNumber: 0, // 年测试数
                    metaSupplier: '', // 原供应商
                    purchaseOrganizationId: '', // 采购组织
                    writeDescription: '' // 录入摘要
                },
                formAttrInquiryInfo: {
                    customerName: '', // 客户名称
                    commodityName: '', // 物料名称
                    commodityBrand: '', // 物料品牌
                    commoditySpecializedGroupId: '', // 专业分组id
                    instrumentName: '', // 仪器名称
                    manufacturer: '', // 生产厂家
                    outboundMethodId: '', // 出库方式
                    deliveryMethodId: '', // 发货方式
                    commoditySpec: '', // 物料规格
                    commodityNumber: '', // 货号
                    commodityUnitName: '', // 物料单位
                    price: 0, // 销售价格
                    yearOrderNumber: 0, // 年订单量
                    yearTestNumber: 0, // 年测试数
                    metaSupplier: '', // 原供应商
                    purchaseOrganizationId: '', // 采购组织
                    writeDescription: '' // 录入摘要
                },
                disabledFlag: false, // 询价页面不能编辑
                subCustomerName: '', // 选择客户时候搜索的客户名称
                tableQueryAttr: {
                    customerName: '', // 名称
                    inquiryTaskStatus: ''
                },
                doubleClickFlag: false, // 取消需要两次执行清楚表单验证
                supplierShowFlag: false, // 供应商确认选择按钮显示开关
                ruleValidate: {
                    customerName: [
                        {
                            required: true,
                            message: '客户名称不能为空'
                        }
                    ],
                    commodityName: [
                        {
                            required: true,
                            message: '物料名称不能为空'
                        }
                    ],
                    commodityBrand: [
                        {
                            required: true,
                            message: '物料品牌不能为空'
                        }
                    ],
                    commoditySpecializedGroupId: [
                        {
                            required: true,
                            message: '专业分组不能为空'
                        }
                    ],
                    purchaseOrganizationId: [
                        {
                            required: true,
                            message: '采购组织不能为空'
                        }
                    ],
                    commoditySpec: [
                        {
                            required: true,
                            message: '物料规格不能为空'
                        }
                    ]
                },
                checkNameTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center',
                        fixed: 'left'
                    },
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 200,
                        key: 'customerName'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 200,
                        key: 'commodityName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroupName'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 140,
                        key: 'commodityBrand'
                    },
                    {
                        title: '仪器名称',
                        align: 'center',
                        minWidth: 200,
                        key: 'instrumentName'
                    },
                    {
                        title: '出库方式',
                        align: 'center',
                        minWidth: 100,
                        key: 'outboundMethodName'
                    },
                    {
                        title: '发货方式',
                        align: 'center',
                        minWidth: 100,
                        key: 'deliveryMethodName'
                    },
                    {
                        title: '首营状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'statusDescription'
                    },
                    {
                        title: '询价状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'inquiryStatusDescription'
                    },
                    {
                        title: '创建人员',
                        align: 'center',
                        minWidth: 100,
                        key: 'createName'
                    },
                    {
                        title: '创建时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 220,
                        fixed: 'right',
                        render: (h, params) => {
                            // 未提交的首营单且未发起询价
                            const editBtnFlag = params.row.inquiryTaskStatus === 0 && params.row.taskStatus === 0;
                            // 是否申请了首营
                            const taskBtnFlag = params.row.inquiryTaskStatus === 2 && params.row.taskStatus === 0 && params.row.inquiryResult !== 0;
                            return h('div', [
                                editBtnFlag ? h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.getAllSelectData(() => {
                                                    this.modalIsFirstMaterialApply = false;
                                                    this.editTableData(
                                                        params,
                                                        '编辑首营物料申请'
                                                    );
                                                });
                                            }
                                        },
                                        style: {
                                            marginRight: '8px'
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.firstMaterialApplyUpdate
                                            }
                                        ]
                                    },
                                    '编辑'
                                ) : null,
                                editBtnFlag ? h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'error',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.currentId =
                                                    params.row.id;
                                                this.$Modal.confirm({
                                                    title: `确认删除吗？`,
                                                    onOk: async () => {
                                                        const res = await deleteCommodityTask(
                                                            this.currentId
                                                        );
                                                        if (
                                                            res.status ===
                                                            this.code
                                                        ) {
                                                            this.$Message.success(
                                                                res.msg
                                                            );
                                                            this.currentId = null;
                                                            this.getTableList();
                                                        }
                                                    }
                                                });
                                            }
                                        },
                                        style: {
                                            marginRight: '8px'
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.firstMaterialApplyDelete
                                            }
                                        ]
                                    },
                                    '删除') : null,
                                params.row.inquiryTaskStatus === 0 ? h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'info',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.showInquiry(params.row, '发起询价');
                                            }
                                        },
                                        style: {
                                            marginRight: '8px'
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.firstMaterialApplyStartInquiry
                                            }
                                        ]
                                    },
                                    '发起询价'
                                ) : null,
                                params.row.inquiryTaskStatus === 2 ? h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'info',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.doubleClickFlag = true;
                                                this.showInquiry(params.row, '查看询价');
                                            }
                                        },
                                        style: {
                                            marginRight: '8px'
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.firstMaterialApplyResultGet
                                            }
                                        ]
                                    },
                                    '查看询价'
                                ) : null,
                                taskBtnFlag ? h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'info',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.currentId = params.row.id;
                                                this.getCustomer();
                                                this.customerModal = true;
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.firstMaterialApplyTaskSubmit
                                            }
                                        ]
                                    },
                                    '申请首营'
                                ) : null
                            ]);
                        }
                    }
                ],
                customerNameArr: [], // 物料专业分组下拉
                outboundMethodNameArr: [], // 出库方式下拉
                deliveryMethodNameArr: [], // 发货方式下拉
                purchaseOrganizationArr: [], // 采购组织下拉
                modalIsFirstMaterialApply: false, // modal是否是询价
                customerModal: false, // 客户选择弹框
                cusData: [], // 可选择客户列表
                cusColumns: [
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'customerName'
                    },
                    {
                        title: '客户编码',
                        align: 'center',
                        minWidth: 80,
                        key: 'customerCode'
                    },
                    {
                        title: '上级客户',
                        align: 'center',
                        minWidth: 120,
                        key: 'null'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            const statusFlag = params.row.status === 3;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: statusFlag ? 'success' : 'default'
                                    }
                                },
                                statusFlag ? '有效' : '无效'
                            );
                        }
                    },
                    {
                        title: '操作',
                        minWidth: 100,
                        align: 'center',
                        fixed: 'right',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'success',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.selectionCustomer(params.row);
                                            }
                                        }
                                    },
                                    '选择'
                                )
                            ]);
                        }
                    }
                ],
                tabsName: '', // modal tabs index
                inquiryResult: {}, // 询价结果
                inquiryInfo: {}, // 反馈信息
                SHENQING_TXT: 'shenqing',
                XUNJIA_TXT: 'xunjia',
                FANKUI_TXT: 'fankui',
                inquiryResultTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '供应商名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '包装单位 ',
                        align: 'center',
                        minWidth: 120,
                        key: 'unitName'
                    },
                    {
                        title: '税率',
                        align: 'center',
                        minWidth: 120,
                        key: 'taxRate'
                    },
                    {
                        title: '市场指导价',
                        align: 'center',
                        minWidth: 120,
                        key: 'marketPrice'
                    },
                    {
                        title: '币种',
                        align: 'center',
                        minWidth: 120,
                        key: 'currencyName'
                    },
                    {
                        title: '询价时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.inquiryTime, 'long')
                            );
                        }
                    }
                    // {
                    //     title: '供应商选择',
                    //     align: 'center',
                    //     minWidth: 120
                    // }
                ],
                hasInquiryTask: false, // 是否已经发起了询价
                hasInquiryTaskResult: false, // 是否已经有了询价结果
                currentInquiryId: '', // 当前询价id
                supplierArr: [] // 供应商id（客户id）选择列表
            };
        },
        methods: {
            add () {
                // this.modalShowFlag = true;
                this.getAllSelectData(() => {
                    this.addItem('新增首营物料申请');
                    this.modalIsFirstMaterialApply = false;
                });
            },
            async getAllSelectData (cb) {
                this.getFieldValuesData(
                    'specialty_group',
                    'customerNameArr'
                );
                this.getFieldValuesData('outbound_method', 'outboundMethodNameArr');
                this.getFieldValuesData('delivery_method', 'deliveryMethodNameArr');
                this.getPurchaseOrganizationList(cb);
            },
            // 获取所有采购组织
            async getPurchaseOrganizationList (cb) {
                if (
                    cb &&
                    typeof cb === 'function' &&
                    this.purchaseOrganizationArr.length
                ) {
                    cb();
                    return;
                }
                const res = await getPurchaseOrganizationList({});
                if (res.status === this.code) {
                    this.purchaseOrganizationArr = res.content;
                    if (cb) cb();
                }
            },
            // 获取可选择客户list
            async getCustomer () {
                this.modelLoading = true;
                const res = await salesChangeList({
                    customerName: this.subCustomerName
                });
                if (res.status === this.code) {
                    this.modelLoading = false;
                    this.cusData = res.content;
                }
            },
            getTableList () {
                const params = Object.assign(
                    {},
                    this.tableComAttr,
                    this.tableQueryAttr
                );
                this.getTableListFn(async call => {
                    const res = await getCommodityTaskList(params);
                    call(res);
                });
            },
            // 选中客户
            async selectionCustomer (row) {
                const { enableCode } = row;
                const res = await submitCommodityTask(this.currentId, enableCode);
                if (res.status === this.code) {
                    this.$Message.success(res.msg); // 提示消息
                    this.getTableList();
                    this.customerModal = false;
                }
            },
            // 询价modal
            showInquiry (row, title) {
                this.getAllSelectData(() => {
                    this.modalIsFirstMaterialApply = true;
                    this.hasInquiryTask = row.inquiryTaskStatus > 0;
                    this.hasInquiryTaskResult = row.inquiryTaskStatus === 2;
                    this.modalTitle = title;
                    this.currentId = row.id;
                    this.currentInquiryId = row.inquiryId;
                    this.tabsName = this.SHENQING_TXT;
                    for (let key in this.formAttr) {
                        this.formAttr[key] = row[key];
                    }
                    setTimeout(() => {
                        this.disabledFlag = true;
                        this.modalShowFlag = true;
                    }, 300);
                });
            },
            // 批量询价
            async togetherMakePrice () {
                if (this.delCheck('请至少选择一项')) {
                    if (!this.checkHasInquiry(this.tableSelectList)) {
                        this.$Message.error('勾选项中有已发起询价或询价结束的申请单，请重新勾选');
                    } else {
                        // 处理批量询价
                        this.$Modal.confirm({
                            title: `确认批量询价吗？`,
                            onOk: async () => {
                                const res = await startInquiryBat(this.tableSelectValue);
                                if (res.status === this.code) {
                                    this.$Message.success(res.msg);
                                    this.getTableList();
                                }
                            }
                        });
                    }
                }
            },
            checkHasInquiry (arr) {
                return arr.every(item => {
                    return item.inquiryTaskStatus === 0;
                });
            },
            /**
             * 重置对象的所有属性
             * @param obj
             * @param resetNumber
             * @param list
             */
            resetObj (obj, resetNumber, list) {
                let newObj = {};
                const isObj = obj => {
                    return Object.prototype.toString.call(obj) === '[object Object]';
                };
                if (!isObj(obj)) {
                    return;
                }
                Object.keys(obj).forEach(item => {
                    if (isObj(obj[item])) {
                        resetObj(obj[item]);
                    } else if (Array.isArray(obj[item])) {
                        newObj[item] = [];
                    } else if (typeof obj[item] === 'number' && !isNaN(obj[item])) {
                        if (list.indexOf(item) !== -1) {
                            newObj[item] = '';
                        } else {
                            newObj[item] = resetNumber || 0;
                        }
                    } else {
                        newObj[item] = '';
                    }
                });
                return newObj;
            },
            modalCancelCst (cb) {
                this.modalShowFlag = false;
                setTimeout(() => {
                    this.disabledFlag = false;
                    this.currentId = '';
                    this.currentInquiryId = '';
                    this.tabsName = this.SHENQING_TXT;
                    this.inquiryResult = {};
                    this.$refs.firstApply && this.$refs.firstApply.getForm().resetFields();
                    this.$refs.firstApplyInner && this.$refs.firstApplyInner.getForm().resetFields();
                    resetObj(this.formAttr);
                    resetObj(this.formAttrInquiryInfo);
                    console.log(this.formAttr);
                    setTimeout(() => {
                        if (this.doubleClickFlag) {
                            this.doubleClickFlag = false;
                            this.modalCancelCst();
                        }
                    }, 100);
                    if (cb && typeof cb === 'function') cb();
                }, 200);
            },
            modalOk (cb) {
                this.$refs.firstApply.getForm().validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res;
                    if (this.currentId) {
                        res = await updateCommodityTask({
                            ...this.formAttr,
                            id: this.currentId
                        });
                    } else {
                        res = await addCommodityTask(this.formAttr);
                    }
                    if (res.status === this.code) {
                        this.$Message.success(res.msg); // 提示消息
                        this.tableComAttr.pageNo = 1;
                        this.getTableList();
                        this.modalCancelCst(() => {
                            if (cb && typeof cb === 'function') cb();
                        }); // 执行取消操作重置信息
                    } else {
                        this.changeLoading();
                    }
                });
            },
            modalOkAgain () {
                this.modalOk(() => {
                    this.modalShowFlag = true;
                });
            },
            // 发起询价
            async modalOkInquiry () {
                const res = await startInquiry(this.currentId);
                if (res.status === this.code) {
                    this.$Message.success(res.msg); // 提示消息
                    this.tableComAttr.pageNo = 1;
                    this.getTableList();
                    this.modalCancelCst(() => {
                    }); // 执行取消操作重置信息
                } else {
                    this.changeLoading();
                }
            },
            handleClickTabs (name) {
                this.tabsName = name;
                if (!this.hasInquiryTaskResult) return;
                switch (name) {
                    case this.XUNJIA_TXT:
                        // 获取询价结果
                        this.getInquiryResult();
                        break;
                    case this.FANKUI_TXT:
                        this.supplierShowFlag = false;
                        // 获取反馈信息
                        this.getInquiryInfo();
                        break;
                    default:
                        this.supplierShowFlag = false;
                        break;
                }
            },
            async getInquiryResult () {
                this.supplierShowFlag = true;
                const res = await getInquiryResult(this.currentInquiryId);
                if (res.status === this.code) {
                    if (res.content) {
                        if (Array.isArray(res.content.items)) {
                            this.inquiryResult = {
                                ...res.content,
                                items: res.content.items.map(item => {
                                    if (item.isChecked === 1) {
                                        this.supplierArr.push(item.id);
                                    }
                                    return {
                                        ...item,
                                        _checked: item.isChecked === 1
                                    };
                                })
                            };
                        }
                    }
                }
            },
            async getInquiryInfo () {
                const res = await getInquiryInfo(this.currentInquiryId);
                if (res.status === this.code) {
                    this.formAttrInquiryInfo = JSON.parse(JSON.stringify(res.content)) || {};
                }
            },
            // 供应商选择
            selectionChangeSupplier (selection) {
                this.supplierArr = selection.map(item => {
                    return item.id;
                });
            },
            async modalOkSupplier () {
                const res = await supplierChecked(this.currentInquiryId, this.supplierArr);
                if (res.status === this.code) {
                    this.$Message.success(res.msg); // 提示消息
                    this.tableComAttr.pageNo = 1;
                    this.getTableList();
                    this.modalCancelCst(); // 执行取消操作重置信息
                } else {
                    this.changeLoading();
                }
            }
        }
    };
</script>
<style lang="less" scoped>

</style>
