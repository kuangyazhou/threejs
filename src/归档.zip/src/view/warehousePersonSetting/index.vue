<template>
    <div class="erp-content" ref="erp">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16" class="mb20">
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.erpOwnerCode"
                        @on-change="searchInventory"
                        placeholder="请选择库存组织"
                    >
                        <Option
                            v-for="item in inventoryOrganizationArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.warehouseCode"
                        :disabled="!tableQueryAttr.erpOwnerCode"
                        @on-change="selectSearch"
                        placeholder="请选择仓库"
                    >
                        <Option
                            v-for="item in warehouseArr"
                            :value="item.value"
                            :key="item.id"
                        >{{ item.label }}
                        </Option>
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.employeeName"
                        placeholder="姓名"
                    ></Input>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                仓储人员列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button v-has="btnRightList.employeeBatchAdd" @click="openUserModal(2)" icon="md-add">批量新增</Button>
                    <Button v-has="btnRightList.employeeAdd" @click="add" icon="md-add">新增</Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>
        <!--用户新增编辑弹窗-->
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel">
            <div class="erp-modal-content">
                <Form
                    ref="formValidate"
                    :model="formAttr"
                    :label-width="120"
                    :rules="ruleValidate">
                    <FormItem label="库存组织" prop="erpOwnerCode">
                        <Select
                            v-model="formAttr.erpOwnerCode"
                            @on-change="searchInventory"
                            placeholder="请选择库存组织"
                        >
                            <Option
                                v-for="item in inventoryOrganizationArr"
                                :value="item.value"
                                :key="item.value"
                            >{{ item.label }}
                            </Option>
                        </Select>
                    </FormItem>
                    <FormItem label="仓库" prop="warehouseCodes">
                        <Select v-model="formAttr.warehouseCodes" placeholder="请选择仓库" multiple
                                @on-open-change="afterSelectWareHouse">
                            <Option v-for="(option, index) in warehouseArr" :value="option.value"
                                    :label="option.label"
                                    :key="index">
                            </Option>
                        </Select>
                    </FormItem>
                    <FormItem label="用户" prop="userName">
                        <Button
                            @click="openUserModal(1)"
                            class="form-button-select"
                            icon="ios-arrow-down"
                        >{{
                            formAttr.userName
                            ? formAttr.employeeName
                            : '请选择用户'
                            }}
                        </Button>
                    </FormItem>
                    <FormItem label="人员编号" class="is-required">
                        <Input disabled v-model="formAttr.employeeCode"></Input>
                    </FormItem>
                    <FormItem label="状态">
                        <Select
                            placeholder="请选择状态"
                            remote v-model="formAttr.status">
                            <Option v-for="item in statusList" :label="item.label"
                                    :value="item.value"
                                    :key="item.value"></Option>
                        </Select>
                    </FormItem>
                    <FormItem label="业主" prop="ownerCodes">
                        <Select v-model="formAttr.ownerCodes" placeholder="请选择业主" multiple>
                            <Option
                                v-for="item in inventoryOrganizationArr"
                                :value="item.value"
                                :key="item.value"
                            >{{ item.label }}
                            </Option>
                        </Select>
                    </FormItem>
                    <FormItem label="角色" prop="roleIds">
                        <Select v-model="formAttr.roleIds" placeholder="请选择角色" multiple>
                            <Option v-for="(option, index) in roleArr" :value="option.id"
                                    :label="option.roleName+'('+option.warehouseCode+')'"
                                    :key="index">
                            </Option>
                        </Select>
                    </FormItem>
                    <FormItem label="PDA绑定仓库">
                        <Select v-model="formAttr.pdaWarehouseCode" placeholder="请选择PDA绑定仓库">
                            <Option v-for="(option, index) in selectWarehouseArr" :value="option.value"
                                    :label="option.label"
                                    :key="index">
                            </Option>
                        </Select>
                    </FormItem>
                    <FormItem label="备注">
                        <Input v-model="formAttr.remark" placeholder="请填写备注"></Input>
                    </FormItem>
                    <FormItem label="助记码">
                        <Input v-model="formAttr.memoryCode" placeholder="请填写助记码"></Input>
                    </FormItem>
                </Form>
            </div>
        </Modal>
        <!--        用户列表弹窗-->
        <Modal
            v-model="userModalShowFlag"
            width="650"
            title="选择用户"
            :mask-closable="maskClosable"
            :footer-hide="addType"
            :loading="userModelLoading"
            @on-ok="userModalOk"
            @on-cancel="userModalCancel"
        >
            <div>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="ios-search"></Icon>
                        查询条件
                    </p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button @click="userSearch" icon="md-search"
                                >搜索
                            </Button>
                            <Button @click="userReset" icon="md-refresh"
                                >重置
                            </Button>
                        </ButtonGroup>
                    </div>
                    <Row :gutter="16">
                        <Col span="12" class="maxWidth">
                            <Input
                                v-model="userTableQuery.realName"
                                @on-search="userSearch"
                                search
                                placeholder="请输入名称"
                            >
                                <Button
                                    @click="userSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                        <Col span="12">
                            <Input
                                v-model="userTableQuery.departmentName"
                                @on-search="userSearch"
                                search
                                placeholder="请输入部门"
                            >
                                <Button
                                    @click="userSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                    </Row>
                </Card>
<!--                <erp-table-->
<!--                    :erpTableTitle="userTableTitle"-->
<!--                    :erpTableData="userTableData"-->
<!--                    :tableLoading="userTableLoading"-->
<!--                    :current="userComAttr.pageNo"-->
<!--                    :showSizer='showSizer'-->
<!--                    :showElevator='showSizer'-->
<!--                    :total="userTotal"-->
<!--                >-->
<!--                </erp-table>-->
                <Table
                    border
                    @on-selection-change="selectUser"
                    :data="userTableData"
                    :columns="userTableTitle"
                    :loading="userTableLoading"
                    height="300"
                ></Table>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { getOrganizationDropList } from '@/api/inventory/inventory';
    import {
        addWarehousePerson,
        editWarehousePerson,
        getWarehousePersonList,
        getUsersList,
        getWarehouseDropList,
        getRoleList,
        batchAddWarehousePerson
    } from '@/api/inventory/warehousePerson';
    import { resetObj } from '@/libs/tools';

    export default {
        name: 'warehousePersonSetting',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    erpOwnerCode: '',
                    warehouseCode: '',
                    employeeName: ''
                }, // 表格查询条件
                formAttr: {
                    userName: '',
                    employeeName: '',
                    status: '',
                    remark: '',
                    erpOwnerCode: '',
                    memoryCode: '',
                    pdaWarehouseCode: '',
                    employeeCode: '',
                    roleIds: [],
                    warehouseCodes: [],
                    ownerCodes: []
                }, // modal 值对象
                ruleValidate: {
                    userName: [
                        { required: true, message: '用户不能为空', trigger: 'blur' }
                    ],
                    roleIds: [
                        { required: true, type: 'array', message: '角色不能为空', trigger: 'change' }
                    ],
                    erpOwnerCode: [
                        { required: true, message: '库存组织不能为空', trigger: 'change' }
                    ],
                    warehouseCodes: [
                        { required: true, type: 'array', message: '仓库编号不能为空', trigger: 'change' }
                    ],
                    ownerCodes: [
                        { required: true, type: 'array', message: '业主不能为空', trigger: 'change' }
                    ]
                },
                erpTableTitle: [
                    {
                        title: '姓名',
                        align: 'center',
                        minWidth: 120,
                        key: 'employeeName'
                    },
                    {
                        title: '编号',
                        align: 'center',
                        minWidth: 90,
                        key: 'employeeCode'
                    },
                    {
                        title: '库存组织',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            const erpOwnerName = params.row.erpOwnerName || '';
                            return h('div', {}, erpOwnerName);
                        }
                    },
                    {
                        title: '仓库',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            const warehouseName = params.row.warehouses.map(item => {
                                return h('Tag', {
                                    props: {
                                        color: 'geekblue'
                                    },
                                    style: {}
                                }, item.warehouseName);
                            });
                            return h('div', {}, warehouseName);
                        }
                    },
                    {
                        title: '角色',
                        align: 'center',
                        minWidth: 300,
                        render: (h, params) => {
                            const roleArr = (params.row.roles || []).map(item => {
                                return h('Tag', {
                                    props: {
                                        color: 'blue'
                                    },
                                    style: {}
                                }, item.roleName);
                            });
                            return h('div', roleArr);
                        }
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            const validFlag = params.row.status === 1;
                            return h('Tag', {
                                props: {
                                    color: validFlag ? 'success' : 'warning'
                                }
                            }, validFlag ? '有效' : '无效');
                        }
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 120,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: { type: 'primary', size: 'small' },
                                        on: {
                                            click: () => {
                                                this.editTableData(
                                                    params,
                                                    '编辑仓储人员',
                                                    this.editBefore
                                                );
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.employeeEdit
                                            }
                                        ]
                                    },
                                    '编辑'
                                )
                            ]);
                        }
                    }
                ], // 表格标题
                userTableQuery: {
                    realName: '',
                    departmentName: ''
                }, // 用户弹窗搜索条件
                userModalShowFlag: false, // 用户弹窗开关
                userTableCommon: [
                    {
                        title: '姓名',
                        align: 'center',
                        minWidth: 100,
                        key: 'realName'
                    },
                    {
                        title: '性别',
                        align: 'center',
                        minWidth: 80,
                        key: 'sexName'
                    },
                    {
                        title: '公司',
                        align: 'center',
                        minWidth: 100,
                        key: 'enterpriseName'
                    },
                    {
                        title: '部门',
                        align: 'center',
                        minWidth: 90,
                        key: 'departmentName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 90,
                        render: (h, params) => {
                            const status =
                                params.row.status === 1 ? '有效' : '无效';
                            return h('span', {}, status);
                        }
                    }
                ],
                userTableTitle: [],
                userTableData: [],
                userTableLoading: false,
                showSizer: false,
                userComAttr: {
                    pageNo: 1,
                    pageSize: 10
                },
                userTotal: 0,
                inventoryOrganizationArr: [], // 库存组织下拉
                warehouseArr: [], // 仓库列表下拉
                selectWarehouseArr: [], // 当前用户已选中的仓库
                roleArr: [], // 角色数组
                addType: true, // true为单个新增false批量新增
                curUserList: [], // 选中的当前用户
                userModelLoading: false
            };
        },
        created () {
            this.getAllSelectData();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                if (!this.tableQueryAttr.warehouseCode && !this.tableQueryAttr.erpOwnerCode) return;
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getWarehousePersonList(params);
                    getListMixin(res);
                });
            },
            add () {
                this.formAttr = Object.assign({}, this.formAttr, {
                    status: 1,
                    ownerCodes: [this.tableQueryAttr.erpOwnerCode],
                    erpOwnerCode: this.tableQueryAttr.erpOwnerCode,
                    warehouseCodes: [this.tableQueryAttr.warehouseCode]
                });
                this.selectWarehouseArr = this.warehouseArr.filter(item => {
                    return item.value === this.tableQueryAttr.warehouseCode;
                });
                this.addItem('单个新增仓储人员');
                this.getRoleData();
            },
            getAllSelectData () {
                this.getInventoryOrganizationList();
            },
            // 选择库存之后
            searchInventory (val) {
                this.getWarehouseList(val);
            },
            // 库存组织下拉
            async getInventoryOrganizationList () {
                const res = await getOrganizationDropList();
                if (res.status === this.code) {
                    this.inventoryOrganizationArr = res.content.map(item => {
                        return {
                            label: item.inventoryOrganizationName,
                            value: item.inventoryOrganizationCode
                        };
                    });
                    if (this.inventoryOrganizationArr.length && !this.tableQueryAttr.erpOwnerCode) {
                        this.tableQueryAttr.erpOwnerCode = this.inventoryOrganizationArr[0].value;
                        this.getWarehouseList(this.tableQueryAttr.erpOwnerCode);
                    }
                }
            },
            // 获取库存组织关联的仓库
            async getWarehouseList (id) {
                if (!id) return;
                const params = Object.assign({}, {
                    inventoryOrganizationCode: id
                });
                const res = await getWarehouseDropList(params);
                if (res.status === this.code) {
                    this.warehouseArr = res.content.map((item, index) => {
                        return {
                            label: item.warehouseName,
                            value: item.warehouseCode,
                            id: index
                        };
                    });
                    if (this.warehouseArr.length) {
                        this.tableQueryAttr.warehouseCode = this.warehouseArr[0].value;
                        if (this.tableQueryAttr.warehouseCode && this.tableQueryAttr.erpOwnerCode && !this.modalShowFlag) {
                            this.getTableList();
                        }
                    } else {
                        this.tableQueryAttr.warehouseCode = '';
                    }
                }
            },
            // 获取可新增的用户列表
            async getUsersList () {
                this.userTableLoading = true;
                const params = Object.assign({}, this.userComAttr, this.userTableQuery, {
                    erpOwnerCode: this.formAttr.erpOwnerCode || this.tableQueryAttr.erpOwnerCode
                });
                const res = await getUsersList(params);
                this.userTableLoading = false;
                if (res.status === this.code) {
                    this.userTableData = res.content;
                }
            },
            // 搜索用户
            userSearch () {
                this.getUsersList();
            },
            // 重置用户
            userReset () {
                resetObj(this.userTableQuery);
                this.getUsersList();
            },
            // 打开用户弹窗
            openUserModal (num) {
                if (num === 1) {
                    this.addType = true;
                    const tdAction = [
                        {
                            title: '操作',
                            key: 'action',
                            width: 100,
                            align: 'center',
                            render: (h, params) => {
                                return h('div', [
                                    h(
                                        'Button',
                                        {
                                            props: { type: 'primary', size: 'small' },
                                            on: {
                                                click: () => {
                                                    this.selectionUser(params.row);
                                                }
                                            }
                                        },
                                        '选择'
                                    )
                                ]);
                            }
                        }
                    ];
                    this.userTableTitle = [...this.userTableCommon, ...tdAction];
                } else {
                    this.addType = false;
                    const selection = [
                        {
                            type: 'selection',
                            width: 60,
                            align: 'center'
                        }
                    ];
                    this.userTableTitle = [...selection, ...this.userTableCommon];
                }
                this.userComAttr.pageNo = 1;
                this.getUsersList();
                this.userModalShowFlag = true;
            },
            // 选中新增用户
            selectionUser (val) {
                this.formAttr = Object.assign({}, this.formAttr, {
                    employeeName: val.realName,
                    userName: val.userName
                });
                this.userModalShowFlag = false;
            },
            // 选择仓库后获取角色列表
            afterSelectWareHouse (val) {
                if (!val && this.formAttr.warehouseCodes.length) {
                    this.getRoleData();
                    this.selectWarehouseArr = this.warehouseArr.filter(item => {
                        return this.formAttr.warehouseCodes.includes(item.value);
                    });
                }
            },
            // 获取角色数据
            async getRoleData () {
                if (this.formAttr.warehouseCodes.length === 0) return;
                const params = {
                    warehouseCodes: this.formAttr.warehouseCodes.join()
                };
                const res = await getRoleList(params);
                if (res.status === this.code) {
                    this.roleArr = res.content;
                }
            },
            // 新增编辑仓储人员
            modalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res;
                    if (this.currentId) {
                        const params = Object.assign({}, this.formAttr, {
                            id: this.currentId
                        });
                        res = await editWarehousePerson(params);
                    } else {
                        const params = Object.assign({}, this.formAttr);
                        res = await addWarehousePerson(params);
                    }
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    } else {
                        this.changeLoading();
                    }
                });
            },
            // 编辑前格式化
            editBefore (data) {
                const roleIds = data.roles.map(function (item) {
                    return Number(item.roleId);
                });
                const ownerCodes = data.employeeOwners.map(function (item) {
                    return item.ownerCode;
                });
                const warehouseCodes = data.warehouses.map(function (item) {
                    return item.warehouseCode;
                });
                this.formAttr = Object.assign({}, this.formAttr, {
                    roleIds,
                    ownerCodes,
                    warehouseCodes
                });
                this.selectWarehouseArr = this.warehouseArr.filter(item => {
                    return this.formAttr.warehouseCodes.includes(item.value);
                });
                this.getRoleData();
            },
            // 选中用户
            selectUser (val) {
                this.curUserList = val.map(item => {
                    return {
                        employeeName: item.realName,
                        userName: item.userName,
                        erpOwnerCode: this.tableQueryAttr.erpOwnerCode,
                        warehouseCodes: [this.tableQueryAttr.warehouseCode],
                        ownerCodes: [this.tableQueryAttr.erpOwnerCode]
                    };
                });
            },
            // 确认选择用户
            async userModalOk () {
                if (this.curUserList.length === 0) {
                    this.$Message.error('请先勾选用户');
                    return this.changeLoading('userModelLoading');
                }
                const params = Object.assign({}, {
                    params: this.curUserList
                });
                const res = await batchAddWarehousePerson(params);
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.userModalCancel();
                    this.getTableList();
                } else {
                    this.changeLoading();
                }
            },
            userModalCancel () {
                this.userModalShowFlag = false;
                this.curUserList = [];
                this.userTableTitle = [];
            }
        }
    };
</script>

<style scoped lang="less">
/deep/ .ivu-transfer-list {
    width: 250px;
    height: 400px;
}
/deep/ .ivu-transfer-operation {
    .ivu-btn {
        height: 60px;
    }
}
.is-required {
    /deep/ .ivu-form-item-label {
        &::before {
            content: '*';
            display: inline-block;
            margin-right: 4px;
            line-height: 1;
            font-family: SimSun;
            font-size: 12px;
            color: #ed4014;
        }
        .ivu-tooltip {
            padding: 10px 12px 10px 0;
        }
    }
}
</style>
