<template>
    <div class="user-admin">
        <!-- <h1>用户管理</h1> -->
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon> 查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5">
                    <Input
                        v-model="tableQueryAttr.realName"
                        placeholder="用户姓名"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5">
                    <Input
                        v-model="tableQueryAttr.mobile"
                        placeholder="手机号码"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <!-- <Col span="5">
                    <Select
                        filterable
                        placeholder="用户状态"
                        @on-change="selectSearch"
                        v-model="tableQueryAttr.status"
                    >
                        <Option
                            v-for="(item, index) in slectList"
                            :label="item.label"
                            :value="item.value"
                            :key="index"
                        ></Option>
                    </Select>
                </Col>
                <Col span="5">
                    <Select
                        filterable
                        placeholder="锁定状态"
                        @on-change="selectSearch"
                        v-model="tableQueryAttr.locked"
                    >
                        <Option
                            v-for="(item, index) in statusList"
                            :label="item.label"
                            :value="item.value"
                            :key="index"
                        ></Option>
                    </Select>
                </Col>-->
            </Row>
        </Card>
        <Card :border="false">
            <p slot="title"><Icon type="md-list"></Icon>用户列表</p>
            <div slot="extra">
                <Button @click="add" v-has="btnRightList.platfromUserCreate"  icon="md-add">新增</Button>
            </div>
            <erp-table
                :erpTableTitle="userTitle"
                :erpTableData="erpTableData"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
            ></erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel"
        >
            <div class="erp-modal-content">
                <Form :model="formAttr" :rules="ruleValidate" ref="formValidate" :label-width="120">
                    <FormItem label="用户名" prop="userName">
                        <Input v-model="formAttr.userName" placeholder="请输入用户名"></Input>
                    </FormItem>
                    <!-- <FormItem label="所属组织">
                        {{formAttr.parentOrganizationName}}
                        <Button type="primary" @click="selectSwitch=true">选择</Button>
                    </FormItem>-->
                    <FormItem label="性别" prop="sex">
                        <RadioGroup v-model="formAttr.sex">
                            <Radio v-for="item in sexRadio" :label="item.value" :key="item.index">
                                <span>{{ item.label }}</span>
                            </Radio>
                        </RadioGroup>
                    </FormItem>
                    <FormItem label="重置密码" v-if="currentId">
                        <Button type="primary" @click="resetPassword()">重置</Button>
                    </FormItem>
                    <FormItem label="用户姓名" prop="realName">
                        <Input v-model="formAttr.realName" placeholder="请输入用户名"></Input>
                    </FormItem>
                    <FormItem label="邮箱">
                        <Input v-model="formAttr.email" placeholder="邮箱"></Input>
                    </FormItem>
                    <FormItem label="手机号码" prop="mobile">
                        <Input v-model="formAttr.mobile" placeholder="手机号码"></Input>
                    </FormItem>
                    <FormItem label="身份证号">
                        <Input v-model="formAttr.idNumber" placeholder="身份证号"></Input>
                    </FormItem>
                    <div v-show="currentId">
                        <!-- <FormItem label="用户状态">
                            <RadioGroup v-model="formAttr.status">
                                <Radio
                                    v-for="item in statusRadio"
                                    :label="item.value"
                                    :key="item.index"
                                >
                                    <span>{{item.label}}</span>
                                </Radio>
                            </RadioGroup>
                        </FormItem>
                        <FormItem label="锁定状态">
                            <RadioGroup v-model="formAttr.locked">
                                <Radio
                                    v-for="item in lockRadio"
                                    :label="item.value"
                                    :key="item.index"
                                >
                                    <span>{{item.label}}</span>
                                </Radio>
                            </RadioGroup>
                        </FormItem>-->
                        <FormItem label="创建时间">
                            <Input v-model="formAttr.createTime" disabled placeholder="创建时间"></Input>
                        </FormItem>
                        <FormItem label="创建人">
                            <Input v-model="formAttr.createUserRealName" disabled placeholder="创建人"></Input>
                        </FormItem>
                        <FormItem label="最后修改时间">
                            <Input v-model="formAttr.updateTime" disabled placeholder="最后修改时间"></Input>
                        </FormItem>
                        <FormItem label="最后修改人">
                            <Input
                                v-model="formAttr.updateUserRealName"
                                disabled
                                placeholder="最后修改人"
                            ></Input>
                        </FormItem>
                    </div>
                </Form>
            </div>
        </Modal>
        <Modal
            v-model="orgModal"
            @on-ok="confirmOrg"
            title="组织选择"
            :mask-closable="false"
            width="960"
        >
            <div class="erp-modal-content">
                <div class="search-container">
                    <Input v-model="orgName" clearable placeholder="组织名称" class="searchInput"></Input>
                    <Button type="primary" @click="searchName">搜索</Button>
                </div>
                <div class="org-tag">
                    <Row>
                        <!-- <Col span="2"> -->
                        <span>所属组织：</span>
                        <!-- </Col> -->
                        <!-- <Col span="20"> -->
                        <Tag
                            v-for="(item, index) in orgBelong"
                            closable
                            color="success"
                            type="dot"
                            :name="item.id"
                            :key="index"
                            @on-close="delOrg"
                        >{{ item.organizationName }}</Tag>
                        <!-- </Col> -->
                    </Row>
                </div>
                <!-- <Card :border="false" class="wrapper-query"></Card> -->
                <Table :columns="orgColumns" :data="orgData"></Table>
                <div class="page-contaner">
                    <!-- <Page
                    :current="Page.current"
                    @on-change="pageChange"
                    @on-page-size-change="pageSizeChange"
                    show-size
                    :total="Page.total"
                    show-elevator
                    />-->
                </div>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        getUserList,
        createUser,
        updateUser,
        resetPwd,
        updateOrg
    } from '@/api/organization/useradmin';
    import { getOrganizationList, getUserOrg } from '@/api/organization/orgList';
    import { getDate } from '@/libs/tools';
    export default {
        components: { ErpTable },
        mixins: [tableMixin],
        data () {
            return {
                orgModal: false, // 组织选择diallog
                tableQueryAttr: {
                    realName: '',
                    mobile: '',
                    status: '',
                    locked: ''
                },
                formAttr: {
                    userName: '',
                    realName: '',
                    sex: null,
                    mobile: '',
                    email: '',
                    idNumber: '',
                    status: '',
                    locked: '',
                    createTime: '',
                    createUserRealName: '',
                    updateTime: '',
                    updateUserRealName: '',
                    parentOrganizationName: ''
                },
                orgBelong: [
                    // { organizationName: "abc", id: 1 },
                    // { organizationName: "abc", id: 2 },
                    // { organizationName: "abc", id: 3 }
                ],
                orgName: '',
                orgColumns: [
                    {
                        title: '组织名称',
                        align: 'center',
                        minWidth: 80,
                        key: 'organizationName'
                    },
                    {
                        title: '上级组织',
                        align: 'center',
                        minWidth: 80,
                        key: 'parentOrganizationName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 80,
                        key: 'status',
                        render: (h, params) => {
                            const status = params.row.status === 1;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: status ? 'success' : 'default'
                                    }
                                },
                                status ? '有效' : '无效'
                            );
                        }
                    },
                    {
                        title: '是否锁定',
                        align: 'center',
                        minWidth: 80,
                        key: 'locked',
                        render: (h, params) => {
                            const status = params.row.locked === 1;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: status ? 'success' : 'default'
                                    }
                                },
                                status ? '正常' : '锁定'
                            );
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 80,
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.addOrg(params);
                                            }
                                        }
                                    },
                                    '选择'
                                )
                            ]);
                        }
                    }
                ],
                orgData: [],
                // 状态下拉框
                statusList: [
                    {
                        label: '全部',
                        value: ''
                    },
                    {
                        label: '正常',
                        value: 1
                    },
                    {
                        label: '锁定',
                        value: 0
                    }
                ],
                // 性别单选框
                sexRadio: [
                    {
                        label: '男',
                        value: 0
                    },
                    {
                        label: '女',
                        value: 1
                    }
                ],
                // 锁定下拉框
                lockRadio: [
                    {
                        label: '锁定',
                        value: 0
                    },
                    {
                        label: '正常',
                        value: 1
                    }
                ],
                // 状态单选框
                statusRadio: [
                    {
                        label: '无效',
                        value: 0
                    },
                    {
                        label: '有效',
                        value: 1
                    }
                ],
                ruleValidate: {
                    userName: [{ required: true, message: '用户名不能为空' }],
                    sex: [
                        {
                            required: true,
                            message: '性别为必选项',
                            type: 'number',
                            trigger: 'blur'
                        }
                    ],
                    realName: [{ required: true, message: '用户姓名不能为空' }],
                    mobile: [{ required: true, message: '手机号不能为空' }]
                },
                slectList: [
                    {
                        label: '全部',
                        value: ''
                    },
                    {
                        label: '有效',
                        value: 1
                    },
                    {
                        label: '无效',
                        value: 0
                    }
                ],
                // 初始化列表表头
                userTitle: [
                    {
                        type: 'index',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '用户名',
                        minWidth: 100,
                        align: 'center',
                        key: 'userName'
                    },
                    {
                        title: '用户姓名',
                        minWidth: 100,
                        align: 'center',
                        key: 'realName'
                    },
                    {
                        title: '性别',
                        minWidth: 100,
                        align: 'center',
                        // key: "sex"
                        render: (h, params) => {
                            const sex = params.row.sex === 1;
                            return h('span', {}, sex ? '女' : '男');
                        }
                    },
                    {
                        title: '手机号码',
                        minWidth: 100,
                        align: 'center',
                        key: 'mobile'
                    },
                    // {
                    //     title: "状态",
                    //     minWidth: 100,
                    //     align: "center",
                    //     key: "status",
                    //     render: (h, params) => {
                    //         const status = params.row.status == 1;
                    //         return h(
                    //             "Tag",
                    //             {
                    //                 props: {
                    //                     color: status ? "success" : "default"
                    //                 }
                    //             },
                    //             status ? "有效" : "无效"
                    //         );
                    //     }
                    // },
                    // {
                    //     title: "是否锁定",
                    //     minWidth: 100,
                    //     align: "center",
                    //     key: "locked",
                    //     render: (h, params) => {
                    //         const status = params.row.status == 1;
                    //         return h(
                    //             "Tag",
                    //             {
                    //                 props: {
                    //                     color: status ? "success" : "default"
                    //                 }
                    //             },
                    //             status ? "正常" : "锁定"
                    //         );
                    //     }
                    // },
                    {
                        title: '最后更新人',
                        minWidth: 100,
                        align: 'center',
                        key: 'updateUserRealName'
                    },
                    {
                        title: '最后更新时间',
                        minWidth: 120,
                        align: 'center',
                        // key: "updateTime",
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.updateTime, 'long')
                            );
                        }
                    },
                    {
                        title: '操作',
                        fixed: 'right',
                        minWidth: 100,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        attrs: {
                                            style: 'margin-right:6px'
                                        },
                                        on: {
                                            click: () => {
                                                this.editTableData(
                                                    params,
                                                    '用户编辑',
                                                    this.timeFormat
                                                );
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList
                                                    .platfromUserUpdate
                                            }
                                        ]
                                    },
                                    '编辑'
                                ),
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'success',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.orgModal = true;
                                                this.currentId = params.row.id;
                                                this.getOrg();
                                                this.userOrg(params.row);
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList
                                                    .platfromUpdateOrg
                                            }
                                        ]
                                    },
                                    '组织'
                                )
                            ]);
                        }
                    }
                ]
            };
        },
        computed: {},
        watch: {},
        created () {},
        mounted () {},
        destroyed () {},
        methods: {
            add () {
                this.addItem('用户新增');
            },
            modalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res = null;
                    const params = this.currentId
                        ? Object.assign({}, this.formAttr, { id: this.currentId })
                        : Object.assign({}, this.formAttr);
                    if (this.currentId) {
                        res = await updateUser(params);
                    } else {
                        res = await createUser(params);
                    }
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    } else {
                        this.changeLoading();
                    }
                });
            },
            // 重置密码
            async resetPassword () {
                const params = {
                    userId: this.currentId
                };
                const res = await resetPwd(params);
                if (res.status === this.code) {
                    this.$Message.success({
                        duration: 3,
                        content: res.content
                    });
                }
            },
            // 删除组织按钮
            delOrg (e, name) {
                let index = this.orgBelong.findIndex(item => {
                    return item.id === name;
                });
                this.orgBelong.splice(index, 1);
            },
            selectSearch () {},
            searchName () {
                this.getOrg();
            },
            async getTableList () {
                const params = Object.assign(
                    {},
                    this.tableComAttr,
                    this.tableQueryAttr
                );
                this.getTableListFn(async getListMixin => {
                    const res = await getUserList(params);
                    if (res.status === this.code) {
                        getListMixin(res);
                    }
                });
            // this.tableLoading = true;
            // const res = await getUserList(params);
            // this.tableLoading = false;
            // if (res.status === this.code) {
            //     const content = res.content;
            //     this.userData = content.list;
            // }
            },
            // 获取组织列表
            async getOrg () {
                const params = {
                    organizationName: this.orgName
                };
                const res = await getOrganizationList(params);
                if (res.status === this.code) {
                    this.orgData = res.content;
                }
            },
            // 获取用户所属组织
            async userOrg (e) {
                const params = {
                    userId: e.id
                };
                const res = await getUserOrg(params);
                if (res.status === this.code) {
                    this.orgBelong = res.content;
                }
            },
            // 添加组织
            addOrg (params) {
                let index = this.orgBelong.findIndex(item => {
                    return item.organizationName === params.row.organizationName;
                });
                if (index < 0) {
                    this.orgBelong.push({
                        organizationName: params.row.organizationName,
                        id: params.row.id
                    });
                }
            },
            // 组织修改确认
            async confirmOrg () {
                let temp = [];
                this.orgBelong.forEach(item => {
                    temp.push(item.id);
                });
                const params = {
                    userId: this.currentId,
                    organizationIds: temp
                };
                const res = await updateOrg(params);
                if (res.status === this.code) {
                    this.refreshToken();
                    this.orgModal = false;
                    this.$Message.success(res.msg);
                }
            },
            // 格式化时间
            timeFormat (row) {
                this.formAttr.createTime = getDate(row.createTime, 'long');
                this.formAttr.updateTime = getDate(row.updateTime, 'long');
            }
        }
    };
</script>

<style scoped>
.search-container,
.org-tag {
    margin-bottom: 16px;
}
.searchInput {
    width: 180px;
    margin-right: 24px;
}
</style>
