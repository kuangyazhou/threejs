<template>
    <div class="inventoryInit">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.orderType"
                        @on-change="selectSearch"
                        placeholder="请选择单据类型"
                    >
                        <Option
                            v-for="item in orderArr"
                            :value="item.value"
                            :key="item.id"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.warehouseId"
                        @on-change="selectSearch"
                        placeholder="请选择仓库"
                    >
                        <Option
                            v-for="item in warehouseArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
<!--                <Col span="5" class="maxWidth">-->
<!--                    <Select-->
<!--                        placeholder="请选择单据状态"-->
<!--                        @on-change="selectSearch"-->
<!--                        remote-->
<!--                        v-model="tableQueryAttr.auditStatus"-->
<!--                    >-->
<!--                        <Option-->
<!--                            v-for="item in statusArr"-->
<!--                            :label="item.label"-->
<!--                            :value="item.value"-->
<!--                            :key="item.id"-->
<!--                        ></Option>-->
<!--                    </Select>-->
<!--                </Col>-->
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                其他出库单列表
            </p>
            <div slot="extra">
<!--                <ButtonGroup>-->
<!--                    <Button @click="openSendModal"-->
<!--                        icon="md-add"-->
<!--                    >新增</Button>-->
<!--                    <Button-->
<!--                        icon="ios-create-outline"-->
<!--                    >编辑</Button>-->
<!--                    <Button-->
<!--                        icon="md-send"-->
<!--                    >提交</Button>-->
<!--                    <Button-->
<!--                        icon="md-undo"-->
<!--                    >撤回</Button>-->
<!--                    <Button-->
<!--                        icon="md-redo"-->
<!--                    >审核</Button>-->
<!--                    <Button-->
<!--                        icon="ios-key"-->
<!--                    >增加红字</Button>-->
<!--                </ButtonGroup>-->
            </div>
            <erp-table
                ref="salesTable"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>

    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { getWarehouseDropList } from '@/api/inventory/inventory';
    import { getOtherOutboundOrderDetailList } from '@/api/inventory/outboundBusiness/saleOutOrder';
    import { getDate } from '@/libs/tools';
    import { mapGetters } from 'vuex';

    export default {
        name: 'othersOutbound',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    orderType: '',
                    warehouseId: '',
                    auditStatus: ''
                },
                inventoryOrganizationArr: [], // 库存组织下拉
                warehouseArr: [], // 仓库列表下拉
                erpTableTitle: [
                    {
                        title: '出库单号',
                        align: 'center',
                        minWidth: 120,
                        key: 'outboundOrderNo'
                    },
                    {
                        title: '出库类型',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            const orderType = params.row.orderType === 1 ? '报废出库' : '';
                            return h('span', {}, orderType);
                        }
                    },
                    {
                        title: '来源类型',
                        align: 'center',
                        minWidth: 90,
                        key: 'sourceType'
                    },
                    {
                        title: '来源单据号',
                        align: 'center',
                        minWidth: 100,
                        key: 'sourceOrderNo'
                    },
                    {
                        title: '库存组织',
                        align: 'center',
                        minWidth: 120,
                        key: 'inventoryOrganizationName'
                    },
                    {
                        title: '仓库',
                        align: 'center',
                        minWidth: 120,
                        key: 'warehouseName'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityName'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '数量',
                        align: 'center',
                        minWidth: 90,
                        key: 'quantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 90,
                        key: 'unitName'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.effectiveDate)
                            );
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '录入时间',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            const status =
                                params.row.auditStatus === 1 ? '未提交' : params.row.auditStatus === 2 ? '已提交' : '已审核';
                            return h('span', {}, status);
                        }
                    }
                    // {
                    //     title: '操作',
                    //     key: 'action',
                    //     width: 140,
                    //     align: 'center',
                    //     fixed: 'right',
                    //     render: (h, params) => {
                    //         return h('div', [
                    //             h(
                    //                 'Button',
                    //                 {
                    //                     props: {
                    //                         type: 'primary',
                    //                         size: 'small'
                    //                     },
                    //                     style: {
                    //                         marginRight: '5px'
                    //                     },
                    //                     on: {
                    //                         click: () => {
                    //                             this.currentId = params.row.orderId;
                    //                             this.openOutOrderModal();
                    //                         }
                    //                     }
                    //                 },
                    //                 '查看'
                    //             )
                    //         ]);
                    //     }
                    // }
                ],
                orderArr: [
                    {
                        id: 1,
                        label: '报废出库',
                        value: 1
                    }
                ] // 订单类型
            };
        },
        computed: {
            ...mapGetters([
                'inventoryOrganizationId'
            ])
        },
        created () {
            this.getAllSelectData();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                if (!this.tableQueryAttr.warehouseId) return;
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr, {
                            orderType: this.tableQueryAttr.orderType ? this.tableQueryAttr.orderType : 1
                        }
                    );
                    const res = await getOtherOutboundOrderDetailList(params);
                    getListMixin(res);
                });
            },
            getAllSelectData () {
                this.getWarehouseList();
            },
            // 获取库存组织关联的仓库
            async getWarehouseList () {
                const params = Object.assign({}, {
                    inventoryOrganizationId: this.inventoryOrganizationId
                });
                const res = await getWarehouseDropList(params);
                if (res.status === this.code) {
                    this.warehouseArr = res.content.map(item => {
                        return {
                            label: item.warehouseName,
                            value: item.id
                        };
                    });
                    if (this.warehouseArr.length) {
                        this.tableQueryAttr.warehouseId = this.warehouseArr[0].value;
                        this.getTableList();
                    }
                }
            }
        }
    };
</script>

<style scoped lang="less">
.redOrder{
    color: red;
}
</style>
