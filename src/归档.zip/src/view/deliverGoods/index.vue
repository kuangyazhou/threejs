<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-14 14:52:27
 * @LastEditTime: 2019-08-16 10:45:22
 * @LastEditors: Please set LastEditors
 -->
<template>
    <!-- 发货通知单 -->
    <div class="inventoryInit">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="12" class="mb10">
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.inventoryOrganizationId"
                        @on-change="searchInventory"
                        placeholder="请选择库存组织"
                    >
                        <Option
                            v-for="item in inventoryOrganizationArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option>
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <DatePicker placeholder="发货日期" v-model="tableQueryAttr.shipmentDate"></DatePicker>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        placeholder="发货时段"
                        @on-change="search"
                        remote
                        v-model="tableQueryAttr.shipmentTime"
                    >
                        <Option label="全天" :value="1"></Option>
                        <Option label="上午" :value="2"></Option>
                        <Option label="下午" :value="3"></Option>
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.orderNo"
                        placeholder="来源单据号"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
            </Row>
            <Row :gutter="12">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.customerName"
                        placeholder="客户名称"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        placeholder="销售订单类型"
                        @on-change="search"
                        remote
                        v-model="tableQueryAttr.orderType"
                    >
                        <Option
                            v-for="item in orderTypeArr"
                            :label="item.fieldValue"
                            :value="item.id"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        placeholder="单据状态"
                        @on-change="search"
                        remote
                        v-model="tableQueryAttr.shipmentNoticeStatus"
                    >
                        <Option
                            v-for="item in statusArr"
                            :label="item.label"
                            :value="item.value"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                发货通知单列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="add" v-has="btnRightList.goodsSave" icon="md-add">新增</Button>
                    <Button
                        @click="addRed"
                        v-has="btnRightList.goodsSave"
                        icon="ios-add-circle"
                    >新增红字
                    </Button>
                    <Button
                        @click="csvAll"
                        icon="md-arrow-down"
                    >导出excel
                    </Button>
                </ButtonGroup>
            </div>
            <erp-table
                ref="salesTable"
                @on-current-change="currentChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :hasPage="false"
                :total="total"
            ></erp-table>
        </Card>
        <Modal v-model="inveModal" title="选择库存" width="960" @on-close="inveClose" :mask-closable="false">
            <Row :gutter="18" class="mb10">
                <Col span="6">
                    <Select placeholder="选择仓库" remote v-model="batchAttr.warehouseId">
                        <Option
                            v-for="(item ,index) in warArr"
                            :label="item.warehouseName"
                            :value="item.id"
                            :key="index"
                        ></Option>
                    </Select>
                </Col>
                <Col span="6">
                    <DatePicker placeholder="开始时间" v-model="batchAttr.effectiveDateStart"></DatePicker>
                </Col>
                <Col span="6">
                    <DatePicker placeholder="结束时间" v-model="batchAttr.effectiveDateEnd"></DatePicker>
                </Col>
                <Col span="4">
                    <Button type="primary" @click="batchSearch">搜索</Button>
                </Col>
            </Row>
            <Table :data="inveData" :columns="inveTitle"></Table>
            <div slot="footer"></div>
        </Modal>
        <!--选择销售订单弹窗-->
        <Modal
            v-model="sendShowFlag"
            width="960"
            title="销售订单选择"
            :loading="sendModelLoading"
            :mask-closable="false"
            @on-ok="sendModalOk"
            @on-cancel="sendModalCancel"
        >
            <Row :gutter="16" class="mb20">
                <Col span="6">
                    <Select
                        label-in-value
                        v-model="sendQueryAttr.customerEnableCode"
                        @on-change="sendSearch"
                        placeholder="请选择客户"
                        filterable
                        ref="filter"
                    >
                        <Option
                            v-for="item in customerArr"
                            :value="item.customerEnableCode"
                            :label="item.customerName"
                            :key="item.value"
                        ></Option>
                    </Select>
                </Col>
                <Col span="6" class="maxWidth">
                    <DatePicker
                        v-model="sendQueryAttr.inputTimeStart"
                        format="yyyy-MM-dd"
                        type="daterange"
                        @on-change="shipmentDateChange"
                        placeholder="开始时间"
                    ></DatePicker>
                </Col>
                <!-- <Col span="6" class="maxWidth">
                    <DatePicker
                        v-model="sendQueryAttr.shipmentDate"
                        format="yyyy-MM-dd"
                        type="date"
                        @on-change="shipmentDateChange"
                        placeholder="结束时间"
                    ></DatePicker>
                </Col>-->
                <Col span="4">
                    <Button @click="sendSearch" type="primary">搜索</Button>
                </Col>
            </Row>
            <Table
                :columns="sendTableTitle"
                :data="sendTableData"
                @on-selection-change="sendSelection"
                height="400"
                border
            ></Table>
            <!-- <Page
                :current="orderPage.current"
                @on-change="orderPageChange"
                @on-page-size-change="orderPageSize"
                show-sizer
                :total="orderPage.total"
            />-->
        </Modal>

        <!-- 红字订单选择框 -->
        <Modal
            title="发货通知单明细选择"
            width="960"
            v-model="redModal"
            :mask-closable="false"
            @on-ok="redOk"
            @on-cancel="redCancel"
        >
            <Row :gutter="16" class="mb20">
                <Col span="6">
                    <Select
                        label-in-value
                        v-model="redQueryAttr.customerId"
                        @on-change="redSearch"
                        placeholder="请选择客户"
                        filterable
                        ref="filter"
                    >
                        <Option
                            v-for="item in customerArr"
                            :value="item.customerId"
                            :label="item.customerName"
                            :key="item.value"
                        ></Option>
                    </Select>
                </Col>
                <Col span="4">
                    <Select
                        placeholder="选择仓库"
                        remote
                        @on-change="redSearch"
                        v-model="redQueryAttr.warehouseCode"
                    >
                        <Option
                            v-for="(item,index) in warArr"
                            :label="item.warehouseName"
                            :value="item.warehouseCode"
                            :key="index"
                        ></Option>
                    </Select>
                </Col>
                <Col span="4">
                    <DatePicker v-model="redQueryAttr.shipmentDate" placeholder="选择日期"></DatePicker>
                </Col>
                <Col span="4">
                    <Select
                        placeholder="发货时段"
                        remote
                        v-model="redQueryAttr.shipmentTime"
                        @on-change="redSearch"
                    >
                        <Option label="全天" :value="1"></Option>
                        <Option label="上午" :value="2"></Option>
                        <Option label="下午" :value="3"></Option>
                    </Select>
                </Col>
                <Col span="4">
                    <Button @click="redSearch" type="primary">搜索</Button>
                </Col>
            </Row>
            <Table
                height="400"
                :columns="redColumns"
                :data="redTable"
                @on-selection-change="redSelect"
            ></Table>
        </Modal>
        <!-- 新增编辑出库单弹窗-->
        <Modal
            v-model="modalShowFlag"
            width="960"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-cancel="modalCancel"
        >
            <div>
                <Form :model="formAttr" ref="formValidate" :rules="ruleValidate" :label-width="120">
                    <Row>
                        <Col span="12">
                            <FormItem label="发货通知单号">
                                <Input disabled v-model="formAttr.orderNo" placeholder="发货通知单号"></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="库存组织">
                                <Input
                                    disabled
                                    :class="{ redOrder: Boolean(formAttr.isRedOrder) }"
                                    v-model="formAttr.inventoryOrganizationName"
                                    placeholder="请输入出库类型"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="客户">
                                <!-- :disabled="formAttr.shipmentNoticeStatus===3||Boolean(formAttr.isRedNotice)" -->
                                <Input
                                    v-model="formAttr.customerName"
                                    disabled
                                    placeholder="客户"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="识别码" prop="identificationCode">
                                <Select
                                    v-model="formAttr.identificationCode"
                                    :disabled="Boolean(formAttr.isRedNotice)||isRed||readonly"
                                    placeholder="识别码"
                                >
                                    <Option
                                        v-for="item in addressArr"
                                        :key="item.index"
                                        :value="item.id"
                                        :label="item.identificationCode"
                                    ></Option>
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span="24">
                            <FormItem label="收货地址">
                                <Input
                                    v-model="formAttr.customerAddress"
                                    :disabled="Boolean(formAttr.isRedNotice)||isRed||readonly"
                                    placeholder="收货地址"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="发货时间" prop="shipmentDate">
                                <DatePicker
                                    :options="dateOptions"
                                    v-model="formAttr.shipmentDate"
                                    :disabled="Boolean(formAttr.isRedNotice)||isRed||readonly"
                                    placeholder="发货时间"
                                ></DatePicker>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="发货时段" prop="shipmentTime">
                                <Select
                                    v-model="formAttr.shipmentTime"
                                    :disabled="Boolean(formAttr.isRedNotice)||isRed||readonly"
                                    placeholder="发货时段"
                                >
                                    <Option label="全天" :value="1"></Option>
                                    <Option label="上午" :value="2"></Option>
                                    <Option label="下午" :value="3"></Option>
                                </Select>
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="md-list"></Icon>
                        发货通知单明细列表
                    </p>
                    <div slot="extra"></div>
                    <Table border :columns="orderDetailTableTitle" :data="orderDetailTableData">
                        <template slot-scope="{row,index}" slot="sourceTypeName">{{'销售订单'}}</template>
                    </Table>
                </Card>
            </div>
            <div slot="footer">
                <Button @click="modalCancel">取消</Button>
                <Button @click="modalSave" v-if="!readonly||isRed" type="primary">保存</Button>
                <Button @click="modalSubmit" v-if="!readonly" type="warning">提交</Button>
            </div>
        </Modal>
        <Modal v-model="printModalShowFlag"
               width="1060"
               title="打印预览"
               :mask-closable="maskClosable"
               @on-ok="printModalOk"
               @on-cancel="printModalCancel">
            <div style="max-height: 700px; overflow-y: auto">
                <iframe style="width: 990px; height: 100%" :src="printDeliverGoodsNoPrice" frameborder="0"
                        ref="iframe"></iframe>
            </div>
        </Modal>
        <Modal v-model="printPriceModalShowFlag"
               width="1060"
               title="打印预览"
               :mask-closable="maskClosable"
               @on-ok="printPriceModalOk"
               @on-cancel="printModalCancel">
            <div style="max-height: 700px; overflow-y: auto">
                <iframe style="width: 990px; height: 100%" :src="printDeliverGoodsPrice" frameborder="0"
                        ref="iframePrice"></iframe>
            </div>
        </Modal>
    </div>
</template>

<script>
    import { mapGetters } from 'vuex';
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { getDate, resetObj, environmentConfig } from '@/libs/tools';
    import { getOrganizationDropList } from '@/api/inventory/inventory';
    import { getSaveCustomerList } from '@/api/saleManage/sale';
    import {
        adviceAudit,
        adviceDel,
        adviceDetail,
        adviceList,
        adviceSave,
        adviceSubmit,
        adviceUpdate,
        getInve,
        getOrderDetail,
        getPrintInfo,
        getUserAddress,
        getWarhouse
    } from '@/api/outGoods/index';

    export default {
        name: 'saleOutOrder',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        computed: {
            ...mapGetters(['salerId']),
            readonly: function () {
                return this.formAttr.shipmentNoticeStatus === 3;
            },
            printDeliverGoodsNoPrice () {
                return environmentConfig('printDeliverGoodsNoPrice');
            },
            printDeliverGoodsPrice () {
                return environmentConfig('printDeliverGoodsPrice');
            }
        },
        data () {
            return {
                erpTableTitleCst: [
                    {
                        title: '发货通知单号',
                        align: 'center',
                        minWidth: 180,
                        key: 'shipmentNoticeCode'
                    },
                    {
                        title: '库存组织',
                        align: 'center',
                        minWidth: 200,
                        key: 'inventoryOrganizationName'
                    },
                    {
                        title: '仓库',
                        align: 'center',
                        minWidth: 120,
                        key: 'warehouseName'
                    },
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 200,
                        key: 'customerName'
                    },
                    {
                        title: '发货日期',
                        align: 'center',
                        minWidth: 110,
                        key: 'shipmentDate'
                    },
                    {
                        title: '发货时段',
                        align: 'center',
                        minWidth: 120,
                        key: 'shipmentTimeName'
                    },
                    {
                        title: '来源类型',
                        align: 'center',
                        minWidth: 120,
                        key: 'sourceTypeName'
                    },
                    {
                        title: '来源单据号',
                        align: 'center',
                        minWidth: 180,
                        key: 'orderNo'
                    },
                    {
                        title: '销售类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'orderTypeName'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 190,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 190,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 120,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 120,
                        key: 'brandName'
                    },
                    {
                        title: '数量',
                        align: 'center',
                        minWidth: 60,
                        key: 'quantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 60,
                        key: 'unitName'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    {
                        title: '生产日期',
                        align: 'center',
                        minWidth: 110,
                        key: 'producedDate'
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 120,
                        // key: 'effectiveDate'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.effectiveDate)
                            );
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 220,
                        key: 'supplierName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 90,
                        key: 'shipmentNoticeStatusName'
                    }
                ], // 计算后供导出的标题
                erpTableDataCst: [], // 计算后供导出的数据
                addressArr: [], // 收货地址数据
                batchArr: [], // 批号数据源
                inveModal: false, // 选择库存
                tableQueryAttr: {
                    shipmentTime: 1, // 发货时段 1全天 2上午 3下午
                    shipmentDate: '', // 发货日期
                    inventoryOrganizationId: '', // 库存组织
                    orderNo: '', // 来源单据号
                    customerName: '', // 客户名称
                    orderType: '', // 订单类型
                    shipmentNoticeStatus: '' // 单据状态
                },
                inventoryOrganizationId: '', // 库存组织
                inventoryOrganizationName: '', // 库存名称
                inventoryOrganizationArr: [], // 库存组织下拉
                warehouseArr: [], // 仓库列表下拉
                orderTypeArr: [], // 销售订单类型数据
                redModal: false, // 红字modal
                redTable: [], // 红字订单表格数据
                redSelectValue: [], // 红字订单已选择数据
                ids: [], // 保存出库通知单明细的id
                orderId: '', // 订单id
                customerArr: [], // 客户数据
                // 红字订单搜索
                redQueryAttr: {
                    inventoryOrganizationId: '',
                    customerId: '',
                    shipmentDate: '',
                    shipmentTime: '',
                    warehouseCode: '' // 仓库编码
                },
                warArr: [], // 仓库组织数据
                dateOptions: {
                    disabledDate (date) {
                        return date && date.valueOf() < (new Date().valueOf() - 24 * 3600 * 1000);
                    }
                },
                orderPage: {
                    current: 1,
                    total: 0,
                    pageNo: 1
                },
                inveIndex: null,
                inveRow: {},
                isRed: false, // 是否红字订单
                inveData: [], // 库存数据
                // 批号搜索条件
                batchAttr: {
                    warehouseId: '',
                    effectiveDateStart: '',
                    effectiveDateEnd: ''
                },
                ruleValidate: {
                    shipmentDate: [
                        {
                            required: true,
                            message: '发货时间不可为空',
                            type: 'date',
                            trigger: 'blur'
                        }
                    ],
                    shipmentTime: [
                        {
                            required: true,
                            message: '发货时段不可为空',
                            type: 'number',
                            trigger: 'blur'
                        }
                    ],
                    identificationCode: [
                        {
                            required: false,
                            message: '识别码不可为空',
                            type: 'number',
                            trigger: 'blur'
                        }
                    ]
                },
                erpTableTitle: [
                    {
                        title: '发货通知单号',
                        align: 'center',
                        minWidth: 180,
                        // key: 'shipmentNoticeCode',
                        render: (h, params) => {
                            return h(
                                'span',
                                {
                                    class: {
                                        redOrder: params.row.isRedNotice
                                    }
                                },
                                params.row.shipmentNoticeCode
                            );
                        }
                    },
                    {
                        title: '库存组织',
                        align: 'center',
                        minWidth: 200,
                        key: 'inventoryOrganizationName'
                    },
                    {
                        title: '仓库',
                        align: 'center',
                        minWidth: 120,
                        key: 'warehouseName'
                    },
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 200,
                        key: 'customerName'
                    },
                    {
                        title: '发货日期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.shipmentDate)
                            );
                        }
                    },
                    {
                        title: '发货时段',
                        align: 'center',
                        minWidth: 120,
                        key: 'shipmentTimeName'
                    },
                    {
                        title: '来源类型',
                        align: 'center',
                        minWidth: 120,
                        key: 'sourceTypeName'
                    },
                    {
                        title: '来源单据号',
                        align: 'center',
                        minWidth: 180,
                        key: 'orderNo'
                    },
                    {
                        title: '销售类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'orderTypeName'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 190,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 190,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 120,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 120,
                        key: 'brandName'
                    },
                    {
                        title: '数量',
                        align: 'center',
                        minWidth: 60,
                        key: 'quantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 60,
                        key: 'unitName'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    // {
                    //     title: '库存数量',
                    //     align: 'center',
                    //     minWidth: 120,
                    //     key: 'leftQuantity'
                    // },
                    {
                        title: '生产日期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.producedDate)
                            );
                        }
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.effectiveDate)
                            );
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 220,
                        key: 'supplierName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 90,
                        key: 'shipmentNoticeStatusName'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 300,
                        align: 'center',
                        fixed: 'right',
                        render: (h, params) => {
                            let element = null;
                            if (params.row.shipmentNoticeStatus === 1) {
                                element = [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                size: 'small',
                                                type: 'warning'
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList
                                                        .goodsSubAndReturn
                                                }
                                            ],
                                            class: 'mr6',
                                            on: {
                                                click: () => {
                                                    // 提交
                                                    this.formAttr.id =
                                                        params.row.id;
                                                    this.modalSubmit({
                                                        id: params.row.id,
                                                        operationType: 1
                                                    });
                                                }
                                            }
                                        },
                                        '提交'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                size: 'small',
                                                type: 'error'
                                            },
                                            class: 'mr6',
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList
                                                        .goodsDel
                                                }
                                            ],
                                            on: {
                                                click: () => {
                                                    this.del(params.row);
                                                }
                                            }
                                        },
                                        '删除'
                                    )
                                ];
                            }
                            if (params.row.shipmentNoticeStatus === 2) {
                                element = [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                size: 'small',
                                                type: 'default'
                                            },
                                            class: 'mr6',
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList
                                                        .goodsSubAndReturn
                                                }
                                            ],
                                            on: {
                                                click: () => {
                                                    // 撤回
                                                    this.formAttr.id =
                                                        params.row.id;
                                                    this.modalSubmit({
                                                        id: params.row.id,
                                                        operationType: 2
                                                    });
                                                }
                                            }
                                        },
                                        '撤回'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                size: 'small',
                                                type: 'warning'
                                            },
                                            class: 'mr6',
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList
                                                        .goodsAudit
                                                }
                                            ],
                                            on: {
                                                click: () => {
                                                    this.formAttr.id =
                                                        params.row.id;
                                                    this.audit(params.row);
                                                }
                                            }
                                        },
                                        '审核'
                                    )
                                ];
                            }
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            size: 'small',
                                            type: 'primary'
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.goodsUpdate
                                            }
                                        ],
                                        class: 'mr6',
                                        on: {
                                            click: () => {
                                                this.editTableData(
                                                    params,
                                                    params.row
                                                        .shipmentNoticeStatus === 3
                                                        ? '查看发货通知单'
                                                        : '编辑发货通知单',
                                                    this.formatForm
                                                );
                                                this.adviceDetail(params.row);
                                            }
                                        }
                                    },
                                    params.row.shipmentNoticeStatus === 3
                                        ? '查看'
                                        : '编辑'
                                ),
                                params.row.shipmentNoticeStatus === 3 ? h(
                                    'Button',
                                    {
                                        props: { size: 'small' },
                                        class: 'mr6',
                                        on: {
                                            'click': () => {
                                                this.getPrintDetail(params.row, (res) => {
                                                    this.printModalShowFlag = true;
                                                    this.prepareData(JSON.stringify(res), 'iframe');
                                                });
                                            }
                                        }
                                    },
                                    '打印无价'
                                ) : null,
                                params.row.shipmentNoticeStatus === 3 ? h(
                                    'Button',
                                    {
                                        props: { size: 'small' },
                                        class: 'mr6',
                                        on: {
                                            'click': () => {
                                                this.getPrintDetail(params.row, (res) => {
                                                    this.printPriceModalShowFlag = true;
                                                    this.prepareData(JSON.stringify(res), 'iframePrice');
                                                });
                                            }
                                        }
                                    },
                                    '打印有价'
                                ) : null,
                                params.row.shipmentNoticeStatus === 3 ? h(
                                    'Button',
                                    {
                                        props: { size: 'small' },
                                        class: 'mr6',
                                        on: {
                                            'click': () => {
                                                this.getPrintDetail(params.row, (res) => {
                                                    this.csv(res);
                                                });
                                            }
                                        }
                                    },
                                    '导出excel'
                                ) : null,
                                element
                            ]);
                        }
                    }
                ],
                statusArr: [
                    {
                        id: 1,
                        label: '未提交',
                        value: 1
                    },
                    {
                        id: 2,
                        label: '已提交',
                        value: 2
                    },
                    {
                        id: 3,
                        label: '已审核',
                        value: 3
                    }
                ],
                sendShowFlag: false, // 发货通知单弹窗开关
                sendModelLoading: false,
                sendQueryAttr: {
                    inventoryOrganizationId: '',
                    warehouseId: '',
                    customerId: null,
                    inputTimeStart: '',
                    shipmentTime: '',
                    sendQueryAttr: ''
                },
                // 销售订单搜索
                sendTableTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '客户',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerName'
                    },
                    {
                        title: '订单类型',
                        align: 'center',
                        minWidth: 110,
                        key: 'orderTypeName'
                    },
                    {
                        title: '出库类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'outboundTypeName'
                    },
                    {
                        title: '核算年月',
                        align: 'center',
                        minWidth: 120,
                        // key: 'accountingDate'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.accountingDate)
                            );
                        }
                    },
                    {
                        title: '物料编码',
                        align: 'center',
                        minWidth: 110,
                        key: 'commodityCode'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 90,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 100,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '发货数量',
                        align: 'center',
                        minWidth: 90,
                        key: 'quantity'
                    },
                    {
                        title: '剩余数量',
                        align: 'center',
                        minWidth: 120,
                        key: 'leftQuantity'
                    },
                    {
                        title: '单价',
                        align: 'center',
                        minWidth: 120,
                        key: 'salePrice'
                    },
                    {
                        title: '币种',
                        align: 'center',
                        minWidth: 120,
                        key: 'currencyName'
                    },
                    {
                        title: '税率',
                        align: 'center',
                        minWidth: 120,
                        key: 'taxRate'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 120,
                        key: 'unitName'
                    },
                    {
                        title: '金额',
                        align: 'center',
                        minWidth: 120,
                        key: 'amount'
                    },
                    {
                        title: '要求到货',
                        align: 'center',
                        minWidth: 120,
                        // key: 'arriveDate',
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.arriveDate)
                            );
                        }
                    },
                    {
                        title: '要求效期',
                        align: 'center',
                        minWidth: 120,
                        // key: 'effectiveDate'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.effectiveDate)
                            );
                        }
                    },
                    {
                        title: '录入时间',
                        align: 'center',
                        minWidth: 120,
                        // key: 'createTime'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.createTime)
                            );
                        }
                    }
                ], // 发货通知单明细栏目
                sendTableData: [], // 发货通知单明细数据
                curSendData: [], // 选中的发货通知单
                formAttr: {
                    id: '',
                    orderId: '',
                    orderType: '',
                    orderNo: '',
                    warehouse: '',
                    customerAddress: '',
                    addItems: [],
                    deleteItems: [],
                    updateItems: [],
                    inventoryOrganizationId: '',
                    inventoryOrganizationName: '',
                    customerName: '',
                    customerId: '',
                    identificationCode: '',
                    customerAddressId: '',
                    shipmentTime: 1,
                    shipmentDate: '',
                    isRedNotice: 0,
                    warehouseCode: '',
                    supplierEnableCode: '',
                    shipmentNoticeStatus: ''
                },
                shipmentTimeArr: [
                    {
                        id: 1,
                        value: 2,
                        label: '上午'
                    },
                    {
                        id: 2,
                        value: 3,
                        label: '下午'
                    }
                ],
                orderDetailTableTitle: [
                    {
                        title: '来源类型',
                        align: 'center',
                        minWidth: 100,
                        slot: 'sourceTypeName'
                    },
                    {
                        title: '来源单据号',
                        align: 'center',
                        minWidth: 120,
                        key: 'orderNo'
                    },
                    {
                        title: '明细单据号',
                        align: 'center',
                        minWidth: 100,
                        key: 'shipmentNoticeItemCode'
                    },
                    {
                        title: '物料编码',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityCode'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 110,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 90,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '数量',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h('InputNumber', {
                                props: {
                                    // type: 'number',
                                    min: 0,
                                    value: params.row.quantity,
                                    disabled: this.isRed ? false : this.formAttr.shipmentNoticeStatus === 3
                                },
                                on: {
                                    'on-change': val => {
                                        // console.log(val);
                                        // const value = val.target.value;
                                        params.row.quantity = val;
                                        // this.orderDetailTableData[params.index].quantity = val;
                                        this.orderDetailTableData[params.index] = params.row;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '剩余数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'leftQuantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 90,
                        key: 'unitName'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        // key: 'batchNo',
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {
                                        disabled:
                                            Boolean(params.row.isRedNotice) ||
                                            this.readonly
                                    },
                                    on: {
                                        click: () => {
                                            this.inveModal = true;
                                            this.inveIndex = params.index;
                                            this.inveRow = params.row;
                                            this.getBatch(params);
                                            // 查询仓库
                                            this.redChange();
                                        }
                                    }
                                },
                                params.row.batchNo ? params.row.batchNo : '选择批号'
                            );
                            // return h(
                            //     'Select',
                            //     {
                            //         props: {
                            //             type: 'text',
                            //             value: params.row.batchNo
                            //         },
                            //         on: {
                            //             'on-change': e => {
                            //                 params.row.batchNo = e;
                            //             },
                            //             'on-open-change': flag => {
                            //                 if (flag) {
                            //                     const arg = {
                            //                         commodityCode:
                            //                             params.row.commodityCode,
                            //                         customerCommodityId:
                            //                             params.row
                            //                                 .customerCommodityId,
                            //                         effectiveTime:
                            //                             params.row.effectiveDate
                            //                     };
                            //                     this.getBatch(arg, res => {
                            //                         console.log(res);
                            //                         this.batchArr[
                            //                             params.index
                            //                         ] = res;
                            //                         this.batchArr = JSON.parse(
                            //                             JSON.stringify(
                            //                                 this.batchArr
                            //                             )
                            //                         );
                            //                     });
                            //                 }
                            //             }
                            //         }
                            //     },
                            //     (this.batchArr[params.index] || []).map(item => {
                            //         return h('Option', {
                            //             props: {
                            //                 value: item.id,
                            //                 label: item.fieldValue
                            //             }
                            //         });
                            //     })
                            // );
                        }
                    },
                    {
                        title: '生产日期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h('span', {}, getDate(params.row.producedDate));
                        }
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h('span', {}, getDate(params.row.effectiveDate));
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 220,
                        key: 'supplierName'
                    },
                    {
                        title: '录入时间',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h('span', {}, getDate(params.row.createTime));
                        }
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            const status =
                                params.row.auditStatus === 1
                                    ? '未提交'
                                    : params.row.auditStatus === 2
                                        ? '已提交'
                                        : '已审核';
                            return h('span', {}, status);
                        }
                    },
                    {
                        title: '操作',
                        key: 'action',
                        minWidth: 180,
                        align: 'center',
                        fixed: 'right',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'info',
                                            size: 'small',
                                            disabled: this.readonly
                                        },
                                        style: {
                                            marginRight: '5px'
                                        },
                                        on: {
                                            click: () => {
                                                this.orderDetailTableData.splice(
                                                    params.index,
                                                    0,
                                                    this.orderDetailTableData[params.index]
                                                );
                                            }
                                        }
                                    },
                                    '插入'
                                ),
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'error',
                                            size: 'small',
                                            disabled: this.readonly
                                        },
                                        style: {},
                                        on: {
                                            click: () => {
                                                this.$Modal.confirm({
                                                    title: '确定删除吗?',
                                                    onOk: async () => {
                                                        this.orderDetailTableData = this.delArrItemFormIndex(
                                                            this
                                                                .orderDetailTableData,
                                                            params.index
                                                        );
                                                    }
                                                });
                                            }
                                        }
                                    },
                                    '删除'
                                )
                            ]);
                        }
                    }
                ], // 出库单明细表栏目
                orderDetailTableData: [], // 发货通知单明细表数据
                curIndex: null, // 新增插入的当前行号,
                // 库存表头
                inveTitle: [
                    {
                        title: '库存组织',
                        align: 'center',
                        minWidth: 100,
                        key: 'inventoryOrganizationName'
                    },
                    {
                        title: '仓库',
                        align: 'center',
                        minWidth: 100,
                        key: 'warehouseName'
                    },
                    {
                        title: '物料编码',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityCode'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 100,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '可用数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'leftQuantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 100,
                        key: 'unitName'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 100,
                        // key: 'effectiveDate'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.effectiveDate)
                            );
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 220,
                        key: 'supplierName'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        fixed: 'right',
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {
                                        type: 'success',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            this.selectInve(params);
                                        }
                                    }
                                },
                                '选择'
                            );
                        }
                    }
                ],
                redColumns: [
                    { type: 'selection', align: 'center', minWidth: 60 },
                    {
                        title: '来源类型',
                        align: 'center',
                        minWidth: 120,
                        key: 'sourceTypeName'
                    },
                    {
                        title: '来源单据号',
                        align: 'center',
                        minWidth: 120,
                        key: 'sourceOrderNo'
                    },
                    {
                        title: '物料编码',
                        align: 'center',
                        minWidth: 180,
                        key: 'commodityCode'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 120,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 120,
                        key: 'brandName'
                    },
                    {
                        title: '发货数量',
                        align: 'center',
                        minWidth: 120,
                        key: ''
                    },
                    {
                        title: '剩余数量',
                        align: 'center',
                        minWidth: 120,
                        key: 'leftQuantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 120,
                        key: 'unitName'
                    },
                    {
                        title: '发货日期',
                        align: 'center',
                        minWidth: 110,
                        key: ''
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 220,
                        key: 'supplierName'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    {
                        title: '生产日期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h('span', {}, getDate(params.row.producedDate));
                        }
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 120,
                        // key: 'effectiveDate'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.effectiveDate)
                            );
                        }
                    }
                ],
                printDetail: [], // 打印明细列表
                printModalShowFlag: false, // 无价打印预览开关
                printPriceModalShowFlag: false, // 有价打印预览开关
                printTypeFlag: false, // 选择打印模板开关
                currentData: null, // 当前操作的发货通知单数据
                printWidth: 0, // 打印模板宽度
                printHeight: 0 // 打印模板高度
            };
        },
        created () {
            this.getAllSelectData();
        },
        mounted () {
            this.prepareData();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                // if (
                //     !this.tableQueryAttr.warehouseId &&
                //     !this.tableQueryAttr.inventoryOrganizationId
                // )
                //     return;
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr,
                        {
                            shipmentDate: this.getDate(
                                this.tableQueryAttr.shipmentDate
                            )
                        }
                    );
                    let res = await adviceList(params);
                    if (res.status === this.code) {
                        let temp = [];
                        // 将每个发货通知单明细的item展示出来
                        res.content.forEach((item, index) => {
                            if (item.itemList.length) {
                                item.itemList.forEach(listItem => {
                                    let combine = Object.assign({}, item, listItem);
                                    combine.id = item.id;
                                    combine.itemId = listItem.id;
                                    temp.push(combine);
                                });
                            } else {
                                temp.push(item);
                            }
                        });
                        const s = {
                            status: res.status,
                            content: temp,
                            total: res.total
                        };
                        getListMixin(s);
                    } else {
                        getListMixin(res);
                    }
                }, (list) => {
                    this.erpTableDataCst = list.content.map(item => {
                        return {
                            ...item,
                            shipmentDate: this.getDate(item.shipmentDate),
                            producedDate: this.getDate(item.producedDate),
                            effectiveDate: this.getDate(item.effectiveDate),
                            batchNo: `'${item.batchNo}`
                        };
                    });
                });
            },

            // 新增发货通知单
            add () {
                // this.addItem('销售订单选择')
                this.sendShowFlag = true;
                this.getOutboundNoticeOrderDetail();
                this.getCustomer();
            },

            // 获取客户
            async getCustomer () {
                const params = { salerId: this.salerId };
                const res = await getSaveCustomerList(params);
                if (res.status === this.code) {
                    this.customerArr = res.content;
                }
            },

            // 红字订单选择事件
            redSelect (value) {
                this.redSelectValue = value;
            },

            async getRedData () {
                const params = Object.assign(this.redQueryAttr, {
                    shipmentNoticeStatus: 3,
                    shipmentDate: this.getDate(this.redQueryAttr.shipmentDate),
                    isRedNotice: 0
                });
                const res = await adviceList(params);
                if (res.status === this.code) {
                    this.redModal = true;
                    const temp = [];
                    // 遍历itemList
                    res.content.forEach((item, index) => {
                        this.orderId = item.id;
                        item.itemList.forEach((listItem, listIndex) => {
                            const { ...itemArg } = item;
                            const { ...listArg } = listItem;
                            const combine = Object.assign(itemArg, listArg);
                            temp.push(combine);
                        });
                    });
                    this.redTable = temp;
                }
            },
            // 选择红字订单搜索
            redSearch () {
                this.getRedData();
            },

            modalCancel () {
                this.$refs['formValidate'] && this.$refs['formValidate'].resetFields();
                this.formAttr && resetObj(this.formAttr);
                this.currentId = null;
                this.modalShowFlag = false;
                this.isRed = false;
                this.orderDetailTableData = [];
            },

            // 新增红字发货通知单
            async addRed () {
                this.isRed = true;
                this.getRedData();
                this.getCustomer();
                this.redChange();
            },
            // table data 导入excel
            csvAll () {
                this.$Modal.confirm({
                    title: '确认导出ecxel表格吗？',
                    onOk: async () => {
                        console.log(this.erpTableDataCst);
                        this.$refs.salesTable.exportCsv({
                            data: this.erpTableDataCst,
                            columns: this.erpTableTitleCst,
                            quoted: true,
                            filename: '销售出库' + this.getDate(new Date().getTime())
                        });
                    }
                });
            },
            csv (res) {
                console.log(res);
                const { createName, createTime, customerName, outboundCode, receiveAddress, receiveName, receivePhone, shippingPhone, total } = res;
                const columns = [
                    {
                        title: '产品编号',
                        key: 'commodityCode'
                    },
                    {
                        title: '产品货号',
                        key: 'commodityNumber'
                    },
                    {
                        title: '产品名称',
                        key: 'commodityName'
                    },
                    {
                        title: '规格',
                        key: 'commoditySpec'
                    },
                    {
                        title: '单位',
                        key: 'unitName'
                    },
                    {
                        title: '数量',
                        key: 'quantity'
                    },
                    {
                        title: '储运条件',
                        key: 'storageCondition'
                    },
                    {
                        title: '生产企业',
                        key: 'manufacturerName'
                    },
                    {
                        title: '批号',
                        key: 'batchNo'
                    },
                    {
                        title: '有效期',
                        key: 'effectiveDate'
                    },
                    {
                        title: '注册证号',
                        key: 'registerNumber'
                    },
                    {
                        title: '收货单位',
                        key: 'customerName'
                    },
                    {
                        title: '收货地址',
                        key: 'receiveAddress'
                    },
                    {
                        title: '单号',
                        key: 'outboundCode'
                    },
                    {
                        title: '收货人',
                        key: 'receiveName'
                    },
                    {
                        title: '日期',
                        key: 'createTime'
                    },
                    {
                        title: '合计',
                        key: 'total'
                    },
                    {
                        title: '制单',
                        key: 'createName'
                    },
                    {
                        title: '电话',
                        key: 'shippingPhone'
                    }
                ];
                const data = res.itemList.map(item => {
                    return {
                        ...item,
                        effectiveDate: this.getDate(item.effectiveDate),
                        createName,
                        createTime: this.getDate(createTime),
                        customerName,
                        outboundCode,
                        receiveAddress,
                        receiveName,
                        receivePhone,
                        shippingPhone,
                        total
                    };
                });
                this.$Modal.confirm({
                    title: '确认导出ecxel表格吗？',
                    onOk: async () => {
                        console.log(this.erpTableDataCst);
                        this.$refs.salesTable.exportCsv({
                            data,
                            columns,
                            quoted: true,
                            filename: '销售出库' + this.getDate(new Date().getTime())
                        });
                    }
                });
                console.log(data);
            },
            // 发货通知单保存
            async modalSave () {
                // console.log(this.formAttr);
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res = null;
                    // 校验明细
                    let isReq = this.orderDetailTableData.every(item => {
                        return item.quantity && item.batchNo;
                    });
                    if (!isReq) {
                        this.$Message.error('请将订单明细数据填充完整');
                        return;
                    }
                    const newForm = { ...this.formAttr };
                    let date = newForm.shipmentDate instanceof Date ? newForm.shipmentDate.valueOf() : new Date(newForm.shipmentDate).valueOf();
                    if (this.formAttr.id) {
                        if (this.isRed) {
                            const newList = this.orderDetailTableData.map(item => {
                                const { id, ...arg } = item;
                                return Object.assign(
                                    { shipmentNoticeItemId: id },
                                    arg
                                );
                            });
                            const params = Object.assign({}, newForm, {
                                itemList: newList,
                                inventoryOrganizationId: this
                                    .inventoryOrganizationId,
                                shipmentDate: date,
                                isRedNotice: this.isRed ? 1 : 0,
                                id: this.isRed ? null : newForm.id,
                                customerAddressId: newForm.identificationCode
                            });
                            res = await adviceSave(params);
                        } else {
                            const params = Object.assign({}, newForm, {
                                itemList: this.orderDetailTableData,
                                inventoryOrganizationId: this
                                    .inventoryOrganizationId,
                                shipmentDate: date,
                                isRedNotice: this.isRed ? 1 : 0,
                                customerAddressId: newForm.identificationCode
                            });
                            res = await adviceUpdate(params);
                        }
                    } else {
                        const params = Object.assign({}, newForm, {
                            itemList: this.orderDetailTableData,
                            inventoryOrganizationId: this.inventoryOrganizationId,
                            shipmentDate: date,
                            isRedNotice: this.isRed ? 1 : 0,
                            customerAddressId: newForm.identificationCode
                        });
                        res = await adviceSave(params);
                    }
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                        this.isRed = false;
                        // console.log(this.formAttr);
                    }
                });

                // });
            },

            // 发货通知单审核
            async audit (row) {
                const params = { id: row.id };
                const res = await adviceAudit(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },
            del (row) {
                this.$Modal.confirm({
                    title: `确认删除该地址吗？`,
                    onOk: async () => {
                        const params = { id: row.id };
                        const res = await adviceDel(params);
                        if (res.status === this.code) {
                            this.todoOver(res.msg);
                        }
                    }
                });
            },
            // 红字订单选择
            async redOk () {
                if (!this.redSelectValue.length) {
                    this.$Message.error('请至少选择一条数据');
                    return;
                }
                let isEqual = this.redSelectValue.every(item => {
                    return (
                        item.shipmentNoticeId ===
                        this.redSelectValue[0].shipmentNoticeId
                    );
                });
                if (!isEqual) {
                    return this.$Message.error('请选择同一出库通知单的明细');
                }

                this.ids = this.redSelectValue.map(item => {
                    return item.id;
                });

                this.adviceDetail({ id: this.orderId }); // 获取发货通知单详情
                this.getAddress(this.redSelectValue[0].shipmentNoticeId);

                this.editTableData(
                    { row: this.redSelectValue[0] },
                    '新增红字发货通知单',
                    this.formatForm
                );
            },

            redCancel () {
            },

            // 发货通知单提交
            async modalSubmit (params) {
                if (!this.formAttr.id) {
                    this.$Message.error('请先点击保存');
                    return;
                }
                if (!params) return;
                // const params = { id: this.formAttr.id, operationType: 1 };
                const res = await adviceSubmit(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            getAllSelectData () {
                this.getInventoryOrganizationList(); // 获取库存组织
                this.getOrderType(); // 获取销售订单类型
            },

            // 获取发货通知单详情
            async adviceDetail (row) {
                this.orderDetailTableData = [];
                const params = { id: row.shipmentNoticeId || row.id };
                const res = await adviceDetail(params);
                if (res.status === this.code) {
                    const data = res.content;
                    const { itemList, ...order } = data;
                    if (itemList && itemList.length) {
                        let temp = itemList.map(item => {
                            return Object.assign({}, order, item, {
                                sourceId: order.id
                            });
                        });
                        this.orderDetailTableData = [...temp];
                    }
                }
            },
            // 库存组织下拉
            async getInventoryOrganizationList () {
                const res = await getOrganizationDropList();
                if (res.status === this.code) {
                    this.inventoryOrganizationArr = res.content.map(item => {
                        return {
                            label: item.inventoryOrganizationName,
                            value: item.id
                        };
                    });
                    if (
                        this.inventoryOrganizationArr.length &&
                        !this.tableQueryAttr.inventoryOrganizationId
                    ) {
                        this.tableQueryAttr.inventoryOrganizationId = this.inventoryOrganizationArr[0].value;
                        this.inventoryOrganizationId = this.inventoryOrganizationArr[0].value;
                        this.inventoryOrganizationName = this.inventoryOrganizationArr[0].label;
                        // this.getWarehouseList(
                        //     this.tableQueryAttr.inventoryOrganizationId
                        // );
                    }
                }
            },
            // 选择组织查询仓库
            async redChange () {
                // this.getWarehouseList();
                const params = {
                    inventoryOrganizationId:
                        this.redQueryAttr.inventoryOrganizationId ||
                        this.inventoryOrganizationId
                };
                const res = await getWarhouse(params);
                if (res.status === this.code) {
                    this.warArr = res.content;
                }
            },
            // 获取库存组织关联的仓库
            async getWarehouseList (id) {
                if (!id) return;
                const params = Object.assign({}, {
                    inventoryOrganizationId: id
                });
                const res = await getWarehouseDropList(params);
                if (res.status === this.code) {
                    this.warehouseArr = res.content.map(item => {
                        return {
                            label: item.warehouseName,
                            value: item.id
                        };
                    });
                    if (this.warehouseArr.length) {
                        this.tableQueryAttr.warehouseId = this.warehouseArr[0].value;
                        if (
                            this.tableQueryAttr.warehouseId &&
                            this.tableQueryAttr.inventoryOrganizationId &&
                            !this.sendModelLoading
                        ) {
                            this.getTableList();
                        }
                        if (this.sendModelLoading) {
                            this.sendQueryAttr.warehouseId = this.warehouseArr[0].value;
                            this.getOutboundNoticeOrderDetail();
                        }
                    }
                }
            },
            getOrderType () {
                this.getFieldValuesData('order_type', 'orderTypeArr');
            },
            // 选择库存之后
            searchInventory (val) {
                if (val) {
                    this.inventoryOrganizationId = val.value;
                    this.inventoryOrganizationName = val.label;
                }
            },
            // 选中单行后
            currentChange (val) {
                this.currentId = val.orderId;
            },
            // 确认选中发货通知单
            async sendModalOk () {
                if (this.curSendData.length === 0) {
                    this.$Message.error('请先勾选销售订单');
                    return this.sendChangeLoading();
                }
                let temp = this.curSendData.map(item => {
                    const { id, ...arg } = item;
                    return Object.assign(
                        { saleOrderItemId: id },
                        { sourceOrderNo: item.orderNo },
                        arg
                    );
                });
                this.orderDetailTableData = temp;
                this.editTableData({ row: { id: '' } }, '新增发货通知单');
                this.getAddress(this.curSendData[0].customerId);
                this.formAttr.inventoryOrganizationName = this.inventoryOrganizationName;
                this.formAttr.customerName = this.curSendData[0].customerName;
                this.formAttr.customerId = this.curSendData[0].customerId;
                this.formAttr.customerAddress = this.curSendData[0].customerAddress;
            },
            // 批号搜索
            async batchSearch () {
                const params = Object.assign(
                    {
                        commodityCode: this.inveRow.commodityCode,
                        customerCommodityId: this.inveRow.customerCommodityId,
                        effectiveDate: this.getDate(
                            this.inveRow.effectiveDate,
                            'long'
                        )
                    },

                    this.batchAttr,
                    {
                        effectiveDateStart: this.getDate(this.batchAttr.effectiveDateStart, 'long'),
                        effectiveDateEnd: this.getDate(this.batchAttr.effectiveDateEnd, 'long')
                    }
                );
                const res = await getInve(params);
                if (res.status === this.code) {
                    this.inveData = res.content;
                }
            },

            inveClose () {
                resetObj(this.batchAttr);
            },

            // 关闭发货通知单弹窗
            sendModalCancel () {
                this.curSendData = [];
                this.sendShowFlag = false;
            },
            // 处理modal确认异步
            sendChangeLoading () {
                this.sendModelLoading = false;
                this.$nextTick(() => {
                    this.sendModelLoading = true;
                });
            },
            // 获取销售订单
            async getOutboundNoticeOrderDetail () {
                const date = this.sendQueryAttr.inputTimeStart;
                const params = Object.assign(
                    {},
                    this.sendQueryAttr,
                    this.orderPage,
                    {
                        orderDateStart: date[0] && this.getDate(new Date(date[0])),
                        orderDateEnd: date[1] && this.getDate(new Date(date[1]))
                    }
                    // { inputTimeStart: this.getDate(this.sendQueryAttr.inputTimeStart) }
                );
                const res = await getOrderDetail(params);
                if (res.status === this.code) {
                    this.sendTableData = res.content;
                }
            },
            formatForm (row) {
                this.getAddress(row.customerId); // 获取收货地址
                this.$set(this.formAttr, 'shipmentDate', this.getDate(this.formAttr.shipmentDate));
                this.formAttr.identificationCode = row.customerAddressId;
            },
            // 格式化发货时间
            shipmentDateChange (value) {
                this.sendQueryAttr.shipmentDate = value;
                this.getOutboundNoticeOrderDetail();
            },
            sendSearch () {
                this.orderPage.pageNo = 1;
                this.getOutboundNoticeOrderDetail();
            },
            orderPageChange (val) {
                if (val) {
                    this.orderPage.pageNo = val;
                    this.getOutboundNoticeOrderDetail();
                }
            },
            orderPageSize (val) {
                if (val) {
                    this.orderPage.pageSize = val;
                    this.getOutboundNoticeOrderDetail();
                }
            },
            // 发货通知单勾选
            sendSelection (value) {
                this.curSendData = value;
                // this.curSendData = value.map((item, index) => {
                //     return {
                //         orderSourceItemId: item.noticeItemId,
                //         seqNo: index
                //     };
                // });
            },

            // 获取标识码
            async getAddress (id) {
                // this.curSendData[0].customerId
                const params = { customerId: id };
                const res = await getUserAddress(params);
                if (res.status === this.code) {
                    this.addressArr = res.content;
                    if (res.content.length === 1) {
                        this.formAttr.identificationCode = res.content[0].id;
                    }
                }
            },

            // 选择库存
            selectInve (params) {
                Object.keys(params.row).forEach(item => {
                    this.orderDetailTableData[this.inveIndex][item] = params.row[item];
                });
                this.orderDetailTableData[this.inveIndex].quotiety =
                    params.row.inventoryQuotiety;
                this.orderDetailTableData[this.inveIndex].inventoryId =
                    params.row.id;
                this.inveData = [];
                this.inveModal = false;
            },

            // 获取批号
            async getBatch (params) {
                const arg = {
                    commodityCode: params.row.commodityCode,
                    customerCommodityId: params.row.customerCommodityId,
                    effectiveDate: this.getDate(params.row.effectiveDate, 'long')
                };
                const res = await getInve(arg);
                if (res.status === this.code) {
                    this.inveData = res.content;
                }
            },

            // 保存出库单
            async modalOk () {
                let params = Object.assign({}, this.formAttr);
                if (this.orderDetailTableData.length === 0) {
                    this.changeLoading();
                    this.$Message.error('至少要有一条出库单明细');
                    return;
                }
                this.orderDetailTableData.forEach((item, index) => {
                    if (item.detailType === 0) {
                        params.updateItems.push({
                            itemId: item.orderItemId,
                            quantity: item.quantity,
                            seqNo: index
                        });
                    } else if (item.detailType === 1) {
                        params.addItems.push({
                            itemId: item.orderItemId,
                            quantity: item.quantity,
                            seqNo: index
                        });
                    }
                    params.deleteItems = this.formAttr.deleteItems.filter(
                        option => {
                            return option !== item.noticeItemId;
                        }
                    );
                });
                const res = await editSaleOutboundOrder(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                } else {
                    this.changeLoading();
                }
            },

            delArrItemFormIndex (arr, index) {
                let res = [];
                if (Array.isArray(arr)) {
                    arr.forEach((item, i) => {
                        if (index !== i) {
                            res.push(item);
                        }
                    });
                }
                return res;
            },
            /**
             * 获取打印或者导出信息
             * @param row
             * @param cb
             * @returns {Promise<void>}
             */
            async getPrintDetail (row, cb) {
                const res = await getPrintInfo(row);
                if (res.status === this.code) {
                    this.printDetail = res.content;
                    if (this.printDetail) {
                        if (cb) cb(this.printDetail);
                    }
                }
            },
            prepareData (data, myFrameName) {
                this.$nextTick(() => {
                    const myFrame = this.$refs[myFrameName];
                    if (myFrame) {
                        let _this = this;
                        const setHeight = () => {
                            const app = myFrame.contentWindow.document.getElementById('app');
                            const body = myFrame.contentWindow.document.body;
                            if (app && app.style) {
                                app.style.height = 'auto';
                            }
                            if (body && body.style) {
                                body.style.height = 'auto';
                            }
                        };
                        myFrame.onload = function () {
                            myFrame.contentWindow.postMessage(data || '', '*');
                            setHeight();
                            _this.setIframeHeight(myFrame);
                        };
                        myFrame.contentWindow.postMessage(data || '', '*');
                        setHeight();
                        _this.setIframeHeight(myFrame);
                    }
                });
            },
            setIframeHeight (iframe) {
                if (iframe) {
                    let iframeWin = iframe.contentWindow || iframe.contentDocument.parentWindow;
                    if (iframeWin.document.body) {
                        const body = iframeWin.document.body;
                        setTimeout(() => {
                            iframe.style.height = body.getBoundingClientRect().height + 60 + 'px';
                        }, 200);
                    }
                }
            },
            printModalCancel () {

            },
            printModalOk () {
                this.$refs.iframe.contentWindow.focus();
                this.$refs.iframe.contentWindow.print();
            },
            printPriceModalOk () {
                this.$refs.iframePrice.contentWindow.focus();
                this.$refs.iframePrice.contentWindow.print();
            }
        }
    };
</script>

<style scoped lang="less">
    /deep/ .ivu-table-cell {
        .redOrder {
            color: #e53935;
        }
    }
</style>
