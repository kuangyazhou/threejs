<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-10 14:43:41
 * @LastEditTime: 2019-08-16 09:26:02
 * @LastEditors: Please set LastEditors
 -->
<template>
    <div class="erp-content">
        <!-- <h1>客户物料信息</h1> -->
        <div class="add-commissioner">
            <Card :border="false" class="wrapper-query">
                <p slot="title">
                    <Icon type="ios-search"></Icon> 查询条件
                </p>
                <div slot="extra">
                    <ButtonGroup>
                        <Button @click="search" icon="md-search">搜索</Button>
                        <Button @click="reset" icon="md-refresh">重置</Button>
                    </ButtonGroup>
                </div>
                <Row :gutter="16">
                    <Col span="4" class="maxWidth">
                        <Select
                            v-model="tableQueryAttr.customerEnableCode"
                            placeholder="请选择客户"
                            @on-change="getTableList"
                            filterable
                            ref="filter"
                        >
                            <Option
                                v-for="item in customerArr"
                                :key="item.index"
                                :label="item.customerName"
                                :value="item.enableCode"
                            ></Option>
                        </Select>
                    </Col>
                    <Col span="4">
                        <Input v-model="tableQueryAttr.commodityName" placeholder="物料名称" search>
                            <Button @click="search" slot="append" icon="ios-search"></Button>
                        </Input>
                    </Col>
                    <Col span="4">
                        <Input v-model="tableQueryAttr.specializedGroupName" placeholder="专业分组">
                            <Button @click="search" slot="append" icon="ios-search"></Button>
                        </Input>
                    </Col>
                    <Col span="4">
                        <Select
                            v-model="tableQueryAttr.taskStatus"
                            placeholder="请选择状态"
                            @on-change="getTableList"
                        >
                            <Option
                                v-for="item in typeList"
                                :key="item.index"
                                :label="item.label"
                                :value="item.value"
                            ></Option>
                        </Select>
                    </Col>
                </Row>
            </Card>
            <Card :border="false">
                <p slot="title"><Icon type="md-list"></Icon>客户物料列表</p>
                <div slot="extra">
                    <ButtonGroup>
                        <Button
                            @click="multipleAudit"
                            v-has="btnRightList.materialInfoPassMul"
                            icon="ios-checkbox-outline"
                        >审核</Button>
                        <Button
                            @click="multipleCancel"
                            v-has="btnRightList.materialInfoReturnMul"
                            icon="md-checkmark"
                        >取消审核</Button>
                    </ButtonGroup>
                </div>
                <erp-table
                    ref="managerTable"
                    @on-selection-change="selectionChange"
                    @on-page-no-change="pageNoChange"
                    @on-page-size-change="pageSizeChange"
                    :erpTableTitle="erpTableTitle"
                    :erpTableData="erpTableData"
                    :tableLoading="tableLoading"
                    :total="total"
                    :current="tableComAttr.pageNo"
                ></erp-table>
            </Card>
        </div>
        <!-- 批量添加Modal -->
        <Modal
            v-model="modalAdds"
            @on-ok="multipleModalOk"
            :mask-closable="maskClosable"
            title="批量添加客户物料"
            width="950"
        >
            <Card :border="false">
                <div slot="title">
                    <Row :gutter="12">
                        <Col span="8">
                            <Select v-model="multipleAttr.customerEnableCode" placeholder="请选择客户">
                                <Option
                                    v-for="item in customerArr"
                                    :key="item.index"
                                    :label="item.customerName"
                                    :value="item.enableCode"
                                ></Option>
                            </Select>
                        </Col>
                        <Col span="8">
                            <Select v-model="multipleAttr.saleOrganizationId" placeholder="请选择销售组织">
                                <Option
                                    v-for="item in saleOrgArr"
                                    :key="item.index"
                                    :label="item.saleOrganizationName"
                                    :value="item.id"
                                ></Option>
                            </Select>
                        </Col>
                    </Row>
                </div>
                <div slot="extra">
                    <ButtonGroup class="z10">
                        <Button @click="chooseMaterial(multipleAttr)">选择物料</Button>
                    </ButtonGroup>
                </div>
                <Table :columns="multipleTitle" :data="multipleData">
                    <template slot-scope="{ row, index }" slot="invoiceName">
                        <Input v-model="materialitems[index].invoiceName" placeholder="开票名称"></Input>
                    </template>
                    <template slot-scope="{ row, index }" slot="remark">
                        <Input v-model="materialitems[index].remark" placeholder="备注"></Input>
                    </template>
                    <template slot-scope="{ row }" slot="operate">
                        <Button type="error" size="small">删除</Button>
                    </template>
                </Table>
            </Card>
        </Modal>

        <!-- 单个添加Modal -->
        <Modal
            @on-ok="modalOk"
            @on-cancel="modalCancel"
            v-model="modalShowFlag"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
        >
            <Form :model="formAttr" :rules="ruleValidate" ref="formValidate" :label-width="120">
                <FormItem label="客户">
                    <!-- <Input placeholder="客户"></Input> -->
                    <Select v-model="formAttr.customerEnableCode" :disabled="true">
                        <Option
                            v-for="item in customerArr"
                            :key="item.index"
                            :label="item.customerName"
                            :value="item.enableCode"
                        ></Option>
                    </Select>
                </FormItem>
                <FormItem label="销售组织">
                    <!-- <Select
                        v-model="formAttr.saleOrganizationId"
                        :disabled="true"
                    >
                        <Option
                            v-for="item in saleOrgArr"
                            :key="item.index"
                            :label="item.saleOrganizationName"
                            :value="item.id"
                        ></Option>
                    </Select>-->
                    <Input v-model="formAttr.saleOrganizationName" disabled></Input>
                </FormItem>
                <FormItem label="物料">
                    <!-- <Input placeholder="物料"></Input> -->
                    <span class="mr6">{{ formAttr.commodityName }}</span>
                    <!-- <Button type="success" size="small" @click="chooseMaterial">选择</Button> -->
                </FormItem>

                <FormItem label="开票名称">
                    <Input v-model="formAttr.invoiceName" disabled placeholder="开票名称"></Input>
                </FormItem>
                <FormItem label="备注">
                    <Input v-model="formAttr.remark" disabled type="textarea" placeholder="客户"></Input>
                </FormItem>
            </Form>
        </Modal>

        <!-- 供应商数据 -->
        <Modal
            v-model="modalSupplier"
            @on-ok="supplierOk"
            :mask-closable="maskClosable"
            width="650"
            title="选择供应商"
        >
            <Transfer
                :data="supplierArr"
                :target-keys="supplierTargetArr"
                @on-change="supplierChange"
            ></Transfer>
        </Modal>

        <!-- 物料Modal -->
        <Modal v-model="modalMaterial" title="物料选择" :mask-closable="maskClosable" width="950">
            <Card>
                <div slot="title">
                    <Row :gutter="12">
                        <Col span="8">
                            <Input placeholder="物料名称"></Input>
                        </Col>
                        <Col span="8">
                            <Input placeholder="专业分组"></Input>
                        </Col>
                        <Col span="4">
                            <Button @click="getMaterialList({})" type="primary">搜索</Button>
                        </Col>
                    </Row>
                </div>
                <Table :columns="materialTitle" :data="materialData">
                    <template slot-scope="{ row }" slot="operate">
                        <Button @click="materilSelect(row)" type="success" size="small">选择</Button>
                    </template>
                </Table>
            </Card>
        </Modal>
    </div>
</template>

<script>
    import { mapGetters } from 'vuex';
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';

    import {
        getCustomerInfo,
        getMaterialInfo,
        materialAddMultiple,
        customerMaterialSubmit,
        customerMaterialBack,
        customerMaterialBackMul,
        customerMaterialPass,
        customerMaterialPassMul,
        addSupplier,
        getSupplierList
    } from '@/api/customerMaterial/materialInfo';
    import { getAllCustomerList } from '@/api/saleManage/sale';
    import { getCompanySalesOrganizationList } from '@/api/saleManage/saleGroup';
    import { getAllSupplierList } from '@/api/purchaseManage/buyer';

    export default {
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                modalAdds: false, // 批量添加Modal,
                modalSupplier: false, // 设置供应商
                customerArr: [], // 客户下拉数据
                saleOrgArr: [], // 销售组织下拉数据
                modalMaterial: false, // 物料Modal

                materialData: [],
                supplierArr: [], // 供应商数据
                supplierTargetArr: [], // 供应商已选数据
                // 物料多选搜索条件
                multipleAttr: {
                    customerEnableCode: '',
                    saleOrganizationId: ''
                },

                // 审核状态数据
                typeList: [
                    { label: '未提交', value: 0 },
                    { label: '审核中', value: 1 },
                    { label: '已审核', value: 2 }
                ],
                materialId: '',
                formAttr: {
                    customerEnableCode: '',
                    commodityCode: '',
                    invoiceName: '',
                    remark: '',
                    saleOrganizationId: '',
                    saleOrganizationName: '',
                    commodityName: ''
                },
                materialitems: [], // 批量添加items
                ruleValidate: {},
                tableQueryAttr: {
                    taskStatus: 1,
                    commodityName: '',
                    specializedGroupName: '',
                    customerEnableCode: '',
                    saleOrganizationId: '',
                    salerId: this.salerId
                },
                erpTableTitle: [
                    {
                        type: 'selection',
                        minWidth: 60,
                        align: 'center',
                        fixed: 'left'
                    },
                    {
                        title: '销售组织',
                        align: 'center',
                        minWidth: 100,
                        key: 'saleOrganizationName'
                    },
                    {
                        title: '客户',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerName'
                    },
                    {
                        title: '物料常用名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '厂家',
                        align: 'center',
                        minWidth: 100,
                        key: 'manufacturerName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroupName'
                    },
                    {
                        title: '供应商条数',
                        align: 'center',
                        minWidth: 100,
                        key: 'countSupplier'
                    },
                    {
                        title: '销售价格',
                        align: 'center',
                        minWidth: 100,
                        key: 'countPrice'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'statusDescription'
                    },
                    {
                        title: '操作',
                        fixed: 'right',
                        align: 'center',
                        minWidth: 160,
                        render: (h, params) => {
                            let temp = null;
                            if (params.row.taskStatus === 1) {
                                temp = h(
                                    'Button',
                                    {
                                        props: { type: 'success', size: 'small' },
                                        on: {
                                            click: () => {
                                                this.auditPass(params.row);
                                            }
                                        },
                                        class: 'mr6',
                                        directives: {
                                            name: 'has',
                                            value: this.btnRightList
                                                .materialInfoPass
                                        }
                                    },
                                    '审核'
                                );
                            }
                            if (params.row.taskStatus === 2) {
                                temp = h(
                                    'Button',
                                    {
                                        props: { type: 'default', size: 'small' },
                                        on: {
                                            click: () => {
                                                this.cacelAudit(params.row);
                                            }
                                        },
                                        class: 'mr6',
                                        directives: {
                                            name: 'has',
                                            value: this.btnRightList
                                                .materialInfoReturn
                                        }
                                    },
                                    '取消审核'
                                );
                            }
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: { type: 'primary', size: 'small' },
                                        class: 'mr6',
                                        on: {
                                            click: () => {
                                                this.editTableData(
                                                    params,
                                                    '查看客户物料'
                                                );
                                            // this.addItem('查看客户物料')
                                            }
                                        }
                                    },
                                    '查看'
                                ),
                                temp // 审核与取消审核按钮
                            ]);
                        }
                    }
                ],
                multipleTitle: [
                    {
                        title: '物料常用名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroup'
                    },
                    {
                        title: '开票名称',
                        align: 'center',
                        minWidth: 100,
                        slot: 'invoiceName'
                    },
                    {
                        title: '备注',
                        align: 'center',
                        minWidth: 100,
                        slot: 'remark'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        slot: 'operate'
                    }
                ],
                multipleData: [],
                materialTitle: [
                    {
                        title: '常用名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroup'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        slot: 'operate'
                    }
                ] // 物料表头
            };
        },

        computed: {
            ...mapGetters(['salerId'])
        },
        methods: {
            // 批量添加
            addMultiple () {
                this.getSaleOrg();
                this.getCustomerData();
                this.multipleSearch();
                this.modalAdds = true;
            },

            // 单个添加
            add () {
                this.addItem('添加客户物料');
                this.getSaleOrg();
                this.getCustomerData();
            },

            async modalOk () {
                this.modalShowFlag = false;
            // if (this.currentId) {
            //     const params = Object.assign({}, this.formAttr);
            //     const res = await customerMaterialUpdate(params);
            //     if (res.status === this.code) {
            //         this.todoOver(res.msg);
            //     }
            // } else {
            //     const params = Object.assign({}, this.formAttr);
            //     const res = await materialAdd(params);
            //     if (res.status === this.code) {
            //         this.todoOver(res.msg);
            //     }
            // }
            },

            // 提交
            async submit (row) {
                const params = {
                    id: row.id
                };
                const res = await customerMaterialSubmit(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            // 审核通过
            async auditPass (row) {
                const params = {
                    id: row.id
                };
                const res = await customerMaterialPass(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            // 取消审核
            async cacelAudit (row) {
                const params = {
                    id: row.id
                };
                const res = await customerMaterialBack(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            // 设定供应商,获取供应商列表
            async setSupplier (row) {
                this.modalSupplier = true;
                this.materialId = row.id;

                // 获取已添加供应商
                const params = {
                    customerCommodityId: row.id
                };
                const supRes = await getSupplierList(params);
                if (supRes.status === this.code) {
                    this.supplierTargetArr = supRes.content.map(item => {
                        // return {
                        //     key: item.enableCode,
                        //     label: item.supplierName
                        // };
                        return item.supplierEnableCode;
                    });
                }

                // 获取所有供应商列表
                const res = await getAllSupplierList();
                if (res.status === this.code) {
                    this.supplierArr = res.content.map(item => {
                        return {
                            key: item.enableCode,
                            label: item.supplierName
                        };
                    });
                }
            },

            supplierChange (e) {
                this.supplierTargetArr = e;
            },

            // 添加供应商
            async supplierOk () {
                const params = {
                    id: this.materialId,
                    suppliers: this.supplierTargetArr
                };
                const res = await addSupplier(params);
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.supplierTargetArr = [];
                    this.modalSupplier = false;
                    this.materialId = null;
                }
            },

            // 物料选择
            materilSelect (row) {
                // 判断是单个添加还是批量添加
                if (this.modalShowFlag) {
                    this.formAttr.commodityCode = row.commodityCode;
                    this.formAttr.commodityName = row.commodityName;
                    this.modalMaterial = false;
                }
                if (this.modalAdds) {
                    this.materialitems.push({
                        customerEnableCode: row.customerEnableCode,
                        commodityCode: row.commodityCode,
                        invoiceName: '',
                        remark: '',
                        saleOrganizationId: row.saleOrganizationId,
                        id: row.commodityCode
                    });
                    this.multipleData.push(row);
                    this.modalMaterial = false;
                }
            },

            // 添加多个物料搜索
            async multipleSearch () {
                const params = Object.assign({}, this.multipleAttr);
                const res = await getMaterialInfo(params);
                if (res.status === this.code) {
                    // this.multipleData = res.content;
                }
            },

            // 批量添加确认
            async multipleModalOk () {
                const params = Object.assign({}, this.multipleAttr, {
                    items: this.materialitems
                });
                const res = await materialAddMultiple(params);
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.modalAdds = false;
                    this.getTableList();
                }
            },
            // 批量审核
            async multipleAudit () {
                if (this.delCheck('请至少选择一项')) {
                    const isEqual = this.tableSelectList.every(item => {
                        return item.taskStatus === 1;
                    });
                    if (!isEqual) {
                        return this.$Message.error('请选择状态为审核中的数据');
                    }
                    const params = { ids: this.tableSelectValue };
                    const res = await customerMaterialPassMul(params);
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    }
                }
            },
            // 批量取消
            async multipleCancel () {
                if (this.delCheck('请至少选择一项')) {
                    const isEqual = this.tableSelectList.every(item => {
                        return item.taskStatus === 2;
                    });
                    if (!isEqual) {
                        return this.$Message.error('请选择状态为已审核的数据');
                    }
                    const params = { ids: this.tableSelectValue };
                    const res = await customerMaterialBackMul(params);
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    }
                }
            },

            // 客户物料添加
            // async customerMaterialSave() {
            //     const params = Object.assign({}, this.formAttr);
            //     const res = await materialAdd(params);
            //     if (res.status === this.code) {
            //         this.todoOver(res.msg);
            //     }
            // },
            // 选择物料
            chooseMaterial (arg) {
                this.getMaterialList(arg);
                this.modalMaterial = true;
            },

            // 获取当前企业下的物料信息
            async getMaterialList (params) {
                // const params = {
                //     commodityName: '',
                //     specializedGroup: ''
                // };
                const res = await getMaterialInfo(params);
                if (res.status === this.code) {
                    this.materialData = res.content;
                }
            },
            // 获取客户列表
            async getCustomerData () {
                const params = {
                    salerId: this.salerId
                };
                const res = await getAllCustomerList(params);
                if (res.status === this.code) {
                    this.customerArr = res.content;
                }
            },

            // 获取销售组织列表
            async getSaleOrg () {
                const params = {};
                const res = await getCompanySalesOrganizationList(params);
                if (res.status === this.code) {
                    this.saleOrgArr = res.content;
                }
            },

            // 获取表格数据
            getTableList () {
                // 获取客户数据
                this.getCustomerData();
                this.getTableListFn(async call => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr,
                        { salerId: this.salerId }
                    );
                    const res = await getCustomerInfo(params);
                    call(res);
                });
            }
        }
    };
</script>

<style scoped lang="less">
/deep/ .ivu-transfer-list {
    width: 250px;
    height: 400px;
}
/deep/ .ivu-transfer-operation {
    .ivu-btn {
        height: 60px;
    }
}
</style>
