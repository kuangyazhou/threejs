<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-09 15:45:17
 * @LastEditTime: 2019-08-16 09:26:26
 * @LastEditors: Please set LastEditors
 -->
<template>
    <div class="erp-content">
        <!-- <h1>客户物料信息</h1> -->
        <div class="add-commissioner">
            <Card :border="false" class="wrapper-query">
                <p slot="title">
                    <Icon type="ios-search"></Icon> 查询条件
                </p>
                <div slot="extra">
                    <ButtonGroup>
                        <Button @click="search" icon="md-search">搜索</Button>
                        <Button @click="reset" icon="md-refresh">重置</Button>
                    </ButtonGroup>
                </div>
                <Row :gutter="16">
                    <Col span="4" class="maxWidth">
                        <Select
                            v-model="tableQueryAttr.customerEnableCode"
                            placeholder="请选择客户"
                            @on-change="getTableList"
                            filterable
                            ref="filter"
                        >
                            <Option
                                v-for="item in customerArr"
                                :key="item.index"
                                :label="item.customerName"
                                :value="item.customerEnableCode"
                            ></Option>
                        </Select>
                    </Col>
                    <Col span="4">
                        <Input v-model="tableQueryAttr.commodityName" placeholder="物料名称" search>
                            <Button @click="search" slot="append" icon="ios-search"></Button>
                        </Input>
                    </Col>
                    <Col span="4">
                        <Input v-model="tableQueryAttr.specializedGroupName" placeholder="专业分组">
                            <Button @click="search" slot="append" icon="ios-search"></Button>
                        </Input>
                    </Col>
                    <Col span="4">
                        <Select
                            v-model="tableQueryAttr.taskStatus"
                            placeholder="请选择状态"
                            @on-change="getTableList"
                        >
                            <Option
                                v-for="item in typeList"
                                :key="item.index"
                                :label="item.label"
                                :value="item.value"
                            ></Option>
                        </Select>
                    </Col>
                </Row>
            </Card>
            <Card :border="false">
                <p slot="title"><Icon type="md-list"></Icon>客户物料列表</p>
                <div slot="extra">
                    <ButtonGroup>
                        <Button
                            @click="addMultiple"
                            v-has="btnRightList.multipleAdd"
                            icon="ios-checkbox-outline"
                        >批量添加</Button>
                        <Button @click="add" v-has="btnRightList.singleAdd" icon="md-checkmark">添加</Button>
                        <Button
                            @click="multipleSubmit"
                            v-has="btnRightList.materialInfoSubmitMul"
                            icon="md-checkmark"
                        >提交</Button>
                        <Button
                            @click="multipleAudit"
                            v-has="btnRightList.materialInfoPassMul"
                            icon="ios-checkbox-outline"
                        >审核</Button>
                        <Button
                            @click="multipleCancel"
                            v-has="btnRightList.materialInfoReturnMul"
                            icon="md-checkmark"
                        >取消审核</Button>
                        <Button
                            @click="multipleReturn"
                            v-has="btnRightList.materialInfoReturnMul"
                            icon="ios-checkbox-outline"
                        >撤回</Button>
                    </ButtonGroup>
                </div>
                <erp-table
                    ref="managerTable"
                    @on-page-no-change="pageNoChange"
                    @on-page-size-change="pageSizeChange"
                    @on-selection-change="selectionChange"
                    :erpTableTitle="erpTableTitle"
                    :erpTableData="erpTableData"
                    :tableLoading="tableLoading"
                    :total="total"
                    :current="tableComAttr.pageNo"
                ></erp-table>
            </Card>
        </div>
        <!-- 批量添加Modal -->
        <Modal
            v-model="modalAdds"
            :mask-closable="maskClosable"
            :loading="multipleLoading"
            title="批量添加客户物料"
            width="950"
            @on-cancel="multipleClose"
        >
            <Card :border="false">
                <div slot="title">
                    <Row :gutter="12">
                        <Col span="8">
                            <Select v-model="multipleAttr.customerEnableCode" placeholder="请选择客户">
                                <Option
                                    v-for="item in customerArr"
                                    :key="item.index"
                                    :label="item.customerName"
                                    :value="item.customerEnableCode"
                                ></Option>
                            </Select>
                        </Col>
                        <Col span="8">
                            <Select v-model="multipleAttr.saleOrganizationId" placeholder="请选择销售组织">
                                <Option
                                    v-for="item in saleOrgArr"
                                    :key="item.index"
                                    :label="item.saleOrganizationName"
                                    :value="item.id"
                                ></Option>
                            </Select>
                        </Col>
                    </Row>
                </div>
                <div slot="extra">
                    <ButtonGroup class="z10">
                        <Button @click="getMaterial()">选择物料</Button>
                    </ButtonGroup>
                </div>
                <Table :columns="multipleTitle" :data="multipleData">
                    <template slot-scope="{ row, index }" slot="minimumEffectiveDays">
                        <Input
                            v-model="materialitems[index].minimumEffectiveDays"
                            type="number"
                            placeholder="最短效期"
                        ></Input>
                    </template>
                    <template slot-scope="{ row, index }" slot="winBidCode">
                        <Input v-model="materialitems[index].winBidCode" placeholder="中标编码"></Input>
                    </template>
                    <template slot-scope="{ row, index }" slot="invoiceName">
                        <Input v-model="materialitems[index].invoiceName" placeholder="开票名称"></Input>
                    </template>
                    <template slot-scope="{ row, index }" slot="invoiceUnitCode">
                        <!-- <Input v-model="materialitems[index].invoiceUnitCode" placeholder="开票单位"></Input> -->
                        <Select v-model="materialitems[index].invoiceUnitCode">
                            <Option
                                v-for="item in materialitems[index].unitArr"
                                :value="item.unitCode"
                                :label="item.unitName"
                                :key="item.id"
                            ></Option>
                        </Select>
                    </template>
                    <template slot-scope="{ row, index }" slot="remark">
                        <Input v-model="materialitems[index].remark" placeholder="备注"></Input>
                    </template>
                    <template slot-scope="{ row }" slot="operate">
                        <Button @click="del(row)" type="error" size="small">删除</Button>
                    </template>
                </Table>
            </Card>
            <div slot="footer">
                <Button @click="multipleClose">取消</Button>
                <Button type="primary" @click="multipleModalOk">确认</Button>
            </div>
        </Modal>

        <!-- 单个添加Modal -->
        <Modal
            @on-ok="modalOk"
            @on-cancel="modalCancel"
            v-model="modalShowFlag"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
        >
            <Form :model="formAttr" :rules="ruleValidate" ref="formValidate" :label-width="120">
                <FormItem label="客户">
                    <!-- <Input placeholder="客户"></Input> -->
                    <Select v-model="formAttr.customerEnableCode" @on-change="clearCommodity">
                        <Option
                            v-for="item in customerArr"
                            :key="item.index"
                            :label="item.customerName"
                            :value="item.customerEnableCode"
                        ></Option>
                    </Select>
                </FormItem>
                <FormItem label="销售组织">
                    <Select v-model="formAttr.saleOrganizationId"  @on-change="clearCommodity">
                        <Option
                            v-for="item in saleOrgArr"
                            :key="item.index"
                            :label="item.saleOrganizationName"
                            :value="item.id"
                        ></Option>
                    </Select>
                </FormItem>
                <FormItem label="物料">
                    <!-- <Input placeholder="物料"></Input> -->
                    <span class="mr6">{{ formAttr.commodityName }}</span>
                    <Button type="success" size="small" @click="chooseMaterial">选择</Button>
                </FormItem>
                <FormItem label="最短效期">
                    <Input v-model="formAttr.minimumEffectiveDays" type="number" placeholder="最短效期"></Input>
                </FormItem>
                <FormItem label="中标编码">
                    <Input v-model="formAttr.winBidCode" placeholder="中标编码"></Input>
                </FormItem>
                <FormItem label="开票单位">
                    <Select v-model="formAttr.invoiceUnitCode" placeholder="开票单位">
                        <Option
                            v-for="item in unitArr"
                            :label="item.unitName"
                            :value="item.unitCode"
                            :key="item.id"
                        ></Option>
                    </Select>
                </FormItem>
                <FormItem label="开票名称">
                    <Input v-model="formAttr.invoiceName" placeholder="开票名称"></Input>
                </FormItem>
                <FormItem label="备注">
                    <Input v-model="formAttr.remark" type="textarea" placeholder="客户"></Input>
                </FormItem>
            </Form>
        </Modal>

        <!-- 供应商数据 -->
        <Modal
            v-model="modalSupplier"
            @on-ok="supplierOk"
            :mask-closable="maskClosable"
            width="650"
            title="选择供应商"
        >
            <Transfer
                :data="supplierArr"
                :target-keys="supplierTargetArr"
                @on-change="supplierChange"
            ></Transfer>
        </Modal>

        <!-- 物料Modal -->
        <Modal v-model="modalMaterial" title="物料选择" :mask-closable="maskClosable" width="950" footer-hide>
            <Card>
                <div slot="title">
                    <Row :gutter="12">
                        <Col span="8">
                            <Input v-model="searchAttr.commodityName" placeholder="物料名称"></Input>
                        </Col>
                        <Col span="8">
                            <Input v-model="searchAttr.specializedGroup" placeholder="专业分组"></Input>
                        </Col>
                        <Col span="4">
                            <Button @click="getMaterialList()" type="primary">搜索</Button>
                        </Col>
                    </Row>
                </div>
                <div class="clearfix">
                    <Table :columns="materialTitle" :data="materialData"  :loading="modalLoading">
                        <template slot-scope="{ row }" slot="operate">
                            <Button @click="materilSelect(row)" type="success" size="small">选择</Button>
                        </template>
                    </Table>
                    <div class="wrapper-page">
                        <Page
                            :current="searchPage.current"
                            @on-change="changeSearch"
                            :total="searchPage.total"
                        ></Page>
                    </div>
                </div>
            </Card>
        </Modal>
    </div>
</template>

<script>
    import { mapGetters } from 'vuex';
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';

    import {
        getCustomerInfo,
        getMaterialInfo,
        materialAdd,
        customerMaterialUpdate,
        materialAddMultiple,
        customerMaterialSubmit,
        customerMaterialBack,
        customerMaterialPass,
        addSupplier,
        getSupplierList,
        customerMaterialSubmitMutl,
        customerMaterialBackMul,
        customerMaterialPassMul
    } from '@/api/customerMaterial/materialInfo';
    import { getSaveCustomerList } from '@/api/saleManage/sale';
    import { getCompanySalesOrganizationList } from '@/api/saleManage/saleGroup';
    import { getAllSupplierList } from '@/api/purchaseManage/buyer';
    import { packageList } from '@/api/material/materialadd.js';
    import { resetObj } from '@/libs/tools';

    export default {
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                modalAdds: false, // 批量添加Modal,
                modalSupplier: false, // 设置供应商
                customerArr: [], // 客户下拉数据
                saleOrgArr: [], // 销售组织下拉数据
                modalMaterial: false, // 物料Modal
                unitArr: [], // 包装单位数据源
                materialData: [],
                supplierArr: [], // 供应商数据
                supplierTargetArr: [], // 供应商已选数据
                // 物料多选搜索条件
                multipleAttr: {
                    customerEnableCode: '',
                    saleOrganizationId: ''
                },
                multipleLoading: false,
                modalLoading: false,
                // 审核状态数据
                typeList: [
                    { label: '未提交', value: 0 },
                    { label: '审核中', value: 1 },
                    { label: '已审核', value: 2 }
                ],
                // 物料搜索条件
                searchAttr: {
                    commodityName: '',
                    specializedGroup: ''
                },
                searchPage: {
                    pageNo: 1,
                    pageSize: 10,
                    current: 1,
                    total: 0
                },
                materialId: '',
                formAttr: {
                    customerEnableCode: '',
                    commodityCode: '',
                    invoiceName: '',
                    remark: '',
                    saleOrganizationId: '',
                    commodityName: '',
                    taskStatus: '',
                    id: '',
                    minimumEffectiveDays: '',
                    winBidCode: '',
                    invoiceUnitCode: ''
                },
                materialitems: [], // 批量添加items
                ruleValidate: {},
                tableQueryAttr: {
                    taskStatus: '',
                    commodityName: '',
                    specializedGroupName: '',
                    customerEnableCode: '',
                    saleOrganizationId: '',
                    salerId: this.salerId
                },
                erpTableTitle: [
                    {
                        type: 'selection',
                        minWidth: 60,
                        align: 'center',
                        fixed: 'left'
                    },
                    {
                        title: '销售组织',
                        align: 'center',
                        minWidth: 100,
                        key: 'saleOrganizationName'
                    },
                    {
                        title: '客户',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerName'
                    },
                    {
                        title: '物料常用名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '厂家',
                        align: 'center',
                        minWidth: 100,
                        key: 'manufacturerName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroupName'
                    },
                    {
                        title: '供应商条数',
                        align: 'center',
                        minWidth: 100,
                        // key: 'countSupplier',
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {
                                        size: 'small',
                                        type: 'primary'
                                    },
                                    on: {
                                        click: () => {
                                            this.setSupplier(params.row);
                                        }
                                    }
                                },
                                params.row.countSupplier
                            );
                        }
                    },
                    {
                        title: '销售价格',
                        align: 'center',
                        minWidth: 100,
                        key: 'countPrice'
                    // render: (h, params) => {
                    //     return h(
                    //         'Button',
                    //         {
                    //             props: {
                    //                 size: 'small'
                    //             },
                    //             on: {
                    //                 click: () => {
                    //                     this.$router.push({
                    //                         path: 'salePriceMange'
                    //                     });
                    //                 }
                    //             }
                    //         },
                    //         params.row.countPrice
                    //     );
                    // }
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'statusDescription'
                    },
                    {
                        title: '操作',
                        fixed: 'right',
                        align: 'center',
                        minWidth: 230,
                        render: (h, params) => {
                            let temp = null;
                            if (params.row.taskStatus === 0) {
                                temp = h(
                                    'Button',
                                    {
                                        props: { type: 'success', size: 'small' },
                                        on: {
                                            click: () => {
                                                this.submit(params.row);
                                            }
                                        },
                                        class: 'mr6',
                                        directives: {
                                            name: 'has',
                                            value: this.btnRightList
                                                .materialInfoSubmit
                                        }
                                    },
                                    '提交'
                                );
                            }
                            if (params.row.taskStatus === 1) {
                                temp = [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'warning',
                                                size: 'small'
                                            },
                                            on: {
                                                click: () => {
                                                    this.cacelAudit(params.row);
                                                }
                                            },
                                            class: 'mr6',
                                            directives: {
                                                name: 'has',
                                                value: this.btnRightList
                                                    .materialInfoReturn
                                            }
                                        },
                                        '撤回'
                                    ),

                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'success',
                                                size: 'small'
                                            },
                                            on: {
                                                click: () => {
                                                    this.auditPass(params.row);
                                                }
                                            },
                                            class: 'mr6',
                                            directives: {
                                                name: 'has',
                                                value: this.btnRightList
                                                    .materialInfoPass
                                            }
                                        },
                                        '审核'
                                    )
                                ];
                            }
                            // 取消审核
                            if (params.row.taskStatus === 2) {
                                temp = h(
                                    'Button',
                                    {
                                        props: { type: 'warning', size: 'small' },
                                        on: {
                                            click: () => {
                                                this.cacelAudit(params.row);
                                            }
                                        },
                                        class: 'mr6',
                                        directives: {
                                            name: 'has',
                                            value: this.btnRightList
                                                .materialInfoReturn
                                        }
                                    },
                                    '取消审核'
                                );
                            }
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type:
                                                params.row.taskStatus === 2
                                                    ? 'success'
                                                    : 'primary',
                                            size: 'small'
                                        },
                                        class: 'mr6',
                                        on: {
                                            click: () => {
                                                this.getSaleOrg();
                                                this.getUnit(params.row);
                                                this.editTableData(
                                                    params,
                                                    '编辑客户物料'
                                                );
                                            }
                                        }
                                    },
                                    params.row.taskStatus === 2 ? '查看' : '编辑'
                                ),
                                temp, // 审核与取消审核按钮
                                h(
                                    'Button',
                                    {
                                        props: { type: 'info', size: 'small' },
                                        on: {
                                            click: () => {
                                                this.setSupplier(params.row);
                                            }
                                        },
                                        class: 'mr6',
                                        directives: {
                                            name: 'has',
                                            value: this.btnRightList.addSupplier
                                        }
                                    },
                                    '设定供应商'
                                )
                            ]);
                        }
                    }
                ],
                multipleTitle: [
                    {
                        title: '物料常用名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroup'
                    },
                    {
                        title: '开票名称',
                        align: 'center',
                        minWidth: 100,
                        slot: 'invoiceName'
                    },
                    {
                        title: '最短效期',
                        align: 'center',
                        minWidth: 100,
                        slot: 'minimumEffectiveDays'
                    },
                    {
                        title: '中标编码',
                        align: 'center',
                        minWidth: 100,
                        slot: 'winBidCode'
                    },
                    {
                        title: '开票单位',
                        align: 'center',
                        minWidth: 100,
                        slot: 'invoiceUnitCode'
                    },
                    {
                        title: '备注',
                        align: 'center',
                        minWidth: 100,
                        slot: 'remark'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        slot: 'operate'
                    }
                ],
                multipleData: [],
                materialTitle: [
                    {
                        title: '常用名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroup'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        slot: 'operate'
                    }
                ] // 物料表头
            };
        },

        computed: {
            ...mapGetters(['salerId'])
        },
        methods: {
            // 批量添加
            addMultiple () {
                this.getSaleOrg();
                this.getCustomerData();
                this.multipleSearch();
                this.modalAdds = true;
            },

            // 单个添加
            add () {
                this.addItem('添加客户物料');
                this.getSaleOrg();
                this.getCustomerData();
            },

            async modalOk () {
                if (this.formAttr.taskStatus === 2) {
                    this.modalShowFlag = false;
                    this.modalCancel();
                } else {
                    if (this.currentId) {
                        const params = Object.assign({}, this.formAttr);
                        const res = await customerMaterialUpdate(params);
                        if (res.status === this.code) {
                            this.todoOver(res.msg);
                        } else {
                            this.changeLoading();
                        }
                    } else {
                        const params = Object.assign({}, this.formAttr);
                        const res = await materialAdd(params);
                        if (res.status === this.code) {
                            this.todoOver(res.msg);
                        } else {
                            this.changeLoading();
                        }
                    }
                }
            },

            // 提交
            async submit (row) {
                const params = {
                    id: row.id
                };
                const res = await customerMaterialSubmit(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            // 审核通过
            async auditPass (row) {
                const params = {
                    id: row.id
                };
                const res = await customerMaterialPass(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            // 取消审核
            async cacelAudit (row) {
                const params = {
                    id: row.id
                };
                const res = await customerMaterialBack(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            // 设定供应商,获取供应商列表
            async setSupplier (row) {
                this.modalSupplier = true;
                this.materialId = row.id;

                // 获取已添加供应商
                const params = {
                    customerCommodityId: row.id
                };
                const supRes = await getSupplierList(params);
                if (supRes.status === this.code) {
                    this.supplierTargetArr = supRes.content.map(item => {
                        // return {
                        //     key: item.supplierEnableCode,
                        //     label: item.supplierName
                        // };
                        return item.supplierEnableCode;
                    });
                }

                // 获取所有供应商列表
                const res = await getAllSupplierList();
                if (res.status === this.code) {
                    this.supplierArr = res.content.map(item => {
                        return {
                            key: item.enableCode,
                            label: item.supplierName
                        };
                    });
                }
            // console.log(this.supplierTargetArr,this.supplierArr)
            },

            supplierChange (e) {
                this.supplierTargetArr = e;
            },

            // 添加供应商
            async supplierOk () {
                const params = {
                    id: this.materialId,
                    suppliers: this.supplierTargetArr
                };
                const res = await addSupplier(params);
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.supplierTargetArr = [];
                    this.modalSupplier = false;
                    this.materialId = null;
                    this.getTableList();
                }
            },

            // 物料选择
            materilSelect (row, index) {
                // 判断是单个添加还是批量添加
                if (this.modalShowFlag) {
                    this.formAttr.commodityCode = row.commodityCode;
                    this.formAttr.commodityName = row.commodityName;
                    this.modalMaterial = false;
                    // 获取物料包装单位
                    this.getUnit(row);
                }
                if (this.modalAdds) {
                    this.materialitems.push({
                        customerEnableCode: row.customerEnableCode,
                        commodityCode: row.commodityCode,
                        invoiceName: '',
                        remark: '',
                        saleOrganizationId: row.saleOrganizationId,
                        winBidCode: '',
                        invoiceUnitCode: ''
                    // id: row.commodityCode,
                    });
                    this.multipleData.push(row);
                    this.modalMaterial = false;
                    // 获取物料包装单位
                    this.multipleData.forEach((item, i) => {
                        this.addsUnit(item, i);
                    });
                }
            },

            // 批量新增时设置包装单位
            async addsUnit (row, index) {
                // console.log(row);
                const params = { commodityCode: row.commodityCode };
                const res = await packageList(params);
                if (res.status === this.code) {
                    this.$set(this.materialitems[index], 'unitArr', res.content);
                }
            },

            // 获取物料包装单位
            async getUnit (row) {
                const params = { commodityCode: row.commodityCode, status: 3, isDeleted: 1 };
                const res = await packageList(params);
                if (res.status === this.code) {
                    this.unitArr = res.content;
                }
            },

            // 批量提交
            async multipleSubmit () {
                if (this.delCheck('请至少选择一项')) {
                    const isEqual = this.tableSelectList.every(item => {
                        return item.taskStatus === 0;
                    });
                    if (!isEqual) {
                        return this.$Message.error('请选择状态为未提交的数据');
                    }
                    const params = { ids: this.tableSelectValue };
                    const res = await customerMaterialSubmitMutl(params);
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    }
                }
            },

            // 批量审核
            async multipleAudit () {
                if (this.delCheck('请至少选择一项')) {
                    const isEqual = this.tableSelectList.every(item => {
                        return item.taskStatus === 1;
                    });
                    if (!isEqual) {
                        return this.$Message.error('请选择状态为审核中的数据');
                    }
                    const params = { ids: this.tableSelectValue };
                    const res = await customerMaterialPassMul(params);
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    }
                }
            },

            // 批量取消
            async multipleCancel () {
                if (this.delCheck('请至少选择一项')) {
                    const isEqual = this.tableSelectList.every(item => {
                        console.log(item);
                        return item.taskStatus === 2;
                    });

                    if (!isEqual) {
                        return this.$Message.error('请选择状态为已审核的数据');
                    }
                    const params = { ids: this.tableSelectValue };
                    const res = await customerMaterialBackMul(params);
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    }
                }
            },

            //    批量撤回
            async multipleReturn () {
                if (this.delCheck('请至少选择一项')) {
                    const isEqual = this.tableSelectList.every(item => {
                        return item.taskStatus === 1;
                    });
                    if (!isEqual) {
                        return this.$Message.error('请选择状态为已审核的数据');
                    }
                    const params = { ids: this.tableSelectValue };
                    const res = await customerMaterialBackMul(params);
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    }
                }
            },

            // 添加多个物料搜索
            async multipleSearch () {
                const params = Object.assign({}, this.multipleAttr);
                const res = await getMaterialInfo(params);
                if (res.status === this.code) {
                    // this.multipleData = res.content;
                }
            },

            // 批量添加确认
            async multipleModalOk () {
                this.multipleLoading = true;
                let valid = true;
                if (!this.materialitems.length) {
                    valid = false;
                }

                if (!this.multipleAttr.customerEnableCode) {
                    this.$Message.error('请选择客户');
                    this.valid = false;
                }

                if (!this.multipleAttr.saleOrganizationId) {
                    this.$Message.error('请选择销售组织');
                    valid = false;
                }

                if (valid) {
                    const params = Object.assign({}, this.multipleAttr, {
                        items: this.materialitems
                    });
                    const res = await materialAddMultiple(params);
                    if (res.status === this.code) {
                        this.$Message.success(res.msg);
                        this.multipleLoading = false;
                        this.multipleClose();
                        this.getTableList();
                    }
                } else {
                    this.$nextTick(() => {
                        this.multipleLoading = false;
                    });
                }
            },
            // 批量添加关闭
            multipleClose () {
                this.modalAdds = false;
                this.materialitems = [];
                this.multipleData = [];
                resetObj(this.multipleAttr);
            },

            // 客户物料添加
            // async customerMaterialSave() {
            //     const params = Object.assign({}, this.formAttr);
            //     const res = await materialAdd(params);
            //     if (res.status === this.code) {
            //         this.todoOver(res.msg);
            //     }
            // },
            // 清空已选择物料
            clearCommodity () {
                this.formAttr.commodityCode = '';
                this.formAttr.commodityName = '';
            },

            // 选择物料
            chooseMaterial () {
                if (!this.formAttr.customerEnableCode) {
                    this.$Message.error('请先选择客户');
                    return;
                }
                if (!this.formAttr.saleOrganizationId) {
                    this.$Message.error('请先选择销售组织');
                    return;
                }
                this.getMaterialList();
                this.modalMaterial = true;
            },
            // 选择物料
            getMaterial () {
                if (!this.multipleAttr.customerEnableCode) {
                    this.$Message.error('请先选择客户');
                    return;
                }
                if (!this.multipleAttr.saleOrganizationId) {
                    this.$Message.error('请先选择销售组织');
                    return;
                }
                this.getMaterialList();
                this.modalMaterial = true;
            },

            // 获取当前企业下的物料信息
            async getMaterialList () {
                this.modalLoading = true;
                const res = await getMaterialInfo(
                    Object.assign({}, this.searchPage, this.searchAttr, {
                        customerEnableCode: this.formAttr.customerEnableCode || this.multipleAttr.customerEnableCode,
                        saleOrganizationId: this.formAttr.saleOrganizationId || this.multipleAttr.saleOrganizationId
                    })
                );
                if (res.status === this.code) {
                    this.modalLoading = false;
                    this.materialData = res.content.list;
                    this.searchPage.total = res.content.total;
                }
            },
            changeSearch (value) {
                if (value) {
                    this.searchPage.pageNo = value;
                    this.getMaterialList();
                }
            },
            // 获取客户列表
            async getCustomerData () {
                const params = {
                    salerId: this.salerId
                };
                const res = await getSaveCustomerList(params);
                if (res.status === this.code) {
                    // console.log(res);
                    this.customerArr = res.content;
                }
            },

            // 获取销售组织列表
            async getSaleOrg () {
                const params = {};
                const res = await getCompanySalesOrganizationList(params);
                if (res.status === this.code) {
                    this.saleOrgArr = res.content;
                }
            },

            // 物料多选删除
            del (row) {
                let index = null;
                this.multipleData.forEach((item, i) => {
                    if (item.commodityId === row.commodityId) index = i;
                });
                this.multipleData.splice(index, 1);
                this.materialitems.splice(index, 1);
            },
            // 获取表格数据
            getTableList () {
                // 获取客户数据
                this.getCustomerData();
                this.getTableListFn(async call => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr,
                        { salerId: this.salerId }
                    );
                    const res = await getCustomerInfo(params);
                    call(res);
                });
            }
        }
    };
</script>

<style scoped lang="less">
/deep/ .ivu-transfer-list {
    width: 250px;
    height: 400px;
}
/deep/ .ivu-transfer-operation {
    .ivu-btn {
        height: 60px;
    }
}
</style>
