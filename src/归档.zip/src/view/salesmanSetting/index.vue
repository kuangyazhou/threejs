<template>
    <div class="erp-content" ref="erp">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.salerName"
                        @on-search="search"
                        search
                        placeholder="姓名"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                销售员列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button v-has="btnRightList.salersAdd" @click="add" icon="md-add">新增</Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>
        <!--        用户列表弹窗-->
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel"
        >
            <div>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="ios-search"></Icon>
                        查询条件
                    </p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button @click="userSearch" icon="md-search"
                                >搜索
                            </Button>
                            <Button @click="userReset" icon="md-refresh"
                                >重置
                            </Button>
                        </ButtonGroup>
                    </div>
                    <Row :gutter="16">
                        <Col span="12" class="maxWidth">
                            <Input
                                v-model="userTableQuery.realName"
                                @on-search="userSearch"
                                search
                                placeholder="名称"
                            >
                                <Button
                                    @click="userSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                        <Col span="12">
                            <Input
                                v-model="userTableQuery.departmentName"
                                @on-search="userSearch"
                                search
                                placeholder="部门"
                            >
                                <Button
                                    @click="userSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                    </Row>
                </Card>
                <Table
                    border
                    @on-selection-change="selectionUser"
                    :columns="userTableTitle"
                    :data="userTableData"
                    :tableLoading="userTableLoading"
                ></Table>
            </div>
        </Modal>
        <!--客户弹窗-->
        <Modal
            v-model="customerShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="customerModalOk"
            @on-cancel="customerModalCancel"
        >
            <div>
                <Transfer
                    :data="customerGroupAllArr"
                    :target-keys="targetGroupArr"
                    filterable
                    :filter-placeholder="customerPlaceholder"
                    :filter-method="customerFilterMethod"
                    @on-change="handleChangeCustomer"
                ></Transfer>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        addSalesman,
        getSalesManList,
        getUsersList,
        salesmanDisable,
        salesmanEnable,
        addSalerCustomer,
        getSaveCustomerList,
        getAllCustomerList
    } from '@/api/saleManage/sale';
    import { resetObj } from '@/libs/tools';

    export default {
        name: 'salesmanSetting',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    salerName: ''
                }, // 表格查询条件
                formAttr: {
                    items: []
                }, // modal 值对象
                erpTableTitle: [
                    {
                        title: '姓名',
                        align: 'center',
                        minWidth: 120,
                        key: 'salerName'
                    },
                    {
                        title: '性别',
                        align: 'center',
                        minWidth: 90,
                        render: (h, params) => {
                            const sex = params.row.sex ? '女' : '男';
                            return h('span', {}, sex);
                        }
                    },
                    {
                        title: '客户数',
                        align: 'center',
                        minWidth: 100,
                        key: 'countCustomer'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 160,
                        render: (h, params) => {
                            const validFlag = params.row.status === 3;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: validFlag ? 'success' : 'default'
                                    }
                                },
                                validFlag ? '有效' : '无效'
                            );
                        }
                    },
                    {
                        title: '销售组织',
                        align: 'center',
                        minWidth: 100,
                        key: 'saleOrganizationName'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 220,
                        align: 'center',
                        render: (h, params) => {
                            let btnType;
                            if (params.row.status === 3) {
                                btnType = h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'warning',
                                            size: 'small'
                                        },
                                        style: {},
                                        on: {
                                            click: () => {
                                                this.statusSetInvalid(
                                                    params.row.id
                                                );
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.salersSetDisable
                                            }
                                        ]
                                    },
                                    '无效'
                                );
                            } else {
                                btnType = h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'success',
                                            size: 'small'
                                        },
                                        style: {},
                                        on: {
                                            click: () => {
                                                this.statusSetValid(
                                                    params.row.id
                                                );
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.salersSetEnable
                                            }
                                        ]
                                    },
                                    '恢复'
                                );
                            }
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'info',
                                            size: 'small'
                                        },
                                        style: {
                                            marginRight: '5px'
                                        },
                                        on: {
                                            click: () => {
                                                this.currentId = params.row.id;
                                                this.customerPlaceholder =
                                                    '请输入客户名称';
                                                this.modalTitle = '选择客户';
                                                this.getCustomerFormatData();
                                                this.getSaveGroupList();
                                                this.customerShowFlag = true;
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.salersUnitCustomer
                                            }
                                        ]
                                    },
                                    '关联客户'
                                ),
                                btnType
                            ]);
                        }
                    }
                ], // 表格标题
                userTableQuery: {
                    realName: '',
                    departmentName: ''
                }, // 用户弹窗搜索条件
                userTableTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '姓名',
                        align: 'center',
                        minWidth: 100,
                        key: 'realName'
                    },
                    {
                        title: '性别',
                        align: 'center',
                        minWidth: 80,
                        render: (h, params) => {
                            return h('span', {}, params.row.sex);
                        }
                    },
                    {
                        title: '公司',
                        align: 'center',
                        minWidth: 100,
                        key: 'enterpriseName'
                    },
                    {
                        title: '部门',
                        align: 'center',
                        minWidth: 90,
                        key: 'departmentName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 90,
                        render: (h, params) => {
                            const status =
                                params.row.status === 1 ? '有效' : '无效';
                            return h('span', {}, status);
                        }
                    }
                ],
                userTableData: [],
                userTableLoading: false,
                customerShowFlag: false, // 客户弹窗开关
                customerGroupAllArr: [], // 客户源数据
                targetGroupArr: [], // 选中的客户分组
                customerPlaceholder: '' // 穿梭框搜索默认
            };
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getSalesManList(params);
                    getListMixin(res);
                });
            },
            add () {
                this.getUsersList();
                this.addItem('用户选择');
            },
            // 获取可新增的用户列表
            async getUsersList () {
                this.userTableLoading = true;
                const res = await getUsersList(this.userTableQuery);
                if (res.status === this.code) {
                    this.userTableData = res.content;
                    this.userTableLoading = false;
                }
            },
            // 搜索用户
            userSearch () {
                this.getUsersList();
            },
            // 重置用户
            userReset () {
                resetObj(this.userTableQuery);
                this.getUsersList();
            },
            // 选中新增用户
            selectionUser (val) {
                this.formAttr.items = val.map(item => {
                    return {
                        departmentId: item.departmentId,
                        enterpriseId: item.enterpriseId,
                        organizationId: item.organizationId,
                        userId: item.userId
                    };
                });
            },
            // 保存新增销售员
            async modalOk () {
                if (this.formAttr.items.length === 0) {
                    this.changeLoading();
                    return this.$Message.error('请先勾选用户');
                }
                const res = await addSalesman(this.formAttr);
                this.changeLoading();
                if (res.status === this.code) {
                    this.refreshToken().then(() => {
                        this.$Message.success(res.msg);
                        this.modalCancel();
                        this.getTableList();
                    });
                }
            },
            // 获取已关联的客户
            async getSaveGroupList () {
                const params = {
                    salerId: this.currentId
                };
                const res = await getSaveCustomerList(params);
                if (res.status === this.code) {
                    this.targetGroupArr = res.content.map(item => {
                        return item.customerEnableCode;
                    });
                }
            },
            // 保存关联客户
            async customerModalOk () {
                const params = {
                    salerId: this.currentId,
                    customerCodes: this.targetGroupArr
                };
                const res = await addSalerCustomer(params);
                this.changeLoading();
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.customerShowFlag = false;
                    this.getTableList();
                }
            },
            // 关闭客户弹窗
            customerModalCancel () {
                this.customerShowFlag = false;
                this.customerGroupAllArr = [];
                this.targetGroupArr = [];
            },
            // 获取全部客户数据客户数据
            async getCustomerFormatData () {
                const res = await getAllCustomerList();
                if (res.status === this.code) {
                    this.customerGroupAllArr = res.content.map(item => {
                        return {
                            key: item.enableCode,
                            label: item.customerName
                        };
                    });
                }
            },
            // 客户穿梭框改变
            handleChangeCustomer (newTargetKeys) {
                this.targetGroupArr = newTargetKeys;
            },
            // 关键词搜索客户
            customerFilterMethod (data, query) {
                return data.label.indexOf(query) > -1;
            },
            // 状态有效无效
            statusSetInvalid (id) {
                this.$Modal.confirm({
                    title: '确认把该销售员状态设置为无效吗？',
                    onOk: async () => {
                        const params = {
                            id
                        };
                        const res = await salesmanDisable(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getTableList();
                        }
                    }
                });
            },
            // 状态有效有效
            statusSetValid (id) {
                this.$Modal.confirm({
                    title: '确认把该销售员状态恢复为有效吗？',
                    onOk: async () => {
                        const params = {
                            id
                        };
                        const res = await salesmanEnable(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getTableList();
                        }
                    }
                });
            }
        }
    };
</script>

<style scoped lang="less">
/deep/ .ivu-transfer-list {
    width: 250px;
    height: 400px;
}
/deep/ .ivu-transfer-operation {
    .ivu-btn {
        height: 60px;
    }
}
</style>
