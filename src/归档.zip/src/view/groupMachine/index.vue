<template>
    <div class="group-machine">
        <!-- <h1>器械分类-集团</h1> -->
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon> 查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.deviceClassifyName"
                        placeholder="分类名称"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.deviceClassifyCode"
                        placeholder="器械分类"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5">
                    <Select
                        filterable
                        placeholder="所有类别"
                        @on-change="selectSearch"
                        v-model="tableQueryAttr.deviceClassifyType"
                    >
                        <Option
                            v-for="(item, index) in typeList"
                            :label="item.fieldValue"
                            :value="item.id"
                            :key="index"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card :border="false">
            <p slot="title"><Icon type="md-list"></Icon>器械分类列表</p>
            <div slot="extra">
                <Button v-has="btnRightList.groupMachineAdd" @click="add" icon="md-add">新增</Button>
            </div>
            <erp-table
                :erpTableTitle="bankTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
            ></erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-cancel="modalCancel"
            @on-ok="modalOk"
        >
            <div class="erp-modal-content">
                <Form :model="formAttr" :rules="ruleValidate" ref="formValidate" :label-width="120">
                    <FormItem label="分类名称" prop="deviceClassifyName">
                        <Input v-model="formAttr.deviceClassifyName" placeholder="分类名称"></Input>
                    </FormItem>
                    <FormItem label="器械分类" prop="deviceClassifyCode">
                        <Input v-model="formAttr.deviceClassifyCode" placeholder="器械分类"></Input>
                    </FormItem>
                    <FormItem label="器械类别" prop="deviceClassifyType">
                        <Select filterable placeholder="请选择" v-model="formAttr.deviceClassifyType">
                            <Option
                                v-for="item in typeList"
                                :label="item.fieldValue"
                                :value="item.id"
                                :key="item.index"
                            ></Option>
                        </Select>
                    </FormItem>
                    <div v-show="currentId">
                        <FormItem label="状态">
                            <RadioGroup v-model="formAttr.status">
                                <Radio
                                    v-for="item in statusRadio"
                                    :label="item.value"
                                    :key="item.index"
                                >
                                    <span>{{ item.label }}</span>
                                </Radio>
                            </RadioGroup>
                        </FormItem>
                        <FormItem label="创建时间">
                            <Input v-model="formAttr.createTime" disabled placeholder="创建时间"></Input>
                        </FormItem>
                        <FormItem label="创建人">
                            <Input v-model="formAttr.createUserRealName" disabled placeholder="创建人"></Input>
                        </FormItem>
                        <FormItem label="最后修改时间">
                            <Input v-model="formAttr.updateTime" disabled placeholder="最后修改时间"></Input>
                        </FormItem>
                        <FormItem label="最后修改人">
                            <Input
                                v-model="formAttr.updateUserRealName"
                                disabled
                                placeholder="最后修改人"
                            ></Input>
                        </FormItem>
                    </div>
                </Form>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        getMachineList,
        addDeviceType,
        updateDevice
    } from '@/api/dataSet/groupMachine';
    import { getDate } from '@/libs/tools';
    import { getMachineType } from '@/api/common';

    export default {
        components: { ErpTable },
        mixins: [tableMixin],
        data () {
            return {
                formAttr: {
                    deviceClassifyType: '',
                    deviceClassifyCode: '',
                    deviceClassifyName: '',
                    status: '',
                    createTime: '',
                    createUserRealName: '',
                    updateTime: '',
                    updateUserRealName: ''
                },
                tableQueryAttr: {
                    deviceClassifyCode: '',
                    deviceClassifyName: '',
                    deviceClassifyType: ''
                },
                ruleValidate: {
                    deviceClassifyName: [
                        { required: true, message: '分类名称不能为空' }
                    ],
                    deviceClassifyCode: [
                        { required: true, message: '器械分类不能为空' }
                    ],
                    deviceClassifyType: [
                        { required: true, message: '器械类别为必选项' }
                    ]
                },
                typeList: [],
                slectList: [],
                // 状态单选框
                statusRadio: [
                    {
                        label: '无效',
                        value: 4
                    },
                    {
                        label: '有效',
                        value: 3
                    }
                ],
                bankTitle: [
                    {
                        type: 'index',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '器械类别',
                        align: 'center',
                        minWidth: 180,
                        key: 'deviceClassifyTypeName'
                    },
                    {
                        title: '器械分类',
                        align: 'center',
                        minWidth: 100,
                        key: 'deviceClassifyCode'
                    },
                    {
                        title: '分类名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'deviceClassifyName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'organizationName',
                        render: (h, params) => {
                            const status = params.row.status === 3;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: status ? 'success' : 'default'
                                    }
                                },
                                status ? '有效' : '无效'
                            );
                        }
                    },
                    {
                        title: '最后更新人',
                        align: 'center',
                        minWidth: 100,
                        key: 'updateUserRealName'
                    },
                    {
                        title: '最后更新时间',
                        align: 'center',
                        minWidth: 150,
                        key: 'organizationName',
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.updateTime, 'long')
                            );
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            this.getTypeList();
                                            this.editTableData(
                                                params,
                                                '器械编辑',
                                                this.formatTime
                                            );
                                        }
                                    },
                                    directives: [
                                        {
                                            name: 'has',
                                            value: this.btnRightList
                                                .groupMachineUpdate
                                        }
                                    ]
                                },
                                '编辑'
                            );
                        }
                    }
                ]
            };
        },
        methods: {
            add () {
                this.addItem('器械分类新增');
                this.getTypeList();
            },
            modalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res = null;
                    const params = this.currentId
                        ? Object.assign({}, this.formAttr, { id: this.currentId })
                        : Object.assign({}, this.formAttr, {
                            organizationId: this.currentOrganization.id
                    });
                    if (this.currentId) {
                        res = await updateDevice(params);
                    } else {
                        // console.log(params);
                        res = await addDeviceType(params);
                    }
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    } else {
                        this.changeLoading();
                    }
                });
            },
            // 获取器械分类
            async getTypeList () {
                const params = {
                    level: 1,
                    levelId: this.currentOrganization.id,
                    fieldCode: 'device_classify_type'
                };
                const res = await getMachineType(params);
                if (res.status === this.code) {
                    this.typeList = res.content;
                }
            },
            getTableList () {
                this.getTypeList(); // 获取器械分类
                const params = Object.assign(
                    {},
                    this.tableComAttr,
                    this.tableQueryAttr,
                    { organizationId: this.currentOrganization.id }
                );
                this.getTableListFn(async call => {
                    const res = await getMachineList(params);
                    call(res);
                });
            },
            // 格式化时间
            formatTime (row) {
                this.formAttr.createTime = getDate(row.createTime, 'long');
                this.formAttr.updateTime = getDate(row.updateTime, 'long');
            }
        }
    };
</script>

<style scoped>
.erp-modal-content {
    min-height: 250px;
}
</style>
