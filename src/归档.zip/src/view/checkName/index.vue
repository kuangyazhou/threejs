<template>
    <div class="check-name">
        <!-- <h1>核算名称设置</h1> -->
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon> 查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.accountingName"
                        placeholder="核算名称"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.threeLevelEnter"
                        placeholder="三级分录"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <!-- <Input placeholder="全部状态"></Input> -->
                    <Select v-model="tableQueryAttr.status" @on-change="getTableList">
                        <Option label="全部状态" :value="''"></Option>
                        <Option label="待审核" :value="0"></Option>
                        <Option label="已审核" :value="1"></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card :border="false">
            <p slot="title"><Icon type="md-list"></Icon>核算名称</p>
            <div slot="extra">
                <Button @click="add" v-has="btnRightList.checkNameAdd" icon="md-add">新增</Button>
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="checkNameTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
            ></erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel"
        >
            <Form :model="formAttr" :rules="ruleValidate" ref="formValidate" :label-width="120">
                <FormItem label="核算名称" prop="accountingName">
                    <Input v-model="formAttr.accountingName"></Input>
                </FormItem>
                <FormItem label="三级分录">
                    <Input v-model="formAttr.threeLevelEnter"></Input>
                </FormItem>
            </Form>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { getDate } from '@/libs/tools';

    import {
        getCheckName,
        addCheckName,
        checkNameUpdate,
        checkNameDel,
        checkNameAudit,
        cancelAudit
    } from '@/api/materialManage/checkName';

    export default {
        components: { ErpTable },
        mixins: [tableMixin],
        data () {
            return {
                formAttr: {
                    accountingName: '',
                    threeLevelEnter: ''
                },
                tableQueryAttr: {
                    accountingName: '',
                    threeLevelEnter: '',
                    status: ''
                },
                ruleValidate: {
                    accountingName: [
                        {
                            required: true,
                            message: '核算名称不能为空'
                        }
                    ]
                },
                checkNameTitle: [
                    { type: 'index', title: '序号', align: 'center' },
                    {
                        title: '核算名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'accountingName'
                    },
                    {
                        title: '三级分录',
                        align: 'center',
                        minWidth: 100,
                        key: 'threeLevelEnter'
                    },
                    {
                        title: '审核日期',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.approveTime, 'long')
                            );
                        }
                    },
                    {
                        title: '审核人员',
                        align: 'center',
                        minWidth: 100,
                        key: 'approveUserName'
                    },
                    {
                        title: '录入日期',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.updateTime, 'long')
                            );
                        }
                    },
                    {
                        title: '录入人员',
                        align: 'center',
                        minWidth: 100,
                        key: 'updateUserName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'statusDescription'
                    // render: (h, params) => {
                    //     const status = params.row.status === 3;
                    //     return h(
                    //         'Tag',
                    //         {
                    //             props: {
                    //                 color: status ? 'success' : 'default'
                    //             }
                    //         },
                    //         status ? '有效' : '无效'
                    //     );
                    // }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 180,
                        render: (h, params) => {
                            if (params.row.status === 4) {
                                return h('div', [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'primary',
                                                size: 'small'
                                            },
                                            class: 'mr6',
                                            on: {
                                                click: () => {
                                                    this.editTableData(
                                                        params,
                                                        '编辑核算名称'
                                                    );
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList
                                                        .checkNameUpdate
                                                }
                                            ]
                                        },
                                        '编辑'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'warning',
                                                size: 'small'
                                            },
                                            class: 'mr6',
                                            on: {
                                                click: () => {
                                                    this.Audit(params);
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList
                                                        .checkNameAudit
                                                }
                                            ]
                                        },
                                        '审核'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'error',
                                                size: 'small'
                                            },
                                            class: 'mr6',
                                            on: {
                                                click: () => {
                                                    this.delItem(params.row.id);
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList
                                                        .checkNameDel
                                                }
                                            ]
                                        },
                                        '删除'
                                    )
                                ]);
                            } else {
                                return h('div', [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'primary',
                                                size: 'small'
                                            },
                                            class: 'mr6',
                                            on: {
                                                click: () => {
                                                    this.editTableData(
                                                        params,
                                                        '编辑核算名称'
                                                    );
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList
                                                        .checkNameUpdate
                                                }
                                            ]
                                        },
                                        '编辑'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                size: 'small'
                                            },
                                            class: 'mr6',
                                            on: {
                                                click: () => {
                                                    this.cancelAudit(params);
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList
                                                        .checkNameCancel
                                                }
                                            ]
                                        },
                                        '取消审核'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'error',
                                                size: 'small'
                                            },
                                            class: 'mr6',
                                            on: {
                                                click: () => {
                                                    this.delItem(params.row.id);
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList
                                                        .checkNameDel
                                                }
                                            ]
                                        },
                                        '删除'
                                    )
                                ]);
                            }
                        }
                    }
                ]
            };
        },
        methods: {
            add () {
                this.addItem('新增核算名称');
            },
            modalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res = null;
                    const params = this.currentId
                        ? Object.assign({}, this.formAttr, { id: this.currentId })
                        : Object.assign({}, this.formAttr);
                    if (this.currentId) {
                        res = await checkNameUpdate(params);
                    } else {
                        res = await addCheckName(params);
                    }
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    } else {
                        this.changeLoading();
                    }
                });
            },
            getTableList () {
                const params = Object.assign(
                    {},
                    this.tableComAttr,
                    this.tableQueryAttr
                );
                this.getTableListFn(async call => {
                    const res = await getCheckName(params);
                    call(res);
                });
            },
            // 发起审核
            async Audit (item) {
                const params = { id: item.row.id };
                const res = await checkNameAudit(params);
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.getTableList();
                }
            },
            // 取消审核
            async cancelAudit (item) {
                const params = { id: item.row.id };
                const res = await cancelAudit(params);
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.getTableList();
                }
            },
            // 核算名称删除
            delItem (id) {
                this.$Modal.confirm({
                    title: '确认删除此项吗?',
                    onOk: async () => {
                        const params = {
                            id: id
                        };
                        const res = await checkNameDel(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getTableList();
                        }
                    }
                });
            }
        }
    };
</script>
