<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-07 11:05:03
 * @LastEditTime: 2019-08-10 11:28:42
 * @LastEditors: Please set LastEditors
 -->
<template>
    <div class="user-admin">
        <Card dis-hover :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon> 查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.realName"
                        placeholder="用户姓名"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.mobile"
                        placeholder="手机号码"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        @on-change="selectSearch"
                        placeholder="用户状态"
                        remote
                        v-model="tableQueryAttr.status"
                    >
                        <Option
                            v-for="item in statusList"
                            :label="item.label"
                            :value="item.value"
                            :key="item.value"
                        ></Option>
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        @on-change="selectSearch"
                        placeholder="锁定状态"
                        remote
                        v-model="tableQueryAttr.locked"
                    >
                        <Option
                            v-for="item in lockedStatusList"
                            :label="item.label"
                            :value="item.value"
                            :key="item.value"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card :border="false">
            <p slot="title">用户列表</p>
            <div slot="extra">
                <Button v-has="btnRightList.sUserAdd" icon="md-add" @click="add">新增</Button>
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            ></erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :mask-closable="maskClosable"
            @on-cancel="modalCancel"
        >
            <div class="erp-modal-content">
                <Form :model="formAttr" :rules="ruleValidate" ref="formValidate" :label-width="120">
                    <FormItem label="所属组织" prop="organizationName">
                        <Input
                            v-model="currentOrganization.organizationName"
                            disabled
                            placeholder="请输入所属组织"
                        ></Input>
                    </FormItem>
                    <FormItem label="用户名" prop="userName">
                        <Input v-model="formAttr.userName" placeholder="请输入用户名"></Input>
                    </FormItem>
                    <FormItem label="用户姓名" prop="realName">
                        <Input v-model="formAttr.realName" placeholder="请输入用户名"></Input>
                    </FormItem>
                    <FormItem label="所属部门" prop="departmentId">
                        <Button
                            class="button-department"
                            @click="drawerShowFlag = true"
                            icon="ios-arrow-down"
                        >
                            {{
                            formAttr.departmentName
                            ? formAttr.departmentName
                            : '请选择所属部门'
                            }}
                        </Button>
                    </FormItem>
                    <FormItem label="手机号码" prop="mobile">
                        <Input v-model="formAttr.mobile" type="number" placeholder="手机号码"></Input>
                    </FormItem>
                    <FormItem label="性别" prop="sex">
                        <RadioGroup v-model="formAttr.sex">
                            <Radio v-for="item in sexRadio" :label="item.value" :key="item.value">
                                <span>{{ item.label }}</span>
                            </Radio>
                        </RadioGroup>
                    </FormItem>
                    <FormItem label="角色" prop="roleIds">
                        <Select v-model="formAttr.roleIds" placeholder="请选择角色" multiple>
                            <Option
                                v-for="(option, index) in roleArr"
                                :value="option.id"
                                :label="option.roleName"
                                :key="index"
                            ></Option>
                        </Select>
                    </FormItem>
                    <FormItem label="邮箱">
                        <Input v-model="formAttr.email" placeholder="邮箱"></Input>
                    </FormItem>
                    <FormItem label="身份证号">
                        <Input v-model="formAttr.idNumber" placeholder="身份证号"></Input>
                    </FormItem>
                    <div v-if="currentId">
                        <FormItem label="用户状态" prop="status">
                            <RadioGroup v-model="formAttr.status">
                                <Radio
                                    v-for="item in statusList"
                                    :label="item.value"
                                    :key="item.value"
                                >
                                    <span>{{ item.label }}</span>
                                </Radio>
                            </RadioGroup>
                        </FormItem>
                        <FormItem label="锁定状态" prop="locked">
                            <RadioGroup v-model="formAttr.locked">
                                <Radio
                                    v-for="item in lockedStatusList"
                                    :label="item.value"
                                    :key="item.id"
                                >
                                    <span>{{ item.label }}</span>
                                </Radio>
                            </RadioGroup>
                        </FormItem>
                        <FormItem label="创建时间">
                            <Input v-model="formAttr.createTime" disabled placeholder="创建时间"></Input>
                        </FormItem>
                        <FormItem label="创建人">
                            <Input v-model="formAttr.createUserRealName" disabled placeholder="创建人"></Input>
                        </FormItem>
                        <FormItem label="最后修改时间">
                            <Input v-model="formAttr.updateTime" disabled placeholder="最后修改时间"></Input>
                        </FormItem>
                        <FormItem label="最后修改人">
                            <Input
                                v-model="formAttr.updateUserRealName"
                                disabled
                                placeholder="最后修改人"
                            ></Input>
                        </FormItem>
                    </div>
                </Form>
            </div>
            <div slot="footer">
                <Button
                    v-if="judgeBtnRight('sUserResetPassword') && currentId"
                    @click="resetPassword"
                    type="warning"
                >重置密码</Button>
                <Button @click="modalCancel">取消</Button>
                <Button
                    v-if="
                        judgeBtnRight('sUserAdd') || judgeBtnRight('sUserEdit')
                    "
                    :loading="!modelLoading"
                    @click="modalOk"
                    type="primary"
                >确定</Button>
            </div>
        </Modal>

        <!--组织树抽屉-->
        <Drawer title="部门选择" width="360" v-model="drawerShowFlag" :mask-closable="maskClosable">
            <div>
                <Tree :data="departmentTreeData" @on-select-change="handleDepartClick"></Tree>
            </div>
            <div class="depart-drawer-footer">
                <Button style="margin-right: 8px" @click="drawerShowFlag = false">取消</Button>
                <Button type="primary" @click="departDrawerSure">确定</Button>
            </div>
        </Drawer>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        getUserList,
        addUser,
        editUser,
        resetUserPassword
    } from '@/api/setting/user';
    import { getDepartTree } from '@/api/setting/organization';
    import { getRoleList } from '@/api/setting/role';
    import { getDate } from '@/libs/tools';

    export default {
        name: 'sUerManage',
        components: { ErpTable },
        mixins: [tableMixin],
        data () {
            return {
                orgModal: false,
                tableQueryAttr: {
                    realName: '',
                    mobile: '',
                    status: '',
                    locked: ''
                },
                formAttr: {
                    userName: '',
                    realName: '',
                    departmentId: '',
                    departmentName: '',
                    sex: null,
                    mobile: '',
                    email: '',
                    idNumber: '',
                    roleIds: [],
                    status: '',
                    locked: '',
                    createTime: '',
                    createUserRealName: '',
                    updateTime: '',
                    updateUserRealName: '',
                    parentOrganizationName: ''
                },
                sexRadio: [
                    {
                        label: '男',
                        value: 0
                    },
                    {
                        label: '女',
                        value: 1
                    }
                ],
                ruleValidate: {
                    userName: [
                        {
                            required: true,
                            message: '用户名不能为空',
                            trigger: 'blur'
                        }
                    ],
                    realName: [
                        {
                            required: true,
                            message: '用户姓名不能为空',
                            trigger: 'blur'
                        }
                    ],
                    sex: [
                        {
                            required: true,
                            message: '性别不能为空',
                            type: 'number',
                            trigger: 'blur'
                        }
                    ],
                    departmentId: [
                        {
                            required: true,
                            type: 'number',
                            message: '所属部门不能为空',
                            trigger: 'change'
                        }
                    ],
                    mobile: [
                        {
                            required: true,
                            message: '手机号不能为空',
                            trigger: 'blur'
                        },
                        { pattern: /^1[0-9]{10}$/, message: '请输入有效的手机号', trigger: 'blur' }
                    ],
                    status: [
                        {
                            required: true,
                            message: '用户状态不能为空',
                            type: 'number',
                            trigger: 'blur'
                        }
                    ],
                    locked: [
                        {
                            required: true,
                            message: '锁定状态不能为空',
                            type: 'number',
                            trigger: 'blur'
                        }
                    ]
                },
                erpTableTitle: [
                    {
                        title: '用户名',
                        minWidth: 100,
                        align: 'center',
                        key: 'userName'
                    },
                    {
                        title: '用户姓名',
                        minWidth: 100,
                        align: 'center',
                        key: 'realName'
                    },
                    {
                        title: '性别',
                        minWidth: 100,
                        align: 'center',
                        render: (h, params) => {
                            const sex = params.row.sex === 1;
                            return h('span', {}, sex ? '女' : '男');
                        }
                    },
                    {
                        title: '手机号码',
                        minWidth: 100,
                        align: 'center',
                        key: 'mobile'
                    },
                    {
                        title: '角色',
                        align: 'center',
                        minWidth: 200,
                        render: (h, params) => {
                            const roleArr = params.row.roles.map(item => {
                                return h(
                                    'Tag',
                                    {
                                        props: {
                                            color: 'blue'
                                        },
                                        style: {}
                                    },
                                    item.roleName
                                );
                            });
                            return h('div', roleArr);
                        }
                    },
                    {
                        title: '所属部门',
                        minWidth: 110,
                        align: 'center',
                        key: 'departmentName'
                    },
                    {
                        title: '所属公司',
                        minWidth: 110,
                        align: 'center',
                        key: 'enterpriseName'
                    },
                    {
                        title: '角色状态',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            const validFlag = params.row.status === 1;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: validFlag ? 'success' : 'default'
                                    }
                                },
                                validFlag ? '有效' : '无效'
                            );
                        }
                    },
                    {
                        title: '是否锁定',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            const validFlag = params.row.locked === 1;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: validFlag ? 'success' : 'default'
                                    }
                                },
                                validFlag ? '否' : '是'
                            );
                        }
                    },
                    {
                        title: '最后更新人',
                        minWidth: 100,
                        align: 'center',
                        key: 'updateUserRealName'
                    },
                    {
                        title: '最后更新时间',
                        minWidth: 150,
                        align: 'center',
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                params.row.updateTime
                                    ? getDate(params.row.updateTime, 'long')
                                    : ''
                            );
                        }
                    },
                    {
                        title: '操作',
                        minWidth: 100,
                        align: 'center',
                        fixed: 'right',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.editTableData(
                                                    params,
                                                    '用户编辑',
                                                    this.dataFormat
                                                );
                                            }
                                        }
                                    },
                                    '编辑'
                                )
                            ]);
                        }
                    }
                ],
                lockedStatusList: [
                    {
                        id: 1,
                        value: 1,
                        label: '正常'
                    },
                    {
                        id: 2,
                        value: 0,
                        label: '锁定'
                    }
                ], // 锁定状态数组
                drawerShowFlag: false, // 组织树抽屉开关
                treeData: [], // 组织树源数据
                departmentTreeData: [], // 格式化后组织树
                currentTreeNode: '', // 选中的当前tree节点
                roleArr: [] // 角色数组
            };
        },
        created () {
            this.getAllSelectData();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getUserList(params);
                    if (res.status === this.code) {
                        getListMixin(res);
                    }
                });
            },
            add () {
                this.addItem('用户新增');
            },
            modalOk () {
                this.modelLoading = false;
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res = null;
                    let params;
                    if (this.currentId) {
                        params = Object.assign({}, this.formAttr, {
                            id: this.currentId,
                            organizationId: this.currentOrganization.id
                        });
                        res = await editUser(params);
                    } else {
                        params = Object.assign({}, this.formAttr, {
                            organizationId: this.currentOrganization.id
                        });
                        res = await addUser(params);
                    }
                    if (res.status === this.code) {
                        this.refreshToken().then(() => {
                            this.todoOver(res.msg);
                            this.changeLoading();
                        }).catch(() => {
                            this.changeLoading();
                        });
                    } else {
                        this.changeLoading();
                    }
                });
            },
            // 编辑前格式化数据
            dataFormat (row) {
                const roleIds = row.roles.map(function (item) {
                    return Number(item.id);
                });
                if (!row.departmentId && row.enterpriseId) {
                    this.formAttr = Object.assign({}, this.formAttr, {
                        departmentId: row.enterpriseId,
                        departmentName: row.enterpriseName,
                        createTime: getDate(row.createTime, 'long'),
                        updateTime: getDate(row.updateTime, 'long'),
                        roleIds,
                        type: 2
                    });
                } else {
                    this.formAttr = Object.assign({}, this.formAttr, {
                        createTime: getDate(row.createTime, 'long'),
                        updateTime: getDate(row.updateTime, 'long'),
                        roleIds,
                        type: 1
                    });
                }
                this.formatOrganizationTree();
            },
            // 获取组织树数据
            async getDepartmentTree () {
                const params = {
                    organizationId: this.currentOrganization.id,
                    status: 1
                };
                const res = await getDepartTree(params);
                if (res.status === this.code) {
                    this.treeData = res.content;
                    this.formatOrganizationTree();
                }
            },
            // 格式化组织树
            formatOrganizationTree () {
                const tree = this.treeData;
                this.departmentTreeData = [
                    {
                        children: this.backendResourcesToTrees(tree[0].children),
                        expand: true,
                        id: tree[0].id,
                        edId: tree[0].edId,
                        parentId: tree[0].parentId,
                        parentEdId: tree[0].parentEdId,
                        parentName: tree[0].name,
                        title: tree[0].name,
                        type: tree[0].type
                    }
                ];
            },
            backendResourcesToTrees (list) {
                let data = [];
                if (list && Array.isArray(list)) {
                    list.forEach(item => {
                        // 将后端数据转换成tree
                        let treeItem = this.backendResourceToTree(item);
                        // 如果后端数据有下级，则递归处理下级
                        if (item.children && item.children.length !== 0) {
                            treeItem.children = this.backendResourcesToTrees(
                                item.children
                            );
                        }
                        data.push(treeItem);
                    });
                }
                return data;
            },
            backendResourceToTree (item) {
                // const hasChild = item.children && item.children.length !== 0;
                const hasSelected = item.edId === this.formAttr.departmentId;
                const obj = {
                    title: item.name,
                    expand: false,
                    parentId: item.parentId,
                    parentEdId: item.parentEdId,
                    parentName: item.parentName,
                    selected: hasSelected,
                    id: item.id,
                    edId: item.edId,
                    type: item.type
                };
                if (hasSelected) this.currentTreeNode = obj;
                return obj;
            },
            // 点击组织tree
            handleDepartClick (arr, cur) {
                this.currentTreeNode = cur;
            },
            // 确认选中部门
            departDrawerSure () {
                this.formAttr = Object.assign({}, this.formAttr, {
                    departmentId: this.currentTreeNode.edId,
                    type: this.currentTreeNode.type,
                    departmentName: this.currentTreeNode.title
                });
                this.drawerShowFlag = false;
            },
            // 获取该页面所有下拉框数据
            getAllSelectData () {
                this.getDepartmentTree();
                this.getRoleData();
            },
            // 获取角色数据
            async getRoleData () {
                const params = {};
                const res = await getRoleList(params);
                if (res.status === this.code) {
                    this.roleArr = res.content;
                }
            },
            // 重置密码
            resetPassword () {
                this.$Modal.confirm({
                    title: '是否确定重置密码？',
                    onOk: async () => {
                        const params = {
                            userId: this.currentId
                        };
                        const res = await resetUserPassword(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.content);
                        }
                    }
                });
            }
        }
    };
</script>

<style scoped lang="less">
.search-container,
.org-tag {
    margin-bottom: 16px;
}

.searchInput {
    width: 180px;
    margin-right: 24px;
}
.v-transfer-dom {
    /deep/ .ivu-drawer-mask {
        z-index: 4000;
    }
    /deep/ .ivu-drawer-wrap {
        z-index: 9999;
    }
}

.button-department {
    width: 100%;
    text-align: left;
    padding-left: 7px;
    padding-right: 24px;
    position: relative;
    /deep/ .ivu-icon-ios-arrow-down {
        position: absolute;
        top: 50%;
        right: 8px;
        margin-top: -7px;
    }
    /deep/ span {
        margin-left: 0;
    }
}

.depart-drawer-footer {
    width: 100%;
    position: absolute;
    bottom: 0;
    left: 0;
    border-top: 1px solid #e8e8e8;
    padding: 10px 16px;
    text-align: right;
    background: #fff;
}
</style>
