<template>
    <div class="erp-content" ref="erp">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.purchaseGroupName"
                        @on-search="search"
                        search
                        placeholder="采购组名称"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        placeholder="采购组织"
                        @on-change="search"
                        remote
                        v-model="tableQueryAttr.purchaseOrganizationId"
                    >
                        <Option
                            v-for="item in purchaseOrganizationArr"
                            :label="item.purchaseOrganizationName"
                            :value="item.id"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                采购组列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button v-has="btnRightList.purchaseGroupAdd" @click="add" icon="md-add">新增</Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>
        <!--        新增采购组弹窗-->
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel"
        >
            <div>
                <Form
                    :model="formAttr"
                    :rules="ruleValidate"
                    ref="formValidate"
                    :label-width="120"
                >
                    <Row>
                        <Col span="12">
                            <FormItem
                                label="采购组织"
                                prop="purchaseOrganizationId"
                            >
                                <Select
                                    placeholder="请选择采购组织"
                                    remote
                                    v-model="formAttr.purchaseOrganizationId"
                                >
                                    <Option
                                        v-for="item in purchaseOrganizationArr"
                                        :label="item.purchaseOrganizationName"
                                        :value="item.id"
                                        :key="item.id"
                                    ></Option>
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem
                                label="采购组名称"
                                prop="purchaseGroupName"
                            >
                                <Input
                                    v-model="formAttr.purchaseGroupName"
                                    placeholder="请输入采购组名称"
                                ></Input>
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="md-list"></Icon>
                        采购组成员列表
                    </p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button v-has="btnRightList.purchaseGroupBuyerAdd" @click="openGroupBuyer">新增</Button>
                        </ButtonGroup>
                    </div>
                    <Table
                        border
                        :columns="purchaserTableTitle"
                        :data="purchaserTableData"
                        :tableLoading="purchaserTableLoading"
                    ></Table>
                </Card>
            </div>
        </Modal>
        <!--        采购员列表弹窗-->
        <Modal
            v-model="buyerShowFlag"
            width="700"
            title="选择采购员"
            :loading="buyerModelLoading"
            :mask-closable="maskClosable"
            @on-ok="buyerModalOk"
            @on-cancel="buyerModalCancel"
        >
            <div>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="ios-search"></Icon>
                        查询条件
                    </p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button @click="buyerSearch" icon="md-search"
                                >搜索
                            </Button>
                            <Button @click="buyerReset" icon="md-refresh"
                                >重置
                            </Button>
                        </ButtonGroup>
                    </div>
                    <Row :gutter="16">
                        <Col span="12" class="maxWidth">
                            <Input
                                v-model="buyerTableQuery.realName"
                                @on-search="buyerSearch"
                                search
                                placeholder="名称"
                            >
                                <Button
                                    @click="buyerSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                        <Col span="12">
                            <Input
                                v-model="buyerTableQuery.departmentName"
                                @on-search="buyerSearch"
                                search
                                placeholder="部门"
                            >
                                <Button
                                    @click="buyerSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                    </Row>
                </Card>
                <Table
                    border
                    @on-selection-change="selectionBuyer"
                    :columns="buyerTableTitle"
                    :data="buyerTableData"
                    height="320"
                    :tableLoading="buyerTableLoading"
                ></Table>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        getPurchaseGroupList,
        getCompanyPurchaseOrganizationList,
        addPurchaseGroup,
        getPurchaseGroupDetail,
        editPurchaseGroup,
        getCompanyBuyerList,
        purchaseGroupAddBuyer,
        purchaseGroupDeleteBuyer,
        delPurchaseGroup
    } from '@/api/purchaseManage/purchaseGroup';
    import { resetObj } from '@/libs/tools';

    export default {
        name: 'purchaseGroupSetting',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    purchaseGroupName: '',
                    purchaseOrganizationId: ''
                }, // 表格查询条件
                formAttr: {
                    purchaseOrganizationId: '',
                    purchaseGroupName: '',
                    purchaserIds: []
                }, // modal 值对象
                ruleValidate: {
                    purchaseOrganizationId: [
                        {
                            required: true,
                            type: 'number',
                            message: '采购组织不能为空',
                            trigger: 'change'
                        }
                    ],
                    purchaseGroupName: [
                        {
                            required: true,
                            message: '采购组名称不能为空',
                            trigger: 'blur'
                        }
                    ]
                }, // modal 表单验证
                erpTableTitle: [
                    {
                        title: '采购组织',
                        align: 'center',
                        minWidth: 140,
                        key: 'purchaseOrganizationName'
                    },
                    {
                        title: '采购组名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'purchaseGroupName'
                    },
                    {
                        title: '组内成员',
                        align: 'center',
                        minWidth: 200,
                        key: 'purchaserNames'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 120,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        style: {
                                            marginRight: '5px'
                                        },
                                        on: {
                                            click: () => {
                                                this.currentId = params.row.id;
                                                this.modalTitle = '编辑采购组';
                                                this.getPurchaseGroupDetail();
                                                this.modalShowFlag = true;
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.purchaseGroupEdit
                                            }
                                        ]
                                    },
                                    '编辑'
                                ),
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'error',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.delPurchaseGroup(
                                                    params.row.id
                                                );
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.purchaseGroupDel
                                            }
                                        ]
                                    },
                                    '删除'
                                )
                            ]);
                        }
                    }
                ], // 表格标题
                purchaseOrganizationArr: [], // 当前公司的采购组织
                purchaserTableTitle: [
                    {
                        type: 'index',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '姓名',
                        align: 'center',
                        minWidth: 100,
                        key: 'name'
                    },
                    {
                        title: '性别',
                        align: 'center',
                        minWidth: 90,
                        render: (h, params) => {
                            return h('span', {}, params.row.sex);
                        }
                    },
                    {
                        title: '专业名称',
                        align: 'center',
                        minWidth: 90,
                        key: 'professionalNames'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 90,
                        key: 'statusDesc'
                    },
                    {
                        title: '操作',
                        minWidth: 100,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'error',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                if (params.row.id) {
                                                    this.purchaserTableData.splice(
                                                        params.index,
                                                        1
                                                    );
                                                    return;
                                                }
                                                this.delGroupBuyer(
                                                    params.row
                                                        .purchaseGroupPurchaseId
                                                );
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.purchaseGroupBuyerDel
                                            }
                                        ]
                                    },
                                    '删除'
                                )
                            ]);
                        }
                    }
                ], // 采购组成员栏目
                purchaserTableData: [], // 采购组成员列表
                purchaserTableLoading: false,
                buyerShowFlag: false, // 采购员弹窗开关
                buyerModelLoading: false,
                buyerTableQuery: {
                    realName: '',
                    departmentName: ''
                },
                curBuyerId: [], // 选中的采购员id
                curBuyerList: [],
                buyerTableTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '姓名',
                        align: 'center',
                        minWidth: 100,
                        key: 'realName'
                    },
                    {
                        title: '性别',
                        align: 'center',
                        minWidth: 90,
                        render: (h, params) => {
                            return h('span', {}, params.row.sex);
                        }
                    },
                    {
                        title: '公司',
                        align: 'center',
                        minWidth: 100,
                        key: 'enterpriseName'
                    },
                    {
                        title: '部门',
                        align: 'center',
                        minWidth: 90,
                        key: 'departmentName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 90,
                        render: (h, params) => {
                            const status =
                                params.row.status === 3 ? '有效' : '无效';
                            return h('span', {}, status);
                        }
                    }
                ], // 采购员列表栏目
                buyerTableData: [],
                buyerTableLoading: false
            };
        },
        created () {
            this.getCompanyPurchaseOrganizationList();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getPurchaseGroupList(params);
                    getListMixin(res);
                });
            },
            // 新增编辑确认按钮
            modalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res;
                    const params = this.currentId
                        ? Object.assign({}, this.formAttr, {
                            id: this.currentId,
                            organizationId: this.currentOrganization.id
                        })
                        : Object.assign({}, this.formAttr, {
                            organizationId: this.currentOrganization.id
                    });
                    if (this.currentId) {
                        res = await editPurchaseGroup(params);
                    } else {
                        res = await addPurchaseGroup(params);
                    }
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    } else {
                        this.changeLoading();
                    }
                });
            },
            add () {
                this.purchaserTableData = [];
                this.addItem('新增采购组');
            },
            // 获取当前公司的采购组织
            async getCompanyPurchaseOrganizationList () {
                const res = await getCompanyPurchaseOrganizationList();
                if (res.status === this.code) {
                    this.purchaseOrganizationArr = res.content;
                }
            },
            // 获取当前公司所有采购员
            async getCompanyBuyerList () {
                this.buyerTableLoading = true;
                const params = this.currentId ? Object.assign({}, this.buyerTableQuery, {
                    purchaseGroupId: this.currentId
                }) : Object.assign({}, this.buyerTableQuery);
                const res = await getCompanyBuyerList(params);
                this.buyerTableLoading = false;
                if (res.status === this.code) {
                    this.buyerTableData = res.content;
                }
            },
            // 确认选中采购员
            async buyerModalOk () {
                if (this.curBuyerId.length === 0) {
                    this.$Message.error('请先勾选采购员');
                    this.changeLoading('buyerModelLoading');
                    return;
                }
                if (!this.currentId) {
                    const purchaserIds = this.purchaserTableData.map(item => {
                        return item.purchaserId;
                    });
                    this.formAttr.purchaserIds = this.curBuyerId;
                    this.curBuyerList.forEach(item => {
                        if (!purchaserIds.includes(item.id)) {
                            this.purchaserTableData.push({
                                id: item.id,
                                name: item.realName,
                                sex: item.sex,
                                professionalNames: '',
                                statusDesc: item.status === 3 ? '有效' : '无效'
                            });
                        }
                    });
                    this.changeLoading('buyerModelLoading');
                    this.buyerModalCancel();
                } else {
                    const params = {
                        purchaseGroupId: this.currentId,
                        purchaserIds: this.curBuyerId
                    };
                    const res = await purchaseGroupAddBuyer(params);
                    this.changeLoading('buyerModelLoading');
                    if (res.status === this.code) {
                        this.$Message.success(res.msg);
                        this.buyerModalCancel();
                        this.getPurchaseGroupDetail();
                    } else {
                        this.curBuyerId = [];
                        this.curBuyerList = [];
                        this.getCompanyBuyerList();
                    }
                }
            },
            // 关闭采购员弹窗
            buyerModalCancel () {
                this.buyerTableData = [];
                this.curBuyerId = [];
                this.curBuyerList = [];
                this.buyerShowFlag = false;
                resetObj(this.buyerTableQuery);
            },
            // 搜索采购员列表
            buyerSearch () {
                this.getCompanyBuyerList();
            },
            // 重置采购员搜索
            buyerReset () {
                resetObj(this.buyerTableQuery);
                this.getCompanyBuyerList();
            },
            // 选中采购员
            selectionBuyer (value) {
                this.curBuyerList = value;
                this.curBuyerId = value.map(item => {
                    return item.id;
                });
            },
            // 打开采购员弹窗
            openGroupBuyer () {
                this.getCompanyBuyerList();
                this.buyerShowFlag = true;
            },
            // 获取当前采购组明细
            async getPurchaseGroupDetail () {
                const params = {
                    id: this.currentId
                };
                const res = await getPurchaseGroupDetail(params);
                if (res.status === this.code) {
                    this.purchaserTableData = res.content.purchaserInfoList;
                    this.formAttr = Object.assign(
                        {},
                        {
                            purchaseOrganizationId:
                                res.content.purchaseOrganizationId,
                            purchaseGroupName: res.content.purchaseGroupName
                        }
                    );
                }
            },
            // 删除关联的采购员
            delGroupBuyer (id) {
                this.$Modal.confirm({
                    title: '确认删除该采购员吗？',
                    onOk: async () => {
                        const params = {
                            purchaseGroupPurchaseId: id
                        };
                        const res = await purchaseGroupDeleteBuyer(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getPurchaseGroupDetail();
                            this.getTableList();
                        }
                    }
                });
            },
            // 删除采购组
            delPurchaseGroup (id) {
                this.$Modal.confirm({
                    title: '确认删除该采购组吗？',
                    onOk: async () => {
                        const params = {
                            id
                        };
                        const res = await delPurchaseGroup(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getTableList();
                        }
                    }
                });
            }
        }
    };
</script>

<style scoped lang="less"></style>
