`<template>
    <div>
        <div class="page computed">
            <table border="0" cellspacing="1" cellpadding="0">
                <tr>
                    <th>产品编号</th>
                    <th>产品名称</th>
                    <th>规格</th>
                    <th>单位</th>
                    <th>数量</th>
                    <th>储运条件</th>
                    <th>生产企业</th>
                    <th>批号</th>
                    <th>有效期</th>
                    <th>注册证号</th>
                </tr>
                <tr ref="heightItem" v-for="(item, index) in printList" :key="index">
                    <td class="four">{{item.commodityCode}}</td>
                    <td class="four">{{item.commodityName}}</td>
                    <td class="two">{{item.commoditySpec}}</td>
                    <td class="two">{{item.unitName}}</td>
                    <td class="two">{{item.quantity}}</td>
                    <td class="four">{{item.storageCondition}}</td>
                    <td class="four">{{item.manufacturerName}}</td>
                    <td class="two">{{item.batchNo}}</td>
                    <td class="three date">{{getDate(item.effectiveDate)}}</td>
                    <td class="four">{{item.registerNumber}}</td>
                </tr>
            </table>
        </div>
        <div class="page" v-for="(printList, i) in pageList" :key="i" style="page-break-before: always;">
            <div class="c-name">武汉奥申博科技有限公司</div>
            <p>销售出库单</p>
            <div class="clearfix mb10">
                <div class="fl fs14 left">
                    购货单位：{{detail.customerName}}
                </div>
                <div class="fr fs14 right">
                    收货人：{{detail.receiveName}}

                </div>
            </div>
            <div class="clearfix mb10">
                <div class="fl fs14 left">
                    收货地址：{{detail.receiveAddress}}
                </div>
                <div class="fr fs14 right">
                    收货电话：{{detail.receivePhone}}
                </div>
            </div>
            <div class="clearfix mb10">
                <div class="fl fs14 left">
                    单号：{{detail.outboundCode}}
                </div>
                <div class="fr fs14 right">
                    日期：{{getDate(detail.createTime)}}
                </div>
            </div>
            <table border="0" cellspacing="1" cellpadding="0">
                <tr>
                    <th>产品编号</th>
                    <th>产品名称</th>
                    <th>规格</th>
                    <th>单位</th>
                    <th>数量</th>
                    <th>储运条件</th>
                    <th>生产厂家</th>
                    <th>批号</th>
                    <th>有效期</th>
                    <th>注册证号</th>
                </tr>
                <tr v-for="(item, index) in printList" :key="index">
                    <td class="four">{{item.commodityCode}}</td>
                    <td class="four">{{item.commodityName}}</td>
                    <td class="two">{{item.commoditySpec}}</td>
                    <td class="two">{{item.unitName}}</td>
                    <td class="two">{{item.quantity}}</td>
                    <td class="four">{{item.storageCondition}}</td>
                    <td class="four">{{item.manufacturerName}}</td>
                    <td class="two">{{item.batchNo}}</td>
                    <td class="three date">{{getDate(item.effectiveDate)}}</td>
                    <td class="four">{{item.registerNumber}}</td>
                </tr>
            </table>
            <div class="total fs14 mt10">
                <span>数量合计：{{detail.totalQuantity}}</span>
            </div>
            <div class="clearfix notice mt10">
                <div class="fl w33 fs14">
                    制单：{{detail.createName}}
                </div>
                <div class="fl w33 fs14">
                    复核员：
                </div>
                <div class="fl w33 fs14">
                    收货人：
                </div>
            </div>
            <div class="tel fs14 mt10">
                电话：{{detail.shippingPhone}}
            </div>
            <div class="clearfix fs14">
                <div class="fr">第{{i+1}}页/共{{pageList.length}}页</div>
            </div>
        </div>
    </div>

</template>

<script>
    export default {
        name: 'deliveryNotice',
        data () {
            return {
                printWidth: 0,
                printHeight: 0,
                customerName: '', // 收货单位
                customerAddress: '', // 收货地址
                orderNo: '', // 单号
                person: '', // 收货人
                pageList: [], // 表格分页
                printList: [], // 自动分页计算数据
                detail: {} // 其他信息
            };
        },
        mounted () {
            this.printWidth = this.mmConversionPx(280);
            this.printHeight = this.mmConversionPx(240);
            window.addEventListener('message', (e) => {
                // console.log(e.origin, e.data); // 子页面接收参数
                if (e.data && !e.data.data && !e.data.type) {
                    const detail = JSON.parse(e.data);
                    console.log(detail);
                    this.customerName = detail.customerName;
                    this.customerAddress = detail.customerAddress;
                    const printList = [...detail.itemList] || [];
                    // let arr = [];
                    // for (let i = 0, len = 10; i < len; i++) {
                    //     arr.push(...detail.itemList);
                    // }
                    // const printList = arr || [];
                    this.printList = printList;
                    this.detail = detail;
                    this.$nextTick(() => {
                        this.pageList = this.setItemMaxHeight(printList);
                    });
                }
            }, false);
        },
        methods: {
            /**
             * @param {Number} timeStamp 判断时间戳格式是否是毫秒
             * @returns {Boolean}
             */
            isMillisecond (timeStamp) {
                const timeStr = String(timeStamp);
                return timeStr.length > 10;
            },
            /**
             * @param {Number} num 数值
             * @returns {String} 处理后的字符串
             * @description 如果传入的数值小于10，即位数只有1位，则在前面补充0
             */
            getHandledValue (num) {
                return num < 10 ? '0' + num : num;
            },
            /**
             * @param {Number} timeStamp 传入的时间戳
             * @param {Number} startType 要返回的时间字符串的格式类型，传入'long'则返回年开头的完整时间
             */
            getDate (timeStamp, startType) {
                if (!timeStamp) return '';
                // 判断当前传入的时间戳是秒格式还是毫秒
                const IS_MILLISECOND = this.isMillisecond(timeStamp);
                const d = IS_MILLISECOND
                    ? new Date(timeStamp * 1)
                    : new Date(timeStamp * 1000);
                const year = d.getFullYear();
                const month = this.getHandledValue(d.getMonth() + 1);
                const date = this.getHandledValue(d.getDate());
                const hours = this.getHandledValue(d.getHours());
                const minutes = this.getHandledValue(d.getMinutes());
                const second = this.getHandledValue(d.getSeconds());
                let resStr = '';
                if (startType === 'long') {
                    resStr =
                        year +
                        '-' +
                        month +
                        '-' +
                        date +
                        ' ' +
                        hours +
                        ':' +
                        minutes +
                        ':' +
                        second;
                } else {
                    resStr = year + '-' + month + '-' + date;
                }
                return resStr;
            },
            setItemMaxHeight (arr) {
                let tableMaxHeight = 440;
                let currentHeight = 0;
                let newArr = [];
                let tpl = [];
                arr.forEach((item, index) => {
                    // 预先加上每行的高度
                    currentHeight += this.$refs.heightItem[index].getBoundingClientRect().height;
                    // 如果高度不超过一页的最大高度
                    if (currentHeight < tableMaxHeight) {
                        // 做成一页
                        tpl.push(item);
                        // 如果循环结束，还没超过一页的最大高度
                        if (index === arr.length - 1) {
                            newArr.push(tpl);
                            currentHeight = 0;
                            tpl = [];
                        }
                    } else {
                        // 如果加上后的高度超过了一页的最大高度
                        newArr.push(tpl);
                        tpl = [item];
                        currentHeight = this.$refs.heightItem[index].getBoundingClientRect().height;
                    }
                });
                console.log(newArr);
                return newArr;
            },
            formatDate () {
                const d = new Date();
                const year = d.getFullYear();
                const month = d.getMonth() + 1;
                const date = d.getDate();
                return `${year}年${month}月${date}日`;
            },
            conversion_getDPI () {
                let arrDPI = [];
                if (window.screen.deviceXDPI) {
                    arrDPI[0] = window.screen.deviceXDPI;
                    arrDPI[1] = window.screen.deviceYDPI;
                } else {
                    let tmpNode = document.createElement('DIV');
                    tmpNode.style.cssText = 'width:1in;height:1in;position:absolute;left:0px;top:0px;z-index:99;visibility:hidden';
                    document.body.appendChild(tmpNode);
                    arrDPI[0] = parseInt(tmpNode.offsetWidth);
                    arrDPI[1] = parseInt(tmpNode.offsetHeight);
                    tmpNode.parentNode.removeChild(tmpNode);
                }
                return arrDPI;
            },
            pxConversionMm (value) {
                let inch = value / this.conversion_getDPI()[0];
                return inch * 25.4;
            },
            mmConversionPx (value) {
                let inch = value / 25.4;
                return inch * this.conversion_getDPI()[0];
            }
        }
    };
</script>

<style scoped lang="less">
    * {
        /*font-family: 'SimHei'!important;*/
        color: #000;
    }

    .page {
        /*border: 1px dotted #000;*/
        padding: 30px;
        margin-bottom: 20px;
        &.computed {
            width: 990px;
            position: fixed;
            left: -100%;
            top: -100%;
            visibility: hidden;
        }
    }

    .c-name {
        font-size: 16px;
        font-weight: normal;
        text-align: center;
        letter-spacing: 4px;
        margin-top: 20px;
    }

    p {
        font-size: 16px;
        letter-spacing: 2px;
        text-align: center;
        margin-bottom: 10px;
        /*margin-top: 10px;*/
    }

    .fl {
        float: left;
    }

    .fr {
        float: right;
    }

    .clearfix:after {
        content: "";
        display: block;
        height: 0;
        clear: both;
        visibility: hidden;
    }

    .clearfix {
        *zoom: 1;
    }

    .mb10 {
        margin-bottom: 6px;
    }

    .mt10 {
        margin-top: 10px;
    }

    .fs14 {
        font-size: 12px;
    }

    .w33 {
        width: 33.33%;
    }

    .left {
        width: 70%;
    }

    .right {
        width: 30%;
    }

    table {
        border-collapse: collapse;
        margin: 16px auto 0;
        text-align: center;
        width: 100%;
        th {
            font-weight: normal;
        }
    }

    table td, table th {
        border: 1px solid #000;
        color: #000;
        height: 30px;
        font-size: 12px !important;
        white-space: pre-line;
        word-wrap: break-word;
        word-break: break-all;
        padding: 2px;
    }

    table td {
        &.two {
            min-width: 34px;
        }
        &.three {
            min-width: 50px;
        }
        &.four {
            min-width: 60px;
        }
    }

    table td.date {
        min-width: 80px;
    }

    .total {
        margin-top: 10px;
        border-bottom: 1px solid #000;
        padding-bottom: 4px;
    }
</style>
<style media="print">
    @page {
        size: auto;  /* auto is the initial value */
        margin: 0mm 10mm; /* this affects the margin in the printer settings */
        /*font-family: 'SimHei'!important;*/
        /*color: #000;*/
    }

    body {
        font-family: 'Microsoft JhengHei';
    }

    .fs14 {
        font-size: 10px;
    }

    .table td, table th {
        font-size: 810px;
    }

    /** {*/
    /*font-family: 'SimHei'!important;*/
    /*color: #000;*/
    /*}*/
</style>
`
