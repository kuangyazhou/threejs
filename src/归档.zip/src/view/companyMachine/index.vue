<template>
    <div class="group-machine">
        <!-- <h1>器械分类-公司</h1> -->
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon> 查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.deviceClassifyName"
                        placeholder="分类名称"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.deviceClassifyCode"
                        placeholder="器械分类"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5">
                    <Select
                        filterable
                        placeholder="所有类别"
                        v-model="tableQueryAttr.deviceClassifyType"
                        @on-change="selectSearch"
                    >
                        <Option
                            v-for="(item, index) in slectList"
                            :label="item.fieldValue"
                            :value="item.id"
                            :key="index"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card :border="false">
            <p slot="title"><Icon type="md-list"></Icon>器械分类列表</p>
            <div slot="extra">
                <Button v-has="btnRightList.companyMachineImport" @click="add" icon="md-add">引入</Button>
            </div>
            <erp-table
                :erpTableTitle="bankTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
            ></erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-cancel="modalCancel"
            @on-ok="modalOk"
        >
            <div class="erp-modal-content">
                <CheckboxGroup v-model="unSetdData" v-if="checkData.length > 0">
                    <div v-for="item in checkData" :key="item.index" class="checkbox-container">
                        <Checkbox :label="item.id" class="f16">
                            <!-- {{
                                `${item.deviceClassifyType},${
                                    item.deviceClassifyCode
                                } ${item.deviceClassifyTypeName}`
                            }}-->
                            {{
                            `${item.deviceClassifyTypeName},
                            ${item.deviceClassifyCode},
                            ${item.deviceClassifyName}`
                            }}
                        </Checkbox>
                    </div>
                </CheckboxGroup>
                <p v-else>暂无可选数据</p>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { getDate } from '@/libs/tools';
    import {
        getMachineList,
        getUnsedList,
        importDevice,
        delDevice
    } from '@/api/dataSet/companyMachine';
    import { getMachineType } from '@/api/common';
    export default {
        components: { ErpTable },
        mixins: [tableMixin],

        data () {
            return {
                tableQueryAttr: {
                    deviceClassifyName: '',
                    deviceClassifyType: '',
                    deviceClassifyCode: ''
                },
                ruleValidate: {},
                slectList: [],
                bankData: [],
                unSetdData: [],
                checkData: [], // 未引入分类器械数据
                bankTitle: [
                    {
                        type: 'index',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '器械类别',
                        align: 'center',
                        minWidth: 180,
                        key: 'deviceClassifyTypeName'
                    },
                    {
                        title: '器械分类',
                        align: 'center',
                        minWidth: 100,
                        key: 'deviceClassifyCode'
                    },
                    {
                        title: '分类名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'deviceClassifyName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'organizationName',
                        render: (h, params) => {
                            const status = params.row.status === 3;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: status ? 'success' : 'default'
                                    }
                                },
                                status ? '有效' : '无效'
                            );
                        }
                    },
                    {
                        title: '最后更新人',
                        align: 'center',
                        minWidth: 100,
                        key: 'createUserRealName'
                    },
                    {
                        title: '最后更新时间',
                        align: 'center',
                        minWidth: 150,
                        key: 'createTime',
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {
                                        type: 'error',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            // this.editTableData(params, "银行编辑");
                                            this.del(params);
                                        }
                                    },
                                    directives: [
                                        {
                                            name: 'has',
                                            value: this.btnRightList
                                                .companyMachineDel
                                        }
                                    ]
                                },
                                '删除'
                            );
                        }
                    }
                ]
            };
        },
        methods: {
            add () {
                this.getCheckData();
                this.addItem('引入器械分类');
            },
            async modalOk () {
                if (this.unSetdData.length < 1) {
                    this.$Message.error('请至少选择一个分类');
                    this.changeLoading();
                    return;
                }
                // let temp = [];
                // this.unSetdData.forEach(item => {
                //     temp.push(item.id);
                // });
                const params = {
                    enterpriseId: this.currentDepartment.id,
                    deviceClassifyIds: this.unSetdData
                };
                const res = await importDevice(params);
                if (res.status === this.code) {
                    this.unSetdData = [];
                    this.todoOver(res.msg);
                }
            },

            // 获取未引入器械分类数据
            async getCheckData () {
                const params = {
                    enterpriseId: this.currentDepartment.id,
                    organizationId: this.currentOrganization.id
                };
                const res = await getUnsedList(params);
                if (res.status === this.code) {
                    this.checkData = res.content;
                }
            },
            // 删除器械分类
            del (e) {
                this.$Modal.confirm({
                    title: '是否确认删除',
                    onOk: async () => {
                        const params = {
                            enterpriseId: this.currentDepartment.id,
                            deviceClassifyIds: [e.row.deviceClassifyId]
                        };
                        const res = await delDevice(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getTableList();
                        }
                    }
                });
            },
            getTableList () {
                // console.log(this.currentOrganization, this.currentDepartment);
                const params = Object.assign(
                    {},
                    this.tableComAttr,
                    this.tableQueryAttr,
                    { enterpriseId: this.currentDepartment.id }
                );
                this.getTableListFn(async call => {
                    const res = await getMachineList(params);
                    call(res);
                });
                this.getTypeList();
            },
            // 获取器械分类下拉框数据
            async getTypeList () {
                const params = {
                    level: 1,
                    levelId: this.currentOrganization.id,
                    fieldCode: 'device_classify_type'
                };
                const res = await getMachineType(params);
                if (res.status === this.code) {
                    this.slectList = res.content;
                }
            }
        }
    };
</script>

<style scoped>
.checkbox-container:not(:last-child) {
    margin-bottom: 8px;
}
</style>
