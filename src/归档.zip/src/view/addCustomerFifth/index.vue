<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-07 11:05:03
 * @LastEditTime: 2019-08-13 15:09:43
 * @LastEditors: Please set LastEditors
 -->
<template>
    <!-- <div>新增客户-质管负责人</div> -->
    <div class="add-commissioner">
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon> 查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="4"  class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.customerName"
                        placeholder="客户名称"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5"  class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.statusArr"
                        multiple
                        @on-change="searchStatus"
                        :max-tag-count="4"
                        placeholder="状态"
                    >
                        <Option
                            v-for="item in typeList"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}</Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card :border="false">
            <p slot="title"><Icon type="md-list"></Icon>客户列表</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="edit" icon="ios-create-outline">查看</Button>
                    <Button
                        v-has="btnRightList.customerFifthSubmit"
                        @click="submit"
                        icon="md-arrow-forward"
                    >下一步</Button>
                    <Button
                        v-has="btnRightList.customerBackUp"
                        @click="backUp(4)"
                        icon="md-arrow-back"
                    >退回</Button>
                    <Button
                        v-has="btnRightList.customerInValid"
                        @click="inValid"
                        icon="ios-trash"
                    >无效</Button>
                </ButtonGroup>
            </div>
            <erp-table
                ref="managerTable"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                @on-current-change="currentChange"
                highlight
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
            ></erp-table>
        </Card>
        <Modal
            @on-ok="modalOk"
            @on-cancel="modalCancel"
            fullscreen
            v-model="modalShowFlag"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            width="960"
            okText="保存"
            full-screen
        >
            <Tabs v-model="tabIndex" type="card" @on-click="tabsBind">
                <TabPane label="基础信息">
                    <BaseInFoForm
                        ref="baseInfoForm"
                        @changeLoading="changeLoading"
                        :oldFormAttr="formAttr"
                        :customerAreaArr="customerAreaArr"
                        :customerTypeArr="customerTypeArr"
                        :customerClassifyArr="customerClassifyArr"
                        :saleMethodArr="saleMethodArr"
                        :saleModeArr="saleModeArr"
                        :saleDepartmentArr="saleDepartmentArr"
                        :customerLevelArr="customerLevelArr"
                        :baseInfoReadOnly="true"
                    ></BaseInFoForm>
                </TabPane>
                <template v-if="currentId">
                    <TabPane label="器械分类">
                        <MachineClass
                            ref="machineClass"
                            @changeLoading="changeLoading"
                            :materialCheckbox="materialList"
                            :machineCheckbox="machineList"
                            :selectData="infoData"
                            :taskInstanceId="currentId"
                            :selectedMachine="selectedMachine"
                            :selectedMaterial="selectedMaterial"
                        ></MachineClass>
                    </TabPane>
                    <TabPane label="上传资料">
                        <UploadData
                            ref="uploadData"
                            @updateTable="updateTable"
                            :radioData="infoData"
                            :taskInstanceId="currentId"
                            :uploadTable="uploadTable"
                            :uploadReadonly="false"
                        ></UploadData>
                    </TabPane>
                    <TabPane label="收货地址">
                        <ReceiveAddress
                            ref="receiveAddress"
                            @addressList="getCustomerAddressList"
                            :customerAddressList="customerAddressList"
                            :taskInstanceId="currentId"
                            :addressReadonly="false"
                        ></ReceiveAddress>
                    </TabPane>
                    <TabPane label="联系人">
                        <Contact
                            ref="contact"
                            @contactList="getCustomerContactList"
                            :customerContactList="customerContactList"
                            :taskInstanceId="currentId"
                            :concatReadonly="false"
                        ></Contact>
                    </TabPane>
                </template>
            </Tabs>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import statusMixin from '@/mixins/statusMixin';

    import {
        BaseInFoForm,
        MachineClass,
        UploadData,
        ReceiveAddress,
        Contact
    } from '_c/customer';

    import { getCustomerManage, submitGroupAudit } from '@/api/masterData/customer';

    import { getDate } from '@/libs/tools';

    export default {
        components: {
            ErpTable,
            BaseInFoForm,
            MachineClass,
            UploadData,
            ReceiveAddress,
            Contact
        },
        mixins: [tableMixin, statusMixin],
        data () {
            return {
                tableQueryAttr: {
                    customerName: '',
                    statusArr: [4],
                    status: '4'
                },
                // 表头
                erpTableTitle: [
                    {
                        title: '公司',
                        align: 'center',
                        minWidth: 140,
                        key: 'enterpriseName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 90,
                        key: 'statusDescription'
                    },
                    {
                        title: '编号',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerCode'
                    },
                    {
                        title: '名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerName'
                    },
                    {
                        title: '区域',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerAreaName'
                    },
                    {
                        title: '分类',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerClassifyName'
                    },
                    {
                        title: '类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerTypeName'
                    },
                    {
                        title: '上级',
                        align: 'center',
                        minWidth: 100,
                        key: 'parentName'
                    },
                    {
                        title: '创建人员',
                        align: 'center',
                        minWidth: 90,
                        key: 'createName'
                    },
                    {
                        title: '创建时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    }
                ]
            };
        },
        methods: {
            edit () {
                let valid = this.validCurrent();
                if (!valid) return false;
                this.getAllSelectData();
                this.editTableData({ row: this.currentRow }, '编辑客户');
                this.$refs.managerTable.clearCurrentTableRow();
            },
            modalOk () {
                this.changeLoading();
            },
            // 下一步
            submit () {
                this.submitFn(async call => {
                    const params = {
                        id: this.currentId
                    };
                    const res = await submitGroupAudit(params);
                    call(res);
                });
            },

            // tab点击
            tabsBind (name) {
                switch (name) {
                    case 0:
                        break;
                    case 1:
                        this.getMachineCheckbox();
                        this.getInfoRadio();
                        this.getSelectedMaterial();
                        this.getSelectedMachine();
                        break;
                    case 2:
                        this.getInfoRadio();
                        this.getUploadTabe();
                        break;
                    case 3:
                        this.getCustomerAddressList();
                        break;
                    case 4:
                        this.getCustomerContactList();
                        break;
                }
            },
            // 更新已上传资料表格数据
            updateTable (e) {
                this.getUploadTabe(e);
            },
            // 获取表格数据
            getTableList () {
                this.getTableListFn(async call => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getCustomerManage(params);
                    call(res);
                });
            }
        }
    };
</script>

<style scoped>
.m8 {
    margin-right: 8px;
}
</style>
