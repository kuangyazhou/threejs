<template>
    <div class="sales-change">
        <!-- <h1>客户变更-质管</h1> -->
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon> 查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.customerName"
                        placeholder="客户名称"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title"><Icon type="md-list"></Icon>变更列表</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="addCustomer" icon="ios-create-outline">新增变更</Button>
                    <Button @click="sendAudit" icon="md-send">发起审批</Button>
                    <Button @click="auditPass">审批通过</Button>
                    <!-- <Button
                        @click="backTo"
                        icon="md-log-in"
                        v-has="btnRightList.qualityChangeBack"
                        >退回</Button
                    >
                    <Button
                        icon="md-send"
                        @click="changePass"
                        v-has="btnRightList.qualityChangePass"
                        >下一步</Button
                    >-->
                    <Button
                        @click="delAudit"
                        icon="md-trash"
                        v-has="btnRightList.qualityChangeDel"
                    >删除</Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                @on-current-change="currentChange"
                highlight
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
                ref="managerTable"
            ></erp-table>
        </Card>
        <!-- 客户选择Modal -->
        <Modal
            v-model="customerModal"
            width="650"
            title="选择客户"
            :loading="customerLoading"
            :mask-closable="false"
            @on-cancel="customerCancel"
            @on-ok="customerOk"
        >
            <Row :gutter="16" class="search-container">
                <Col span="8">
                    <Input v-model="formAttr.customerName" placeholder="客户名称"></Input>
                </Col>
                <Col span="8">
                    <Input v-model="formAttr.uniqueCode" placeholder="唋一识别码"></Input>
                </Col>
                <Col span="8">
                    <Button @click="cusSearch">搜索</Button>
                </Col>
            </Row>
            <div class="clearfix">
                <Table :columns="cusColumns" :data="cusData" border>
                    <template slot-scope="{ row }" slot="operate">
                        <Button
                            @click="edit(row)"
                            type="primary"
                            icon="ios-create-outline"
                            size="small"
                        >修改</Button>
                    </template>
                </Table>
                <div class="wrapper-page">
                    <Page
                        :current="customerPage.pageNo"
                        :total="customerPage.total"
                        show-sizer
                        show-elevator
                        @on-change="cusPageChange"
                        @on-page-size-change="cusSizeChange"
                    ></Page>
                </div>
            </div>
        </Modal>
        <Modal
            @on-cancel="onClose"
            @on-ok="modalOk"
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            fullscreen
        >
            <Tabs v-model="tabIndex" type="card" @on-click="tabsBind">
                <TabPane label="基础信息">
                    <BaseInFoForm
                        ref="baseInfoForm"
                        @changeLoading="changeLoading"
                        @isSave="setSave"
                        @changeCurrentId="changeCurrentId"
                        :oldFormAttr="formAttr"
                        :customerAreaArr="customerAreaArr"
                        :customerTypeArr="customerTypeArr"
                        :customerClassifyArr="customerClassifyArr"
                        :saleMethodArr="saleMethodArr"
                        :saleModeArr="saleModeArr"
                        :saleDepartmentArr="saleDepartmentArr"
                        :customerLevelArr="customerLevelArr"
                        :isChange="true"
                        :changeQuality="false"
                        :oldBaseInfo="oldBaseInfo"
                    ></BaseInFoForm>
                </TabPane>
                <template v-if="hasSaved">
                    <TabPane label="器械分类">
                        <MachineClass
                            ref="machineClass"
                            @changeLoading="changeLoading"
                            :materialCheckbox="materialList"
                            :machineCheckbox="machineList"
                            :selectData="infoData"
                            :taskInstanceId="currentId"
                            :selectedMachine="selectedMachine"
                            :selectedMaterial="selectedMaterial"
                            :oldMaterial="oldMaterialArr"
                            :oldMachine="oldMachineArr"
                            :machineReadonly="true"
                            :isChange="true"
                        ></MachineClass>
                    </TabPane>
                    <TabPane label="上传资料">
                        <UploadData
                            ref="uploadData"
                            @updateTable="updateTable"
                            :radioData="infoData"
                            :taskInstanceId="currentId"
                            :uploadTable="uploadTable"
                            :oldLicense="oldLicenseArr"
                            :uploadReadonly="!firstImport && !firstSub"
                            :isChange="true"
                        ></UploadData>
                    </TabPane>
                    <TabPane label="收货地址">
                        <ReceiveAddress
                            ref="receiveAddress"
                            @addressList="getCustomerAddressList"
                            :customerAddressList="customerAddressList"
                            :taskInstanceId="currentId"
                            :oldAdress="oldAddressArr"
                            :addressReadonly="true"
                        ></ReceiveAddress>
                    </TabPane>
                    <TabPane label="联系人">
                        <Contact
                            ref="contact"
                            @contactList="getCustomerContactList"
                            :customerContactList="customerContactList"
                            :taskInstanceId="currentId"
                            :oldContact="oldContactArr"
                            :concatReadonly="true"
                        ></Contact>
                    </TabPane>
                </template>
            </Tabs>
            <div slot="footer">
                <Button @click="onClose">取消</Button>
                <Button @click="modalOk">保存</Button>
                <Button @click="changePass" type="primary">生成变更单</Button>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import statusMixin from '@/mixins/statusMixin';

    import { getDate } from '@/libs/tools';
    import {
        salesChangeList,
        customerList,
        changeBackUp,
        oldBaseInfo,
        oldLicense,
        oldAddress,
        oldContact,
        oldMaterial,
        oldMachineclass
    } from '@/api/masterData/userchange';

    import {
        BaseInFoForm,
        MachineClass,
        UploadData,
        ReceiveAddress,
        Contact
    } from '_c/customer';

    export default {
        mixins: [tableMixin, statusMixin],
        components: {
            ErpTable,
            BaseInFoForm,
            MachineClass,
            UploadData,
            ReceiveAddress,
            Contact
        },
        data () {
            return {
                oldBaseInfo: {},
                oldLicenseArr: [],
                oldAddressArr: [],
                oldContactArr: [],
                oldMaterialArr: [],
                oldMachineArr: [],
                tableQueryAttr: {
                    customerName: '',
                    status: 1
                },
                formAttr: {
                    customerName: '',
                    customerCode: '',
                    customerArea: '',
                    customerType: '',
                    customerClassify: '',
                    contractPaymentMonth: '',
                    saleMethod: '',
                    saleMode: '',
                    parentId: '',
                    saleDepartment: '',
                    customerLevel: '',
                    licenseRegistrationCode: '',
                    customerAddress: '',
                    unifiedSocialCreditCode: '',
                    dutyParagraph: '',
                    bankName: '',
                    bankCode: '',
                    bankAccount: '',
                    bankType: '',
                    invoiceDescription: '',
                    invoiceAddress: '',
                    customerDescription: '',
                    warehouseAddress: '',
                    id: '',
                    uniqueCode: '',
                    customerId: ''
                },
                customerPage: {
                    pageNo: 1,
                    pageSize: 10,
                    total: 0
                },
                hasSaved: false, // 基础信息是否保存
                tabIndex: 0,
                customerModal: false, // 客户选择弹框
                customerLoading: false, // 客户选择loading
                cusData: [], // 可选择客户列表
                erpTableTitle: [
                    {
                        title: '公司',
                        align: 'center',
                        minWidth: 100,
                        key: 'enterpriseName'
                    },
                    {
                        title: '编号',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerCode'
                    },
                    {
                        title: '名称',
                        align: 'center',
                        minWidth: 140,
                        key: 'customerName'
                    },
                    {
                        title: '区域',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerAreaName'
                    },
                    {
                        title: '分类',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerClassifyName'
                    },
                    {
                        title: '类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerTypeName'
                    },
                    {
                        title: '上级',
                        align: 'center',
                        minWidth: 100,
                        key: 'parentName'
                    },
                    {
                        title: '创建人',
                        align: 'center',
                        minWidth: 100,
                        key: 'createName'
                    },
                    {
                        title: '创建时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '审批状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'status',
                        render: (h, params) => {
                            const map = {
                                0: '待发起',
                                1: '审批中',
                                2: '审核通过',
                                3: '打回'
                            };
                            return h('span', {}, map[params.row.status]);
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        fixed: 'right',
                        minWidth: 100,
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        attrs: {
                                            style: 'margin-right:12px'
                                        },
                                        on: {
                                            click: e => {
                                                if (e && e.stopPropagation) {
                                                    // 非IE
                                                    e.stopPropagation();
                                                } else {
                                                    // IE
                                                    window.event.cancelBubble = true;
                                                }
                                                this.editTableData(
                                                    params,
                                                    '修改客户'
                                                );
                                                this.getOldBaseInfo();
                                                this.getAllSelectData();
                                                this.customerModal = false;
                                                this.hasSaved = true; // 显示其他资料
                                                if (params.row.parentId) {
                                                    this.firstSub = true;
                                                } else {
                                                    this.firstSub = false;
                                                }
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList
                                                    .qualityChangeUpdate
                                            }
                                        ]
                                    },
                                    '编辑'
                                )
                            // 暂时没做钉钉审批流程
                            // h(
                            //     'Button',
                            //     {
                            //         props: {
                            //             type: 'success',
                            //             size: 'small',
                            //             icon: 'ios-create-outline'
                            //         }
                            //     },
                            //     '查看'
                            // )
                            ]);
                        }
                    }
                ],
                cusColumns: [
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'customerName'
                    },
                    {
                        title: '区域',
                        align: 'center',
                        minWidth: 80,
                        key: 'customerAreaName'
                    },
                    {
                        title: '执业许可登记号',
                        align: 'center',
                        minWidth: 120,
                        key: 'licenseRegistrationCode'
                    },
                    {
                        title: '统一社会信用码',
                        align: 'center',
                        minWidth: 120,
                        key: 'unifiedSocialCreditCode'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        slot: 'operate'
                    }
                ]
            };
        },
        methods: {
            add () {
                this.addItem('客户选择');
            },
            // 修改客户信息
            edit (row) {
                // this.taskInstanceId = row.taskInstanceId;
                row.customerId = row.id;
                this.editTableData({ row }, '修改客户');
                this.formAttr.id = null; // 新增时不带id，修改时带id
                this.getAllSelectData();
                this.customerModal = false;
            },
            onClose () {
                this.oldBaseInfo = {};
                this.hasSaved = false;
                this.modalShowFlag = false;
                this.tabIndex = 0;
                this.getTableList();
                this.modalCancel();
            },
            // 保存按钮
            async modalOk () {
                switch (this.tabIndex) {
                    case 0:
                        this.$refs['baseInfoForm'].changeSave();
                        break;
                }
            },
            getTableList () {
                this.getTableListFn(async call => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr,
                        {
                            status: 1
                        }
                    );
                    const res = await customerList(params);
                    call(res);
                });
            },
            // 客户选择
            addCustomer () {
                this.customerModal = true;
                this.isPass = false;
                this.$refs.managerTable.clearCurrentTableRow();
                this.currentId = null;
                this.getCustomer();
            },

            customerCancel () {
                this.customerPage.pageNo = 1;
                Object.keys(this.formAttr).forEach(item => {
                    this.formAttr[item] = '';
                });
            },
            customerOk () {},
            // tab点击
            tabsBind (name) {
                switch (name) {
                    case 0:
                        // this.getOldBaseInfo();
                        break;
                    case 1:
                        this.getMachineCheckbox();
                        this.getInfoRadio();
                        this.getSelectedMaterial();
                        this.getSelectedMachine();
                        this.getOldMaterial();
                        this.getOldMachine();
                        break;
                    case 2:
                        this.getInfoRadio();
                        this.getUploadTabe();
                        this.getOldLicense();
                        break;
                    case 3:
                        this.getCustomerAddressList();
                        this.getOldAdress();
                        break;
                    case 4:
                        this.getCustomerContactList();
                        this.getOldContact();
                        break;
                }
            },

            // 判断基础信息是否保存
            setSave (e) {
                this.hasSaved = e;
                this.getOldBaseInfo(); // 变更后获取基础信息
            },
            // 更新表格数据
            updateTable (e) {
                this.getUploadTabe(e);
            },

            // 获取子组件传来的id
            changeCurrentId (id) {
                this.currentId = id;
            },

            // 打回
            async backTo () {
                let valid = this.validCurrent();
                if (!valid) return false;
                const params = {
                    id: this.currentId
                };
                const res = await changeBackUp(params);
                if (res.status === this.code) {
                    this.$Message.success('退回成功');
                }
            },

            async getOldBaseInfo () {
                const params = { id: this.currentId };
                const res = await oldBaseInfo(params);
                if (res.status === this.code) {
                    this.oldBaseInfo = res.content;
                }
            },
            // 获取历史证照
            async getOldLicense () {
                const params = { taskInstanceId: this.currentId };
                const res = await oldLicense(params);
                if (res.status === this.code) {
                    this.oldLicenseArr = res.content;
                }
            },
            // 获取历史地址
            async getOldAdress () {
                const params = { taskInstanceId: this.currentId };
                const res = await oldAddress(params);
                if (res.status === this.code) {
                    this.oldAddressArr = res.content;
                }
            },
            // 获取历史联系人
            async getOldContact () {
                const params = { taskInstanceId: this.currentId };
                const res = await oldContact(params);
                if (res.status === this.code) {
                    this.oldContactArr = res.content;
                }
            },
            //
            cusPageChange (e) {
                this.customerPage.pageNo = e;
                this.getCustomer();
            },

            cusSizeChange (e) {
                this.customerPage.pageSize = e;
                this.getCustomer();
            },

            cusSearch () {
                this.customerPage.pageNo = 1;
                this.getCustomer();
            },

            // 获取可选择客户list
            async getCustomer () {
                this.customerLoading = true;
                const params = Object.assign({}, this.formAttr, this.customerPage);
                const res = await salesChangeList(params);
                if (res.status === this.code) {
                    this.customerLoading = false;
                    this.cusData = res.content.list;
                    this.customerPage.total = res.content.total;
                }
            },

            // 获取变更前物料类型
            async getOldMaterial () {
                const params = { taskInstanceId: this.currentId };
                const res = await oldMaterial(params);
                if (res.status === this.code) {
                    this.oldMaterialArr = res.content;
                }
            },
            // 获取变更前器械分类
            async getOldMachine () {
                const params = { taskInstanceId: this.currentId };
                const res = await oldMachineclass(params);
                if (res.status === this.code) {
                    this.oldMachineArr = res.content;
                }
            }
        }
    };
</script>

<style scoped>
.search-container {
    margin-bottom: 16px;
}
</style>
