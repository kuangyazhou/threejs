<template>
    <div class="add-commissioner">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title"><Icon type="ios-search"></Icon> 查询条件</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.customerName"
                        @on-search="search"
                        search
                        placeholder="客户名称"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="6">
                    <Select
                        v-model="tableQueryAttr.statusArr"
                        multiple
                        @on-change="searchStatus"
                        :max-tag-count="4"
                        placeholder="状态"
                    >
                        <Option
                            v-for="item in typeList"
                            :value="item.value"
                            :key="item.value"
                            >{{ item.label }}</Option
                        >
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">客户列表</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button
                        v-has="btnRightList.customerInfoSave"
                        icon="md-log-in"
                        @click="importCustomer"
                        >引入</Button
                    >
                    <Dropdown
                        class="dropdown-add"
                        v-has="btnRightList.customerInfoSave"
                        @on-click="addCustomer"
                    >
                        <Button> <Icon type="md-add"></Icon>新增 </Button>
                        <DropdownMenu slot="list">
                            <DropdownItem
                                v-for="item in customerAddList"
                                :key="item.id"
                                :name="item.id"
                                >{{ item.label }}</DropdownItem
                            >
                        </DropdownMenu>
                    </Dropdown>
                    <Button
                        v-has="btnRightList.customerInValid"
                        icon="md-thumbs-down"
                        @click="inValid"
                        >无效</Button
                    >
                    <Button
                        v-has="btnRightList.customerFirstSubmit"
                        icon="md-send"
                        @click="submit"
                        >提交</Button
                    >
                    <Button
                        v-has="btnRightList.customerFirstRestart"
                        icon="md-undo"
                        @click="reStart"
                        >重新启用</Button
                    >
                </ButtonGroup>
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                @on-current-change="currentChange"
                highlight
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
                ref="managerTable"
            ></erp-table>
        </Card>
        <!--新增客户弹窗-->
        <Modal
            @on-ok="modalOk"
            @on-cancel="customerModalCancel"
            fullscreen
            v-model="modalShowFlag"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
        >
            <Tabs v-model="tabIndex" type="card" @on-click="tabsBind">
                <TabPane label="基础信息">
                    <BaseInFoForm
                        ref="baseInfoForm"
                        @changeLoading="changeLoading"
                        @changeCurrentId="changeCurrentId"
                        @getTableList="getTableList"
                        :oldFormAttr="formAttr"
                        :customerAreaArr="customerAreaArr"
                        :customerTypeArr="customerTypeArr"
                        :customerClassifyArr="customerClassifyArr"
                        :saleMethodArr="saleMethodArr"
                        :saleModeArr="saleModeArr"
                        :saleDepartmentArr="saleDepartmentArr"
                        :customerLevelArr="customerLevelArr"
                        :firstImport="firstImport"
                        :firstSub="firstSub"
                        :baseInfoReadOnly="isPass"
                    ></BaseInFoForm>
                </TabPane>
                <template v-if="currentId">
                    <TabPane label="器械分类">
                        <MachineClass
                            ref="machineClass"
                            @changeLoading="changeLoading"
                            :materialCheckbox="materialList"
                            :machineCheckbox="machineList"
                            :selectData="infoData"
                            :taskInstanceId="currentId"
                            :selectedMachine="selectedMachine"
                            :selectedMaterial="selectedMaterial"
                            :machineReadonly="isPass"
                        ></MachineClass>
                    </TabPane>
                    <TabPane label="上传资料">
                        <UploadData
                            ref="uploadData"
                            @updateTable="updateTable"
                            :radioData="infoData"
                            :taskInstanceId="currentId"
                            :uploadTable="uploadTable"
                            :firstFile="firstFile"
                            :uploadReadonly="!isPass"
                        ></UploadData>
                    </TabPane>
                    <TabPane label="收货地址">
                        <ReceiveAddress
                            ref="receiveAddress"
                            @addressList="getCustomerAddressList"
                            :customerAddressList="customerAddressList"
                            :taskInstanceId="currentId"
                            :addressReadonly="!isPass"
                        ></ReceiveAddress>
                    </TabPane>
                    <TabPane label="联系人">
                        <Contact
                            ref="contact"
                            @contactList="getCustomerContactList"
                            :customerContactList="customerContactList"
                            :taskInstanceId="currentId"
                            :concatReadonly="!isPass"
                        ></Contact>
                    </TabPane>
                </template>
            </Tabs>
        </Modal>
        <!--新增临时客户弹窗-->
        <Modal
            v-model="temporaryShowFlag"
            width="650"
            title="新增临时客户"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="temporaryCustomerOk"
            @on-cancel="temporaryCustomerCancel"
        >
            <div class="erp-modal-content">
                <Form
                    :model="temporaryForm"
                    :rules="temporaryRuleValidate"
                    ref="temporaryFormValidate"
                    :label-width="120"
                >
                    <FormItem label="客户名称" prop="customerName">
                        <Input
                            v-model="temporaryForm.customerName"
                            placeholder="请输入客户名称"
                        ></Input>
                    </FormItem>
                    <FormItem label="上级客户">
                        <Button
                            class="button-department"
                            @click="handleTemporaryParentCustomer"
                            icon="ios-arrow-down"
                        >
                            {{
                                temporaryForm.parentName
                                    ? temporaryForm.parentName
                                    : '请选择上级客户'
                            }}
                        </Button>
                    </FormItem>
                </Form>
            </div>
        </Modal>
        <!--客户列表弹窗-->
        <Modal
            v-model="customerShowFlag"
            width="850"
            height="400"
            title="客户列表"
            :mask-closable="maskClosable"
            footer-hide
        >
            <div>
                <Card dis-hover :bordered="false">
                    <p slot="title"><Icon type="ios-search"></Icon> 查询条件</p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button @click="customerSearch" icon="md-search"
                                >搜索</Button
                            >
                            <Button @click="customerReset" icon="md-refresh"
                                >重置</Button
                            >
                        </ButtonGroup>
                    </div>
                    <Row :gutter="16">
                        <Col span="12" class="maxWidth">
                            <Input
                                v-model="customerTableQuery.customerName"
                                @on-search="customerSearch"
                                search
                                placeholder="客户名称"
                            >
                                <Button
                                    @click="customerSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                        <Col span="12">
                            <Input
                                v-model="customerTableQuery.uniqueCode"
                                @on-search="customerSearch"
                                search
                                placeholder="唯一识别码"
                            >
                                <Button
                                    @click="customerSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                    </Row>
                </Card>
                <div class="clearfix">
                    <Table
                        border
                        :columns="customerTableTitle"
                        :data="customerTableData"
                        :tableLoading="customerTableLoading"
                    ></Table>
                    <div class="wrapper-page">
                        <Page
                            :current="customerPage.pageNo"
                            @on-change="customerChangePage"
                            @on-page-size-change="customerChangePageSize"
                            show-sizer
                            :total="customerTotal"
                            show-elevator
                        />
                    </div>
                </div>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import statusMixin from '@/mixins/statusMixin';
    import {
        BaseInFoForm,
        MachineClass,
        UploadData,
        ReceiveAddress,
        Contact
    } from '_c/customer';
    import {
        getCustomerCreateList,
        saveCustomerInfo,
        getCustomerSelect,
        submitCustomerManage
    } from '@/api/masterData/customer';
    import { resetObj, getDate } from '@/libs/tools';

    export default {
        name: 'addCustomerFirst',
        components: {
            ErpTable,
            BaseInFoForm,
            MachineClass,
            UploadData,
            ReceiveAddress,
            Contact
        },
        mixins: [tableMixin, statusMixin],
        data () {
            return {
                tableQueryAttr: {
                    customerName: '',
                    status: '0',
                    statusArr: [0]
                },
                erpTableTitle: [
                    {
                        title: '公司',
                        align: 'center',
                        minWidth: 140,
                        key: 'enterpriseName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 90,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.typeList[params.row.status].label
                            );
                        }
                    },
                    {
                        title: '编号',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerCode'
                    },
                    {
                        title: '名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerName'
                    },
                    {
                        title: '区域',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerAreaName'
                    },
                    {
                        title: '分类',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerClassifyName'
                    },
                    {
                        title: '类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerTypeName'
                    },
                    {
                        title: '上级',
                        align: 'center',
                        minWidth: 100,
                        key: 'parentName'
                    },
                    {
                        title: '创建人员',
                        align: 'center',
                        minWidth: 90,
                        key: 'createName'
                    },
                    {
                        title: '创建时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '操作',
                        minWidth: 120,
                        align: 'center',
                        fixed: 'right',
                        render: (h, params) => {
                            if (params.row.status === 6) {
                                return h(
                                    'Button',
                                    {
                                        props: {
                                            size: 'small',
                                            type: 'success'
                                        },
                                        on: {
                                            click: e => {
                                                this.isPass = true;
                                                if (e && e.stopPropagation) {
                                                    // 非IE
                                                    e.stopPropagation();
                                                } else {
                                                    // IE
                                                    window.event.cancelBubble = true;
                                                }
                                                this.getAllSelectData();
                                                this.editTableData(
                                                    params,
                                                    '查看客户'
                                                );
                                                this.$refs.managerTable.clearCurrentTableRow();
                                            }
                                        }
                                    },
                                    '查看'
                                );
                            } else {
                                return h('div', [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'primary',
                                                size: 'small'
                                            },
                                            on: {
                                                click: e => {
                                                    if (e && e.stopPropagation) {
                                                        // 非IE
                                                        e.stopPropagation();
                                                    } else {
                                                        // IE
                                                        window.event.cancelBubble = true;
                                                    }

                                                    // 判断是否引入客户
                                                    this.firstImport = !!params.row.isImport;
                                                    // 判断是否子客户
                                                    this.firstSub = !!params.row.parentId;
                                                    this.firstFile = !!params.row
                                                        .parentId;
                                                    this.getAllSelectData();
                                                    this.editTableData(
                                                        params,
                                                        '编辑客户'
                                                    );
                                                    this.$refs.managerTable.clearCurrentTableRow();
                                                }
                                            }
                                        },
                                        '编辑'
                                    )
                                ]);
                            }
                        }
                    }
                ],
                customerAddList: [
                    {
                        id: 1,
                        label: '临时客户'
                    },
                    {
                        id: 2,
                        label: '一级客户'
                    },
                    {
                        id: 3,
                        label: '子客户'
                    }
                ], // 新增客户类型
                temporaryShowFlag: false, // 新增临时客户弹窗开关
                temporaryForm: {
                    customerName: '',
                    parentId: '',
                    parentName: ''
                }, // 临时客户表单
                temporaryRuleValidate: {
                    customerName: [
                        {
                            required: true,
                            message: '客户名称不能为空',
                            trigger: 'blur'
                        }
                    ]
                }, // 临时客户校验规则
                customerShowFlag: false, // 客户列表弹窗开关
                customerTableQuery: {
                    customerName: '',
                    uniqueCode: ''
                }, // 客户列表查询条件
                customerTableTitle: [
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 140,
                        key: 'customerName'
                    },
                    {
                        title: '区域',
                        align: 'center',
                        minWidth: 80,
                        key: 'customerAreaName'
                    },
                    {
                        title: '执业许可登记号',
                        align: 'center',
                        minWidth: 130,
                        key: 'licenseRegistrationCode'
                    },
                    {
                        title: '统一社会信用码',
                        align: 'center',
                        minWidth: 130,
                        key: 'unifiedSocialCreditCode'
                    },
                    {
                        title: '操作',
                        minWidth: 100,
                        align: 'center',
                        fixed: 'right',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'success',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.selectionCustomer(params.row);
                                            }
                                        }
                                    },
                                    '选择'
                                )
                            ]);
                        }
                    }
                ], // 客户列表栏目
                customerTableData: [], // 客户列表数据
                customerTableLoading: false, // 客户列表加载ing开关
                customerPage: {
                    pageNo: 1,
                    pageSize: 10
                },
                customerTotal: 0, // 客户列表总数
                customerModalType: 0, // 0引入客户弹窗，1子客户弹窗,2临时客户
                firstFile: false // 新增子客户时传true文件不能上传
            };
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getCustomerCreateList(params);
                    getListMixin(res);
                });
            },
            // 新增客户
            addCustomer (index) {
                this.currentId = null;
                this.firstImport = false;
                this.firstSub = false;
                this.firstFile = false;
                this.$refs.managerTable.clearCurrentTableRow();
                this.isPass = false;
                switch (index) {
                    case 1:
                        this.temporaryShowFlag = true;
                        break;
                    case 2:
                        this.getAllSelectData();
                        this.addItem('新增客户');
                        break;
                    case 3:
                        this.getAllSelectData();
                        this.customerModalType = 1;
                        this.customerShowFlag = true;
                        this.customerReset();
                        break;
                }
            },
            // 引入客户
            importCustomer () {
                this.isPass = false;
                this.$refs.managerTable.clearCurrentTableRow();
                this.currentId = null;
                this.customerModalType = 0;
                this.customerShowFlag = true;
                this.customerReset();
            },
            modalOk () {
                switch (this.tabIndex) {
                    case 0:
                        if (this.judgeBtnRight('customerInfoSave')) {
                            this.$refs.baseInfoForm.saveInfo();
                        } else {
                            this.changeLoading();
                        }
                        break;
                    case 1:
                        if (
                            this.judgeBtnRight('customerGoodsTypeSave') &&
                            this.judgeBtnRight('customerClassifySave')
                        ) {
                            this.$refs.machineClass.saveData();
                        } else {
                            this.changeLoading();
                        }
                        break;
                    case 2:
                        this.changeLoading();
                        break;
                    case 3:
                        this.changeLoading();
                        break;
                    case 4:
                        this.changeLoading();
                        break;
                }
            },
            // 确认新增临时客户
            temporaryCustomerOk () {
                this.$refs['temporaryFormValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeTemporaryLoading();
                    }
                    const params = Object.assign({}, this.temporaryForm, {
                        isImport: 0
                    });
                    const res = await saveCustomerInfo(params);
                    if (res.status === this.code) {
                        this.temporaryCustomerCancel();
                        this.$Message.success(res.msg);
                        this.tableComAttr.pageNo = 1;
                        this.getTableList();
                    } else {
                        this.changeTemporaryLoading();
                    }
                });
            },
            // 临时客户弹窗关闭
            temporaryCustomerCancel () {
                this.$refs['temporaryFormValidate'].resetFields();
                this.temporaryShowFlag = false;
                resetObj(this.temporaryForm);
            },
            // 处理临时客户modal确认异步
            changeTemporaryLoading () {
                this.modelLoading = false;
                this.$nextTick(() => {
                    this.modelLoading = true;
                });
            },
            // tab点击
            tabsBind (name) {
                switch (name) {
                    case 0:
                        break;
                    case 1:
                        this.getMachineCheckbox();
                        this.getInfoRadio();
                        this.getSelectedMaterial();
                        this.getSelectedMachine();
                        break;
                    case 2:
                        this.getInfoRadio();
                        this.getUploadTabe();
                        break;
                    case 3:
                        this.getCustomerAddressList();
                        break;
                    case 4:
                        this.getCustomerContactList();
                        break;
                }
            },
            // 获取该页面所有下拉框数据
            getAllSelectData () {
                this.getFieldValuesData('customer_area', 'customerAreaArr');
                this.getFieldValuesData('customer_type', 'customerTypeArr');
                this.getFieldValuesData('customer_classify', 'customerClassifyArr');
                this.getFieldValuesData('sale_method', 'saleMethodArr');
                this.getFieldValuesData('sale_mode', 'saleModeArr');
                this.getFieldValuesData('sale_department', 'saleDepartmentArr');
                this.getFieldValuesData('customer_level', 'customerLevelArr');
            },
            // 获取子组件传来的id
            changeCurrentId (id) {
                this.currentId = id;
                this.modelLoading = false;
                // 获取器械分类数据
                this.$nextTick(() => {
                    this.modelLoading = true;
                    this.getMachineCheckbox();
                });
            },
            // 获取弹窗中客户列表
            async getModalCustomerList () {
                this.customerTableLoading = true;
                const params = Object.assign(
                    {},
                    this.customerPage,
                    this.customerTableQuery
                );
                const res = await getCustomerSelect(params, this.customerModalType);
                if (res.status === this.code) {
                    this.customerTableData = res.content.list;
                    this.customerTableLoading = false;
                    this.customerTotal = res.content.total;
                }
            },
            // 更新表格数据
            updateTable (e) {
                this.getUploadTabe(e);
            },
            // 搜索客户列表
            customerSearch () {
                this.getModalCustomerList();
            },
            // 客户列表搜索重置
            customerReset () {
                this.customerPage.pageNo = 1;
                resetObj(this.customerTableQuery);
                this.getModalCustomerList();
            },
            // 改变客户列表页码
            customerChangePage (value) {
                this.customerPage.pageNo = value;
                this.getModalCustomerList();
            },
            // 改变客户列表每页条数
            customerChangePageSize (value) {
                this.customerPage.pageNo = 1;
                this.customerPage.pageSize = value;
                this.getModalCustomerList();
            },
            // 选中客户
            selectionCustomer (row) {
                this.getAllSelectData();
                this.customerShowFlag = false;
                if (this.customerModalType === 0) {
                    this.firstImport = true;
                    this.modalTitle = '新增引入客户';
                    this.currentId = null;
                    this.formAttr = Object.assign({}, this.formAttr, {
                        customerName: row.customerName,
                        customerCode: row.customerCode,
                        customerArea: row.customerArea,
                        customerLevel: row.customerLevel,
                        licenseRegistrationCode: row.licenseRegistrationCode,
                        unifiedSocialCreditCode: row.unifiedSocialCreditCode,
                        customerId: row.id,
                        id: ''
                    });
                    this.modalShowFlag = true;
                } else if (this.customerModalType === 1) {
                    this.firstSub = true;
                    this.firstFile = true;
                    this.modalTitle = '新增子客户';
                    this.currentId = null;
                    for (let key in row) {
                        this.formAttr[key] = row[key];
                    }
                    this.formAttr = Object.assign({}, this.formAttr, {
                        parentId: row.id,
                        parentName: row.customerName,
                        id: ''
                    });
                    this.modalShowFlag = true;
                } else if (this.customerModalType === 2) {
                    this.temporaryForm = Object.assign({}, this.temporaryForm, {
                        parentId: row.id,
                        parentName: row.customerName
                    });
                }
            },
            // 临时客户点击打开上级客户弹窗
            handleTemporaryParentCustomer () {
                this.customerModalType = 2;
                this.customerShowFlag = true;
                this.customerReset();
            },
            // 提交客管审核
            async submit () {
                this.submitFn(async call => {
                    const params = {
                        id: this.currentId
                    };
                    const res = await submitCustomerManage(params);
                    call(res);
                });
            }
        }
    };
</script>

<style scoped lang="less">
.dropdown-add {
    float: left;
    position: relative;
    margin-left: -1px;

    .ivu-btn-default {
        border-radius: 0;
    }

    &:hover {
        z-index: 2;
    }

    & + .ivu-btn {
        margin-left: -0.5px;
    }
}

.button-department {
    width: 100%;
    text-align: left;
    padding-left: 7px;
    padding-right: 24px;
    position: relative;

    /deep/ .ivu-icon-ios-arrow-down {
        position: absolute;
        top: 50%;
        right: 8px;
        margin-top: -7px;
    }

    /deep/ span {
        margin-left: 0;
    }
}
.erp-modal-content {
    padding-top: 0;
}
</style>
