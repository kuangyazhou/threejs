<template>
    <div class="add-commissioner">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title"><Icon type="ios-search"></Icon> 查询条件</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.supplierName"
                        @on-search="search"
                        search
                        placeholder="供应商名称"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <!--                <Col span="5">-->
                <!--                    <Select-->
                <!--                        v-model="tableQueryAttr.taskStatus"-->
                <!--                        @on-change="selectSearch"-->
                <!--                        placeholder="状态"-->
                <!--                    >-->
                <!--                        <Option-->
                <!--                            v-for="item in typeList"-->
                <!--                            :value="item.value"-->
                <!--                            :key="item.value"-->
                <!--                            >{{ item.label }}</Option-->
                <!--                        >-->
                <!--                    </Select>-->
                <!--                </Col>-->
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">供应商变更申请列表</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button
                        v-has="btnRightList.supplierPurChangeAdd"
                        icon="md-log-in"
                        @click="addChange"
                        >新增变更</Button
                    >
                    <Button icon="md-log-in" @click="edit">编辑</Button>
                    <Button
                        v-has="btnRightList.supplierPurChangeSubmit"
                        icon="md-send"
                        @click="submit"
                        >发起审批</Button
                    >
                    <Button
                        icon="md-send"
                        @click="approve"
                    >审批</Button>
                    <Button
                        v-has="btnRightList.supplierPurChangeDel"
                        icon="md-delete"
                        @click="delSuppliersApply"
                        >删除</Button
                    >
                </ButtonGroup>
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                @on-current-change="currentChange"
                highlight
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
                ref="managerTable"
            ></erp-table>
        </Card>
        <!--新增供应商弹窗-->
        <Modal
            @on-cancel="supplierModalCancel"
            fullscreen
            v-model="modalShowFlag"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
        >
            <Tabs v-model="tabIndex" type="card" @on-click="tabsBind">
                <TabPane label="基础信息">
                    <BaseInFoForm
                        ref="baseInfoForm"
                        @changeLoading="changeLoading"
                        @changeCurrentId="changeCurrentId"
                        @getTableList="getTableList"
                        :oldFormAttr="oldFormAttr"
                        :newFormAttr="formAttr"
                        :firstChange="firstChange"
                        :supplierLevelArr="supplierLevelArr"
                        :supplierNatureArr="supplierNatureArr"
                        :supplierClassifyArr="supplierClassifyArr"
                        :supplierCategoryArr="supplierCategoryArr"
                        :specialtyGroupArr="specialtyGroupAllArr"
                        :supplierTypeArr="supplierTypeArr"
                        :supplierStatusArr="supplierStatusArr"
                        :formDisabled="formDisabled"
                    ></BaseInFoForm>
                </TabPane>
                <template v-if="currentId">
                    <TabPane label="上传资料">
                        <UploadData
                            ref="uploadData"
                            @updateTable="updateTable"
                            :firstChange="firstChange"
                            :radioData="infoData"
                            :taskInstanceId="currentId"
                            :uploadTable="uploadTable"
                            :oldUploadTable="oldUploadTable"
                            :formDisabled="formDisabled"
                        ></UploadData>
                    </TabPane>
                    <TabPane label="器械生产信息">
                        <MachineProduction
                            ref="machineProduction"
                            @changeLoading="changeLoading"
                            :machineCheckbox="machineList"
                            :selectData="infoData"
                            :taskInstanceId="currentId"
                            :mainBrand="currentRow.mainBrand"
                            :selectedMachine="selectedMachineProduction"
                            :oldSelectedMachine="oldSelectedMachineProduction"
                            :firstChange="firstChange"
                            :formDisabled="formDisabled"
                        ></MachineProduction>
                    </TabPane>
                    <TabPane label="器械经营信息">
                        <MachineManagement
                            ref="machineManagement"
                            @changeLoading="changeLoading"
                            :machineCheckbox="machineList"
                            :selectData="infoData"
                            :taskInstanceId="currentId"
                            :selectedMachine="selectedMachineManagement"
                            :oldSelectedMachine="oldSelectedMachineManagement"
                            :firstChange="firstChange"
                            :formDisabled="formDisabled"
                        ></MachineManagement>
                    </TabPane>
                    <TabPane label="联系人">
                        <Contact
                            ref="contact"
                            @contactList="getSupplierContactList"
                            :supplierContactList="supplierContactList"
                            :oldContactList="oldSupplierContactList"
                            :taskInstanceId="currentId"
                            :firstChange="firstChange"
                            :formDisabled="formDisabled"
                        ></Contact>
                    </TabPane>
                </template>
            </Tabs>
            <div slot="footer">
                <Button @click="supplierModalCancel">取消</Button>
                <Button type="primary" size="large" @click="modalOk"
                    >确认</Button
                >
                <Button
                    v-if="currentId"
                    type="info"
                    size="large"
                    @click="submit"
                    >发起审核</Button
                >
            </div>
        </Modal>
        <!--供应商列表弹窗-->
        <Modal
            v-model="supplierShowFlag"
            width="850"
            height="400"
            title="供应商列表"
            :mask-closable="maskClosable"
            footer-hide
        >
            <div>
                <Card dis-hover :bordered="false">
                    <p slot="title"><Icon type="ios-search"></Icon> 查询条件</p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button @click="supplierSearch" icon="md-search"
                                >搜索</Button
                            >
                            <Button @click="supplierReset" icon="md-refresh"
                                >重置</Button
                            >
                        </ButtonGroup>
                    </div>
                    <Row :gutter="16">
                        <Col span="12" class="maxWidth">
                            <Input
                                v-model="supplierTableQuery.supplierName"
                                @on-search="supplierSearch"
                                search
                                placeholder="供应商名称"
                            >
                                <Button
                                    @click="supplierSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                        <Col span="12">
                            <Input
                                v-model="
                                    supplierTableQuery.unifiedSocialCreditCode
                                "
                                @on-search="supplierSearch"
                                search
                                placeholder="统一社会信用码"
                            >
                                <Button
                                    @click="supplierSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                    </Row>
                </Card>
                <div class="clearfix">
                    <Table
                        border
                        :columns="supplierTableTitle"
                        :data="supplierTableData"
                        :tableLoading="supplierTableLoading"
                    ></Table>
                    <div class="wrapper-page">
                        <Page
                            :current="supplierPage.pageNo"
                            @on-change="supplierChangePage"
                            @on-page-size-change="supplierChangePageSize"
                            show-sizer
                            :total="supplierTotal"
                            show-elevator
                        />
                    </div>
                </div>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import supplierMixin from '@/mixins/supplierMixin';
    import {
        BaseInFoForm,
        MachineManagement,
        UploadData,
        Contact,
        MachineProduction
    } from '_c/supplier';
    import {
        getSupplierChangeList,
        getSpecialtyGroupList,
        getCanChangeSupplierList,
        editSuppliersApply,
        delSuppliersChangeApply,
        editSuppliersApprove
    } from '@/api/masterData/supplier';
    import { resetObj, getDate } from '@/libs/tools';

    export default {
        name: 'editSupplierFirst',
        components: {
            ErpTable,
            BaseInFoForm,
            MachineManagement,
            UploadData,
            Contact,
            MachineProduction
        },
        mixins: [tableMixin, supplierMixin],
        data () {
            return {
                tableQueryAttr: {
                    supplierName: ''
                },
                erpTableTitle: [
                    {
                        title: '公司',
                        align: 'center',
                        minWidth: 110,
                        key: 'enterpriseName'
                    },
                    {
                        title: '名称',
                        align: 'center',
                        minWidth: 140,
                        key: 'supplierName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specialtyGroupName'
                    },
                    {
                        title: '分类',
                        align: 'center',
                        minWidth: 90,
                        key: 'supplierClassifyName'
                    },
                    {
                        title: '性质',
                        align: 'center',
                        minWidth: 90,
                        key: 'supplierNatureName'
                    },
                    {
                        title: '供应商种类',
                        align: 'center',
                        minWidth: 100,
                        key: 'supplierTypeName'
                    },
                    {
                        title: '供应商类别',
                        align: 'center',
                        minWidth: 100,
                        key: 'supplierCategoryName'
                    },
                    {
                        title: '创建人员',
                        align: 'center',
                        minWidth: 90,
                        key: 'createName'
                    },
                    {
                        title: '创建时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '审批状态',
                        align: 'center',
                        minWidth: 90,
                        key: 'taskStatusName'
                    }
                ],
                supplierAddList: [
                    {
                        id: 1,
                        label: '一级供应商'
                    },
                    {
                        id: 2,
                        label: '子供应商'
                    }
                ], // 新增供应商类型
                supplierShowFlag: false, // 供应商列表弹窗开关
                supplierTableQuery: {
                    supplierName: '',
                    unifiedSocialCreditCode: ''
                }, // 供应商列表查询条件
                supplierTableTitle: [
                    {
                        title: '供应商名称',
                        align: 'center',
                        minWidth: 140,
                        key: 'supplierName'
                    },
                    {
                        title: '统一社会信用码',
                        align: 'center',
                        minWidth: 130,
                        key: 'unifiedSocialCreditCode'
                    },
                    {
                        title: '供应商种类',
                        align: 'center',
                        minWidth: 100,
                        key: 'supplierTypeName'
                    },
                    {
                        title: '供应商类别',
                        align: 'center',
                        minWidth: 100,
                        key: 'supplierCategoryName'
                    },
                    {
                        title: '操作',
                        minWidth: 100,
                        align: 'center',
                        fixed: 'right',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'success',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.selectionSupplier(params.row);
                                            }
                                        }
                                    },
                                    '选择'
                                )
                            ]);
                        }
                    }
                ], // 供应商列表栏目
                supplierTableData: [], // 供应商列表数据
                supplierTableLoading: false, // 供应商列表加载ing开关
                supplierPage: {
                    pageNo: 1,
                    pageSize: 10
                },
                supplierTotal: 0, // 供应商列表总数
                firstChange: true,
                specialtyGroupArr: [] // 已存在的专业分组
            };
        },
        created () {
            this.getSpecialtyGroupList();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getSupplierChangeList(params);
                    getListMixin(res);
                });
            },
            // 新增供应商
            addSupplier (index) {
                this.currentId = null;
                this.formDisabled = false;
                this.$refs.managerTable.clearCurrentTableRow();
                switch (index) {
                    case 1:
                        this.getAllSelectData();
                        this.addItem('新增供应商');
                        break;
                    case 2:
                        this.getAllSelectData();
                        this.supplierShowFlag = true;
                        this.supplierReset();
                        break;
                }
            },
            // 点击新增变更按钮
            addChange () {
                this.supplierShowFlag = true;
                this.supplierReset();
            },
            // 编辑数据
            edit () {
                let valid = this.validCurrent();
                if (!valid) return false;
                this.$refs.managerTable.clearCurrentTableRow();
                this.getOldSupplierData();
                this.getAllSelectData();
                this.editTableData({ row: this.currentRow }, '编辑供应商');
            },
            modalOk () {
                if (this.formDisabled) return this.changeLoading();
                switch (this.tabIndex) {
                    case 0:
                        if (
                            this.judgeBtnRight('supplierPurChangeEdit') ||
                            this.judgeBtnRight('supplierPurChangeAdd')
                        ) {
                            this.$refs.baseInfoForm.editSaveInfo();
                        } else {
                            this.changeLoading();
                        }
                        break;
                    case 1:
                        this.changeLoading();
                        break;
                    case 2:
                        if (this.judgeBtnRight('supplierProductionSave')) {
                            this.$refs.machineProduction.saveData();
                        } else {
                            this.changeLoading();
                        }
                        break;
                    case 3:
                        if (this.judgeBtnRight('supplierManageSave')) {
                            this.$refs.machineManagement.saveData();
                        } else {
                            this.changeLoading();
                        }
                        break;
                    case 4:
                        this.changeLoading();
                        break;
                }
            },
            // 处理临时供应商modal确认异步
            changeTemporaryLoading () {
                this.modelLoading = false;
                this.$nextTick(() => {
                    this.modelLoading = true;
                });
            },
            // tab点击
            tabsBind (name) {
                switch (name) {
                    case 0:
                        break;
                    case 1:
                        this.getInfoRadio();
                        this.getOldUploadTable();
                        this.getUploadTable();
                        break;
                    case 2:
                        this.getOldSelectedMachineProduction();
                        this.getInfoRadio();
                        this.getSelectedMachineProduction();
                        break;
                    case 3:
                        this.getOldSelectedMachineManagement();
                        this.getInfoRadio();
                        this.getSelectedMachineManagement();
                        break;
                    case 4:
                        this.getOldSupplierContactList();
                        this.getSupplierContactList();
                        break;
                }
            },
            // 获取子组件传来的id
            changeCurrentId (obj) {
                if (obj.id) {
                    this.currentId = obj.id;
                    this.currentRow.mainBrand = obj.mainBrand;
                }
                this.modelLoading = false;
            },
            // 获取弹窗中供应商列表
            async getModalSupplierList () {
                this.supplierTableLoading = true;
                const params = Object.assign(
                    {},
                    this.supplierPage,
                    this.supplierTableQuery
                );
                const res = await getCanChangeSupplierList(params);
                if (res.status === this.code) {
                    this.supplierTableData = res.content.list;
                    this.supplierTableLoading = false;
                    this.supplierTotal = res.content.total;
                }
            },
            // 更新表格数据
            updateTable (e) {
                this.getUploadTable(e);
            },
            // 搜索供应商列表
            supplierSearch () {
                this.getModalSupplierList();
            },
            // 供应商列表搜索重置
            supplierReset () {
                this.supplierPage.pageNo = 1;
                resetObj(this.supplierTableQuery);
                this.getModalSupplierList();
            },
            // 改变供应商列表页码
            supplierChangePage (value) {
                this.supplierPage.pageNo = value;
                this.getModalSupplierList();
            },
            // 改变供应商列表每页条数
            supplierChangePageSize (value) {
                this.supplierPage.pageNo = 1;
                this.supplierPage.pageSize = value;
                this.getModalSupplierList();
            },
            // 选中供应商
            selectionSupplier (row) {
                this.getAllSelectData();
                this.supplierShowFlag = false;
                this.currentRow = row;
                this.modalTitle = '修改供应商';
                this.currentId = null;
                for (let key in row) {
                    this.oldFormAttr[key] = row[key];
                    this.formAttr[key] = row[key];
                }
                this.oldFormAttr.id = '';
                this.formAttr.id = '';
                this.formAttr.taskStatus = 0;
                this.formAttr.supplierId = row.id;
                this.modalShowFlag = true;
            },
            // 发起审批
            async submit () {
                this.$refs.managerTable.clearCurrentTableRow();
                if (!this.currentId) return this.$Message.error('请先选中一项');
                if (
                    this.currentRow.taskStatus !== 0 &&
                    this.currentRow.taskStatus !== 3 &&
                    !this.modalShowFlag
                ) { return this.$Message.error('只有待发起和打回状态才能发起审批'); }
                this.submitFn(async call => {
                    const params = {
                        taskInstanceId: this.currentId
                    };
                    const res = await editSuppliersApply(params);
                    if (this.modalShowFlag) this.supplierModalCancel();
                    call(res);
                });
            },
            // 审批通过
            async approve () {
                this.$refs.managerTable.clearCurrentTableRow();
                if (!this.currentId) return this.$Message.error('请先选中一项');
                if (
                    this.currentRow.taskStatus !== 1
                ) { return this.$Message.error('只有审批中才能审批通过'); }
                this.submitFn(async call => {
                    const params = {
                        taskInstanceId: this.currentId
                    };
                    const res = await editSuppliersApprove(params);
                    if (this.modalShowFlag) this.supplierModalCancel();
                    call(res);
                });
            },
            // 获取已存在的专业分组
            async getSpecialtyGroupList () {
                const res = await getSpecialtyGroupList();
                if (res.status === this.code) {
                    this.specialtyGroupArr = res.content;
                }
            },
            // 删除新增供应商申请
            async delSuppliersApply () {
                if (!this.currentId) return this.$Message.error('请先选中一项');
                if (this.currentId) {
                    this.$Modal.confirm({
                        title: `确认删除吗？`,
                        onOk: async () => {
                            const params = {
                                taskInstanceId: this.currentId
                            };
                            const res = await delSuppliersChangeApply(params);
                            if (res.status === this.code) {
                                this.$Message.success(res.msg);
                                this.currentId = null;
                                this.getTableList();
                            }
                        }
                    });
                }
            }
        }
    };
</script>

<style scoped lang="less">
.dropdown-add {
    float: left;
    position: relative;
    margin-left: -1px;

    .ivu-btn-default {
        border-radius: 0;
    }

    &:hover {
        z-index: 2;
    }

    & + .ivu-btn {
        margin-left: -0.5px;
    }
}

.button-department {
    width: 100%;
    text-align: left;
    padding-left: 7px;
    padding-right: 24px;
    position: relative;

    /deep/ .ivu-icon-ios-arrow-down {
        position: absolute;
        top: 50%;
        right: 8px;
        margin-top: -7px;
    }

    /deep/ span {
        margin-left: 0;
    }
}
.erp-modal-content {
    padding-top: 0;
}
</style>
