<template>
    <div class="organization">
        <!-- <h1>组织管理</h1> -->
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon> 查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.organizationName"
                        placeholder="组织名称"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        filterable
                        placeholder="组织状态"
                        @on-change="selectSearch"
                        v-model="tableQueryAttr.status"
                    >
                        <Option
                            v-for="(item, index) in slectList"
                            :label="item.label"
                            :value="item.value"
                            :key="index"
                        ></Option>
                    </Select>
                </Col>
                <Col span="5">
                    <Select
                        filterable
                        placeholder="锁定状态"
                        @on-change="selectSearch"
                        v-model="tableQueryAttr.locked"
                    >
                        <Option
                            v-for="(item, index) in statusList"
                            :label="item.label"
                            :value="item.value"
                            :key="index"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card :border="false">
            <p slot="title"><Icon type="md-list"></Icon>组织列表</p>
            <div slot="extra">
                <Button @click="add" v-has="btnRightList.organizationCreate" icon="md-add">新增</Button>
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="orgListTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
            ></erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel"
        >
            <div class="erp-modal-content">
                <Form :model="formAttr" :rules="ruleValidate" ref="formValidate" :label-width="120">
                    <FormItem label="组织名称" prop="organizationName">
                        <Input v-model="formAttr.organizationName" placeholder="请输入组织名称"></Input>
                    </FormItem>
                    <FormItem label="组织编号" prop="organizationCode">
                        <Input v-model="formAttr.organizationCode" placeholder="请输入组织名称"></Input>
                    </FormItem>
                    <FormItem label="机构代码" prop="socialCreditCode">
                        <Input v-model="formAttr.socialCreditCode" placeholder="请输入组织名称"></Input>
                    </FormItem>
                    <FormItem label="上级组织" prop="select">
                        {{ formAttr.parentOrganizationName }}
                        <Button type="primary" @click="getOrg()">选择</Button>
                    </FormItem>
                    <div v-show="currentId">
                        <FormItem label="组织状态">
                            <RadioGroup v-model="formAttr.status">
                                <!-- <Radio label="有效" :value="1"></Radio>
                                <Radio label="无效" :value="0"></Radio>-->
                                <Radio
                                    v-for="item in statusRadio"
                                    :label="item.value"
                                    :key="item.index"
                                >
                                    <span>{{ item.label }}</span>
                                </Radio>
                            </RadioGroup>
                        </FormItem>
                        <FormItem label="锁定状态">
                            <RadioGroup v-model="formAttr.locked">
                                <Radio
                                    v-for="item in lockRadio"
                                    :label="item.value"
                                    :key="item.index"
                                >
                                    <span>{{ item.label }}</span>
                                </Radio>
                            </RadioGroup>
                        </FormItem>
                        <FormItem label="创建时间">
                            <Input v-model="formAttr.createTime" disabled placeholder="创建时间"></Input>
                        </FormItem>
                        <FormItem label="创建人">
                            <Input v-model="formAttr.createUserRealName" disabled placeholder="创建人"></Input>
                        </FormItem>
                        <FormItem label="最后修改时间">
                            <Input v-model="formAttr.updateTime" disabled placeholder="最后修改时间"></Input>
                        </FormItem>
                        <FormItem label="最后修改人">
                            <Input
                                v-model="formAttr.updateUserRealName"
                                disabled
                                placeholder="最后修改人"
                            ></Input>
                        </FormItem>
                    </div>
                </Form>
            </div>
        </Modal>
        <Modal v-model="selectSwitch" title="组织选择" :mask-closable="false" width="760">
            <div class="search-container">
                <Input v-model="orgName" placeholder="组织名称" class="searchInput"></Input>
                <Button type="primary" @click="searchName">搜索</Button>
            </div>
            <Table :columns="orgColumns" :data="orgData" :border="true"></Table>
            <div class="page-contaner">
                <Page
                    :current="Page.pageNo"
                    @on-change="pageChange"
                    @on-page-size-change="pageSizeChange"
                    show-size
                    :total="Page.total"
                    show-elevator
                />
            </div>
            <div slot="footer"></div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        getOrganizationList,
        updateOrganization,
        addOrganization
    } from '@/api/organization/orgList';
    import { getDate } from '@/libs/tools';
    export default {
        components: { ErpTable },
        mixins: [tableMixin],
        data () {
            return {
                selectSwitch: false, // 组织选择dialog
                Page: {
                    pageNo: 1,
                    total: 0,
                    pageSize: 10
                },
                // 状态下拉框
                slectList: [
                    {
                        label: '全部',
                        value: ''
                    },
                    {
                        label: '有效',
                        value: 1
                    },
                    {
                        label: '无效',
                        value: 0
                    }
                ],
                // 锁定下拉框
                statusList: [
                    {
                        label: '全部',
                        value: ''
                    },
                    {
                        label: '正常',
                        value: 1
                    },
                    {
                        label: '锁定',
                        value: 0
                    }
                ],
                // 锁定单选框
                lockRadio: [
                    {
                        label: '锁定',
                        value: 0
                    },
                    {
                        label: '正常',
                        value: 1
                    }
                ],
                // 状态单选框
                statusRadio: [
                    {
                        label: '无效',
                        value: 0
                    },
                    {
                        label: '有效',
                        value: 1
                    }
                ],
                orgName: '', // 已选组织名称
                // 组织列表表头
                orgColumns: [
                    {
                        title: '组织名称',
                        align: 'center',
                        minWidth: 80,
                        key: 'organizationName'
                    },
                    {
                        title: '上级组织',
                        align: 'center',
                        minWidth: 80,
                        key: 'parentOrganizationName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 80,
                        key: 'status',
                        render: (h, params) => {
                            const status = params.row.status === 1;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: status ? 'success' : 'default'
                                    }
                                },
                                status ? '有效' : '无效'
                            );
                        }
                    },
                    {
                        title: '是否锁定',
                        align: 'center',
                        minWidth: 80,
                        key: 'locked',
                        render: (h, params) => {
                            const status = params.row.locked === 1;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: status ? 'success' : 'default'
                                    }
                                },
                                status ? '正常' : '锁定'
                            );
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 80,
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.formAttr.parentOrganizationId =
                                                    params.row.id;
                                                this.formAttr.parentOrganizationName =
                                                    params.row.organizationName;
                                                this.orgName = '';
                                                this.selectSwitch = false;
                                            }
                                        }
                                    },
                                    '选择'
                                )
                            ]);
                        }
                    }
                ],
                orgData: [],
                formAttr: {
                    organizationName: '',
                    organizationCode: '',
                    socialCreditCode: '',
                    status: '',
                    locked: '',
                    createTime: '',
                    createUserRealName: '',
                    updateTime: '',
                    updateUserRealName: '',
                    parentOrganizationId: '',
                    parentOrganizationName: ''
                },
                tableQueryAttr: {
                    organizationName: '',
                    status: '',
                    locked: ''
                },
                ruleValidate: {
                    organizationName: [
                        {
                            required: true,
                            message: '组织名称不能为空'
                        }
                    ]
                },
                // 初始化数据表头
                orgListTitle: [
                    {
                        type: 'index',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '组织名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'organizationName'
                    },
                    {
                        title: '机构代码',
                        align: 'center',
                        minWidth: 120,
                        key: 'socialCreditCode'
                    },
                    {
                        title: '上级组织',
                        align: 'center',
                        minWidth: 100,
                        key: 'parentOrganizationName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'status',
                        render: (h, params) => {
                            const status = params.row.status === 1;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: status ? 'success' : 'default'
                                    }
                                },
                                status ? '有效' : '无效'
                            );
                        }
                    },
                    {
                        title: '是否锁定',
                        align: 'center',
                        minWidth: 100,
                        key: 'locked',
                        render: (h, params) => {
                            const status = params.row.locked === 1;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: status ? 'success' : 'default'
                                    }
                                },
                                status ? '正常' : '锁定'
                            );
                        }
                    },
                    {
                        title: '最后更新人',
                        align: 'center',
                        minWidth: 100,
                        key: 'updateUserRealName'
                    },
                    {
                        title: '最后更新时间',
                        align: 'center',
                        minWidth: 170,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.updateTime, 'long')
                            );
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        fixed: 'right',
                        minWidth: 100,
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        style: {},
                                        on: {
                                            click: () => {
                                                this.editTableData(
                                                    params,
                                                    '组织编辑',
                                                    this.timeFormat
                                                );
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList
                                                    .organizationUpdate
                                            }
                                        ]
                                    },
                                    '编辑'
                                )
                            ]);
                        }
                    }
                ]
            };
        },
        computed: {},
        watch: {},
        created () {
            // this.getTableList();
        },
        mounted () {},
        destroyed () {},
        methods: {
            // search() {
            //     this.getTableList();
            // },
            // reset() {},
            add () {
                this.addItem('组织新增');
            },
            selectSearch () {
                this.getTableList();
            },
            searchName () {
                this.tableQueryAttr.organizationName = this.orgName;
                this.getTableList();
            },
            modalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res = null;
                    const params = this.currentId
                        ? Object.assign({}, this.formAttr, { id: this.currentId })
                        : Object.assign({}, this.formAttr);
                    if (this.currentId) {
                        res = await updateOrganization(params);
                    } else {
                        res = await addOrganization(params);
                    }
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    } else {
                        this.changeLoading();
                    }
                });
            },
            pageChange (e) {
                this.Page.pageNo = e;
                // console.log(e);
                this.getOrg();
            },
            pageSizeChange () {},

            // modalCancel() {},
            async getTableList () {
                const params = Object.assign(
                    {},
                    this.tableComAttr,
                    this.tableQueryAttr
                );
                this.getTableListFn(async getListMixin => {
                    const res = await getOrganizationList(params);
                    getListMixin(res);
                });
            },
            async getOrg () {
                // console.log(params)
                this.selectSwitch = true;
                const res = await getOrganizationList(this.Page);
                if (res.status === this.code) {
                    const content = res.content;
                    this.orgData = content.list;
                    // this.Page.pageNo = content.pageNo;
                    this.Page.total = content.total;
                }
            },

            // 格式时间
            timeFormat (row) {
                // console.log(row);
                this.formAttr.createTime = getDate(row.createTime, 'long');
                this.formAttr.updateTime = getDate(row.updateTime, 'long');
            }
        }
    };
</script>

<style scoped>
.searchInput {
    width: 180px;
    margin-right: 24px;
}

.search-container {
    margin-bottom: 16px;
}

.page-contaner {
    margin-top: 16px;
    text-align: center;
}
</style>
