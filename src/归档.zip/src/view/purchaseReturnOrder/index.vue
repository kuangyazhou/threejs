<template>
    <div class="inventoryInit">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.inventoryOrganizationId"
                        @on-change="searchInventory"
                        placeholder="请选择库存组织"
                    >
                        <Option
                            v-for="item in inventoryOrganizationArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.warehouseId"
                        :disabled="!tableQueryAttr.inventoryOrganizationId"
                        @on-change="selectSearch"
                        placeholder="请选择仓库"
                    >
                        <Option
                            v-for="item in warehouseArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.supplierName"
                        @on-search="search"
                        search
                        placeholder="供应商"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        placeholder="请选择单据状态"
                        @on-change="selectSearch"
                        remote
                        v-model="tableQueryAttr.status"
                    >
                        <Option
                            v-for="item in statusArr"
                            :label="item.label"
                            :value="item.value"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                采购退货单列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button v-has="btnRightList.purchaseRefundAdd" @click="openSendModal"
                        icon="md-add"
                    >新增</Button>
                    <Button
                        v-has="btnRightList.purchaseRefundEdit"
                        @click="getPurchaseReturnDetailList"
                        icon="ios-create-outline"
                    >编辑</Button>
                    <Button
                        v-has="btnRightList.purchaseRefundSubmit"
                        @click="submitPurchaseRefundOrder"
                        icon="md-send"
                    >提交</Button>
                    <Button
                        v-has="btnRightList.purchaseRefundCancel"
                        @click="cancelPurchaseRefundOrder"
                        icon="md-undo"
                    >撤回</Button>
                    <Button
                        v-has="btnRightList.purchaseRefundApprove"
                        @click="approvePurchaseRefundOrder"
                        icon="md-redo"
                    >审核</Button>
                </ButtonGroup>
            </div>
            <erp-table
                ref="purchaseTable"
                highlight
                @on-current-change="currentChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>
<!--        选择采购入库单弹窗-->
        <Modal
            v-model="sendShowFlag"
            width="800"
            title="选择采购入库单明细"
            :loading="sendModelLoading"
            :mask-closable="false"
            @on-ok="sendModalOk"
            @on-cancel="sendModalCancel"
        >
            <Row :gutter="16" class="mb20">
                <Col span="5">
                    <Select
                        v-model="sendQueryAttr.inventoryOrganizationId"
                        @on-change="searchInventory"
                        placeholder="请选择库存组织"
                    >
                        <Option
                            v-for="item in inventoryOrganizationArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5">
                    <Select
                        v-model="sendQueryAttr.warehouseId"
                        :disabled="!sendQueryAttr.inventoryOrganizationId"
                        @on-change="sendSearch"
                        placeholder="请选择仓库"
                    >
                        <Option
                            v-for="item in warehouseArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5">
                    <Input
                        v-model="sendQueryAttr.supplierName"
                        placeholder="供应商名称"
                    ></Input>
                </Col>
                <Col span="5">
                    <DatePicker
                        v-model="sendQueryAttr.createDate"
                        format="yyyy-MM-dd"
                        type="date"
                        @on-change="createDateChange"
                        placeholder="制单日期"
                    ></DatePicker>
                </Col>
                <Col span="4">
                    <Button @click="sendSearch">搜索</Button>
                </Col>
            </Row>
            <erp-table
                @on-selection-change="sendSelection"
                @on-page-no-change="purchasePageNoChange"
                :erpTableTitle="sendTableTitle"
                :erpTableData="sendTableData"
                :tableLoading="purchaseTableLoading"
                :current="purchaseComAttr.pageNo"
                :total="purchaseTotal"
                :showSizer='showSizer'
                :showElevator='showSizer'
            >
            </erp-table>
        </Modal>
<!--        新增编辑采购退货单弹窗-->
        <Modal
            v-model="modalShowFlag"
            width="1000"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-cancel="modalCancel(clearCurrent)"
        >
            <div>
                <Form
                    :model="formAttr"
                    ref="formValidate"
                    :label-width="120"
                >
                    <Row>
                        <Col span="12">
                            <FormItem label="采购退货单号">
                                <Input
                                    disabled
                                    v-model="formAttr.purchaseRefundOrderCode"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="库存组织">
                                <Input
                                    disabled
                                    v-model="formAttr.inventoryOrganizationName"
                                    placeholder="请输入库存组织"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="仓库">
                                <Input
                                    disabled
                                    v-model="formAttr.warehouseName"
                                    placeholder="请输入仓库"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="供应商">
                                <Input
                                    disabled
                                    v-model="formAttr.supplierName"
                                    placeholder="请输入供应商"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="24">
                            <FormItem label="收货地址">
                                <Input
                                    :disabled="Boolean(curStatus)"
                                    v-model="formAttr.receiveAddress"
                                    placeholder="请输入收货地址"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="退货时间">
                                <DatePicker
                                    :disabled="Boolean(curStatus)"
                                    v-model="formAttr.refundDate"
                                    format="yyyy-MM-dd"
                                    type="date"
                                    placeholder="退货时间"
                                ></DatePicker>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="退货时段">
                                <Select
                                    :disabled="Boolean(curStatus)"
                                    placeholder="请选择退货时段"
                                    remote
                                    v-model="formAttr.refundTime"
                                >
                                    <Option
                                        v-for="item in refundTimeArr"
                                        :label="item.label"
                                        :value="item.value"
                                        :key="item.id"
                                    ></Option>
                                </Select>
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="md-list"></Icon>
                        采购退货明细列表
                    </p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button v-if="!curStatus" @click="detailOrderAdd">新增</Button>
                        </ButtonGroup>
                    </div>
                    <Table border :columns="orderDetailTableTitle" :data="orderDetailTableData">
                    </Table>
                </Card>
            </div>
            <div slot="footer">
                <Button @click="modalCancel(clearCurrent)">取消</Button>
                <Button v-if="!curStatus" @click="modalOk">保存</Button>
                <Button v-if="curStatus===0" type="primary" @click="submitPurchaseRefundOrder">提交</Button>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { getOrganizationDropList, getWarehouseDropList } from '@/api/inventory/inventory';
    import { getPurchaseReturnDetailList, addPurchaseRefundOrder, editPurchaseRefundOrder, getPurchaseInboundList, submitPurchaseRefundOrder, cancelPurchaseRefundOrder, approvePurchaseRefundOrder } from '@/api/purchaseManage/purchaseReturn';
    import { getDate, resetObj } from '@/libs/tools';

    export default {
        name: 'purchaseReturnOrder',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    inventoryOrganizationId: '',
                    warehouseId: '',
                    supplierName: '',
                    status: ''
                },
                inventoryOrganizationArr: [], // 库存组织下拉
                warehouseArr: [], // 仓库列表下拉
                erpTableTitle: [
                    {
                        title: '退货单号',
                        align: 'center',
                        minWidth: 120,
                        key: 'purchaseRefundOrderCode'
                    },
                    {
                        title: '库存组织',
                        align: 'center',
                        minWidth: 120,
                        key: 'inventoryOrganizationName'
                    },
                    {
                        title: '仓库',
                        align: 'center',
                        minWidth: 120,
                        key: 'warehouseName'
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '退货时间',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.refundDate)
                            );
                        }
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityName'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '退货数量',
                        align: 'center',
                        minWidth: 90,
                        key: 'quantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 90,
                        key: 'unitName'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    {
                        title: '有效期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            let effectiveDate = getDate(params.row.effectiveDate);
                            if (params.row.effectiveDateFormat === 'yyyy-MM') {
                                effectiveDate = effectiveDate.slice(0, 7);
                            }
                            return h(
                                'span',
                                {},
                                effectiveDate
                            );
                        }
                    },
                    {
                        title: '原退货单明细号',
                        align: 'center',
                        minWidth: 130,
                        key: 'id'
                    },
                    {
                        title: '录入时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 90,
                        fixed: 'right',
                        key: 'statusDescription'
                    }
                    // {
                    //     title: '操作',
                    //     key: 'action',
                    //     width: 140,
                    //     align: 'center',
                    //     fixed: 'right',
                    //     render: (h, params) => {
                    //         if (params.row.status === 0) {
                    //             return h('div', [
                    //                 h(
                    //                     'Button',
                    //                     {
                    //                         props: {
                    //                             type: 'primary',
                    //                             size: 'small'
                    //                         },
                    //                         style: {
                    //                             marginRight: '5px'
                    //                         },
                    //                         on: {
                    //                             click: () => {
                    //                                 this.getPurchaseReturnDetailList(params);
                    //                             }
                    //                         },
                    //                         directives: [
                    //                             {
                    //                                 name: 'has',
                    //                                 value: this.btnRightList.purchaseRefundEdit
                    //                             }
                    //                         ]
                    //                     },
                    //                     '编辑'
                    //                 ),
                    //                 h(
                    //                     'Button',
                    //                     {
                    //                         props: {
                    //                             type: 'success',
                    //                             size: 'small'
                    //                         },
                    //                         style: {},
                    //                         on: {
                    //                             click: () => {
                    //                                 this.currentId = params.row.purchaseRefundOrderId;
                    //                                 this.submitPurchaseRefundOrder();
                    //                             }
                    //                         },
                    //                         directives: [
                    //                             {
                    //                                 name: 'has',
                    //                                 value: this.btnRightList.purchaseRefundSubmit
                    //                             }
                    //                         ]
                    //                     },
                    //                     '提交'
                    //                 )
                    //             ]);
                    //         } else if (params.row.status === 1) {
                    //             return h('div', [
                    //                 h(
                    //                     'Button',
                    //                     {
                    //                         props: {
                    //                             type: 'primary',
                    //                             size: 'small'
                    //                         },
                    //                         style: {
                    //                             marginRight: '5px'
                    //                         },
                    //                         on: {
                    //                             click: () => {
                    //                                 this.getPurchaseReturnDetailList(params);
                    //                             }
                    //                         }
                    //                     },
                    //                     '查看'
                    //                 ),
                    //                 h(
                    //                     'Button',
                    //                     {
                    //                         props: {
                    //                             type: 'success',
                    //                             size: 'small'
                    //                         },
                    //                         style: {
                    //                             marginRight: '5px'
                    //                         },
                    //                         on: {
                    //                             click: () => {
                    //                                 this.currentId = params.row.purchaseRefundOrderId;
                    //                                 this.approvePurchaseRefundOrder();
                    //                             }
                    //                         },
                    //                         directives: [
                    //                             {
                    //                                 name: 'has',
                    //                                 value: this.btnRightList.purchaseRefundApprove
                    //                             }
                    //                         ]
                    //                     },
                    //                     '审核'
                    //                 ),
                    //                 h(
                    //                     'Button',
                    //                     {
                    //                         props: {
                    //                             type: 'error',
                    //                             size: 'small'
                    //                         },
                    //                         style: {},
                    //                         on: {
                    //                             click: () => {
                    //                                 this.currentId = params.row.purchaseRefundOrderId;
                    //                                 this.cancelPurchaseRefundOrder();
                    //                             }
                    //                         },
                    //                         directives: [
                    //                             {
                    //                                 name: 'has',
                    //                                 value: this.btnRightList.purchaseRefundCancel
                    //                             }
                    //                         ]
                    //                     },
                    //                     '撤回'
                    //                 )
                    //             ]);
                    //         } else if (params.row.status === 2) {
                    //             return h('div', [
                    //                 h(
                    //                     'Button',
                    //                     {
                    //                         props: {
                    //                             type: 'primary',
                    //                             size: 'small'
                    //                         },
                    //                         style: {
                    //                             marginRight: '5px'
                    //                         },
                    //                         on: {
                    //                             click: () => {
                    //                                 this.getPurchaseReturnDetailList(params);
                    //                             }
                    //                         }
                    //                     },
                    //                     '查看'
                    //                 )
                    //             ]);
                    //         }
                    //     }
                    // }
                ],
                statusArr: [
                    {
                        id: 1,
                        label: '未提交',
                        value: 0
                    },
                    {
                        id: 2,
                        label: '已提交',
                        value: 1
                    },
                    {
                        id: 3,
                        label: '已审核',
                        value: 2
                    }
                ],
                showSizer: false,
                sendShowFlag: false, // 采购入库单弹窗开关
                sendModelLoading: false,
                sendQueryAttr: {
                    inventoryOrganizationId: '',
                    warehouseId: '',
                    createDate: '',
                    supplierName: ''
                }, // 采购入库单搜索
                purchaseTotal: 0,
                purchaseComAttr: {
                    pageNo: 1,
                    pageSize: 10
                },
                sendTableTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center',
                        fixed: 'left'
                    },
                    {
                        title: '入库单号',
                        align: 'center',
                        minWidth: 110,
                        key: 'inboundOrderCode'
                    },
                    {
                        title: '客户',
                        align: 'center',
                        minWidth: 110,
                        key: 'customerName'
                    },
                    {
                        title: '入库类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'orderTypeName'
                    },
                    {
                        title: '库存组织',
                        align: 'center',
                        minWidth: 120,
                        key: 'inventoryOrganizationName'
                    },
                    {
                        title: '仓库',
                        align: 'center',
                        minWidth: 120,
                        key: 'warehouseName'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 110,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 90,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'quantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 90,
                        key: 'unitName'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            let effectiveDate = getDate(params.row.effectiveDate);
                            if (params.row.effectiveDateFormat === 'yyyy-MM') {
                                effectiveDate = effectiveDate.slice(0, 7);
                            }
                            return h(
                                'span',
                                {},
                                effectiveDate
                            );
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '录入时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    }
                ], // 采购入库单明细栏目
                sendTableData: [], // 采购入库单明细数据
                purchaseTableLoading: false,
                curSendData: [], // 选中的采购入库单
                refundTimeArr: [
                    {
                        id: 1,
                        value: 1,
                        label: '全天'
                    },
                    {
                        id: 2,
                        value: 2,
                        label: '上午'
                    },
                    {
                        id: 3,
                        value: 3,
                        label: '下午'
                    }
                ],
                formAttr: {
                    purchaseRefundOrderCode: '',
                    inventoryOrganizationName: '',
                    inventoryOrganizationId: '',
                    warehouseId: '',
                    warehouseName: '',
                    supplierName: '',
                    supplierId: '',
                    receiveAddress: '',
                    refundDate: '',
                    refundTime: ''
                },
                orderDetailTableTitle: [
                    {
                        title: '来源类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'sourceTypeName'
                    },
                    {
                        title: '来源单据号',
                        align: 'center',
                        minWidth: 110,
                        key: 'sourceOrderCode'
                    },
                    {
                        title: '物料编码',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityCode'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 110,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 90,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '数量',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h('Input', {
                                props: {
                                    type: 'text',
                                    value: params.row.quantity
                                },
                                attrs: {
                                    disabled: Boolean(this.curStatus)
                                },
                                on: {
                                    'on-blur': (val) => {
                                        const value = val.target.value;
                                        if (!value || value === '') {
                                            return this.$Message.error('退货数量不能为空');
                                        }
                                        if (value > params.row.stockSum) {
                                            this.$Message.error('退货数量不能大于库存数量');
                                            params.row.quantity = '';
                                            this.orderDetailTableData[params.index].quantity = '';
                                            return;
                                        }
                                        params.row.quantity = value;
                                        this.orderDetailTableData[params.index].quantity = value;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '库存数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'stockSum'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 90,
                        key: 'unitName'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    {
                        title: '库存组织',
                        align: 'center',
                        minWidth: 120,
                        key: 'inventoryOrganizationName'
                    },
                    {
                        title: '仓库',
                        align: 'center',
                        minWidth: 120,
                        key: 'warehouseName'
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 110,
                        key: 'effectiveDate'
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        minWidth: 120,
                        align: 'center',
                        fixed: 'right',
                        render: (h, params) => {
                            return h('div', [
                                h('Button', {
                                    props: {
                                        type: 'info',
                                        size: 'small'
                                    },
                                    attrs: {
                                        disabled: Boolean(this.curStatus)
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            this.curIndex = params.index;
                                            this.sendQueryAttr = Object.assign({}, this.sendQueryAttr, {
                                                inboundOrderCode: params.row.sourceOrderCode
                                            });
                                            this.getPurchaseInboundDetailList();
                                            this.sendShowFlag = true;
                                        }
                                    }
                                }, '插入'),
                                h('Button', {
                                    props: {
                                        type: 'error',
                                        size: 'small'
                                    },
                                    attrs: {
                                        disabled: Boolean(this.curStatus)
                                    },
                                    on: {
                                        click: () => {
                                            this.delOrderDetail(params);
                                        }
                                    }
                                }, '删除')
                            ]);
                        }
                    }
                ], // 采购退货单明细表栏目
                orderDetailTableData: [], // 采购退货单明细表数据
                curIndex: null, // 新增插入的当前行号
                curRow: null,
                curStatus: null // 0未提交1已提交2已审核
            };
        },
        created () {
            this.getAllSelectData();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                if (!this.tableQueryAttr.warehouseId && !this.tableQueryAttr.inventoryOrganizationId) return;
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr);
                    const res = await getPurchaseReturnDetailList(params);
                    getListMixin(res);
                });
            },
            getAllSelectData () {
                this.getInventoryOrganizationList();
            },
            // 库存组织下拉
            async getInventoryOrganizationList () {
                const res = await getOrganizationDropList();
                if (res.status === this.code) {
                    this.inventoryOrganizationArr = res.content.map(item => {
                        return {
                            label: item.inventoryOrganizationName,
                            value: item.id
                        };
                    });
                    if (this.inventoryOrganizationArr.length && !this.tableQueryAttr.inventoryOrganizationId) {
                        this.tableQueryAttr.inventoryOrganizationId = this.inventoryOrganizationArr[0].value;
                        this.getWarehouseList(this.tableQueryAttr.inventoryOrganizationId);
                    }
                }
            },
            // 获取库存组织关联的仓库
            async getWarehouseList (id) {
                if (!id) return;
                const params = Object.assign({}, {
                    inventoryOrganizationId: id
                });
                const res = await getWarehouseDropList(params);
                if (res.status === this.code) {
                    this.warehouseArr = res.content.map(item => {
                        return {
                            label: item.warehouseName,
                            value: item.id
                        };
                    });
                    if (this.warehouseArr.length) {
                        this.tableQueryAttr.warehouseId = this.warehouseArr[0].value;
                        if (this.tableQueryAttr.warehouseId && this.tableQueryAttr.inventoryOrganizationId && !this.sendModelLoading) {
                            this.getTableList();
                        }
                        if (this.sendModelLoading) {
                            this.sendQueryAttr.warehouseId = this.warehouseArr[0].value;
                            this.getPurchaseInboundDetailList();
                        }
                    }
                }
            },
            // 选择库存之后
            searchInventory (val) {
                if (val) {
                    this.getWarehouseList(val);
                }
            },
            // 选中单行后
            currentChange (val) {
                this.curRow = val;
                this.curStatus = val.status;
                this.currentId = val.purchaseRefundOrderId;
            },
            // 打开采购入库单弹窗
            openSendModal () {
                this.clearCurrent();
                this.sendQueryAttr = Object.assign({}, this.sendQueryAttr, {
                    inventoryOrganizationId: this.tableQueryAttr.inventoryOrganizationId,
                    warehouseId: this.tableQueryAttr.warehouseId
                });
                this.getPurchaseInboundDetailList();
                this.sendShowFlag = true;
            },
            // 取消单行选中
            clearCurrent () {
                this.curIndex = null;
                this.curStatus = null;
                this.curRow = null;
                this.orderDetailTableData = [];
                this.$refs.purchaseTable.clearCurrentTableRow();
            },
            // 确认选中采购入库单
            async sendModalOk () {
                if (this.curSendData.length === 0) {
                    this.$Message.error('请先勾选采购入库单');
                    return this.changeLoading('sendModelLoading');
                }
                const sameOrder = this.curSendData.every(item => {
                    return item.inboundOrderCode === this.curSendData[0].inboundOrderCode;
                });
                if (!sameOrder) {
                    this.$Message.error('只能选择同一个采购入库单的明细');
                    return this.changeLoading('sendModelLoading');
                }
                const curPurchaseOrder = this.curSendData[0];
                this.formAttr = Object.assign({}, this.formAttr, {
                    inventoryOrganizationName: curPurchaseOrder.inventoryOrganizationName,
                    inventoryOrganizationId: curPurchaseOrder.inventoryOrganizationId,
                    warehouseId: curPurchaseOrder.warehouseId,
                    warehouseName: curPurchaseOrder.warehouseName,
                    supplierName: curPurchaseOrder.supplierName,
                    supplierId: curPurchaseOrder.supplierId
                });
                const orderDetailTableData = this.curSendData.map(item => {
                    let effectiveDate = getDate(item.effectiveDate);
                    if (item.effectiveDateFormat === 'yyyy-MM') {
                        effectiveDate = effectiveDate.slice(0, 7);
                    }
                    return Object.assign({}, {
                        sourceTypeName: item.sourceTypeName,
                        sourceOrderCode: item.inboundOrderCode,
                        sourceItemId: item.id,
                        commodityId: item.commodityId,
                        commodityCode: item.commodityCode,
                        commodityName: item.commodityName,
                        registerName: item.registerName,
                        registerNumber: item.registerNumber,
                        commoditySpec: item.commoditySpec,
                        brandName: item.brandName,
                        quantity: item.quantity,
                        stockSum: item.stockSum,
                        unitCode: item.unitCode,
                        unitName: item.unitName,
                        batchNo: item.batchNo,
                        inventoryOrganizationName: item.inventoryOrganizationName,
                        warehouseName: item.warehouseName,
                        effectiveDate: effectiveDate,
                        supplierName: item.supplierName
                    });
                });
                if (this.orderDetailTableData.length === 0) {
                    this.orderDetailTableData = [...orderDetailTableData];
                } else {
                    const detailIds = this.orderDetailTableData.map(item => {
                        return item.sourceItemId;
                    });
                    let addItems = [];
                    orderDetailTableData.forEach(item => {
                        if (!detailIds.includes(item.sourceItemId)) {
                            addItems.push(Object.assign({}, item));
                        }
                    });
                    if (this.curIndex === null) {
                        this.orderDetailTableData = this.orderDetailTableData.concat(addItems);
                    } else {
                        addItems.unshift(this.curIndex + 1, 0);
                        Array.prototype.splice.apply(this.orderDetailTableData, addItems);
                    }
                }
                this.sendModalCancel();
                this.openOutOrderModal();
            },
            // 关闭采购入库单弹窗
            sendModalCancel () {
                this.curSendData = [];
                this.sendTableData = [];
                this.sendShowFlag = false;
                this.purchaseComAttr.pageNo = 1;
                resetObj(this.sendQueryAttr);
            },
            // 获取采购入库单明细
            async getPurchaseInboundDetailList () {
                if (!this.sendQueryAttr.warehouseId && !this.sendQueryAttr.inventoryOrganizationId) return;
                this.purchaseTableLoading = true;
                const params = Object.assign({}, this.purchaseComAttr, this.sendQueryAttr);
                const res = await getPurchaseInboundList(params);
                this.purchaseTableLoading = false;
                if (res.status === this.code) {
                    this.sendTableData = res.content.list;
                    this.purchaseTotal = res.content.total;
                }
            },
            // 格式化制单时间
            createDateChange (value) {
                if (value) {
                    this.sendQueryAttr.createDate = value;
                    this.getPurchaseInboundDetailList();
                }
            },
            sendSearch () {
                this.getPurchaseInboundDetailList();
            },
            // 采购入库单勾选
            sendSelection (value) {
                this.curSendData = value;
            },
            // 打开退货单弹窗
            openOutOrderModal () {
                this.addItem('采购退货单编辑');
            },
            // 保存退货单
            async modalOk () {
                if (this.orderDetailTableData.length === 0) {
                    this.changeLoading();
                    this.$Message.error('至少要有一条退货单明细');
                    return;
                }
                let refundDate = this.formAttr.refundDate;
                if (refundDate instanceof Date) {
                    refundDate = getDate(refundDate);
                }
                let judgeNum = false;
                const items = this.orderDetailTableData.map(item => {
                    if (!item.quantity) judgeNum = true;
                    return Object.assign({}, {
                        sourceOrderCode: item.sourceOrderCode,
                        sourceItemId: item.sourceItemId,
                        commodityId: item.commodityId,
                        commodityCode: item.commodityCode,
                        commodityName: item.commodityName,
                        registerNumber: item.registerNumber,
                        registerName: item.registerName,
                        commoditySpec: item.commoditySpec,
                        brandName: item.brandName,
                        quantity: item.quantity,
                        unitCode: item.unitCode,
                        unitName: item.unitName,
                        batchNo: item.batchNo,
                        effectiveDate: item.effectiveDate
                    });
                });
                if (judgeNum) {
                    this.changeLoading();
                    this.$Message.error('退货数量不能为空');
                    return;
                }
                let res;
                if (this.currentId) {
                    const params = Object.assign({}, this.formAttr, {
                        items: [...items],
                        refundDate,
                        id: this.currentId
                    });
                    res = await editPurchaseRefundOrder(params);
                } else {
                    const params = Object.assign({}, this.formAttr, {
                        refundDate,
                        items: [...items]
                    });
                    res = await addPurchaseRefundOrder(params);
                }
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    if (res.content) {
                        this.formAttr = Object.assign({}, this.formAttr, {
                            purchaseRefundOrderCode: res.content.purchaseRefundOrderCode
                        });
                        this.currentId = res.content.id;
                        this.curStatus = 0;
                    }
                    this.getTableList();
                } else {
                    this.changeLoading();
                }
            },
            // 删除退货单明细
            delOrderDetail (params) {
                this.$Modal.confirm({
                    title: '是否确认删除',
                    onOk: () => {
                        this.orderDetailTableData.splice(params.index, 1);
                    }
                });
            },
            // 退货单弹窗中点击新增
            detailOrderAdd () {
                this.curIndex = null;
                if (this.orderDetailTableData.length) {
                    this.sendQueryAttr = Object.assign({}, this.sendQueryAttr, {
                        inventoryOrganizationId: this.formAttr.inventoryOrganizationId,
                        warehouseId: this.formAttr.warehouseId,
                        inboundOrderCode: this.orderDetailTableData[0].sourceOrderCode
                    });
                }
                this.getPurchaseInboundDetailList();
                this.sendShowFlag = true;
            },
            // 提交
            async submitPurchaseRefundOrder () {
                if (!this.currentId) {
                    return this.$Message.error('请先选择需要提交的订单');
                }
                if (this.curStatus !== 0) {
                    return this.$Message.error('只有未提交的单据允许提交');
                }
                const params = {
                    ids: [this.currentId]
                };
                const res = await submitPurchaseRefundOrder(params);
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    if (this.modalShowFlag) {
                        this.orderDetailTableData = [];
                        this.modalCancel();
                    }
                    this.clearCurrent();
                    this.getTableList();
                }
            },
            // 查看退货单明细
            async getPurchaseReturnDetailList () {
                if (!this.currentId) {
                    return this.$Message.error('请先选择订单');
                }
                const row = Object.assign({}, this.curRow, {
                    id: this.curRow.purchaseRefundOrderId,
                    refundDate: getDate(this.curRow.refundDate)
                });
                const params = Object.assign({}, {
                    purchaseRefundOrderCode: row.purchaseRefundOrderCode
                });
                const res = await getPurchaseReturnDetailList(params);
                if (res.status === this.code) {
                    const orderDetailTableData = res.content.map(item => {
                        let effectiveDate = getDate(item.effectiveDate);
                        if (item.effectiveDateFormat === 'yyyy-MM') {
                            effectiveDate = effectiveDate.slice(0, 7);
                        }
                        return Object.assign({}, {
                            sourceTypeName: item.sourceTypeName,
                            sourceOrderCode: item.sourceOrderCode,
                            sourceItemId: item.sourceItemId,
                            commodityId: item.commodityId,
                            commodityCode: item.commodityCode,
                            commodityName: item.commodityName,
                            registerName: item.registerName,
                            registerNumber: item.registerNumber,
                            commoditySpec: item.commoditySpec,
                            brandName: item.brandName,
                            quantity: item.quantity,
                            stockSum: item.stockSum,
                            unitCode: item.unitCode,
                            unitName: item.unitName,
                            batchNo: item.batchNo,
                            inventoryOrganizationName: item.inventoryOrganizationName,
                            warehouseName: item.warehouseName,
                            effectiveDate,
                            supplierName: item.supplierName
                        });
                    });
                    this.curStatus = row.status;
                    this.orderDetailTableData = [...orderDetailTableData];
                    const editData = Object.assign({}, {
                        row
                    });
                    this.editTableData(editData, '采购退货单编辑');
                }
            },
            // 审核
            async approvePurchaseRefundOrder () {
                if (!this.currentId) {
                    return this.$Message.error('请先选择需要审核的订单');
                }
                if (this.curStatus !== 1) {
                    return this.$Message.error('只有已提交的单据允许审核');
                }
                const params = {
                    ids: [this.currentId]
                };
                const res = await approvePurchaseRefundOrder(params);
                if (res.status === this.code) {
                    this.clearCurrent();
                    this.$Message.success(res.msg);
                    this.getTableList();
                }
            },
            // 撤回
            async cancelPurchaseRefundOrder () {
                if (!this.currentId) {
                    return this.$Message.error('请先选择需要撤回的订单');
                }
                if (this.curStatus !== 1) {
                    return this.$Message.error('只有已提交的单据允许撤回');
                }
                const params = {
                    ids: [this.currentId]
                };
                const res = await cancelPurchaseRefundOrder(params);
                if (res.status === this.code) {
                    this.clearCurrent();
                    this.$Message.success(res.msg);
                    this.getTableList();
                }
            },
            purchasePageNoChange (value) {
                this.purchaseComAttr.pageNo = value;
                this.getPurchaseInboundDetailList();
            }
        }
    };
</script>

<style scoped lang="less">
/deep/ .ivu-table-cell{
    padding: 4px;
}
</style>
