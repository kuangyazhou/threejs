<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-12 19:17:47
 * @LastEditTime: 2019-08-13 20:08:12
 * @LastEditors: Please set LastEditors
 -->
<template>
    <div class="sale-plan-set">
        <!-- <h1>销售计划参数设置</h1> -->
        <Card dis-hover :border="false" class="wrapper-query">
            <p slot="title">销售计划参数设置</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button icon="md-add" @click="add" v-has="btnRightList.salePlanSetSave">新增</Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
                ref="managerTable"
            ></erp-table>
        </Card>
        <Modal
            @on-ok="modalOk"
            @on-cancel="modalCancel"
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
        >
            <Form :model="formAttr" :label-width="120" :rules="ruleValidate" ref="formValidate">
                <FormItem label="每月几号" prop="monthDay">
                    <Select v-model="formAttr.monthDay">
                        <Option
                            v-for="item in dayArr"
                            :key="item.index"
                            :label="item.label"
                            :value="item.value"
                        ></Option>
                    </Select>
                </FormItem>
                <FormItem label="状态">
                    <Input disabled v-model="formAttr.status"></Input>
                </FormItem>
                <FormItem label="关联物料">
                    <Button @click="getMaterial">选择物料</Button>
                </FormItem>
                <Table :data="selectData" :columns="titleSet"></Table>
            </Form>
        </Modal>
        <Modal
            v-model="modalMaterial"
            width="960"
            title="物料选择"
            :mask-closable="maskClosable"
            @on-cancel="materialClose"
        >
            <Row :gutter="18" class="mb10">
                <Col span="6">
                    <Input v-model="materialSearch.registerName" placeholder="注册证名称"></Input>
                </Col>
                <Col span="6">
                    <Input v-model="materialSearch.supplierName" placeholder="供应商"></Input>
                </Col>
                <Col span="4">
                    <Button type="primary" @click="mSearch">搜索</Button>
                </Col>
            </Row>
            <div class="clearfix">
                <Table
                    :data="TableMaterial"
                    :columns="titleMaterial"
                    @on-selection-change="selectionChange"
                    :loading="tableLoading"
                    border
                ></Table>
                <div class="wrapper-page">
                    <Page
                        :current="materialPage.pageNo"
                        @on-change="pageChange"
                        @on-page-size-change="changePageSize"
                        show-sizer
                        :total="materialPage.total"
                    ></Page>
                </div>
            </div>
            <div slot="footer">
                <Button @click="materialClose">取消</Button>
                <Button @click="materialOk" type="success">选择</Button>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { resetObj } from '@/libs/tools';

    import {
        getMaterialList,
        salePlanSetList,
        salePlanSetAdd,
        salePlanSetValid,
        salePlanSetInValid,
        salePlanSetDel,
        salePlanSetUpdate
    } from '@/api/salePlan/index';

    export default {
        components: { ErpTable },
        mixins: [tableMixin],
        data () {
            return {
                dayArr: [], // 日期数据
                modalMaterial: false, // 物料Modal
                TableMaterial: [], // 可选物料表格数据
                selectData: [], // 已选择物料
                materialPage: {
                    pageNo: 1,
                    total: 0,
                    pageSize: 10
                }, // 物料分页
                tableLoading: false,
                materialSearch: {
                    registerName: '',
                    supplierName: ''
                },
                ruleValidate: {
                    monthDay: [
                        {
                            required: true,
                            message: '请选择日期',
                            type: 'number',
                            trigger: 'change'
                        }
                    ]
                },
                formAttr: {
                    monthDay: '',
                    status: '无效',
                    commodities: [],
                    id: null
                },
                erpTableTitle: [
                    {
                        title: '序号',
                        type: 'index',
                        align: 'center',
                        minWidth: 100
                    },
                    {
                        title: '每月几号',
                        align: 'center',
                        minWidth: 100,
                        key: 'monthDay'
                    },
                    {
                        title: '关联物料数',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityNum'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        // key: ''
                        render: (h, params) => {
                            const s = params.row.status === 3;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: s ? 'success' : 'error'
                                    }
                                },
                                s ? '有效' : '无效'
                            );
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        fixed: 'right',
                        minWidth: 100,
                        render: (h, params) => {
                            let temp = null;
                            if (params.row.status === 3) {
                                temp = h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'info',
                                            size: 'small'
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList
                                                    .salePlanInValid
                                            }
                                        ],
                                        class: 'mr6',
                                        on: {
                                            click: () => {
                                                this.setInValid(params.row);
                                                this.getTableList();
                                            }
                                        }
                                    },
                                    '失效'
                                );
                            }
                            if (params.row.status === 4) {
                                temp = h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'success',
                                            size: 'small'
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList
                                                    .salePlanValid
                                            }
                                        ],
                                        class: 'mr6',
                                        on: {
                                            click: () => {
                                                this.setValid(params.row);
                                                this.getTableList();
                                            }
                                        }
                                    },
                                    '生效'
                                );
                            }
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList
                                                    .salePlanSetUpdate
                                            }
                                        ],
                                        class: 'mr6',
                                        on: {
                                            click: () => {
                                                this.editTableData(
                                                    params,
                                                    '销售计划参数设置',
                                                    this.formatStatus
                                                );

                                                // 已关联物料在查询接口中返回;
                                                this.selectData =
                                                    params.row.commodities;
                                            }
                                        }
                                    },
                                    '修改'
                                ),
                                temp,
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'error',
                                            size: 'small'
                                        },
                                        class: 'mr6',
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList
                                                    .salePlanSetDel
                                            }
                                        ],
                                        on: {
                                            click: () => {
                                                this.setDel(params.row);
                                                this.getTableList();
                                            }
                                        }
                                    },
                                    '删除'
                                )
                            ]);
                        }
                    }
                ],
                titleMaterial: [
                    {
                        type: 'selection',
                        align: 'center',
                        minWidth: 60
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 180,
                        key: 'registerName'
                    },
                    {
                        title: '注册证号',
                        align: 'center',
                        minWidth: 100,
                        key: 'registerNumber'
                    },
                    {
                        title: '物料规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    }
                ],
                titleSet: [
                    {
                        title: '物料编码',
                        align: 'center',
                        minWidth: 180,
                        key: 'commodityCode'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'registerName'
                    },
                    {
                        title: '注册证号',
                        align: 'center',
                        minWidth: 100,
                        key: 'registerNumber'
                    },
                    {
                        title: '物料规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    }
                ]
            };
        },
        created () {
            // this.erpTableData = [{ ab: '123' }];
            for (let i = 0; i < 30; i++) {
                this.dayArr.push({
                    value: i + 1,
                    label: i + 1
                });
            }
        },
        methods: {
            add () {
                this.addItem('销售计划参数设置');
                this.formAttr.status = '无效';
            },
            modalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res = null;
                    this.formAttr.commodities = this.selectData;
                    const params = Object.assign({}, this.formAttr);
                    if (this.currentId) {
                        res = await salePlanSetUpdate(params);
                    } else {
                        // this.formAttr.commodities = this.selectData;
                        // const params = Object.assign({}, this.formAttr);
                        res = await salePlanSetAdd(params);
                    }
                    if (res && res.status === this.code) {
                        this.todoOver(res.msg);
                        this.selectData = [];
                    } else {
                        this.selectData = [];
                        return this.changeLoading();
                    }
                });
            // let res = null;

            // if (this.currentId) {
            //     this.$refs['formValidate'].validate(async valid => {
            //         console.log(this.formAttr);
            // return;
            //         if (!valid) {
            //             return this.changeLoading();
            //         }
            //         const params = Object.assign({}, this.formAttr);
            //         res = await salePlanSetUpdate(params);
            //     });
            // } else {
            //     this.$refs['formValidate'].validate(async valid => {
            //         console.log(this.formAttr);
            //         return;
            //         if (!valid) {
            //             return this.changeLoading();
            //         }
            //         this.formAttr.commodities = this.selectData;
            //         const params = Object.assign({}, this.formAttr);
            //         res = await salePlanSetAdd(params);
            //     });
            // }
            // if (res && res.status === this.code) {
            //     this.todoOver(res.msg);
            //     this.selectData = [];
            // } else {
            //     return this.changeLoading();
            // }
            },

            // 获取物料
            async getMaterial () {
                this.tableLoading = true;
                this.modalMaterial = true;
                // this.selectData = [];
                const params = Object.assign(
                    {},
                    this.materialSearch,
                    this.materialPage
                );
                const res = await getMaterialList(params);
                if (res.status === this.code) {
                    this.tableLoading = false;
                    this.TableMaterial = res.content.list;
                    this.materialPage.total = res.content.total;
                }
            },
            mSearch () {
                this.materialPage.pageNo = 1;
                this.getMaterial();
            },

            // 物料选择确认
            materialOk () {
                this.modalMaterial = false;
            // this.selectData=[];
            },

            materialClose () {
                this.modalMaterial = false;
                this.materialPage.pageNo = 1;
                this.selectData = [];
                resetObj(this.materialSearch);
            },

            selectionChange (e) {
                // this.selectData = this.selectData.concat(e);
                this.selectData = e;
            },

            formatStatus () {
                const s = this.formAttr.status === 3;
                this.formAttr.status = s ? '有效' : '无效';
            },

            // 分页事件
            pageChange (val) {
                if (val) {
                    this.materialPage.pageNo = val;
                    this.getMaterial();
                }
            },

            // 分页数
            changePageSize (val) {
                if (val) {
                    this.materialPage.pageSize = val;
                    this.getMaterial();
                }
            },

            // 生效
            async setValid (item) {
                const res = await salePlanSetValid({ id: item.id });
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            // 无效
            async setInValid (item) {
                const res = await salePlanSetInValid({ id: item.id });
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            async setDel (item) {
                const res = await salePlanSetDel({ id: item.id });
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            getTableList () {
                this.getTableListFn(async call => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await salePlanSetList(params);
                    call(res);
                });
            }
        }
    };
</script>
