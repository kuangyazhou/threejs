<template>
    <div class="erp-content" ref="erp">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.specializedGroupName"
                        @on-search="search"
                        search
                        placeholder="专业分组"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.commodityBrand"
                        @on-search="search"
                        search
                        placeholder="物料品牌"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.customerName"
                        @on-search="search"
                        search
                        placeholder="客户名称"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        placeholder="询价状态"
                        @on-change="selectSearch"
                        remote
                        v-model="tableQueryAttr.status"
                    >
                        <Option
                            v-for="item in receiveStatusArr"
                            :label="item.label"
                            :value="item.value"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="md-list"></Icon>
                询价任务列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button v-has="btnRightList.inquiryOrderAdd" @click="add" icon="md-add">生成询价单</Button>
                </ButtonGroup>
            </div>
            <erp-table
                ref="inquiryTask"
                @on-selection-change="selectionChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                @on-current-change="currentChange"
                highlight
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>

        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                询价单列表
            </p>
            <div slot="extra">
            </div>
            <erp-table
                @on-page-no-change="orderPageNoChange"
                @on-page-size-change="orderPageSizeChange"
                :erpTableTitle="orderTableTitle"
                :erpTableData="orderTableData"
                :tableLoading="orderTableLoading"
                :current="orderComAttr.pageNo"
                :total="orderTotal"
            >
            </erp-table>
        </Card>
<!--        查看询价任务弹窗-->
        <Modal
            v-model="materialShowFlag"
            width="800"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="materialModalOk"
            @on-cancel="materialModalCancel"
        >
            <div>
                <first-apply
                    ref="firstApply"
                    :disabled="onlyReady"
                    :customerNameArr="customerNameArr"
                    :outboundMethodNameArr="outboundMethodNameArr"
                    :deliveryMethodNameArr="deliveryMethodNameArr"
                    :purchaseOrganizationArr="purchaseOrganizationArr"
                    :formAttr="materialFormAttr"></first-apply>
            </div>
        </Modal>
<!--        询价单弹窗-->
        <Modal
            v-model="modalShowFlag"
            fullscreen
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-cancel="inquiryOrderCancel"
        >
            <Tabs v-model="tabIndex" type="card" @on-click="tabsBind">
                <TabPane label="基础信息">
                        <Form
                            :model="formAttr"
                            :rules="ruleValidate"
                            ref="formValidate"
                            :label-width="120"
                        >
                            <Row>
                                <Col span="8">
                                    <FormItem label="询价单号">
                                        <Input
                                            disabled
                                            v-model="formAttr.inquiryOrderCode"
                                            placeholder="询价单号"
                                        ></Input>
                                    </FormItem>
                                </Col>
                                <Col span="8">
                                    <FormItem label="供应商">
                                        <Input
                                            :disabled="submitStatus"
                                            v-model="formAttr.supplierName"
                                            placeholder="请输入供应商"
                                        ></Input>
                                    </FormItem>
                                </Col>
                                <Col span="8">
                                    <FormItem label="客户">
                                        <Input
                                            :disabled="submitStatus"
                                            v-model="formAttr.customerName"
                                            placeholder="请输入客户"
                                        ></Input>
                                    </FormItem>
                                </Col>
                                <Col span="24">
                                    <FormItem label="谈判事项">
                                        <Input
                                            :disabled="submitStatus"
                                            type="textarea"
                                            v-model="formAttr.negotiatingMatter"
                                            placeholder="请输入谈判事项"
                                            :autosize="{minRows: 2,maxRows: 5}"
                                        ></Input>
                                    </FormItem>
                                </Col>
                            </Row>
                        </Form>
                    <Card dis-hover :bordered="false">
                        <p slot="title">
                            <Icon type="md-list"></Icon>
                            谈判物料列表
                        </p>
                        <div slot="extra">
                            <ButtonGroup>
                                <Button @click="openImport" :disabled="submitStatus">引入物料</Button>
                            </ButtonGroup>
                        </div>
                        <Table border :columns="materialTableTitle" :data="formItems" class="material-table">
                            <template slot-scope="{ row, index }" slot="packageUnit">
                                <Select
                                    placeholder="请选择包装单位"
                                    remote
                                    :disabled="submitStatus"
                                    v-model="formAttr.items[index].packageUnit"
                                >
                                    <Option
                                        v-for="item in unitArr"
                                        :label="item.fieldValue"
                                        :value="item.id"
                                        :key="item.id"
                                    ></Option>
                                </Select>
                            </template>
                            <template slot-scope="{ row, index }" slot="taxRate">
                                <Input
                                    :disabled="submitStatus"
                                    type="number"
                                    v-model="formAttr.items[index].taxRate"
                                ></Input>
                            </template>
                            <template slot-scope="{ row, index  }" slot="purchasePrice">
                                <Input
                                    :disabled="submitStatus"
                                    type="number"
                                    v-model="formAttr.items[index].purchasePrice"
                                ></Input>
                            </template>
                            <template slot-scope="{ row, index  }" slot="marketPrice">
                                <Input
                                    :disabled="submitStatus"
                                    type="number"
                                    v-model="formAttr.items[index].marketPrice"
                                ></Input>
                            </template>
                            <template slot-scope="{ row, index  }" slot="currencyId">
                                <Select
                                    :disabled="submitStatus"
                                    remote
                                    v-model="formAttr.items[index].currencyId"
                                >
                                    <Option
                                        v-for="item in currencyArr"
                                        :label="item.fieldValue"
                                        :value="item.id"
                                        :key="item.id"
                                    ></Option>
                                </Select>
                            </template>
                            <template slot-scope="{ row, index  }" slot="inquiryTime">
                                <DatePicker
                                    :editable="false"
                                    :disabled="submitStatus"
                                    v-model="formAttr.items[index].inquiryTime"
                                    format="yyyy-MM-dd"
                                    type="date"
                                ></DatePicker>
                            </template>
                            <template slot-scope="{ row, index }" slot="action">
                                <Button
                                    :disabled="submitStatus"
                                    @click="delRow(index)"
                                    type="error"
                                    size="small"
                                >删除</Button
                                >
                            </template>
                        </Table>
                    </Card>
                </TabPane>
                <TabPane v-if="inquiryId" label="谈判记录">
                    <Row class="mb10" v-for="item in negotiationRecordList" :key="item.id">
                        <Col span="3">
                            <p>{{item.createTime}}</p>
                            <h3>{{item.purchaserName}}</h3>
                        </Col>
                        <Col span="18">
                            <p>{{item.recordMsg}}</p>
                        </Col>
                        <Col span="3" class-name="tr">
                            <Button v-has="btnRightList.inquiryRecordDel" @click="delRecord(item.id)" type="error" size="small">删除</Button>
                        </Col>
                    </Row>
                    <Row>
                        <Col span="21">
                            <Input
                                type="textarea"
                                v-model="recordMsg"
                                placeholder="请输入谈判记录"
                                :autosize="{minRows: 3,maxRows: 8}"
                            ></Input>
                        </Col>
                        <Col span="3" class-name="tr">
                            <Button v-has="btnRightList.inquiryRecordAdd" @click="addNegotiationRecord" type="primary" size="large">新增</Button>
                        </Col>
                    </Row>
                </TabPane>
            </Tabs>
            <div slot="footer">
                <Button @click="inquiryOrderCancel">取消</Button>
                <Button :disabled="submitStatus" @click="inquiryOrderModalOk">保存</Button>
                <Button v-if="inquiryId && !submitStatus && judgeBtnRight('inquiryOrderSubmit')" @click="submitInquiryOrder" type="primary">提交</Button>
            </div>
        </Modal>
        <!--        引入物料弹窗-->
        <Modal
            v-model="importShowFlag"
            width="700"
            title="引入物料"
            :mask-closable="maskClosable"
            :loading="importModelLoading"
            @on-ok="importModalOk"
            @on-cancel="importModalCancel"
        >
                <erp-table
                    @on-selection-change="importSelectionChange"
                    @on-page-no-change="importPageNoChange"
                    @on-page-size-change="importPageSizeChange"
                    :erpTableTitle="importTableTitle"
                    :erpTableData="importTableData"
                    :tableLoading="importTableLoading"
                    :current="importComAttr.pageNo"
                    :total="importTotal"
                >
                </erp-table>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import FirstApply from '@/components/firstMaterialApply/firstApply';
    import { getCompanyPurchaseOrganizationList } from '@/api/purchaseManage/purchaseGroup';
    import {
        addInquiryOrder,
        editInquiryOrder,
        delInquiryOrder,
        submitInquiryOrder,
        cancelInquiryOrder,
        editInquiryTaskInfo,
        getInquiryOrderDetail,
        getInquiryOrderList,
        getReceiveInquiryTaskList,
        completeInquiryTask,
        getNegotiationRecord,
        addNegotiationRecord,
        delNegotiationRecord
    } from '@/api/purchaseManage/inquiryTask';
    import { getInquiryInfo } from '@/api/saleManage/firstMaterialApply';
    import { getDate, resetObj } from '@/libs/tools';

    export default {
        name: 'inquiryHandle',
        mixins: [tableMixin],
        components: {
            ErpTable, FirstApply
        },
        data () {
            return {
                tableQueryAttr: {
                    specializedGroupName: '',
                    commodityBrand: '',
                    customerName: '',
                    status: ''
                }, // 表格查询条件
                materialFormAttr: {
                    customerName: '', // 客户名称
                    commodityName: '', // 物料名称
                    commodityBrand: '', // 物料品牌
                    commoditySpecializedGroupId: '', // 专业分组id
                    instrumentName: '', // 仪器名称
                    manufacturer: '', // 生产厂家
                    outboundMethodId: '', // 出库方式
                    deliveryMethodId: '', // 发货方式
                    commoditySpec: '', // 物料规格
                    commodityNumber: '', // 货号
                    commodityUnitName: '', // 物料单位
                    price: 0, // 销售价格
                    yearOrderNumber: 0, // 年订单量
                    yearTestNumber: 0, // 年测试数
                    metaSupplier: '', // 原供应商
                    purchaseOrganizationId: '', // 采购组织
                    writeDescription: '' // 录入摘要
                },
                formAttr: {
                    inquiryOrderCode: '',
                    supplierName: '',
                    customerName: '',
                    negotiatingMatter: '',
                    items: []
                },
                ruleValidate: {

                }, // modal 表单验证
                erpTableTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        fixed: 'left',
                        align: 'center'
                    },
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 140,
                        key: 'customerName'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 150,
                        key: 'commodityName'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 90,
                        key: 'commodityUnitName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroupName'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityBrand'
                    },
                    {
                        title: '仪器名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'instrumentName'
                    },
                    {
                        title: '出库方式',
                        align: 'center',
                        minWidth: 100,
                        key: 'outboundMethodName'
                    },
                    {
                        title: '发货方式',
                        align: 'center',
                        minWidth: 100,
                        key: 'deliveryMethodName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'statusDescription'
                    },
                    {
                        title: '创建人员',
                        align: 'center',
                        minWidth: 100,
                        key: 'createName'
                    },
                    {
                        title: '创建时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '市场指导价',
                        align: 'center',
                        minWidth: 100,
                        key: 'marketPriceCount'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 120,
                        align: 'center',
                        fixed: 'right',
                        render: (h, params) => {
                            if (params.row.status === 1) {
                                return h('div', [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'primary',
                                                size: 'small'
                                            },
                                            style: {
                                                marginRight: '5px'
                                            },
                                            on: {
                                                click: (e) => {
                                                    if (e && e.stopPropagation) {
                                                        // 非IE
                                                        e.stopPropagation();
                                                    } else {
                                                        // IE
                                                        window.event.cancelBubble = true;
                                                    }
                                                    this.currentId = params.row.id;
                                                    this.modalTitle = '编辑首营物料反馈信息';
                                                    this.editApply();
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList.inquiryTaskEdit
                                                }
                                            ]
                                        },
                                        '编辑'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'warning',
                                                size: 'small'
                                            },
                                            style: {
                                                marginRight: '5px'
                                            },
                                            on: {
                                                click: (e) => {
                                                    if (e && e.stopPropagation) {
                                                        // 非IE
                                                        e.stopPropagation();
                                                    } else {
                                                        // IE
                                                        window.event.cancelBubble = true;
                                                    }
                                                    this.currentId =
                                                        params.row.id;
                                                    this.completeInquiryTask();
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList.inquiryTaskComplete
                                                }
                                            ]
                                        },
                                        '完成'
                                    )
                                ]);
                            } else if (params.row.status === 2) {
                                return h('div', [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'success',
                                                size: 'small'
                                            },
                                            style: {
                                                marginRight: '5px'
                                            },
                                            on: {
                                                click: (e) => {
                                                    if (e && e.stopPropagation) {
                                                        // 非IE
                                                        e.stopPropagation();
                                                    } else {
                                                        // IE
                                                        window.event.cancelBubble = true;
                                                    }
                                                    this.onlyReady = true;
                                                    this.currentId = params.row.id;
                                                    this.modalTitle = '查看首营物料反馈信息';
                                                    this.editApply();
                                                }
                                            }
                                        },
                                        '查看'
                                    )
                                ]);
                            }
                        }
                    }
                ], // 表格标题
                receiveStatusArr: [
                    {
                        id: 1,
                        label: '询价中',
                        value: 1
                    },
                    {
                        id: 2,
                        label: '询价结束',
                        value: 2
                    }
                ], // 状态数组
                onlyReady: false,
                materialShowFlag: false, // 首营物料弹窗开关
                customerNameArr: [], // 物料专业分组下拉
                outboundMethodNameArr: [], // 出库方式下拉
                deliveryMethodNameArr: [], // 发货方式下拉
                purchaseOrganizationArr: [], // 采购组织下拉
                orderTableTitle: [
                    {
                        title: '询价单号',
                        align: 'center',
                        minWidth: 100,
                        key: 'inquiryOrderCode'
                    },
                    {
                        title: '客户',
                        align: 'center',
                        minWidth: 120,
                        key: 'customerName'
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '相关物料数',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            const marNum = `${params.row.inquiryCount}(${params.row.marketPriceCount})`;
                            return h(
                                'span',
                                {},
                                marNum
                            );
                        }
                    },
                    {
                        title: '谈判事项',
                        align: 'center',
                        minWidth: 140,
                        key: 'negotiatingMatter'
                    },
                    {
                        title: '创建人员',
                        align: 'center',
                        minWidth: 100,
                        key: 'createName'
                    },
                    {
                        title: '创建时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 120,
                        align: 'center',
                        fixed: 'right',
                        render: (h, params) => {
                            if (params.row.submitStatus === 0) {
                                return h('div', [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'primary',
                                                size: 'small'
                                            },
                                            style: {
                                                marginRight: '5px'
                                            },
                                            on: {
                                                click: () => {
                                                    this.tabIndex = 0;
                                                    this.submitStatus = false;
                                                    this.inquiryId = params.row.id;
                                                    this.modalTitle = '编辑询价单';
                                                    this.getInquiryOrderDetail(params.row);
                                                    this.modalShowFlag = true;
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList.inquiryOrderEdit
                                                }
                                            ]
                                        },
                                        '编辑'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'error',
                                                size: 'small'
                                            },
                                            style: {
                                                marginRight: '5px'
                                            },
                                            on: {
                                                click: () => {
                                                    this.inquiryId =
                                                        params.row.id;
                                                    this.delInquiryOrder();
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList.inquiryOrderDel
                                                }
                                            ]
                                        },
                                        '删除'
                                    )
                                ]);
                            } else if (params.row.submitStatus === 1) {
                                return h('div', [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'success',
                                                size: 'small'
                                            },
                                            style: {
                                                marginRight: '5px'
                                            },
                                            on: {
                                                click: () => {
                                                    this.tabIndex = 0;
                                                    this.submitStatus = true;
                                                    this.inquiryId = params.row.id;
                                                    this.modalTitle = '查看询价单';
                                                    this.getInquiryOrderDetail(params.row);
                                                    this.modalShowFlag = true;
                                                }
                                            }
                                        },
                                        '查看'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'default',
                                                size: 'small'
                                            },
                                            style: {
                                            },
                                            on: {
                                                click: () => {
                                                    this.inquiryId =
                                                        params.row.id;
                                                    this.cancelInquiryOrder();
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList.inquiryOrderCancel
                                                }
                                            ]
                                        },
                                        '撤回'
                                    )
                                ]);
                            }
                        }
                    }
                ], // 询价单栏目
                orderTableData: [],
                orderTableLoading: false,
                orderComAttr: {
                    pageNo: 1,
                    pageSize: 10
                },
                orderTotal: 0,
                inquiryId: null, // 询价单id
                materialTableTitle: [
                    {
                        title: '名称',
                        align: 'center',
                        minWidth: 140,
                        key: 'commodityName'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 90,
                        key: 'commoditySpec'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 90,
                        key: 'commodityUnitName'
                    },
                    {
                        title: '厂家',
                        align: 'center',
                        minWidth: 120,
                        key: 'manufacturer'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityBrand'
                    },
                    {
                        title: '仪器名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'instrumentName'
                    },
                    {
                        title: '包装单位',
                        align: 'center',
                        minWidth: 130,
                        slot: 'packageUnit'
                    },
                    {
                        title: '税率',
                        align: 'center',
                        minWidth: 110,
                        slot: 'taxRate'
                    },
                    {
                        title: '采购价格',
                        align: 'center',
                        minWidth: 120,
                        slot: 'purchasePrice'
                    },
                    {
                        title: '市场指导价',
                        align: 'center',
                        minWidth: 120,
                        slot: 'marketPrice'
                    },
                    {
                        title: '币种',
                        align: 'center',
                        minWidth: 120,
                        slot: 'currencyId'
                    },
                    {
                        title: '询价时间',
                        align: 'center',
                        minWidth: 140,
                        slot: 'inquiryTime'
                    },
                    {
                        title: '操作',
                        slot: 'action',
                        width: 120,
                        align: 'center'
                    }
                ],
                formItems: [],
                unitArr: [], // 包装单位
                currencyArr: [], // 币种
                submitStatus: false, // 询价单false未提交true已提交
                importShowFlag: false, // 引入物料弹窗开关
                importTableTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        fixed: 'left',
                        align: 'center'
                    },
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'customerName'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityName'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 80,
                        key: 'commodityUnitName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 90,
                        key: 'specializedGroupName'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityBrand'
                    },
                    {
                        title: '仪器名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'instrumentName'
                    },
                    {
                        title: '出库方式',
                        align: 'center',
                        minWidth: 90,
                        key: 'outboundMethodName'
                    },
                    {
                        title: '发货方式',
                        align: 'center',
                        minWidth: 90,
                        key: 'deliveryMethodName'
                    }
                ], // 引入物料栏目
                importTableData: [],
                importTableLoading: false,
                importComAttr: {
                    pageNo: 1,
                    pageSize: 10
                },
                importTotal: 0,
                importModelLoading: false,
                importSelectValue: [],
                tabIndex: 0,
                negotiationRecordList: [], // 谈判记录列表
                recordMsg: '' // 谈判记录
            };
        },
        created () {
            this.getAllSelectData();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr);
                    const res = await getReceiveInquiryTaskList(params);
                    getListMixin(res);
                    this.orderTableData = [];
                    this.orderTotal = 0;
                });
            },
            // 确认编辑首营物料反馈信息
            materialModalOk () {
                this.$refs.firstApply.getForm().validate(async valid => {
                    if (!valid) {
                        return this.changeLoading('materialShowFlag');
                    }
                    if (this.onlyReady) {
                        return this.materialModalCancel();
                    }
                    let res;
                    const params = Object.assign({}, this.materialFormAttr, {
                        id: this.currentId
                    });
                    res = await editInquiryTaskInfo(params);
                    if (res.status === this.code) {
                        this.$Message.success(res.msg);
                        this.materialModalCancel();
                        this.tableComAttr.pageNo = 1;
                        this.getTableList();
                    } else {
                        this.changeLoading('materialShowFlag');
                    }
                });
            },
            // 关闭首营物料反馈信息
            materialModalCancel () {
                this.materialShowFlag = false;
                this.currentId = null;
                this.onlyReady = false;
                resetObj(this.materialFormAttr);
                this.$refs.firstApply.getForm().resetFields();
            },
            // 打开物料首营反馈信息弹窗
            editApply () {
                this.getInquiryTaskFirstInfo();
                this.materialShowFlag = true;
            },
            getAllSelectData () {
                this.getFieldValuesData(
                    'commodity_specialized_group',
                    'customerNameArr'
                );
                this.getFieldValuesData('outbound_method', 'outboundMethodNameArr');
                this.getFieldValuesData('delivery_method', 'deliveryMethodNameArr');
                this.getFieldValuesData('package_unit', 'unitArr');
                this.getFieldValuesData('currency', 'currencyArr');
                this.getCompanyPurchaseOrganizationList();
            },
            // 获取当前公司的采购组织
            async getCompanyPurchaseOrganizationList () {
                const res = await getCompanyPurchaseOrganizationList();
                if (res.status === this.code) {
                    this.purchaseOrganizationArr = res.content;
                }
            },
            // 获取询价任务反馈信息
            async getInquiryTaskFirstInfo () {
                const res = await getInquiryInfo(this.currentId);
                if (res.status === this.code) {
                    const formAttr = res.content;
                    for (let key in formAttr) {
                        this.materialFormAttr[key] = formAttr[key];
                    }
                }
            },
            // 获取询价单列表
            async getInquiryOrderList () {
                this.orderTableLoading = true;
                const params = Object.assign(
                    {},
                    this.orderComAttr, {
                        inquiryId: this.currentId
                    }
                );
                const res = await getInquiryOrderList(params);
                this.orderTableLoading = false;
                if (res.status === this.code) {
                    this.orderTableData = res.content.list;
                    this.orderTotal = res.content.total;
                }
            },
            // 改变询价单每页数量
            orderPageSizeChange (value) {
                this.orderComAttr.pageNo = 1;
                this.orderComAttr.pageSize = value;
                this.getInquiryOrderList();
            },
            // 改变询价单页码
            orderPageNoChange (value) {
                this.orderComAttr.pageNo = value;
                this.getInquiryOrderList();
            },
            // 选中当前询价任务行
            currentChange (row) {
                this.currentId = row.id;
                this.getInquiryOrderList();
            },
            // 新增询价单
            add () {
                this.submitStatus = false;
                this.inquiryId = null;
                this.formatMaterialList(this.tableSelectList);
                this.addItem('新增询价单');
            },
            inquiryOrderCancel () {
                this.formItems = [];
                this.modalCancel();
                this.tableSelectValue = [];
                this.tableSelectList = [];
                this.getTableList();
                this.submitStatus = false;
            },
            // 新增编辑保存询价单信息
            async inquiryOrderModalOk () {
                if (this.tabIndex) {
                    return this.changeLoading();
                }
                let res = null;
                let params;
                const items = this.formAttr.items.map(item => {
                    if (item.inquiryTime instanceof Date) {
                        const inquiryTime = getDate(item.inquiryTime);
                        item = Object.assign({}, item, {
                            inquiryTime
                        });
                    }
                    return item;
                });
                if (this.inquiryId) {
                    params = Object.assign({}, this.formAttr, {
                        id: this.inquiryId,
                        items
                    });

                    res = await editInquiryOrder(params);
                } else {
                    params = Object.assign({}, this.formAttr, {
                        items
                    });
                    res = await addInquiryOrder(params);
                }
                this.changeLoading();
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    if (res.content) {
                        this.formAttr.inquiryOrderCode = res.content.inquiryOrderCode;
                        this.inquiryId = res.content.id;
                    }
                }
            },
            // 格式化物料列表
            formatMaterialList (value) {
                const ids = this.formItems.map(item => {
                    return item.inquiryId;
                });
                value.forEach(item => {
                    if (!ids.includes(item.id)) {
                        this.formAttr.items.push({
                            inquiryId: item.id,
                            packageUnit: item.packageUnit || '',
                            taxRate: item.taxRate || '',
                            purchasePrice: item.purchasePrice || '',
                            marketPrice: item.marketPrice || '',
                            inquiryTime: item.inquiryTime ? getDate(item.inquiryTime) : '',
                            currencyId: item.currencyId || ''
                        });
                        this.formItems.push({
                            inquiryId: item.id,
                            commodityName: item.commodityName,
                            commoditySpec: item.commoditySpec,
                            commodityUnitName: item.commodityUnitName,
                            manufacturer: item.manufacturer,
                            commodityBrand: item.commodityBrand,
                            instrumentName: item.instrumentName,
                            packageUnit: item.packageUnit || '',
                            taxRate: item.taxRate || '',
                            purchasePrice: item.purchasePrice || '',
                            marketPrice: item.marketPrice || '',
                            inquiryTime: item.inquiryTime ? getDate(item.inquiryTime) : '',
                            currencyId: item.currencyId || ''
                        });
                    }
                });
            },
            // 获取询价单明细
            async getInquiryOrderDetail (row) {
                this.formAttr = Object.assign({}, this.formAttr, {
                    customerName: row.customerName,
                    supplierName: row.supplierName,
                    negotiatingMatter: row.negotiatingMatter
                });
                const params = Object.assign(
                    {}, {
                        inquiryOrderId: this.inquiryId
                    }
                );
                const res = await getInquiryOrderDetail(params);
                if (res.status === this.code) {
                    this.tableSelectList = res.content.map(item => {
                        return Object.assign({}, item, {
                            id: item.inquiryId
                        });
                    });
                    this.formatMaterialList(this.tableSelectList);
                }
            },
            // 删除物料
            delRow (index) {
                this.$Modal.confirm({
                    title: '是否确认删除',
                    onOk: async () => {
                        this.formItems.splice(index, 1);
                        this.formAttr.items.splice(index, 1);
                    }
                });
            },
            // 删除询价单
            delInquiryOrder () {
                this.$Modal.confirm({
                    title: '是否确认删除该询价单',
                    onOk: async () => {
                        const params = {
                            id: this.inquiryId
                        };
                        const res = await delInquiryOrder(params);
                        if (res.status === this.code) {
                            // this.orderComAttr.pageNo = 1;
                            this.getTableList();
                            this.$Message.success(res.msg);
                        }
                    }
                });
            },
            // 撤回询价单
            cancelInquiryOrder () {
                this.$Modal.confirm({
                    title: '是否确认撤回该询价单',
                    onOk: async () => {
                        const params = {
                            id: this.inquiryId
                        };
                        const res = await cancelInquiryOrder(params);
                        if (res.status === this.code) {
                            // this.orderComAttr.pageNo = 1;
                            this.getTableList();
                            this.$Message.success(res.msg);
                        }
                    }
                });
            },
            // 提交询价单
            async submitInquiryOrder () {
                const params = {
                    id: this.inquiryId
                };
                const res = await submitInquiryOrder(params);
                if (res.status === this.code) {
                    this.inquiryOrderCancel();
                    this.orderComAttr.pageNo = 1;
                    this.getInquiryOrderList();
                    this.$Message.success(res.msg);
                }
            },
            // 提交询价单
            async completeInquiryTask () {
                const params = {
                    id: this.currentId
                };
                const res = await completeInquiryTask(params);
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.getTableList();
                }
            },
            // 获取引入物料列表
            async getImportMaterialList () {
                this.importTableLoading = true;
                const params = Object.assign(
                    {},
                    this.importComAttr
                );
                const res = await getReceiveInquiryTaskList(params);
                this.importTableLoading = false;
                if (res.status === this.code) {
                    this.importTableData = res.content.list;
                    this.importTotal = res.content.total;
                }
            },
            // 改变引入物料每页数量
            importPageSizeChange (value) {
                this.importComAttr.pageNo = 1;
                this.importComAttr.pageSize = value;
                this.getImportMaterialList();
            },
            // 改变引入物料页码
            importPageNoChange (value) {
                this.importComAttr.pageNo = value;
                this.getImportMaterialList();
            },
            // 打开引入物料弹窗
            openImport () {
                this.getImportMaterialList();
                this.importShowFlag = true;
            },
            importSelectionChange (value) {
                this.importSelectValue = value;
            },
            // 确认引入物料
            importModalOk () {
                this.formatMaterialList(this.importSelectValue);
                this.importModalCancel();
            },
            importModalCancel () {
                this.importShowFlag = false;
                this.importSelectionChange = [];
            },
            // tab点击
            tabsBind (name) {
                switch (name) {
                    case 0:
                        break;
                    case 1:
                        this.getNegotiationRecord();
                        break;
                }
            },
            // 获取谈判记录列表
            async getNegotiationRecord () {
                const params = {
                    inquiryOrderId: this.inquiryId
                };
                const res = await getNegotiationRecord(params);
                if (res.status === this.code) {
                    this.negotiationRecordList = res.content.map(item => {
                        return Object.assign({}, item, {
                            createTime: getDate(item.createTime)
                        });
                    });
                }
            },
            // 新增谈判记录
            async addNegotiationRecord () {
                if (!this.recordMsg) {
                    this.$Message.error('请先填写谈判记录');
                    return;
                }
                const params = {
                    inquiryOrderId: this.inquiryId,
                    recordMsg: this.recordMsg
                };
                const res = await addNegotiationRecord(params);
                if (res.status === this.code) {
                    this.recordMsg = '';
                    this.$Message.success(res.msg);
                    this.getNegotiationRecord();
                }
            },
            // 删除谈判记录
            delRecord (id) {
                this.$Modal.confirm({
                    title: '是否确人删除该条谈判记录',
                    onOk: async () => {
                        const params = {
                            id
                        };
                        const res = await delNegotiationRecord(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getNegotiationRecord();
                        }
                    }
                });
            }
        }
    };
</script>

<style scoped lang="less">
    .tr{
        text-align: right;
    }
    .ivu-tabs{
        overflow-y: auto;
        height: 100%;
    }
</style>
