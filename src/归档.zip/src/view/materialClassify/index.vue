<template>
    <div class="material-classify">
        <!-- 主数据管理-物料分类维护 -->
        <Row :gutter="20">
            <Col span="8">
                <Card dis-hover :border="false">
                    <p slot="title"><Icon type="md-list"></Icon>物料分类信息</p>
                    <div class="wrapper-tree">
                        <Tree
                            :data="treeData"
                            :render="orgRenderContent"
                        ></Tree>
                    </div>
                </Card>
            </Col>
            <Col span="16">
                <Card dis-hover :border="false">
                    <p slot="title"><Icon type="md-list"></Icon>分类信息编辑</p>
                    <Form
                        :model="formAttr"
                        :rules="ruleValidate"
                        ref="formValidate"
                        :label-width="120"
                        v-if="formAttr.parentName"
                    >
                        <FormItem label="名称">
                            <Input
                                placeholder="名称"
                                v-model="formAttr.commodityClassifyName"
                            ></Input>
                        </FormItem>
                        <FormItem label="编码">
                            <Input
                                placeholder="编码"
                                v-model="formAttr.commodityClassifyCode"
                            ></Input>
                        </FormItem>
                        <FormItem label="状态">
                            <RadioGroup v-model="formAttr.status">
                                <Radio :label="3">有效</Radio>
                                <Radio :label="4">无效</Radio>
                            </RadioGroup>
                        </FormItem>
                        <FormItem label="上级">
                            <Input
                                placeholder="上级"
                                disabled
                                v-model="formAttr.parentName"
                            ></Input>
                        </FormItem>
                        <template v-if="currentId">
                            <FormItem label="创建时间">
                                <Input
                                    placeholder="创建时间"
                                    v-model="formAttr.createTime"
                                    disabled
                                ></Input>
                            </FormItem>
                            <FormItem label="创建人">
                                <Input
                                    placeholder="创建人"
                                    v-model="formAttr.createName"
                                    disabled
                                ></Input>
                            </FormItem>
                            <FormItem label="最后修改时间">
                                <Input
                                    placeholder="最后修改时间"
                                    v-model="formAttr.updateTime"
                                    disabled
                                ></Input>
                            </FormItem>
                            <FormItem label="最后修改人">
                                <Input
                                    placeholder="最后修改人"
                                    v-model="formAttr.updateName"
                                    disabled
                                ></Input>
                            </FormItem>
                        </template>
                        <FormItem class="tr">
                            <Button type="primary" @click="save">保存</Button>
                        </FormItem>
                    </Form>
                </Card>
            </Col>
        </Row>
    </div>
</template>

<script>
    import tableMixin from '@/mixins/tableMixin';
    import {
        getMaterialTree,
        addMaterial,
        updateMaterial
    } from '@/api/materialManage';
    import { getDate, resetObj } from '@/libs/tools';

    export default {
        mixins: [tableMixin],
        data () {
            return {
                treeData: [],
                buttonProps: {
                    type: 'default',
                    size: 'small'
                },
                currentId: null,
                formAttr: {
                    commodityClassifyCode: '',
                    commodityClassifyName: '',
                    status: 3,
                    parentId: '',
                    createTime: '',
                    createName: '',
                    updateTime: '',
                    updateName: '',
                    parentName: ''
                },
                parentId: null,
                ruleValidate: {}
            };
        },
        methods: {
            // 获取分类信息
            async getTableList () {
                const res = await getMaterialTree();
                if (res.status === this.code) {
                    this.formatTreeData({ children: res.content });
                }
            },
            treeRender () {},
            formatTreeData (data) {
                this.treeData = [];
                const root = {
                    title: '物料分类',
                    expand: true,
                    parentId: 1,
                    children: this.recur(data)
                };
                this.treeData.push(root);
                // console.log(this.treeData);
                if (this.treeData[0].children.length) {
                    this.treeData[0].children.forEach(item => {
                        item.parentName = this.treeData[0].title;
                    });
                }
            },
            // 递归处理数据
            recur (arg) {
                // console.log(arg);
                let data = [];
                if (arg.children.length) {
                    arg.children.forEach(item => {
                        data.push(
                            Object.assign(
                                {},
                                {
                                    title: item.meta.title,
                                    id: item.id,
                                    commodityClassifyCode:
                                        item.commodityClassifyCode,
                                    commodityClassifyName:
                                        item.commodityClassifyName,
                                    status: item.status,
                                    parentId: item.parentId,
                                    createTime: item.createTime,
                                    createName: item.createName,
                                    updateTime: item.updateTime,
                                    updateName: item.updateName,
                                    parentName: item.parentName,
                                    expand: true,
                                    children: this.recur(item)
                                }
                            )
                        );
                    });
                }
                return data;
            },
            // 格式化数据
            orgRenderContent (h, { data }) {
                return h(
                    'span',
                    {
                        style: {
                            display: 'inline-block',
                            width: '100%'
                        }
                    },
                    [
                        h(
                            'span',
                            {
                                class: {
                                    'tree-node-hover': true
                                },
                                on: {
                                    click: () => {
                                        this.handleEdit(data);
                                    }
                                },
                                directives: [
                                    {
                                        name: 'has',
                                        value: this.btnRightList
                                            .materialClassifyUpdate
                                    }
                                ]
                            },
                            [
                                h('Icon', {
                                    props: {
                                        type: 'ios-paper-outline'
                                    },
                                    style: {
                                        marginRight: '8px'
                                    }
                                }),
                                h('span', data.title)
                            ]
                        ),
                        h(
                            'span',
                            {
                                style: {
                                    display: 'inline-block',
                                    float: 'right',
                                    marginRight: '32px'
                                }
                            },
                            [
                                h('Button', {
                                    props: Object.assign({}, this.buttonProps, {
                                        icon: 'ios-add'
                                    }),
                                    style: {
                                        marginRight: '8px'
                                    },
                                    on: {
                                        click: () => {
                                            this.handleAdd(data);
                                        }
                                    },
                                    directives: [
                                        {
                                            name: 'has',
                                            value: this.btnRightList
                                                .materialClassifyAdd
                                        }
                                    ]
                                })
                            // h('Button', {
                            //     props: Object.assign({}, this.buttonProps, {
                            //         icon: 'ios-remove'
                            //     }),
                            //     on: {
                            //         click: () => {
                            //             this.del(data);
                            //         }
                            //     },
                            //     directives: [
                            //         {
                            //             name: 'has',
                            //             value: this.btnRightList.departmentDel
                            //         }
                            //     ]
                            // })
                            ]
                        )
                    ]
                );
            },
            // 节点新增
            handleAdd (e) {
                this.currentId = null;
                this.parentId = e.id || e.parentId;
                resetObj(this.formAttr);
                this.formAttr.parentName = e.title || 'root';
            },
            // 编辑查看
            handleEdit (e) {
                this.currentId = e.id;
                this.parentId = e.parentId;
                this.formAttr = Object.assign({}, e, {
                    createTime: getDate(e.createTime, 'long'),
                    updateTime: getDate(e.updateTime, 'long')
                });
                this.formAttr.parentName = e.parentName; // 添加子节点或者根节点
            },
            async save () {
                let params = null;
                let res = null;
                if (this.currentId) {
                    params = Object.assign({}, this.formAttr, {
                        parentId: this.parentId
                    });
                    res = await updateMaterial(params);
                // console.log(res);
                } else {
                    params = Object.assign({}, this.formAttr, {
                        parentId: this.parentId
                    });
                    res = await addMaterial(params);
                }
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                } else {
                    this.changeLoading();
                }
            }
        // 删除
        // del(e) {

        // }
        }
    };
</script>

<style scoped lang="less">
.tr {
    text-align: right;
}

/deep/ .tree-node-hover {
    cursor: pointer;
}
</style>
