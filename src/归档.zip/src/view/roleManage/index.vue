<template>
    <div class="content-role" ref="erp">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.roleName"
                        @on-search="search"
                        search
                        placeholder="角色名称"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.roleCode"
                        @on-search="search"
                        search
                        placeholder="角色编号"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <!--                <Col span="5" class="maxWidth">-->
                <!--                    <Select-->
                <!--                        @on-change="search"-->
                <!--                        placeholder="全部状态"-->
                <!--                        remote v-model="tableQueryAttr.status">-->
                <!--                        <Option v-for="item in statusList" :label="item.label"-->
                <!--                                :value="item.name"-->
                <!--                                :key="item.value"></Option>-->
                <!--                    </Select>-->
                <!--                </Col>-->
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                角色管理列表
                <span></span>
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button
                        v-has="btnRightList.roleAdd"
                        @click="add"
                        icon="md-add"
                        >新增
                    </Button>
                    <Button
                        v-has="btnRightList.roleDel"
                        @click="del"
                        icon="md-trash"
                        >删除
                    </Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-selection-change="selectionChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
            >
            </erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="850"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel(afterClosePopup)"
        >
            <div class="erp-modal-content">
                <Row>
                    <Col span="10">
                        <Form
                            :model="formAttr"
                            :rules="ruleValidate"
                            ref="formValidate"
                            :label-width="120"
                        >
                            <FormItem label="角色名称" prop="roleName">
                                <Input
                                    v-model="formAttr.roleName"
                                    placeholder="请输入角色名称"
                                ></Input>
                            </FormItem>
                            <FormItem label="角色编号" prop="roleCode">
                                <Input
                                    v-model="formAttr.roleCode"
                                    placeholder="请输入角色编号"
                                ></Input>
                            </FormItem>
                            <FormItem label="状态" prop="status">
                                <Select
                                    placeholder="全部状态"
                                    remote
                                    v-model="formAttr.status"
                                >
                                    <Option
                                        v-for="item in statusList"
                                        :label="item.label"
                                        :value="item.value"
                                        :key="item.value"
                                    ></Option>
                                </Select>
                            </FormItem>
                        </Form>
                    </Col>
                    <Col span="13" offset="1">
                        <Card dis-hover>
                            <p slot="title">
                                <Icon type="md-funnel"></Icon>
                                权限树
                            </p>
                            <Tree
                                @on-check-change="selectTree"
                                multiple
                                :data="resourceList"
                                show-checkbox
                            ></Tree>
                        </Card>
                    </Col>
                </Row>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        addRole,
        deleteRole,
        editRole,
        getRoleList,
        getResourceIds,
        rolesConnectRosource
    } from '@/api/setting/role';
    import { getResourceList } from '@/api/setting/resource';
    import { getDate, deleteArrElement } from '@/libs/tools';

    export default {
        name: 'roleManage',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    roleCode: '',
                    roleName: ''
                }, // 表格查询条件
                formAttr: {
                    roleCode: '',
                    roleName: '',
                    status: ''
                }, // modal 值对象
                ruleValidate: {
                    roleName: [
                        {
                            required: true,
                            message: '角色名称不能为空',
                            trigger: 'blur'
                        }
                    ],
                    roleCode: [
                        {
                            required: true,
                            message: '角色编号不能为空',
                            trigger: 'blur'
                        }
                    ],
                    status: [
                        {
                            required: true,
                            type: 'number',
                            message: '状态不能为空',
                            trigger: 'change'
                        }
                    ]
                }, // modal 表单验证
                erpTableTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '角色名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'roleName'
                    },
                    {
                        title: '角色编号',
                        align: 'center',
                        minWidth: 120,
                        key: 'roleCode'
                    },
                    {
                        title: '创建人',
                        align: 'center',
                        minWidth: 100,
                        key: 'createUserRealName'
                    },
                    {
                        title: '新建时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '更新人',
                        align: 'center',
                        minWidth: 100,
                        key: 'updateUserRealName'
                    },
                    {
                        title: '更新时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.updateTime, 'long')
                            );
                        }
                    },
                    {
                        title: '角色状态',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            const validFlag = params.row.status === 1;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: validFlag ? 'success' : 'default'
                                    }
                                },
                                validFlag ? '有效' : '无效'
                            );
                        }
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 100,
                        fixed: 'right',
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        style: {
                                            marginRight: '5px'
                                        },
                                        on: {
                                            click: () => {
                                                this.editTableData(
                                                    params,
                                                    '编辑角色',
                                                    this.getTreeIdsByRole
                                                );
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.roleEdit
                                            }
                                        ]
                                    },
                                    '编辑'
                                )
                            ]);
                        }
                    }
                ], // 表格标题
                resourceData: [], // 后台返回的权限数据
                resourceList: [], // 权限树
                selectTreeIds: [] // 权限树选中的节点Id
            };
        },
        created () {
            this.getTreeList();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getRoleList(params);
                    if (res.status === this.code) getListMixin(res);
                });
            },

            // 新增编辑确认按钮
            modalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res;
                    const params = this.currentId
                        ? Object.assign({}, this.formAttr, {
                            id: this.currentId
                        })
                        : Object.assign({}, this.formAttr);
                    if (this.currentId) {
                        res = await editRole(params);
                        if (
                            res.status === this.code &&
                            this.judgeBtnRight('roleGrant')
                        ) {
                            this.roleConnectRosource();
                        }
                    } else {
                        res = await addRole(params);
                        if (res.status === this.code) {
                            this.currentId = res.content;
                            if (this.judgeBtnRight('roleGrant')) {
                                this.roleConnectRosource();
                            }
                        }
                    } // eslint-disable-next-line
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    } else {
                        this.changeLoading();
                    }
                });
            },
            add () {
                this.addItem('新增角色');
                this.formatResources(this.resourceData);
            },
            del () {
                const flag = this.delCheck();
                if (flag) {
                    this.$Modal.confirm({
                        title: '确认删除所选项吗？',
                        onOk: async () => {
                            const res = await deleteRole(this.tableSelectValue);
                            if (res.status === this.code) {
                                this.$Message.success(res.msg);
                                this.tableSelectValue = [];
                                this.getTableList();
                            }
                        }
                    });
                }
            },
            // 获取权限列表数据
            async getTreeList () {
                const res = await getResourceList();
                if (res.status === this.code) {
                    this.resourceData = res.content;
                }
            },
            // 根据初始权限数据动态格式化
            formatResources (tree) {
                this.resourceList = [
                    {
                        children: this.backendResourcesToTrees(tree),
                        expand: true,
                        icon: 'md-home',
                        id: 1,
                        nodeKey: 0,
                        parentId: 0,
                        title: '塞力斯ERP管理系统',
                        checked: false
                    }
                ];
            },
            /**
             * 格式化树形组件所需data
             * @param list
             */
            backendResourcesToTrees (list) {
                let data = [];
                if (list && Array.isArray(list)) {
                    list.forEach(item => {
                        // 将后端数据转换成tree
                        let treeItem = this.backendResourceToTree(item);
                        // 如果后端数据有下级，则递归处理下级
                        if (item.children && item.children.length !== 0) {
                            treeItem.children = this.backendResourcesToTrees(
                                item.children
                            );
                        }
                        data.push(treeItem);
                    });
                }
                return data;
            },
            backendResourceToTree (item) {
                const hasChild = item.children && item.children.length !== 0;
                let obj = {
                    title: item.meta.title,
                    expand: false,
                    parentId: item.parentId,
                    id: item.id,
                    level: item.level
                };
                if (this.selectTreeIds.includes(item.id)) {
                    if (item.level === 0) {
                        obj.checked = true;
                    } else if (!hasChild) {
                        obj.checked = true;
                    }
                } else {
                    obj.checked = false;
                }
                return obj;
            },
            // 根据角色id查询权限资源
            async getTreeIdsByRole (row) {
                if (row.id) {
                    const params = Object.assign({}, { roleId: row.id });
                    const res = await getResourceIds(params);
                    if (res.status === this.code) {
                        this.selectTreeIds = res.content;
                        this.formatResources(this.resourceData);
                    }
                }
            },
            // 树形选择
            selectTree (arr) {
                let selectTreeIds = [];
                arr.forEach(item => {
                    selectTreeIds.push(item.id);
                    selectTreeIds = this.arrJoinArr(
                        this.getParentId(this.resourceList, [], item.id),
                        selectTreeIds
                    );
                });
                this.selectTreeIds = selectTreeIds;
            },
            // 根据选择数组获取直到根节点的parentIds
            getParentId (array, childs, ids) {
                for (let i = 0; i < array.length; i++) {
                    let item = array[i];
                    if (Number(item.id) === Number(ids)) {
                        childs.push(item.id);
                        return childs;
                    }
                    if (item.children && item.children.length > 0) {
                        childs.push(item.id);
                        let rs = this.getParentId(item.children, childs, ids);
                        if (rs) {
                            return rs;
                        } else {
                            deleteArrElement(childs, item.id);
                        }
                    }
                }
                return false;
            },
            // 把一个数组arr1加到另外一个数组arr2中去
            arrJoinArr (arr1, arr2) {
                arr1.forEach(item => {
                    if (!arr2.includes(item)) arr2.push(item);
                });
                return arr2;
            },
            // 对角色关联权限
            async roleConnectRosource () {
                if (this.selectTreeIds.length > 0) {
                    const params = Object.assign(
                        {},
                        {
                            id: this.currentId,
                            resourceIds: this.selectTreeIds
                        }
                    );
                    await rolesConnectRosource(params);
                    this.refreshToken();
                }
            },
            // 关闭弹窗后清空tree
            afterClosePopup () {
                this.selectTreeIds = [];
                this.resourceList = [];
            }
        }
    };
</script>

<style scoped lang="less">
.erp-modal-content {
    padding: 10px 20px 10px 0;
}
</style>
