<template>
    <div class="print">打印测试</div>
</template>

<script>
    export default {
        name: 'index'
    };
</script>

<style scoped lang="less">
    .print {
        font-family: 'SimHei'!important;
        font-size: 18px;
        color: #000;
        /*line-height: normal;*/
        /*-webkit-font-smoothing: none;*/
    }
</style>
