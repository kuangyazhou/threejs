<template>
    <div class="deliveryNoticeTrial">
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="resetCst" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        @on-search="search"
                        search
                        v-model="tableQueryAttr.customerName"
                        placeholder="客户名称"

                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        @on-search="search"
                        search
                        v-model="tableQueryAttr.commodityName"
                        placeholder="物料名称"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <DatePicker v-model="tableQueryAttr.orderTime"
                                @on-change="DatePickerSearch"
                                type="daterange" placeholder="订单起止日期"
                                style="width: 100%"></DatePicker>
                </Col>
                <Col span="5" class="maxWidth center">
                    只看待发货
                    <i-switch v-model="tableQueryAttr.hasUnShipmentOrder" @on-change="handleToggle"/>
                </Col>
            </Row>
        </Card>
        <Card :border="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                待发货销售订单
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button
                        v-has="btnRightList.matchAuto"
                        icon="md-locate"
                        @click="handleMatch"
                    >一键匹配
                    </Button>
                    <Button
                        v-has="btnRightList.matchRemove"
                        icon="md-refresh"
                        @click="handleReset"
                    >重置试算
                    </Button>
                    <Button
                        v-has="btnRightList.matchGenerate"
                        icon="md-plane"
                        @click="handlemakeNotice"
                    >生成发货通知
                    </Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-selection-change="selectionChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :hasPage="false"
                :current="tableComAttr.pageNo"
            ></erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            fullscreen
            @on-cancel="modalCancelCst"
        >
            <div>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="ios-search"></Icon>
                        查询条件
                    </p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button @click="searchModal" icon="md-search">搜索</Button>
                            <Button @click="resetModal" icon="md-refresh">重置</Button>
                        </ButtonGroup>
                    </div>
                    <Row :gutter="16">
                        <Col span="5" class="maxWidth">
                            <Select
                                @on-change="searchModal" filterable ref="filter"
                                v-model="modalTableQueryAttr.customerEnableCode"
                                placeholder="客户">
                                <Option v-for="(item, index) in customerList" :label="item.label" :value="item.value"
                                        :key="index"></Option>
                            </Select>
                        </Col>
                        <Col span="5" class="maxWidth">
                            <Select
                                @on-change="searchModal" filterable ref="filter"
                                v-model="modalTableQueryAttr.supplierEnableCode"
                                placeholder="供应商"
                                remote>
                                <Option v-for="(item, index) in supplierList" :label="item.label" :value="item.value"
                                        :key="index"></Option>
                            </Select>
                        </Col>
                        <Col span="5" class="maxWidth">
                            <DatePicker @on-change="modalDatePickerSearch" @on-ok="searchModal"
                                        v-model="modalTableQueryAttr.effectiveDateStart"
                                        type="datetime" placeholder="有效日期" style="width: 100%"></DatePicker>
                        </Col>
                    </Row>
                </Card>
                <Card dis-hover :bordered="false" class="clearfix">
                    <Table
                        height="400"
                        border
                        ref="top"
                        :loading="inventoryLoading"
                        :columns="inventoryTitle"
                        :data="inventoryList"></Table>
                </Card>
                <Card dis-hover :bordered="false">
                    <Table
                        height="400"
                        border
                        ref="bottom"
                        :loading="deliveryLoading"
                        :columns="deliveryTitle"
                        :data="deliveryList"></Table>
                </Card>
            </div>
            <div slot="footer">
                <Button @click="modalCancelCst">取消</Button>
            </div>
        </Modal>

        <Modal
            v-model="chooseModalShowFlag"
            width="450"
            title="提示"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="chooseModalOk"
            @on-cancel="chooseModalCancel"
        >
            <Form
                :model="formAttr"
                :rules="ruleValidate"
                ref="formValidate"
                :label-width="120">
                <FormItem
                    label="发货数量"
                    prop="quantity"
                >
                    <InputNumber
                        style="width: 90%"
                        v-model="formAttr.quantity"
                        placeholder="请输入发货数量"
                    ></InputNumber>
                </FormItem>
            </Form>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        addDeliveryTrialList,
        delDeliveryTrialList,
        getDeliveryNoticeTrialList,
        getDeliveryTrialList,
        getInventoryTrialList,
        matchAuto,
        matchGenerate,
        matchRemove
    } from '@/api/saleManage/deliveryNoticeTrial';
    import { getDate, resetObj } from '@/libs/tools';

    export default {
        name: 'deliveryNoticeTrial',
        components: { ErpTable },
        mixins: [tableMixin],
        data () {
            const validateQuantity = (rule, value, callback) => {
                if (value === '') {
                    callback(new Error('发货数量不能为空'));
                } else if (value === 0) {
                    callback(new Error('发货数量不能为0'));
                } else {
                    callback();
                }
            };
            return {
                tableQueryAttr: {
                    hasUnShipmentOrder: true,
                    orderDateStart: '',
                    orderDateEnd: '',
                    commodityName: '',
                    customerName: '',
                    orderTime: [`${getDate(new Date().getTime()).substr(0, 7)}-01`, getDate(new Date().getTime())]
                },
                erpTableTitle: [
                    {
                        title: '销售订单号',
                        align: 'center',
                        minWidth: 200,
                        key: 'orderNo'
                    },
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 200,
                        key: 'customerName'
                    },
                    {
                        title: '物料编码',
                        align: 'center',
                        minWidth: 200,
                        key: 'commodityCode'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 200,
                        key: 'commodityName'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '订单数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'quantity'
                    },
                    {
                        title: '红字数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'redQuantity'
                    },
                    {
                        title: '待发数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'leftQuantity'
                    },
                    {
                        title: '试算数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'tryQuantity'
                    },
                    {
                        title: '确认效期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.effectiveDate)
                            );
                        }
                    },
                    {
                        title: '匹配效期',
                        align: 'center',
                        minWidth: 110,
                        key: 'matchEffectiveDate'
                    },
                    {
                        title: '匹配批号',
                        align: 'center',
                        minWidth: 140,
                        key: 'matchBatchNo'
                    },
                    {
                        title: '要求到货日期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.arriveDate)
                            );
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        width: 110,
                        fixed: 'right',
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            this.currentOrder = params.row;
                                            this.getInventoryList(true);
                                            this.getDeliveryList();
                                            this.addItem('新增发货通知试算');
                                        }
                                    },
                                    style: {
                                        marginRight: '8px'
                                    },
                                    directives: [
                                        {
                                            name: 'has',
                                            value: this.btnRightList.noticeTrySave || this.btnRightList.noticeTryRemove
                                        }
                                    ]
                                },
                                '试算'
                            );
                        }
                    }
                ],
                inventoryTitle: [
                    {
                        title: '匹配客户',
                        align: 'center',
                        minWidth: 140,
                        key: 'customerName'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 210,
                        key: 'commodityName'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '货号',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityNumber'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 100,
                        key: 'unitName'
                    },
                    {
                        title: '库存数量',
                        align: 'center',
                        minWidth: 140,
                        key: 'leftQuantity'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 140,
                        key: 'batchNo'
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 170,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.effectiveDate)
                            );
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 140,
                        key: 'supplierName'
                    },
                    {
                        title: '要求到货',
                        align: 'center',
                        minWidth: 170,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.arriveDate)
                            );
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        width: 140,
                        fixed: 'right',
                        render: (h, params) => {
                            return h('Button', {
                                props: {
                                    type: 'success',
                                    size: 'small'
                                },
                                on: {
                                    click: () => {
                                        this.currentInventoryId = params.row.id;
                                        this.chooseModalShowFlag = true;
                                    }
                                },
                                directives: [
                                    {
                                        name: 'has',
                                        value: this.btnRightList.noticeTrySave
                                    }
                                ]
                            }, '选择');
                        }
                    }
                ], // 库存
                currentInventoryId: '', // 当前操作的库存id
                inventoryList: [],
                deliveryTitle: [
                    {
                        title: '发货通知单号',
                        align: 'center',
                        minWidth: 140,
                        key: 'shipmentNoticeCode'
                    },
                    {
                        title: '发货数量',
                        align: 'center',
                        minWidth: 140,
                        key: 'quantity'
                    },
                    {
                        title: '红字数量',
                        align: 'center',
                        minWidth: 140,
                        key: 'redQuantity'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 140,
                        key: 'batchNo'
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 170,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.effectiveDate)
                            );
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 140,
                        key: 'supplierName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 140,
                        key: 'shipmentNoticeItemStatusName'
                    },
                    {
                        title: '出库时间',
                        align: 'center',
                        minWidth: 170,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.outboundDate, 'long')
                            );
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        width: 140,
                        fixed: 'right',
                        render: (h, params) => {
                            const showFlag = params.row.shipmentNoticeItemStatus === 0;
                            return showFlag ? h('Button', {
                                props: {
                                    type: 'error',
                                    size: 'small'
                                },
                                on: {
                                    click: () => {
                                        this.$Modal.confirm({
                                            title: '确认移除吗？',
                                            onOk: async () => {
                                                const res = await delDeliveryTrialList(params.row.id);
                                                if (res.status === this.code) {
                                                    this.$Message.success(res.msg);
                                                    this.getInventoryList();
                                                    this.getDeliveryList();
                                                }
                                            }
                                        });
                                    }
                                },
                                directives: [
                                    {
                                        name: 'has',
                                        value: this.btnRightList.noticeTryRemove
                                    }
                                ]
                            }, '移除') : null;
                        }
                    }
                ], // 发货
                deliveryList: [],
                modalTableQueryAttr: {
                    customerEnableCode: '',
                    supplierEnableCode: '',
                    effectiveDateStart: ''
                },
                currentOrder: null,
                customerList: [], // 客户下拉列表
                supplierList: [], // 供应商下拉列表
                inventoryLoading: false,
                deliveryLoading: false,
                chooseModalShowFlag: false, // 库存明细选择数量确认弹框开关
                formAttr: {
                    quantity: 0
                },
                ruleValidate: {
                    quantity: [
                        { validator: validateQuantity, trigger: 'blur', required: true }
                    ]
                }
            };
        },
        methods: {
            getTableList () {
                this.getTableListFn(async call => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getDeliveryNoticeTrialList(params);
                    call(res);
                });
            },
            handleToggle (flag) {
                this.tableQueryAttr.hasUnShipmentOrder = flag;
                this.getTableList();
            },
            DatePickerSearch (value) {
                if (Array.isArray(value) && value.length === 2) {
                    this.tableQueryAttr.orderDateStart = value[0];
                    this.tableQueryAttr.orderDateEnd = value[1];
                }
                console.log(this.tableQueryAttr);
                this.getInventoryList();
            },
            resetCst () {
                this.tableComAttr.pageNo = 1;
                resetObj(this.tableQueryAttr, 1);
                this.tableQueryAttr.hasUnShipmentOrder = true;
                this.getTableList();
            },
            searchModal () {
                this.getInventoryList();
            },
            // 重置
            resetModal () {
                resetObj(this.modalTableQueryAttr, 1);
                this.getInventoryList();
            },
            // 选择日期
            modalDatePickerSearch (value) {
                console.log(value);
                if (value) {
                    this.modalTableQueryAttr.effectiveDateStart = value;
                }
            },
            // 自定义取消
            modalCancelCst () {
                if (this.modalShowFlag) this.modalShowFlag = false;
                setTimeout(() => {
                    resetObj(this.modalTableQueryAttr);
                    this.getTableList();
                }, 300);
            },
            // 库存明细
            async getInventoryList (flag) {
                this.inventoryLoading = true;
                const params = Object.assign({}, this.modalTableQueryAttr, this.currentOrder, {
                    effectiveDate: getDate(this.currentOrder.effectiveDate, 'long'),
                    saleOrderItemId: this.currentOrder.id
                });
                const res = await getInventoryTrialList(params);
                this.inventoryLoading = false;
                if (res.status === this.code) {
                    this.inventoryList = res.content.inventorys;
                    if (flag) {
                        this.customerList = res.content.customers.map(item => {
                            return {
                                label: item.customerName,
                                value: item.enableCode
                            };
                        });
                        this.supplierList = res.content.suppliers.map(item => {
                            return {
                                label: item.supplierName,
                                value: item.enableCode
                            };
                        });
                    }
                }
            },
            // 发货明细
            async getDeliveryList () {
                this.deliveryLoading = true;
                const res = await getDeliveryTrialList(this.currentOrder.id);
                this.deliveryLoading = false;
                if (res.status === this.code) {
                    this.deliveryList = res.content;
                }
            },
            chooseModalOk () {
                this.$refs.formValidate.validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    const res = await addDeliveryTrialList({
                        saleOrderItemId: this.currentOrder.id,
                        inventoryId: this.currentInventoryId,
                        quantity: this.formAttr.quantity
                    });
                    if (res.status === this.code) {
                        this.$Message.success(res.msg);
                        this.chooseModalShowFlag = false;
                        this.getInventoryList();
                        this.getDeliveryList();
                        setTimeout(() => {
                            this.chooseModalCancel();
                        }, 300);
                    } else {
                        this.changeLoading();
                    }
                    console.log(res);
                });
            },
            chooseModalCancel () {
                setTimeout(() => {
                    this.formAttr.quantity = 0;
                }, 300);
                this.$refs['formValidate'] && this.$refs['formValidate'].resetFields();
            },
            // 一键匹配
            async handleMatch () {
                this.$Modal.confirm({
                    title: '确定一键匹配吗？',
                    onOk: async () => {
                        this.$Spin.show();
                        const res = await matchAuto();
                        this.$Spin.hide();
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getTableList();
                        }
                    }
                });
            },
            // 重置试算
            async handleReset () {
                this.$Modal.confirm({
                    title: '确定重置试算吗？',
                    onOk: async () => {
                        this.$Spin.show();
                        const res = await matchRemove();
                        this.$Spin.hide();
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getTableList();
                        }
                    }
                });
            },
            // 生成发货通知
            async handlemakeNotice () {
                this.$Modal.confirm({
                    title: '确定生成发货通知吗？',
                    onOk: async () => {
                        this.$Spin.show();
                        const res = await matchGenerate();
                        this.$Spin.hide();
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getTableList();
                        }
                    }
                });
            }
        }
    };
</script>

<style scoped lang="less">
    .center {
        margin-top: 5px;
    }
</style>
