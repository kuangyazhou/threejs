<template>
    <div class="page-warehouseList">
        <Card dis-hover :bordered="false">
            <p slot="title"><Icon type="md-list"></Icon> 仓库管理列表</p>
            <div slot="extra">
                <Button
                    icon="md-add"
                    @click="add"
                    v-has="btnRightList.warehouseSave"
                >新增
                </Button>
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
                ref="managerTable"
            ></erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel"
        >
            <div class="erp-modal-content">
                <Form
                    :model="formAttr"
                    :rules="ruleValidate"
                    ref="formValidate"
                    :label-width="120">
                    <FormItem
                        label="仓库代码"
                        prop="warehouseCode"
                    >
                        <Input
                            v-model="formAttr.warehouseCode"
                            placeholder="请输入仓库代码"
                        ></Input>
                    </FormItem>
                    <FormItem
                        label="仓库名字"
                        prop="warehouseName"
                    >
                        <Input
                            v-model="formAttr.warehouseName"
                            placeholder="请输入仓库名字"
                        ></Input>
                    </FormItem>
                    <FormItem
                        label="仓库地址"
                        prop="warehouseAddress"
                    >
                        <Input
                            v-model="formAttr.warehouseAddress"
                            placeholder="请输入仓库地址"
                        ></Input>
                    </FormItem>
                    <FormItem
                        label="是否停用"
                    >
                        <Select
                            v-model="formAttr.isStopUse"
                            placeholder="请选择是否停用"
                        >
                            <Option label="是" :value="1"></Option>
                            <Option label="否" :value="0"></Option>
                        </Select>
                    </FormItem>
                    <FormItem
                        label="备注"
                    >
                        <Input
                            v-model="formAttr.remark"
                            placeholder="请输入备注"
                        ></Input>
                    </FormItem>
                    <FormItem
                        label="仓库类型"
                        prop="warehouseType"
                    >
                        <Select
                            v-model="formAttr.warehouseType"
                            placeholder="请选择仓库类型"
                        >
                            <Option label="普通仓" :value="1"></Option>
                            <Option label="赊销仓" :value="3"></Option>
                            <Option label="其他仓" :value="2"></Option>
                        </Select>
                    </FormItem>
                </Form>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { getWarehouseList, addWarehouse, updateWarehouse } from '@/api/inventory/warehouseList';

    export default {
        name: 'index',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                erpTableTitle: [
                    {
                        title: '仓库id',
                        align: 'center',
                        minWidth: 120,
                        key: 'id'
                    },
                    {
                        title: '库存组织',
                        align: 'center',
                        minWidth: 120,
                        key: 'inventoryOrganizationName'
                    },
                    {
                        title: '仓库代码',
                        align: 'center',
                        minWidth: 120,
                        key: 'warehouseCode'
                    },
                    {
                        title: '仓库名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'warehouseName'
                    },
                    {
                        title: '仓库地址',
                        align: 'center',
                        minWidth: 120,
                        key: 'warehouseAddress'
                    },
                    {
                        title: '备注',
                        align: 'center',
                        minWidth: 120,
                        key: 'remark'
                    },
                    {
                        title: '是否停用',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            const validFlag = params.row.isStopUse === 0;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: validFlag ? 'success' : 'error'
                                    }
                                },
                                validFlag ? '否' : '是'
                            );
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        fixed: 'right',
                        render: (h, params) => {
                            return h('ButtonGroup', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small',
                                            icon: 'ios-create-outline'
                                        },
                                        on: {
                                            click: () => {
                                                this.editTableData(params, '编辑仓库');
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.warehouseUpdate
                                            }
                                        ]
                                    },
                                    '编辑'
                                )
                            ]);
                        }
                    }
                ],
                formAttr: {
                    isStopUse: 0,
                    warehouseType: '',
                    warehouseCode: '',
                    warehouseName: '',
                    remark: '',
                    warehouseAddress: ''
                },
                ruleValidate: {
                    warehouseCode: [
                        {
                            required: true,
                            message: '仓库代码不能为空',
                            trigger: 'blur'
                        }
                    ],
                    warehouseName: [
                        {
                            required: true,
                            message: '仓库名字不能为空',
                            trigger: 'blur'
                        }
                    ],
                    warehouseAddress: [
                        {
                            required: true,
                            message: '仓库地址不能为空',
                            trigger: 'blur'
                        }
                    ],
                    warehouseType: [
                        {
                            required: true,
                            message: '仓库类型不能为空',
                            type: 'number',
                            trigger: 'change'
                        }
                    ]
                }
            };
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr
                    );
                    const res = await getWarehouseList(params);
                    getListMixin(res);
                });
            },
            add () {
                this.addItem('新增仓库');
            },
            modalOk () {
                this.$refs.formValidate.validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res;
                    if (this.currentId) {
                        res = await updateWarehouse({
                            ...this.formAttr,
                            id: this.currentId
                        });
                    } else {
                        res = await addWarehouse(this.formAttr);
                    }
                    if (res.status === this.code) {
                        this.$Message.success(res.msg); // 提示消息
                        this.tableComAttr.pageNo = 1;
                        this.getTableList();
                        this.modalCancel();
                    } else {
                        this.changeLoading();
                    }
                });
            }
        }
    };
</script>

<style scoped lang="less">

</style>
