<template>
    <div class="saleMakeInvoice">
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Button icon="ios-arrow-down" class="form-button-select" @click="queryFormSelect">
                        {{tableQueryAttr.customerName || '客户名称'}}
                    </Button>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        placeholder="发票号"
                        @on-search="search"
                        search
                        v-model="tableQueryAttr.invoiceNo"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        placeholder="出库单号"
                        @on-search="search"
                        search
                        v-model="tableQueryAttr.outboundOrderNo"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <DatePicker v-model="tableQueryAttr.outboundTime" type="daterange" @on-change="DatePickerSearch"
                                placeholder="单据起止日期" style="width: 100%"></DatePicker>
                </Col>
            </Row>
        </Card>
        <Card :border="false">
            <p slot="title"><Icon type="md-list"></Icon> 销售开票列表</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button v-has="btnRightList.makeGoldenFile">生成金税文件</Button>
                    <Button v-has="btnRightList.invoiceAdd" icon="md-add" @click="add">新增开票</Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-selection-change="selectionChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
            ></erp-table>
        </Card>
        <Modal
            v-model="selectCustomerFlag"
            width="650"
            title="选择客户"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            footer-hide
        >
            <Row :gutter="16" class="search-container">
                <Col span="8">
                    <Input
                        v-model="tableComAttrInner.customerName"
                        placeholder="客户名称"
                    ></Input>
                </Col>
                <Col span="8">
                    <Input
                        v-model="tableComAttrInner.customerCode"
                        placeholder="客户编码"
                    ></Input>
                </Col>
                <Col span="8">
                    <Button @click="getCustomerList">搜索</Button>
                </Col>
            </Row>
            <erp-table
                @on-page-no-change="pageNoChangeInner"
                @on-page-size-change="pageSizeChangeInner"
                :erpTableTitle="modalTableTitleInner"
                :erpTableData="modalTableDataInner"
                :tableLoading="tableLoading"
                :current="tableComAttrInner.pageNo"
                :total="totalInner"
            >
            </erp-table>
        </Modal>

        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            fullscreen
        >
            <div class="erp-modal-content">
                <Form
                    :model="formAttr"
                    :rules="ruleValidate"
                    ref="formValidate"
                    :label-width="120">

                    <Row>
                        <Col span="11">
                            <FormItem
                                label="单据条码"
                                prop="outboundOrderNos"
                            >
                                <Input
                                    v-model="formAttr.outboundOrderNos"
                                    placeholder="请扫码或输入单据条码"
                                    @on-blur="getItemDetailSaleInvoice"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="13">
                            <FormItem
                                label="开票日期"
                            >
                                <Input
                                    disabled
                                    v-model="formAttr.invoiceDate"
                                    placeholder="请输入开票日期"
                                ></Input>
                            </FormItem>
                        </Col>
                    </Row>

                    <Row>
                        <Col span="11">
                            <FormItem
                                label="开票人员"
                            >
                                <Input
                                    v-model="$store.getters.realName"
                                    disabled
                                    placeholder="开票人员"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="13">

                            <FormItem
                                label="客户名称"
                            >
                                <Input
                                    disabled
                                    v-model="formAttr.customerName"
                                    placeholder="客户名称"
                                ></Input>
                            </FormItem>
                        </Col>
                    </Row>

                    <Row>
                        <Col span="11">
                            <FormItem
                                label="发票号码"
                                prop="invoiceNo"
                            >
                                <Input
                                    v-model="formAttr.invoiceNo"
                                    placeholder="请输入发票号码"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="13">
                            <FormItem
                                label="开票摘要"
                                prop="invoiceAbstract"
                            >
                                <Input
                                    v-model="formAttr.invoiceAbstract"
                                    placeholder="请输入开票摘要"
                                ></Input>
                            </FormItem>
                        </Col>
                    </Row>
                    <Row>
                        <Col span="11">
                            <FormItem
                                label="内部摘要"
                                prop="internalAbstract"
                            >
                                <Input
                                    v-model="formAttr.internalAbstract"
                                    placeholder="请输入内部摘要"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="13">
                            <FormItem
                                label="出库单号"
                            >
                                <Input
                                    disabled
                                    placeholder="出库单号"
                                ></Input>
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
            </div>
            <Table :data="outboundDetailArr" :columns="outboundDetailTitle" border></Table>
            <div slot="footer">
                <Button @click="modalCancel">取消</Button>
                <Button
                    @click="modalOk"
                    v-has="btnRightList.invoiceAdd"
                    type="info"
                >保存
                </Button>
                <Button
                    @click="modalOksubmit"
                    v-has="btnRightList.invoiceSubmit"
                    type="warning"
                >提交
                </Button>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { getCompanyUser } from '@/api/masterData/userselect';
    import {
        addSaleInvoice,
        auditSaleInvoice,
        getDetailSaleInvoice,
        getSaleInvoiceList,
        itemDetailSaleInvoice,
        revocationSaleInvoice,
        submitSaleInvoice
    } from '@/api/saleManage/invoice';
    import { getDate } from '@/libs/tools';

    export default {
        name: 'saleMakeInvoice',
        components: { ErpTable },
        mixins: [tableMixin],
        data () {
            return {
                tableQueryAttr: {
                    customerId: '',
                    customerName: '',
                    invoiceNo: '',
                    outboundOrderNo: '',
                    beginDate: '',
                    endDate: '',
                    outboundTime: ''
                },
                erpTableTitle: [
                    {
                        title: '销售组织',
                        align: 'center',
                        minWidth: 100,
                        key: 'saleOrganizationName'
                    },
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerName'
                    },
                    {
                        title: '发票号码',
                        align: 'center',
                        minWidth: 100,
                        key: 'invoiceNo'
                    },
                    {
                        title: '开票人员',
                        align: 'center',
                        minWidth: 100,
                        key: 'invoiceUser'
                    },
                    {
                        title: '开票日期',
                        align: 'center',
                        minWidth: 100,
                        key: 'invoiceDate'
                    },
                    {
                        title: '销项税额',
                        align: 'center',
                        minWidth: 100,
                        key: 'taxAmount'
                    },
                    {
                        title: '价税合计',
                        align: 'center',
                        minWidth: 100,
                        key: 'priceTaxTotalAmount'
                    },
                    {
                        title: '开票摘要',
                        align: 'center',
                        minWidth: 100,
                        key: 'invoiceAbstract'
                    },
                    {
                        title: '内部摘要',
                        align: 'center',
                        minWidth: 100,
                        key: 'internalAbstract'
                    },

                    {
                        title: '操作',
                        align: 'center',
                        width: 240,
                        fixed: 'right',
                        render: (h, params) => {
                            const editFlag = params.row.invoiceStatus === 1;
                            const submitFlag = params.row.invoiceStatus === 1;
                            const backFlag = params.row.invoiceStatus === 2;
                            const overFlag = params.row.invoiceStatus === 3;
                            return h('div', [
                                editFlag ? h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        on: {
                                            click: async () => {
                                                this.addItem('编辑销售开票');
                                                const res = await getDetailSaleInvoice(params.row.invoiceId);
                                                console.log(res);
                                                if (res.status === this.code) {
                                                    Object.keys(this.formAttr).forEach(item => {
                                                        this.formAttr[item] = res.content[item];
                                                    });
                                                    this.outboundDetailArr = res.content.list;
                                                }
                                            }
                                        },
                                        style: {
                                            marginRight: '8px'
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.invoiceUpdate
                                            }
                                        ]
                                    },
                                    '编辑'
                                ) : null,
                                submitFlag || backFlag ? h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'warning',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.$Modal.confirm({
                                                    title: `确认${submitFlag ? '提交' : backFlag ? '撤回' : ''}吗？`,
                                                    onOk: async () => {
                                                        let res;
                                                        if (submitFlag) {
                                                            res = await submitSaleInvoice([params.row.invoiceId]);
                                                        }
                                                        if (backFlag) {
                                                            res = await revocationSaleInvoice([params.row.invoiceId]);
                                                        }
                                                        if (res.status === this.code) {
                                                            this.$Message.success(res.msg); // 提示消息
                                                            this.tableComAttr.pageNo = 1;
                                                            this.getTableList();
                                                        }
                                                    }
                                                });
                                            }
                                        },
                                        style: {
                                            marginRight: '8px'
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: submitFlag ? this.btnRightList.invoiceSubmit : backFlag ? this.btnRightList.invoiceRevocation : ''
                                            }
                                        ]
                                    },
                                    submitFlag ? '提交' : backFlag ? '撤回' : ''
                                ) : null,
                                backFlag ? h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'info',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.$Modal.confirm({
                                                    title: `确认审核吗？`,
                                                    onOk: async () => {
                                                        const res = await auditSaleInvoice([params.row.invoiceId]);
                                                        if (res.status === this.code) {
                                                            this.$Message.success(res.msg); // 提示消息
                                                            this.tableComAttr.pageNo = 1;
                                                            this.getTableList();
                                                        }
                                                    }
                                                });
                                            }
                                        },
                                        style: {
                                            marginRight: '8px'
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.invoiceAudit
                                            }
                                        ]
                                    },
                                    '审核'
                                ) : null,
                                overFlag ? h('span', {}, '已审核') : null
                            ]);
                        }
                    }
                ],
                selectCustomerFlag: false,
                modalTableTitleInner: [
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'customerName'
                    },
                    {
                        title: '客户编码',
                        align: 'center',
                        minWidth: 120,
                        key: 'customerCode'
                    },
                    {
                        title: '选择',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h('Button', {
                                props: {
                                    type: 'success',
                                    size: 'small'
                                },
                                on: {
                                    'click': () => {
                                        this.selectCustomerFlag = false;
                                        console.log(params.row);
                                        this.tableQueryAttr.customerName = params.row.customerName;
                                        this.tableQueryAttr.customerId = params.row.id;
                                        this.search();
                                    }
                                }
                            }, '选择');
                        }
                    }
                ],
                modalTableDataInner: [], // 客户列表
                tableComAttrInner: {
                    pageNo: 1,
                    pageSize: 10,
                    customerName: '',
                    customerCode: ''
                },
                totalInner: 0,
                typeList: [
                    { label: '未提交', value: 0 },
                    { label: '审核中', value: 1 },
                    { label: '已审核', value: 2 }
                ],
                formAttr: {
                    outboundOrderNos: '',
                    invoiceDate: '',
                    customerName: '',
                    customerId: '',
                    invoiceNo: '',
                    invoiceAbstract: '',
                    internalAbstract: ''
                },
                ruleValidate: {
                    outboundOrderNos: [
                        {
                            required: true,
                            message: '单据条码不能为空',
                            trigger: 'blur'
                        }
                    ],
                    customerName: [
                        {
                            required: true,
                            message: '客户名称不能为空',
                            trigger: 'blur'
                        }
                    ],
                    invoiceNo: [
                        {
                            required: true,
                            message: '发票号码不能为空',
                            trigger: 'blur'
                        }
                    ],
                    invoiceAbstract: [
                        {
                            required: true,
                            message: '开票摘要不能为空',
                            trigger: 'blur'
                        }
                    ],
                    internalAbstract: [
                        {
                            required: true,
                            message: '内部摘要不能为空',
                            trigger: 'blur'
                        }
                    ]
                },
                outboundDetailArr: [],
                outboundDetailTitle: [
                    {
                        title: '序号',
                        type: 'index',
                        align: 'center',
                        minWidth: 60,
                        fixed: 'left'
                    },
                    {
                        title: '出库单号',
                        align: 'center',
                        minWidth: 160,
                        key: 'outboundOrderNo'
                    },
                    {
                        title: '物料代码',
                        align: 'center',
                        minWidth: 160,
                        key: 'commodityCode'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 160,
                        key: 'commodityName'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 160,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 160,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 160,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 160,
                        key: 'brand'
                    },
                    {
                        title: '数量',
                        align: 'center',
                        minWidth: 160,
                        key: 'quantity'
                    },
                    {
                        title: '含税单价',
                        align: 'center',
                        minWidth: 160,
                        key: 'taxedPrice'
                    },
                    {
                        title: '物料单价',
                        align: 'center',
                        minWidth: 160,
                        key: 'price'
                    },
                    {
                        title: '销项税额',
                        align: 'center',
                        minWidth: 160,
                        key: 'taxedAmount'
                    },
                    {
                        title: '物料税率',
                        align: 'center',
                        minWidth: 160,
                        key: 'taxRate'
                    },
                    {
                        title: '物料金额',
                        align: 'center',
                        minWidth: 160,
                        key: 'priceAmount'
                    },
                    {
                        title: '价税合计',
                        align: 'center',
                        minWidth: 160,
                        key: 'priceTaxAmount'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 90,
                        key: 'unit'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 160,
                        key: 'batchNo'
                    },
                    {
                        title: '生产日期',
                        align: 'center',
                        minWidth: 110,
                        key: 'producedDate'
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 110,
                        key: 'effectiveDate'
                    },
                    {
                        title: '录入时间',
                        align: 'center',
                        minWidth: 150,
                        key: 'createTime'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 140,
                        fixed: 'right',
                        render: (h, params) => {
                            return h('Button', {
                                props: {
                                    type: 'error',
                                    size: 'small'
                                },
                                on: {
                                    click: () => {
                                        this.$Modal.confirm({
                                            title: `确认删除吗？`,
                                            onOk: async () => {
                                                this.outboundDetailArr.splice(params.index, 1);
                                            }
                                        });
                                    }
                                }
                            }, '删除');
                        }
                    }
                ]
            };
        },
        methods: {
            // 获取表格数据
            getTableList () {
                this.getTableListFn(async call => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getSaleInvoiceList(params);
                    call(res);
                });
            },
            // 获取公司关联的客户列表
            async getCustomerList () {
                const res = await getCompanyUser(this.tableComAttrInner);
                if (res.status === this.code) {
                    this.modalTableDataInner = res.content.list;
                    this.totalInner = res.content.total;
                }
            },
            // 查询条件 客户名称
            queryFormSelect () {
                this.selectCustomerFlag = true;
                this.getCustomerList();
            },
            pageNoChangeInner (value) {
                this.tableComAttrInner.pageNo = value;
                this.getCustomerList();
            },
            pageSizeChangeInner (value) {
                this.tableComAttrInner.pageNo = 1;
                this.tableComAttrInner.pageSize = value;
                this.getCustomerList();
            },
            add () {
                this.formAttr.invoiceDate = getDate(new Date().getTime());
                this.addItem('新增开票');
            },
            DatePickerSearch (value) {
                console.log(value);
                if (Array.isArray(value) && value.length === 2) {
                    this.tableQueryAttr.beginDate = value[0];
                    this.tableQueryAttr.endDate = value[1];
                }
                console.log(this.tableQueryAttr);
                this.search();
            },
            // 保存
            modalOk () {
                this.$refs.formValidate.validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    if (!this.outboundDetailArr.length) {
                        this.$Message.error({
                            content: '该单据条码无出库单，请重新输入',
                            duration: 4
                        });
                        return this.changeLoading();
                    }
                    const params = Object.assign({}, this.formAttr, {
                        outboundOrderItemIdList: this.outboundDetailArr.map(item => {
                            return item.outboundOrderItemId;
                        }),
                        invoiceStatus: 1
                    });
                    const res = await addSaleInvoice(params);
                    if (res.status === this.code) {
                        this.$Message.success(res.msg); // 提示消息
                        this.tableComAttr.pageNo = 1;
                        this.getTableList();
                        this.modalCancel();
                    } else {
                        this.changeLoading();
                    }
                });
            },
            // 保存并提交
            modalOksubmit () {
                this.$refs.formValidate.validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    if (!this.outboundDetailArr.length) {
                        this.$Message.error({
                            content: '该单据条码无出库单，请重新输入',
                            duration: 4
                        });
                        return this.changeLoading();
                    }
                    const params = Object.assign({}, this.formAttr, {
                        outboundOrderItemIdList: this.outboundDetailArr.map(item => {
                            return item.outboundOrderItemId;
                        }),
                        invoiceStatus: 2
                    });
                    const res = await addSaleInvoice(params);
                    if (res.status === this.code) {
                        this.$Message.success(res.msg); // 提示消息
                        this.tableComAttr.pageNo = 1;
                        this.getTableList();
                        this.modalCancel();
                    } else {
                        this.changeLoading();
                    }
                });
            },
            async getItemDetailSaleInvoice () {
                const res = await itemDetailSaleInvoice(this.formAttr.outboundOrderNos);
                console.log(res);
                if (res.status === this.code) {
                    this.formAttr.customerName = res.content.customerName;
                    this.formAttr.customerId = res.content.customerId;
                    this.outboundDetailArr = res.content.list || [];
                }
            }
        }
    };
</script>

<style scoped lang="less">
    .search-container {
        margin-bottom: 20px;
    }
</style>
