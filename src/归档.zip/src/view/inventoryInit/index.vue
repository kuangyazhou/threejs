<template>
    <div class="inventoryInit">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search(true)" icon="md-search">搜索</Button>
                    <Button @click="getTableList(false)" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.inventoryOrganizationId"
                        @on-change="searchInventoryCst"
                        placeholder="库存组织"
                    >
                        <Option
                            v-for="item in inventoryOrganizationArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.warehouseId"
                        :disabled="!tableQueryAttr.inventoryOrganizationId"
                        @on-change="searchCst"
                        placeholder="仓库"
                    >
                        <Option
                            v-for="item in warehouseArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                库存明细列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Upload
                        v-has="btnRightList.inventoryInitImport"
                        class="upload"
                        name="file"
                        :on-format-error="handleFormatError"
                        :on-error="upError"
                        :on-success="upSuccess"
                        :format="['xlsx','xls']"
                        :show-upload-list="false"
                        :headers="headers"
                        :data="uploadData"
                        :action="action">
                        <Button icon="md-arrow-up">批量导入</Button>
                    </Upload>
                    <Button
                        v-has="btnRightList.inventoryInitDownload"
                        icon="md-arrow-down"
                        class="down"
                        @click="download"
                    >下载模板
                    </Button>
                    <Button
                        v-has="btnRightList.inventoryInitSave"
                        :disabled="!(erpTableData.length === 0 ||  checkDataInventoryStatus === 1)"
                        icon="md-add"
                        @click="addEdit"
                    >新增修改
                    </Button>
                    <Button
                        v-has="btnRightList.inventoryInitSubmit"
                        :disabled="!(erpTableData.length !== 0 && checkDataInventoryStatus === 1)"
                        icon="md-paper-plane"
                        @click="submit"
                    >提交
                    </Button>
                    <Button
                        v-has="btnRightList.inventoryInitComplete"
                        :disabled="!(erpTableData.length !== 0 && checkDataInventoryStatus === 2)"
                        icon="md-checkmark-circle-outline"
                        @click="initComplete"
                    >完成初始化
                    </Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :hasPage="false"
                :current="tableComAttr.pageNo"
                ref="managerTable"
            ></erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            fullscreen
            @on-cancel="modalCancelCst"
        >
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    库存组织：{{inventoryOrganizationName}}
                </Col>
                <Col span="5" class="maxWidth">
                    仓库：{{warehouseName}}
                </Col>
            </Row>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    明细数量：{{detailNumber}}
                </Col>
                <Col span="5" class="maxWidth">
                    总金额：{{totalMoney}}
                </Col>
            </Row>
            <div class="fr modalAdd">
                <Button
                    icon="md-add"
                    @click="modalAdd"
                >新增
                </Button>
            </div>
            <Table style="margin-top: 20px"
                   :columns="cusColumns"
                   :data="cusData"
                   border></Table>
            <div slot="footer">
                <Button @click="modalCancelCst">关闭</Button>
                <Button
                    :disabled="!cusData.length"
                    @click="modalOk"
                    type="primary"
                >保存
                </Button>
                <Button
                    :disabled="!cusData.length"
                    @click="modalOkSubmit"
                    type="info"
                >提交
                </Button>
            </div>
        </Modal>
        <!--物料或者供应商弹窗-->
        <Modal
            v-model="materielShowFlag"
            width="700"
            :title="materielTodoFlag ? '选择物料' : '选择供应商'"
            :mask-closable="maskClosable"
            footer-hide
        >
            <div>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="ios-search"></Icon>
                        查询条件
                    </p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button @click="materielSearch" icon="md-search"
                            >搜索
                            </Button>
                            <Button @click="materielReset" icon="md-refresh"
                            >重置
                            </Button>
                        </ButtonGroup>
                    </div>
                    <Row :gutter="16">
                        <Col span="12" class="maxWidth" v-if="materielTodoFlag">
                            <Input
                                v-model="materielTableQuery.commodityName"
                                @on-search="materielSearch"
                                search
                                placeholder="物料名称"
                            >
                                <Button
                                    @click="materielSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                        <Col span="12" class="maxWidth" v-if="materielTodoFlag">
                            <Input
                                v-model="materielTableQuery.specializedGroup"
                                @on-search="materielSearch"
                                search
                                placeholder="专业分组"
                            >
                                <Button
                                    @click="materielSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                        <Col span="12" class="maxWidth" v-if="!materielTodoFlag">
                            <Input
                                v-model="materielTableQuery.supplierName"
                                @on-search="materielSearch"
                                search
                                placeholder="供应商名称"
                            >
                                <Button
                                    @click="materielSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                    </Row>
                </Card>
                <erp-table
                    @on-page-no-change="materielPageNoChange"
                    @on-page-size-change="materielPageSizeChange"
                    :tableWidth="tableWidth"
                    :erpTableTitle="materielTodoFlag ? materielTableTitle : supplierTableTitle"
                    :erpTableData="materielTableData"
                    :tableLoading="materielTableLoading"
                    :current="materielComAttr.pageNo"
                    :total="materielTotal"
                >
                </erp-table>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        completeInventoryInit,
        getInventoryInitList,
        getOrganizationDropList,
        getPackageDropList,
        getWarehouseDropList,
        saveInventoryInit,
        submitInventoryInit
    } from '@/api/inventory/inventory';
    import { getCompanyMaterialList } from '@/api/purchaseManage/channelPrice';
    import { getAllSupplierList } from '@/api/purchaseManage/inquiryTask';
    import { environmentConfig, getDate, resetObj } from '@/libs/tools';
    import { getSSOToken, getToken } from '@/libs/util';

    export default {
        name: 'inventoryInit',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    inventoryOrganizationId: '',
                    warehouseId: ''
                },
                inventoryOrganizationArr: [], // 库存组织下拉
                warehouseArr: [], // 仓库列表下拉
                erpTableTitle: [
                    {
                        title: '库存组织',
                        align: 'center',
                        minWidth: 140,
                        key: 'inventoryOrganizationName'
                    },
                    {
                        title: '仓库',
                        align: 'center',
                        minWidth: 140,
                        key: 'warehouseName'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 140,
                        key: 'commodityName'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 140,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 140,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 120,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 120,
                        key: 'brandName'
                    },
                    {
                        title: '单价',
                        align: 'center',
                        minWidth: 120,
                        key: 'initPrice'
                    },
                    {
                        title: '数量',
                        align: 'center',
                        minWidth: 120,
                        key: 'quantity'
                    },
                    {
                        title: '包装单位',
                        align: 'center',
                        minWidth: 120,
                        key: 'unitName'
                    },
                    {
                        title: '金额',
                        align: 'center',
                        minWidth: 120,
                        key: 'initAmount'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    {
                        title: '生产日期',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.producedDate)
                            );
                        }
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.effectiveDate)
                            );
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '录入时间',
                        align: 'center',
                        minWidth: 170,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 120,
                        key: '',
                        render: (h, params) => {
                            const status =
                                params.row.inventoryStatus === 1 ? '未提交' : params.row.inventoryStatus === 2 ? '已提交' : '已审核';
                            return h('span', {}, status);
                        }
                    }
                ],
                moneyArr: [], // 总金额数组
                currentInitMaterialIndex: -1, // 新增编辑库存初始化当前操作的下标
                cusColumns: [
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 220,
                        render: (h, params) => {
                            return h('Button', {
                                props: {
                                    icon: 'ios-arrow-down',
                                    type: 'default'
                                },
                                style: {
                                    height: '32px'
                                },
                                class: {
                                    'form-button-select': true
                                },
                                on: {
                                    'click': () => {
                                        this.materielTodoFlag = true;
                                        this.materielShowFlag = true;
                                        this.currentInitMaterialIndex = params.index;
                                        this.getCompanyMaterialList();
                                    }
                                }
                            }, params.row.commodityId ? params.row.commodityName : '请选择物料');
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 220,
                        render: (h, params) => {
                            return h('Button', {
                                props: {
                                    icon: 'ios-arrow-down',
                                    type: 'default'
                                },
                                style: {
                                    height: '32px'
                                },
                                class: {
                                    'form-button-select': true
                                },
                                on: {
                                    'click': () => {
                                        this.materielTodoFlag = false;
                                        this.materielShowFlag = true;
                                        this.currentInitMaterialIndex = params.index;
                                        this.getAllSupplierList();
                                    }
                                }
                            }, params.row.supplierName ? params.row.supplierName : '请选择供应商');
                        }
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 220,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 160,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 120,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 120,
                        key: 'brandName'
                    },
                    {
                        title: '单价',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h('InputNumber', {
                                props: {
                                    value: params.row.initPrice,
                                    min: 0
                                },
                                on: {
                                    'on-change': e => {
                                        params.row.initPrice = e;
                                        this.cusData[params.index] = params.row;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '数量',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h('InputNumber', {
                                props: {
                                    value: params.row.quantity,
                                    min: 0
                                },
                                on: {
                                    'on-change': e => {
                                        params.row.quantity = e;
                                        this.cusData[params.index] = params.row;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '包装单位',
                        align: 'center',
                        minWidth: 140,
                        render: (h, params) => {
                            if (params.row.commodityId && !this.unitNameArr[params.index]) {
                                console.log(11111);
                                this.unitNameArr[params.index] = [{
                                    id: params.row.commodityPackageId,
                                    fieldValue: params.row.unitName
                                }];
                            }
                            return h('Select', {
                                props: {
                                    type: 'text',
                                    value: params.row.commodityPackageId,
                                    disabled: !params.row.commodityId
                                },
                                on: {
                                    'on-change': e => {
                                        this.unitNameArr[params.index].forEach(item => {
                                            if (item.id === e) {
                                                params.row.unitName = item.fieldValue;
                                            }
                                        });
                                        params.row.commodityPackageId = e;
                                        this.cusData[params.index] = params.row;
                                    },
                                    'on-open-change': (flag) => {
                                        if (flag) {
                                            this.getPackageDropList({ commodityId: params.row.commodityId }, (arr) => {
                                                this.unitNameArr[params.index] = arr;
                                                this.unitNameArr = JSON.parse(JSON.stringify(this.unitNameArr));
                                                console.log(this.unitNameArr);
                                            });
                                        }
                                    }
                                }
                            }, (this.unitNameArr[params.index] || []).map((item) => {
                                return h('Option', {
                                    props: {
                                        value: item.id,
                                        label: item.fieldValue
                                    }
                                });
                            }));
                        }
                    },
                    {
                        title: '金额',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h('InputNumber', {
                                props: {
                                    value: params.row.initAmount,
                                    min: 0
                                },
                                on: {
                                    'on-change': e => {
                                        params.row.initAmount = e;
                                        this.cusData[params.index] = params.row;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '币种',
                        align: 'center',
                        minWidth: 140,
                        render: (h, params) => {
                            return h('Select', {
                                props: {
                                    type: 'text',
                                    value: params.row.currencyId
                                },
                                on: {
                                    'on-change': e => {
                                        params.row.currencyId = e;
                                        this.cusData[params.index] = params.row;
                                    }
                                }
                            }, this.currencyArr.map((item) => {
                                return h('Option', {
                                    props: {
                                        value: item.id,
                                        label: item.fieldValue
                                    }
                                });
                            }));
                        }
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 200,
                        render: (h, params) => {
                            return h('Input', {
                                props: {
                                    value: params.row.batchNo,
                                    placeholder: '请输入批号'
                                },
                                on: {
                                    'on-change': e => {
                                        params.row.batchNo = e.target.value;
                                        this.cusData[params.index] = params.row;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '货位编号',
                        align: 'center',
                        minWidth: 200,
                        render: (h, params) => {
                            return h('Input', {
                                props: {
                                    value: params.row.goodsLocationCode,
                                    placeholder: '请输入货位编号'
                                },
                                on: {
                                    'on-change': e => {
                                        params.row.goodsLocationCode = e.target.value;
                                        this.cusData[params.index] = params.row;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '收货人员账号',
                        align: 'center',
                        minWidth: 200,
                        render: (h, params) => {
                            return h('Input', {
                                props: {
                                    value: params.row.inboundUserName,
                                    placeholder: '请输入收货人员账号'
                                },
                                on: {
                                    'on-change': e => {
                                        params.row.inboundUserName = e.target.value;
                                        this.cusData[params.index] = params.row;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '验收人员账号',
                        align: 'center',
                        minWidth: 200,
                        render: (h, params) => {
                            return h('Input', {
                                props: {
                                    value: params.row.acceptanceUserName,
                                    placeholder: '请输入验收人员账号'
                                },
                                on: {
                                    'on-change': e => {
                                        params.row.acceptanceUserName = e.target.value;
                                        this.cusData[params.index] = params.row;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '验收操作员账号',
                        align: 'center',
                        minWidth: 200,
                        render: (h, params) => {
                            return h('Input', {
                                props: {
                                    value: params.row.acceptanceOperaUserName,
                                    placeholder: '请输入验收操作员账号'
                                },
                                on: {
                                    'on-change': e => {
                                        params.row.acceptanceOperaUserName = e.target.value;
                                        this.cusData[params.index] = params.row;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '上架人员账号',
                        align: 'center',
                        minWidth: 200,
                        render: (h, params) => {
                            return h('Input', {
                                props: {
                                    value: params.row.putawayUserName,
                                    placeholder: '请输入上架人员账号'
                                },
                                on: {
                                    'on-change': e => {
                                        params.row.putawayUserName = e.target.value;
                                        this.cusData[params.index] = params.row;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '到货温度',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h('InputNumber', {
                                props: {
                                    value: params.row.arrivalTemperature,
                                    step: 0.01
                                },
                                on: {
                                    'on-change': e => {
                                        params.row.arrivalTemperature = e;
                                        this.cusData[params.index] = params.row;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '注册证号',
                        align: 'center',
                        minWidth: 200,
                        render: (h, params) => {
                            return h('Input', {
                                props: {
                                    value: params.row.approvalCode,
                                    placeholder: '请输入注册证号'
                                },
                                on: {
                                    'on-change': e => {
                                        params.row.approvalCode = e.target.value;
                                        this.cusData[params.index] = params.row;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '生产日期',
                        align: 'center',
                        minWidth: 220,
                        render: (h, params) => {
                            const formatInnerFlag = params.row.producedDateFormat === 'yyyy-MM-dd';
                            const isFormat = `${params.row.producedDate}`.indexOf('-') > 0;
                            if (!isFormat) {
                                params.row.producedDate = getDate(params.row.producedDate);
                                this.cusData[params.index] = params.row;
                            }
                            return h('div', [
                                h('DatePicker', {
                                    props: {
                                        type: 'date',
                                        value: params.row.producedDate,
                                        disabled: !params.row.commodityId,
                                        format: params.row.producedDateFormat,
                                        options: {
                                            disabledDate (date) {
                                                return date && date.valueOf() > Date.now();
                                            }
                                        }
                                    },
                                    style: {
                                        width: '125px',
                                        marginRight: '6px'
                                    },
                                    on: {
                                        'on-change': (val) => {
                                            params.row.producedDate = val;
                                            console.log(getDate(new Date(val).getTime() + params.row.effectiveDays * 86400000));
                                            params.row.effectiveDate = getDate(new Date(val).getTime() + params.row.effectiveDays * 86400000);
                                            this.cusData[params.index] = params.row;
                                        }
                                    }
                                }),
                                h('Button', {
                                    props: {
                                        size: 'small',
                                        disabled: !params.row.commodityId
                                    },
                                    style: {},
                                    on: {
                                        click: () => {
                                            if (formatInnerFlag) {
                                                params.row.producedDateFormat = 'yyyy-MM';
                                                this.cusData[params.index].producedDateFormat = 'yyyy-MM';
                                            } else {
                                                params.row.producedDateFormat = 'yyyy-MM-dd';
                                                this.cusData[params.index].producedDateFormat = 'yyyy-MM-dd';
                                            }
                                        }
                                    }
                                }, formatInnerFlag ? '日' : '月')
                            ]);
                        }
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 220,
                        render: (h, params) => {
                            const formatInnerFlag = params.row.effectiveDateFormat === 'yyyy-MM-dd';
                            const isFormat = `${params.row.effectiveDate}`.indexOf('-') > 0;
                            if (!isFormat) {
                                params.row.effectiveDate = getDate(params.row.effectiveDate);
                                this.cusData[params.index] = params.row;
                            }

                            return h('div', [
                                h('DatePicker', {
                                    props: {
                                        type: 'date',
                                        value: params.row.effectiveDate,
                                        format: params.row.effectiveDateFormat,
                                        disabled: !params.row.commodityName || !params.row.effectiveDate,
                                        options: {
                                            disabledDate (date) {
                                                return date && date.valueOf() < new Date(params.row.effectiveDate).getTime();
                                            }
                                        }
                                    },
                                    style: {
                                        width: '125px',
                                        marginRight: '6px'
                                    },
                                    on: {
                                        'on-change': (val) => {
                                            params.row.effectiveDate = val;
                                            this.cusData[params.index] = params.row;
                                        }
                                    }
                                }),
                                h('Button', {
                                    props: {
                                        size: 'small',
                                        disabled: !params.row.commodityName || !params.row.effectiveDate
                                    },
                                    style: {},
                                    on: {
                                        click: () => {
                                            if (formatInnerFlag) {
                                                params.row.effectiveDateFormat = 'yyyy-MM';
                                                this.cusData[params.index].effectiveDateFormat = 'yyyy-MM';
                                            } else {
                                                params.row.effectiveDateFormat = 'yyyy-MM-dd';
                                                this.cusData[params.index].effectiveDateFormat = 'yyyy-MM-dd';
                                            }
                                        }
                                    }
                                }, formatInnerFlag ? '日' : '月')
                            ]);
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 200,
                        fixed: 'right',
                        render: (h, params) => {
                            return h('div', [
                                h('Button', {
                                    props: {
                                        type: 'error'
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            const arr = this.erpTableData;
                                            console.log(arr);
                                            this.$Modal.confirm({
                                                title: '确定删除吗？',
                                                onOk: async () => {
                                                    this.cusData = this.delArrItemFormIndex(this.cusData, params.index);
                                                }
                                            });
                                        }
                                    }
                                }, '删除'),
                                h('Button', {
                                    props: {
                                        type: 'info'
                                    },
                                    on: {
                                        click: () => {
                                            resetObj(this.tplObj);
                                            this.tplObj.producedDateFormat = 'yyyy-MM-dd';
                                            this.tplObj.effectiveDateFormat = 'yyyy-MM-dd';
                                            this.unitNameArr.splice(params.index, 0, []);
                                            this.cusData.splice(params.index, 0, this.tplObj);
                                        }
                                    }
                                }, '插入')
                            ]);
                        }
                    }
                ], // 弹框标题
                cusData: [], // 弹框数据源
                cusDataBak: [], // 弹框数据源备份
                materielTodoFlag: true, // 物料和供应商弹窗公用一个的信息, 默认物料
                tplObj: {
                    commodityName: '',
                    registerName: '',
                    registerNumber: '',
                    commoditySpec: '',
                    brandName: '',
                    initPrice: 0,
                    quantity: 0,
                    initAmount: 0,
                    batchNo: '',
                    goodsLocationCode: '',
                    producedDate: '',
                    effectiveDate: '',
                    supplierName: '',
                    commodityId: '',
                    supplierId: '',
                    currencyId: '',
                    commodityPackageId: '',
                    inboundUserName: '',
                    acceptanceUserName: '',
                    acceptanceOperaUserName: '',
                    putawayUserName: '',
                    producedDateFormat: 'yyyy-MM-dd',
                    effectiveDateFormat: 'yyyy-MM-dd',
                    arrivalTemperature: 0,
                    approvalCode: ''
                    // goodsLocationCode: ''
                }, // 新增插入的模板
                unitNameArr: [], // 单位下拉列表
                currencyArr: [], // 币种下拉列表
                materielShowFlag: false, // 物料弹框
                materielTableTitle: [
                    {
                        title: '常用名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityName'
                    },
                    {
                        title: '物料规格',
                        align: 'center',
                        minWidth: 90,
                        key: 'commoditySpec'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 90,
                        key: 'brandName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 90,
                        key: 'specializedGroup'
                    },
                    {
                        title: '操作',
                        minWidth: 100,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'success',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.materielShowFlag = false;
                                                const arr = ['registerName', 'registerNumber', 'commoditySpec', 'brandName', 'effectiveDays', 'commodityId', 'commodityName'];
                                                arr.forEach(item => {
                                                    this.cusData[this.currentInitMaterialIndex][item] = params.row[item];
                                                });
                                                this.getPackageDropList(params.row, (arr) => {
                                                    let list = JSON.parse(JSON.stringify(this.unitNameArr));
                                                    list[this.currentInitMaterialIndex] = arr;
                                                    this.unitNameArr = list;
                                                    console.log(this.unitNameArr);
                                                    this.currentInitMaterialIndex = -1;
                                                });
                                            }
                                        }
                                    },
                                    '选择'
                                )
                            ]);
                        }
                    }
                ], // 物料表格栏目
                supplierTableTitle: [
                    {
                        title: '供应商名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '供应商代码 ',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierCode'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 120,
                        key: 'mainBrand'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 120,
                        key: 'specialtyGroupName'
                    },

                    {
                        title: '操作',
                        minWidth: 100,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'success',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.materielShowFlag = false;
                                                this.cusData[this.currentInitMaterialIndex].supplierName = params.row.supplierName;
                                                this.cusData[this.currentInitMaterialIndex].supplierId = params.row.id;
                                                console.log(this.cusData);
                                                this.currentInitMaterialIndex = -1;
                                            }
                                        }
                                    },
                                    '选择'
                                )
                            ]);
                        }
                    }
                ], // 供应商标题
                materielTableData: [],
                materielTableLoading: false,
                materielComAttr: {
                    pageNo: 1,
                    pageSize: 10
                },
                materielTotal: 0,
                materielTableQuery: {
                    commodityName: '',
                    specializedGroup: '',
                    supplierName: ''
                }
            };
        },
        created () {

        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList (todoFlag) {
                const get = () => {
                    this.getTableListFn(async getListMixin => {
                        const params = Object.assign(
                            {},
                            this.tableComAttr,
                            this.tableQueryAttr
                        );
                        const res = await getInventoryInitList(params);
                        getListMixin(res);
                        if (res.status === this.code) {
                            this.moneyArr = res.content.amounts;
                            // this.cusData = [...res.content.list];
                            // this.cusDataBak = [...res.content.list];
                        }
                    });
                };
                if (todoFlag) {
                    get();
                } else {
                    this.getAllSelectData(() => {
                        get();
                    }, todoFlag);
                }
            },
            /**
             * 通过下标删除数组指定元素
             * @param arr
             * @param index
             * @returns {Array}
             */
            delArrItemFormIndex (arr, index) {
                let res = [];
                if (Array.isArray(arr)) {
                    arr.forEach((item, i) => {
                        if (index !== i) {
                            res.push(item);
                        }
                    });
                }
                return res;
            },
            getAllSelectData (cb, todoFlag) {
                this.getInventoryOrganizationList(cb, todoFlag);
                // this.getFieldValuesData('package_unit', 'unitNameArr');
                // this.getPackageDropList();
                this.getFieldValuesData('currency', 'currencyArr');
            },
            async getPackageDropList (params, cb) {
                const res = await getPackageDropList(params);
                console.log(res);
                if (res.status === this.code) {
                    const arr = res.content.map(item => {
                        return {
                            id: item.id,
                            fieldValue: item.unitName
                        };
                    });
                    console.log(arr);
                    if (cb) cb(arr);
                }
            },
            // 库存组织下拉
            async getInventoryOrganizationList (cb, todoFlag) {
                const res = await getOrganizationDropList();
                if (res.status === this.code) {
                    this.inventoryOrganizationArr = res.content.map(item => {
                        return {
                            label: item.inventoryOrganizationName,
                            value: item.id
                        };
                    });
                    if (todoFlag) return;
                    if (this.inventoryOrganizationArr.length) {
                        this.tableQueryAttr.inventoryOrganizationId = this.inventoryOrganizationArr[0].value;
                    }
                    // 仓库下拉
                    const warehouseRes = await getWarehouseDropList({
                        inventoryOrganizationId: this.tableQueryAttr.inventoryOrganizationId
                    });
                    if (warehouseRes.status === this.code) {
                        this.warehouseArr = warehouseRes.content.map(item => {
                            return {
                                label: item.warehouseName,
                                value: item.id
                            };
                        });
                        if (this.warehouseArr.length) {
                            this.tableQueryAttr.warehouseId = this.warehouseArr[0].value;
                        }
                        if (cb && typeof cb === 'function') cb();
                    }
                }
            },
            // 下载模板
            download () {
                window.open(process.env.NODE_ENV === 'development' ? environmentConfig('inventoryInitDownload') : window.location.origin + environmentConfig('inventoryInitDownload'));
            },
            handleFormatError () {
                this.$Message.error({
                    content: '请上传EXCEL表格类型模板',
                    duration: 2.5
                });
            },
            upError () {
                this.$Message.error({
                    content: '模板上传失败，请重试',
                    duration: 2.5
                });
            },
            upSuccess (response, file, fileList) {
                if (response.status === 10000) {
                    this.$Message.success({
                        content: response.msg,
                        duration: 2.5
                    });
                    this.getTableList(true);
                } else {
                    this.$Message.error({
                        content: response.msg,
                        duration: 2.5
                    });
                }
            },
            // 新增修改
            addEdit () {
                if (this.inventoryOrganizationId && this.warehouseId) {
                    this.addItem('库存初始化');
                    this.cusData = [...this.erpTableData];
                    console.log(this.unitNameArr);
                    console.log(this.cusData);
                } else {
                    this.$Message.error('请先选择库存组织和仓库');
                }
            },
            // 提交
            async submit () {
                this.$Modal.confirm({
                    title: `确认提交吗？`,
                    onOk: async () => {
                        const params = {
                            warehouseId: this.warehouseId,
                            inventoryOrganizationId: this.inventoryOrganizationId
                        };
                        const res = await submitInventoryInit(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getTableList(true);
                        }
                    }
                });
            },
            // 初始化完成
            async initComplete () {
                this.$Modal.confirm({
                    title: `确认完成初始化吗？`,
                    onOk: async () => {
                        const params = {
                            warehouseId: this.warehouseId,
                            inventoryOrganizationId: this.inventoryOrganizationId
                        };
                        const res = await completeInventoryInit(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getTableList(true);
                        }
                    }
                });
            },
            searchCst () {
                this.tableComAttr.pageNo = 1;
                this.getTableList(true);
            },
            searchInventoryCst () {
                this.tableComAttr.pageNo = 1;
                this.tableQueryAttr.warehouseId = '';
                this.getTableList(true);
            },
            modalCancelCst () {
                this.modalShowFlag = false;
                this.unitNameArr = [];
            },
            // 判断初始化信息是否填写完毕
            checkInitDataIsComplete (arr) {
                const checkList = ['commodityId', 'supplierId', 'initPrice', 'quantity', 'currencyId',
                                   'batchNo', 'goodsLocationCode', 'producedDate', 'effectiveDate', 'commodityPackageId',
                                   'inboundUserName', 'acceptanceUserName', 'acceptanceOperaUserName', 'putawayUserName',
                                   'producedDateFormat', 'effectiveDateFormat', 'approvalCode'
                ];
                return arr.every(item => {
                    return checkList.every(i => {
                        return item[i];
                    });
                });
            },
            // 保存
            async modalOk () {
                if (!this.checkInitDataIsComplete(this.cusData)) {
                    this.$Message.error('请填写完毕后保存或提交');
                    return this.changeLoading();
                }
                const params = {
                    items: this.cusData,
                    warehouseId: this.warehouseId,
                    inventoryOrganizationId: this.inventoryOrganizationId
                };
                const res = await saveInventoryInit(params);
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.modalCancelCst();
                    this.getTableList(true);
                    console.log(this.unitNameArr);
                    console.log(this.cusData);
                } else {
                    this.changeLoading();
                }
            },
            // 提交
            modalOkSubmit (cb) {
                this.$Modal.confirm({
                    title: `确认提交吗？`,
                    onOk: async () => {
                        const params = {
                            items: this.cusData,
                            warehouseId: this.warehouseId,
                            inventoryOrganizationId: this.inventoryOrganizationId
                        };
                        const res = await saveInventoryInit(params);
                        if (res.status === this.code) {
                            const paramsBak = {
                                warehouseId: this.warehouseId,
                                inventoryOrganizationId: this.inventoryOrganizationId
                            };
                            const result = await submitInventoryInit(paramsBak);
                            if (result.status === this.code) {
                                this.$Message.success(result.msg);
                                this.modalCancelCst();
                                this.getTableList(true);
                                console.log(this.unitNameArr);
                            }
                        } else {
                            this.changeLoading();
                        }
                    }
                });
            },
            // 弹框新增
            modalAdd () {
                resetObj(this.tplObj);
                this.tplObj.producedDateFormat = 'yyyy-MM-dd';
                this.tplObj.effectiveDateFormat = 'yyyy-MM-dd';
                this.cusData.push(this.tplObj);
            },
            // 获取本公司的物料列表
            async getCompanyMaterialList () {
                console.log(123123);
                this.materielTableLoading = true;
                const params = Object.assign(
                    {},
                    this.materielComAttr,
                    this.materielTableQuery
                );
                console.log(params);
                const res = await getCompanyMaterialList(params);
                this.materielTableLoading = false;
                if (res.status === this.code) {
                    this.materielTableData = res.content.list;
                    this.materielTotal = res.content.total;
                }
            },
            // 获取本公司的供应商列表
            async getAllSupplierList () {
                this.materielTableLoading = true;
                const params = Object.assign(
                    {},
                    this.materielComAttr,
                    this.materielTableQuery
                );
                const res = await getAllSupplierList(params);
                this.materielTableLoading = false;
                if (res.status === this.code) {
                    this.materielTableData = res.content.list;
                    this.materielTotal = res.content.total;
                }
            },
            // 搜索物料或者供应商列表
            materielSearch () {
                if (!this.materielTodoFlag) {
                    this.getAllSupplierList();
                    return;
                }
                this.getCompanyMaterialList();
            },
            // 重置物料或者供应商搜索
            materielReset () {
                resetObj(this.materielTableQuery);
                this.materielComAttr.pageNo = 1;
                if (!this.materielTodoFlag) {
                    this.getAllSupplierList();
                    return;
                }
                this.getCompanyMaterialList();
            },
            // 改变物料或者供应商每页数量
            materielPageSizeChange (value) {
                this.materielComAttr.pageNo = 1;
                this.materielComAttr.pageSize = value;
                if (!this.materielTodoFlag) {
                    this.getAllSupplierList();
                    return;
                }
                this.getCompanyMaterialList();
            },
            // 改变物料或者供应商页码
            materielPageNoChange (value) {
                this.materielComAttr.pageNo = value;
                if (!this.materielTodoFlag) {
                    this.getAllSupplierList();
                    return;
                }
                this.getCompanyMaterialList();
            }
        },
        computed: {
            inventoryOrganizationId () {
                return this.tableQueryAttr.inventoryOrganizationId;
            },
            warehouseId () {
                return this.tableQueryAttr.warehouseId;
            },
            headers () {
                return {
                    'Access-Token-Erp': getToken(),
                    'Access-SSOToken-Chain': getSSOToken()
                };
            },
            action () {
                return environmentConfig('inventoryInitUpload');
            },
            uploadData () {
                return {
                    warehouseId: this.tableQueryAttr.warehouseId,
                    inventoryOrganizationId: this.tableQueryAttr.inventoryOrganizationId
                };
            },
            inventoryOrganizationName () {
                for (let i = 0, len = this.inventoryOrganizationArr.length; i < len; i++) {
                    if (this.inventoryOrganizationArr[i].value === this.inventoryOrganizationId) {
                        return this.inventoryOrganizationArr[i].label;
                    }
                }
            },
            warehouseName () {
                for (let i = 0, len = this.warehouseArr.length; i < len; i++) {
                    if (this.warehouseArr[i].value === this.warehouseId) {
                        return this.warehouseArr[i].label;
                    }
                }
            },
            detailNumber () {
                return this.erpTableData.length;
                // return this.cusData.length;
            },
            totalMoney () {
                let str = '';
                if (!this.moneyArr.length) return 0;
                this.moneyArr.forEach(item => {
                    if (str) {
                        str += ', ';
                    }
                    str += `${item.currencyName}${item.initAmount}`;
                });
                return str;
            },
            checkDataInventoryStatus () {
                if (!this.erpTableData.length) return false;
                return this.erpTableData[0].inventoryStatus;
            }
        },
        watch: {
            async inventoryOrganizationId (val) {
                if (val) {
                    // 仓库下拉
                    const warehouseRes = await getWarehouseDropList({
                        inventoryOrganizationId: this.tableQueryAttr.inventoryOrganizationId
                    });
                    if (warehouseRes.status === this.code) {
                        this.warehouseArr = warehouseRes.content.map(item => {
                            return {
                                label: item.warehouseName,
                                value: item.id
                            };
                        });
                    }
                }
            }
        }
    };
</script>

<style scoped lang="less">
    .upload {
        position: relative;
        float: left;
        margin-right: -1px;
        z-index: 1;
        .ivu-btn {
            border-bottom-right-radius: 0;
            border-top-right-radius: 0;
        }
    }

    .ivu-btn-default {
        .down {
            color: #515a6e;
        }
        &:hover {
            .down {
                color: #2d8cf0;
            }
        }
    }

    .modalAdd {
        position: relative;
        button {
            position: absolute;
            top: -20px;
            right: 0;
        }
    }

    .maxWidth {
        font-size: 13px;
        font-weight: bold;
        margin-bottom: 10px;
    }
</style>
