<template>
    <div>
        <!-- <h1>销售订单管理</h1> -->
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.customerId"
                        @on-change="search"
                        filterable
                        placeholder="客户"
                        ref="filter"
                    >
                        <Option
                            v-for="(item,index) in customerArr"
                            :key="index"
                            :label="item.customerName"
                            :value="item.customerId"
                        ></Option>
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <DatePicker
                        v-model="tableQueryAttr.startDate"
                        type="date"
                        placeholder="选择开始束日期"
                    ></DatePicker>
                </Col>
                <Col span="5" class="maxWidth">
                    <DatePicker v-model="tableQueryAttr.endDate" type="date" placeholder="选择结束日期"></DatePicker>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.orderStatus"
                        @on-change="search"
                        placeholder="请选择状态"
                    >
                        <Option label="未提交" :value="0"></Option>
                        <Option label="审核中" :value="1"></Option>
                        <Option label="已审核" :value="2"></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>销售订单列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="add" v-has="btnRightList.saleOrderSave" icon="md-add">新增</Button>
                    <Button
                        @click="addRed"
                        v-has="btnRightList.saleOrderRedSave"
                        icon="ios-add-circle"
                    >新增红字</Button>
                    <Button
                        @click="mulSubmit"
                        v-has="btnRightList.saleOrderSubmit"
                        icon="md-send"
                    >提交</Button>
                    <Button
                        @click="mulReturn"
                        v-has="btnRightList.saleOrderReturn"
                        icon="ios-arrow-back"
                    >撤回</Button>
                    <Button @click="mulDel" v-has="btnRightList.saleOrderDel" icon="ios-trash">删除</Button>
                    <Button @click="mulAudit" v-has="btnRightList.saleOrderPass" icon="md-cube">审核</Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                @on-selection-change="selectionChange"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
                ref="managerTable"
            ></erp-table>
        </Card>
        <!-- 客户物料选择框 -->
        <Modal
            v-model="materialModal"
            width="960"
            title="选择客户物料"
            :mask-closable="false"
            @on-ok="materialOk"
            @on-close="materialClose"
        >
            <Card>
                <Form class="mb10">
                    <Row :gutter="18">
                        <Col span="6">
                            <Input v-model="searchAttr.commodityName" placeholder="物料名称"></Input>
                        </Col>
                        <Col span="6">
                            <Input v-model="searchAttr.specializedGroupName" placeholder="专业分组"></Input>
                        </Col>
                        <Col span="6">
                            <Input v-model="searchAttr.commodityNumber" placeholder="货号"></Input>
                        </Col>
                        <Col span="4">
                            <Button @click="searchMaterial">搜索</Button>
                        </Col>
                    </Row>
                </Form>
                <div class="clearfix">
                    <Table
                        @on-selection-change="materialSelectChange"
                        :data="materialTable"
                        :columns="materialTitle"
                        :loading="materialLoading"
                        border
                    ></Table>
                    <div class="wrapper-page">
                        <Page
                            :current="searchAttr.pageNo"
                            @on-change="materialPageChange"
                            @on-page-size-change="materialSizeChange"
                            show-sizer
                            :total="searchAttr.total"
                        ></Page>
                    </div>
                </div>
            </Card>
        </Modal>
        <!-- 修改单个物料弹框 -->
        <Modal v-model="mUpdateModal" width="960" title="选择客户物料" :mask-closable="false">
            <Card>
                <Form class="mb10">
                    <Row :gutter="18">
                        <Col span="6">
                            <Input v-model="updateAttr.commodityName" placeholder="物料名称"></Input>
                        </Col>
                        <Col span="6">
                            <Input v-model="updateAttr.specializedGroupName" placeholder="专业分组"></Input>
                        </Col>
                        <Col span="4">
                            <Button @click="updateSearch">搜索</Button>
                        </Col>
                    </Row>
                </Form>
                <div class="clearfix">
                    <Table
                        :data="updateTable"
                        :columns="updateTitle"
                        border
                        :loading="updateLoading"
                    ></Table>
                    <div class="wrapper-page">
                        <Page
                            :current="updateAttr.pageNo"
                            @on-change="updatePageChange"
                            @on-page-size-change="updateSizeChange"
                            show-sizer
                            :total="updateAttr.total"
                        ></Page>
                    </div>
                </div>
            </Card>
            <div slot="footer"></div>
        </Modal>

        <!-- 选择单价Modal -->
        <Modal title="单价选择" v-model="priceModal" width="960" :mask-closable="false">
            <Card :border="false">
                <Table :data="priceData" :columns="priceTitle" border :loading="pricelLoading"></Table>
            </Card>
            <div slot="footer"></div>
        </Modal>

        <!-- 凭证Modal -->
        <Modal
            v-model="licenseModal"
            :title="licenseId?'编辑附件':'上传附件'"
            @on-ok="licenseOk"
            @on-cancel="licenseClose"
            :mask-closable="false"
        >
            <Form :model="licenseModel" :label-width="120">
                <FormItem label="资料类型">
                    <Select
                        v-model="licenseModel.saleOrderAttachType"
                        :disabled="formAttr.orderStatus===2"
                    >
                        <Option
                            v-for="item in licenseTypeArr"
                            :key="item.index"
                            :label="item.fieldValue"
                            :value="item.id"
                        ></Option>
                    </Select>
                </FormItem>
                <FormItem label="内容描述">
                    <Input
                        v-model="licenseModel.remark"
                        :disabled="formAttr.orderStatus===2"
                        placeholder="内容描述"
                    ></Input>
                </FormItem>
                <FormItem label="附件">
                    <Upload
                        type="select"
                        accept="image/*, .pdf"
                        multiple
                        action="''"
                        :before-upload="handleBeforeUpload"
                        class="mb10"
                    >
                        <Button
                            :disabled="formAttr.orderStatus===2"
                            icon="ios-cloud-upload-outline"
                        >选择</Button>
                    </Upload>
                </FormItem>
            </Form>
            <!-- 已上传文件表格 -->
            <Table border :columns="fileTitle" :data="fileData">
                <template slot-scope="{ row, index }" slot="index">
                    <span>{{ index+1 }}</span>
                </template>
                <template slot-scope="{ row }" slot="documentName">
                    <span>{{ row.documentName }}</span>
                </template>

                <template slot-scope="{ row }" slot="status">
                    <span v-if="row.documentUrl">已上传</span>
                    <Spin v-else>
                        <Icon type="ios-loading" size="22" style="color: #3399ff"></Icon>
                    </Spin>
                </template>
                <template slot-scope="{ row,index }" slot="operate">
                    <ButtonGroup>
                        <Button @click="delFile(row)" type="error" size="small">删除</Button>
                    </ButtonGroup>
                </template>
            </Table>
        </Modal>
        <!-- 红字订单Modal -->
        <Modal v-model="redModal" title="销售订单选择" width="960" :mask-closable="false">
            <Row :gutter="18" class="mb10 z10">
                <Col span="6">
                    <Select
                        v-model="detailAttr.customerEnableCode"
                        @on-change="getAllDetail"
                        placeholder="选择客户"
                        filterable
                        ref="filter"
                    >
                        <Option
                            v-for="(item,index) in customerArr"
                            :key="index"
                            :label="item.customerName"
                            :value="item.customerEnableCode"
                        ></Option>
                    </Select>
                </Col>
                <Col span="6">
                    <DatePicker v-model="detailAttr.startDate" placeholder="选择开始日期"></DatePicker>
                </Col>
                <Col span="6">
                    <DatePicker v-model="detailAttr.endDate" placeholder="选择结束日期"></DatePicker>
                </Col>
                <Col span="6">
                    <Button type="primary" @click="redSearch">搜索</Button>
                </Col>
            </Row>
            <div class="clearfix">
                <Table
                    :data="TableRed"
                    :columns="titleRed"
                    @on-selection-change="redselectionChange"
                    :loading="redLoading"
                    border
                ></Table>
                <div class="wrapper-page">
                    <Page
                        :current="detailPage.pageNo"
                        @on-change="redPageChange"
                        @on-page-size-change="redSizeChange"
                        show-sizer
                        :total="detailPage.total"
                    ></Page>
                </div>
            </div>

            <div slot="footer">
                <Button @click="redClose">关闭</Button>
                <Button @click="redOk" type="success">选择</Button>
            </div>
        </Modal>
        <!-- 编辑框Modal -->
        <Modal
            v-model="modalShowFlag"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            fullscreen
            @on-cancel="onClose"
        >
            <Form :model="formAttr" :rules="ruleValidate" ref="formValidate" :label-width="120">
                <Row :gutter="12">
                    <Col span="8">
                        <FormItem label="订单类型" prop="orderType">
                            <Select
                                v-model="formAttr.orderType"
                                placeholder="订单类型"
                                :disabled="isRed||readonly"
                                @on-change="typeChange"
                            >
                                <Option
                                    v-for="(item,index) in orderTypeArr"
                                    :key="index"
                                    :label="item.fieldValue"
                                    :value="item.id"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="客户" prop="customerId">
                            <Select
                                v-model="formAttr.customerId"
                                @on-change="getCustomerMaterial(false)"
                                placeholder="客户"
                                :disabled="isRed||readonly"
                                filterable
                                ref="filter"
                            >
                                <Option
                                    v-for="(item,index) in customerArr"
                                    :key="index"
                                    :label="item.customerName"
                                    :value="item.customerId"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="销售部门" prop="saleDepartment">
                            <Select v-model="formAttr.saleDepartment" :disabled="isRed||readonly">
                                <Option
                                    v-for="(item,index) in departmentArr"
                                    :key="index"
                                    :label="item.fieldValue"
                                    :value="item.id"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                </Row>
                <Row :gutter="12">
                    <Col span="8">
                        <FormItem label="开票方式" prop="invoiceType">
                            <Select v-model="formAttr.invoiceType" :disabled="isRed||readonly">
                                <Option
                                    v-for="(item,index) in invoiceArr"
                                    :key="index"
                                    :label="item.fieldValue"
                                    :value="item.id"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="出库类型" prop="outboundType">
                            <Select v-model="formAttr.outboundType" :disabled="isRed||readonly">
                                <Option
                                    v-for="(item,index) in outboundTypeArr"
                                    :key="index"
                                    :label="item.fieldValue"
                                    :value="item.id"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="核算年月" prop="accountingDate">
                            <DatePicker
                                v-model="formAttr.accountingDate"
                                type="month"
                                placeholder="年/月/日"
                                :disabled="isRed||readonly"
                            ></DatePicker>
                        </FormItem>
                    </Col>
                </Row>
                <Row :gutter="12">
                    <Col span="16">
                        <FormItem label="订单摘要">
                            <Input
                                v-model="formAttr.orderRemark"
                                :disabled="isRed||readonly"
                                placeholder="订单摘要"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="业务员" prop="salerId">
                            <Select v-model="formAttr.salerId" :disabled="isRed||readonly">
                                <Option
                                    v-for="(item,index) in saleArr"
                                    :key="index"
                                    :label="item.salerName"
                                    :value="item.id"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                </Row>
                <Row :gutter="12">
                    <Col span="8">
                        <FormItem label="制单人">
                            <Input v-model="getUserName" placeholder="制单人" disabled></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="制单日期">
                            <DatePicker v-model="makeTime" type="date" placeholder="年/月/日" disabled></DatePicker>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="状态">
                            <Input v-model="status" placeholder="状态" disabled></Input>
                        </FormItem>
                    </Col>
                </Row>
            </Form>
            <Card dis-hover :bordered="false">
                <div slot="extra">
                    <ButtonGroup class="z10">
                        <Button
                            v-if="!isRed&&formAttr.orderStatus!==2||!readonly"
                            @click="tabAdd"
                            type="primary"
                        >新增</Button>
                    </ButtonGroup>
                </div>
                <Tabs v-model="tabIndex" @on-click="tabsBind" type="card">
                    <TabPane label="订单明细">
                        <Table :data="tableDetail" :columns="detailTitle" height="400" border>
                            <!-- 操作 -->
                            <template
                                slot-scope="{row,index}"
                                slot="operate"
                                v-if="!isRed||readonly"
                            >
                                <ButtonGroup>
                                    <Button
                                        size="small"
                                        v-if="formAttr.orderStatus!==2"
                                        @click="detailDel(row,index)"
                                    >删除</Button>
                                    <Button
                                        size="small"
                                        type="success"
                                        @click="detailInsert(row,index)"
                                        v-if="formAttr.orderStatus!==2"
                                    >插入</Button>
                                </ButtonGroup>
                            </template>
                        </Table>
                    </TabPane>
                    <template v-if="formAttr.id">
                        <TabPane label="订单凭证">
                            <Table :data="tableLicense" :columns="detailLicense" border>
                                <template
                                    v-if="!isRed||readonly"
                                    slot-scope="{row,index}"
                                    slot="operate"
                                >
                                    <ButtonGroup>
                                        <Button
                                            type="primary"
                                            size="small"
                                            @click="licenseEdit(row)"
                                        >{{formAttr.orderStatus===2?'查看':'编辑'}}</Button>
                                        <Button
                                            type="error"
                                            size="small"
                                            @click="licenseDel(row)"
                                            v-if="formAttr.orderStatus!=2"
                                        >删除</Button>
                                    </ButtonGroup>
                                </template>
                            </Table>
                        </TabPane>
                    </template>
                </Tabs>
            </Card>
            <div slot="footer">
                <Button @click="onClose">关闭</Button>
                <Button type="info" @click="save" v-if="!readonly||isRed">保存</Button>
                <Button type="primary" @click="submit()" v-if="!readonly||isRed">提交</Button>
            </div>
        </Modal>
    </div>
</template>

<script>
    import { mapGetters } from 'vuex';
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { getRecordList } from '@/api/masterData/customer.js';
    import { uploadFile } from '@/api/upload';
    import { getCompanySalesmanList } from '@/api/saleManage/saleGroup';
    import { getSaveCustomerList } from '@/api/saleManage/sale';
    import { getCustomerInfo } from '@/api/customerMaterial/materialInfo';
    import { getSalePriceUnSafe } from '@/api/customerMaterial/materialMoney';
    import {
        getOrderList,
        getOrderDetail,
        saleOrderDel,
        saleOrderSave,
        saleOrderLicense,
        saleOrderSubmit,
        getRemain,
        licenseDel,
        licenseAdd,
        licenseUpdate,
        saleOrderPass,
        saleOrderRevert,
        getOrderHead,
        redOrderSave,
        saleOrderDelMul,
        saleOrderPassMul,
        saleOrderRevertMul,
        saleOrderSubmitMul
    } from '@/api/saleManage/saleOrder';

    import { delRecord } from '@/api/masterData/customer';
    import { resetObj } from '@/libs/tools';
    export default {
        mixins: [tableMixin],
        components: { ErpTable },
        computed: {
            ...mapGetters(['salerId', 'getUserName'])
        },
        async created () {
            const data = await this.getCustomer();
            if (data.content.length) {
                this.tableQueryAttr.customerId = data.content[0].customerId;
                this.getTableList();
            }
        },
        watch: {
            departmentArr: function (val) {
                if (val && val.length === 1) {
                    this.formAttr.saleDepartment = val[0].id;
                }
            }
        },
        data () {
            return {
                tableDetail: [], // 订单明细数据
                customerArr: [], // 客户数据
                orderTypeArr: [], // 订单类型数据
                saleArr: [], // 业务员下拉数据(当前公司下的销售员)
                outboundTypeArr: [], // 出库单类型
                outSourceArr: [], // 出库单类型源数据
                invoiceArr: [], // 开票方式
                departmentArr: [], // 部门数据
                isRed: false, // 是否为红字订单，除数量外，任何数据不可编辑
                readonly: false, // 查看
                tableLicense: [], // 订单凭证数据
                materialArr: [], // 已选择客户的有效物料
                materialModal: false, // 选择物料弹框
                materialTable: [], // 已选择客户的物料数据
                materialSelectData: [], // 物料多选框已选数据
                mUpdateModal: false, // 物料单个选择modal
                updateTable: [], // 修改单个物料
                priceModal: false, // 选择单价modal
                priceData: [], // 单价数据
                licenseModal: false, // 订单凭证Modal
                licenseTypeArr: [], // 订单凭证类型下拉框数据
                licenseId: '', // 凭证id
                fileData: [], // 文件上传记录
                redModal: false, // 红字销售订单弹框
                redSelect: [], // 红字订单已选择数据
                TableRed: [], // 红字订单表格数据
                materialIndex: null, // 记录物料选择操作行
                materialLoading: false,
                updateLoading: false,
                pricelLoading: false,
                redLoading: false,
                // 物料搜索条件
                searchAttr: {
                    commodityName: '',
                    specializedGroupName: '',
                    commodityNumber: '', // 货号
                    pageNo: 1,
                    pageSize: 10,
                    total: 0
                },
                // 物料单个选择搜索条件
                updateAttr: {
                    commodityName: '',
                    specializedGroupName: '',
                    commodityNumber: '', // 货号
                    pageNo: 1,
                    pageSize: 10,
                    total: 0
                },

                // 订单明细搜索条件
                detailAttr: {
                    customerId: null,
                    customerEnableCode: '',
                    startDate: '',
                    endDate: ''
                },
                detailPage: {
                    pageNo: 1,
                    pageSize: 10,
                    total: 0
                },
                tabIndex: 0,
                formAttr: {
                    id: null,
                    orderType: '',
                    customerId: '',
                    customerEnableCode: '',
                    saleDepartment: '',
                    invoiceType: '',
                    outboundType: '',
                    accountingDate: this.getDate(new Date()),
                    orderRemark: '',
                    salerId: '',
                    orderStatus: '',
                    items: []
                },
                makeTime: new Date(),
                status: '未提交',
                tableQueryAttr: {
                    customerId: '',
                    startDate: '',
                    endDate: '',
                    orderStatus: ''
                },
                // 订单凭证表单
                licenseModel: {
                    remark: '',
                    saleOrderAttachType: '',
                    saleOrderId: '',
                    records: []
                },
                // 红字订单表头
                titleRed: [
                    {
                        type: 'selection',
                        title: '选择',
                        align: 'center',
                        minWidth: 80
                    },
                    {
                        title: '客户',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerName'
                    },
                    {
                        title: '订单类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'orderTypeName'
                    },
                    {
                        title: '出库类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'outboundTypeName'
                    },
                    {
                        title: '核算年月',
                        align: 'center',
                        minWidth: 100,
                        // key: 'accountingDate'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.accountingDate)
                            );
                        }
                    },
                    {
                        title: '物料编码',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerCommodityId'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 100,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '发货数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'quantity'
                    },
                    {
                        title: '剩余数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'planLeftQuantity'
                    },
                    {
                        title: '单价',
                        align: 'center',
                        minWidth: 100,
                        key: 'salePrice'
                    },
                    {
                        title: '币种',
                        align: 'center',
                        minWidth: 100,
                        key: 'currencyName'
                    },
                    {
                        title: '税率',
                        align: 'center',
                        minWidth: 100,
                        key: 'taxRate'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 100,
                        key: 'unitName'
                    },
                    {
                        title: '金额',
                        align: 'center',
                        minWidth: 100,
                        key: 'amount'
                    },
                    {
                        title: '要求到货',
                        align: 'center',
                        minWidth: 100,
                        // key: 'arriveDate'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.arriveDate, 'long')
                            );
                        }
                    },
                    {
                        title: '要求效期',
                        align: 'center',
                        minWidth: 100,
                        // key: 'effectiveDate'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.effectiveDate, 'long')
                            );
                        }
                    },
                    {
                        title: '录入时间',
                        align: 'center',
                        minWidth: 100,
                        // key: 'createTime',
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.createTime, 'long')
                            );
                        }
                    }
                ],
                priceTitle: [
                    {
                        title: '单价',
                        align: 'center',
                        minWidth: 100,
                        key: 'price'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 100,
                        key: 'unitName'
                    },
                    {
                        title: '币种',
                        align: 'center',
                        minWidth: 100,
                        key: 'currencyName'
                    },
                    {
                        title: '税率',
                        align: 'center',
                        minWidth: 100,
                        key: 'taxRate'
                    },
                    {
                        title: '客户',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerName'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {
                                        type: 'success',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            this.priceSelect(params.row);
                                        }
                                    }
                                },
                                '选择'
                            );
                        }
                    }
                ],
                materialTitle: [
                    {
                        type: 'selection',
                        align: 'center',
                        minWidth: 60
                    },
                    {
                        title: '常用名称',
                        align: 'center',
                        minWidth: 180,
                        key: 'commodityName'
                    },
                    {
                        title: '物料规格',
                        align: 'center',
                        minWidth: 180,
                        key: 'commoditySpec'
                    },
                    {
                        title: '库存数量',
                        align: 'center',
                        minWidth: 120,
                        key: 'inventoryQuantity'
                    },
                    {
                        title: '货号',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityNumber'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 180,
                        key: 'brandName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 180,
                        key: 'specializedGroupName'
                    }
                ],
                updateTitle: [
                    {
                        title: '常用名称',
                        align: 'center',
                        minWidth: 180,
                        key: 'commodityName'
                    },
                    {
                        title: '物料规格',
                        align: 'center',
                        minWidth: 180,
                        key: 'commoditySpec'
                    },
                    {
                        title: '库存数量',
                        align: 'center',
                        minWidth: 120,
                        key: 'inventoryQuantity'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 180,
                        key: 'brandName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 180,
                        key: 'specializedGroupName'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {
                                        size: 'small',
                                        type: 'success'
                                    },
                                    on: {
                                        click: () => {
                                            this.materialUpdate(params.row);
                                        }
                                    }
                                },
                                '选择'
                            );
                        }
                    }
                ],
                detailTitle: [
                    {
                        title: '物料编码',
                        align: 'center',
                        fixed: 'left',
                        minWidth: 150,
                        // slot: 'customerCommodityId'
                        render: (h, params) => {
                            let code = params.row.commodityCode;
                            return h(
                                'Button',
                                {
                                    props: {
                                        type: 'info',
                                        size: 'small',
                                        disabled: this.readonly
                                    },
                                    on: {
                                        click: () => {
                                            this.chooseMaterial(params);
                                        }
                                    }
                                },
                                code
                                    ? code.slice(0, 4) +
                                        '...' +
                                        code.slice(code.length - 5)
                                    : '选择物料'
                            );
                        }
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 180,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '数量',
                        align: 'center',
                        minWidth: 120,
                        // slot: 'quantity'
                        render: (h, params) => {
                            return h('InputNumber', {
                                props: {
                                    value: params.row.quantity
                                        ? params.row.quantity
                                        : 0,
                                    min: 0,
                                    disabled: this.isRed ? false : this.readonly,
                                    placeholder: '数量'
                                },
                                on: {
                                    'on-change': val => {
                                        params.row.quantity = val;
                                        // 计算总金额
                                        params.row.total = this.accMul(
                                            params.row.quantity || 0,
                                            params.row.salePrice || 0
                                        );
                                        this.tableDetail[params.index] = params.row;
                                    // console.log(
                                    //     this.tableDetail,
                                    //     params.row.total
                                    // );
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '计划剩余数',
                        align: 'center',
                        minWidth: 80,
                        key: 'planLeftQuantity'
                    },
                    {
                        title: '是否计划内',
                        align: 'center',
                        minWidth: 120,
                        // slot: 'isPlaned'
                        render: (h, params) => {
                            let planData = [
                                { label: '计划内', value: 1 },
                                { label: '计划外', value: 2 }
                            ];
                            return h(
                                'Select',
                                {
                                    props: {
                                        value: params.row.isPlaned,
                                        disabled: this.readonly
                                    },
                                    on: {
                                        'on-change': val => {
                                            this.tableDetail[params.index].isPlaned = val;
                                        }
                                    }
                                },
                                planData.map(item => {
                                    return h('Option', {
                                        props: {
                                            value: item.value,
                                            label: item.label
                                        }
                                    });
                                })
                            );
                        }
                    },
                    {
                        title: '单价',
                        align: 'center',
                        minWidth: 120,
                        // slot: 'salePrice'
                        render: (h, params) => {
                            let price = params.row.salePrice;
                            return h(
                                'Button',
                                {
                                    props: {
                                        type: 'info',
                                        size: 'small',
                                        disabled: this.readonly
                                    },
                                    on: {
                                        click: () => {
                                            this.getAllPrice(params);
                                        }
                                    }
                                },
                                price || (price === 0 ? price : '请选择单价')
                            );
                        }
                    },
                    {
                        title: '币种',
                        align: 'center',
                        minWidth: 100,
                        key: 'currencyName'
                    },
                    {
                        title: '税率',
                        align: 'center',
                        minWidth: 100,
                        key: 'taxRate'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 100,
                        key: 'unitName'
                    },
                    {
                        title: '总金额',
                        align: 'center',
                        minWidth: 100,
                        // key: 'total'
                        render: (h, params) => {
                            // let total = params.row.amount;
                            // if (!total) {
                            let total = this.accMul(
                                params.row.salePrice || 0,
                                params.row.quantity || 0
                            );
                            return h('span', {}, total || 0);
                        }
                    },
                    {
                        title: '要求效期',
                        align: 'center',
                        minWidth: 120,
                        // slot: 'effectiveDate'
                        render: (h, params) => {
                            return h('DatePicker', {
                                props: {
                                    value: this.getDate(
                                        new Date(params.row.effectiveDate)
                                    ),
                                    disabled: this.readonly
                                },
                                on: {
                                    'on-change': val => {
                                        this.tableDetail[params.index].effectiveDate = val;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '要求到货',
                        align: 'center',
                        minWidth: 120,
                        // slot: 'arriveDate'
                        render: (h, params) => {
                            return h('DatePicker', {
                                props: {
                                    value: this.getDate(
                                        new Date(params.row.arriveDate)
                                    ),
                                    disabled: this.readonly
                                },
                                on: {
                                    'on-change': val => {
                                        this.tableDetail[params.index].arriveDate = val;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '录入时间',
                        align: 'center',
                        minWidth: 100,
                        // key: 'createTime'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            const map = {
                                0: '未提交',
                                1: '已提交',
                                2: '已审核'
                            };
                            return h('span', {}, map[params.row.orderItemStatus]);
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 120,
                        fixed: 'right',
                        slot: 'operate'
                    }
                ],
                detailLicense: [
                    {
                        title: '附件类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'dataTypeName'
                    },
                    {
                        title: '内容描述',
                        align: 'center',
                        minWidth: 100,
                        key: 'remark'
                    },
                    {
                        title: '上传日期',
                        align: 'center',
                        minWidth: 100,
                        // key: 'updateTime'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.updateTime)
                            );
                        }
                    },
                    {
                        title: '上传人员',
                        align: 'center',
                        minWidth: 100,
                        key: 'updateName'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        slot: 'operate'
                    }
                ],
                fileTitle: [
                    { title: '序号', align: 'center', slot: 'index' },
                    { title: '文件名', slot: 'documentName', align: 'center' },
                    { title: '状态', align: 'center', slot: 'status' },
                    {
                        title: '操作',
                        align: 'center',
                        slot: 'operate',
                        minWidth: 80
                    }
                ],
                // 表头
                erpTableTitle: [
                    {
                        type: 'selection',
                        align: 'center',
                        minWidth: 60,
                        fixed: 'left'
                    },
                    {
                        title: '订单号',
                        align: 'center',
                        minWidth: 180,
                        // key: 'orderNo',
                        render: (h, params) => {
                            return h(
                                'span',
                                {
                                    class: {
                                        redOrder: params.row.isRedOrder === 1
                                    }
                                },
                                params.row.orderNo
                            );
                        }
                    },
                    {
                        title: '销售组织',
                        align: 'center',
                        minWidth: 100,
                        key: 'saleOrganizationName'
                    },
                    {
                        title: '订单类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'orderTypeName'
                    },
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerName'
                    },
                    {
                        title: '销售部门',
                        align: 'center',
                        minWidth: 100,
                        key: 'saleDepartmentName'
                    },
                    {
                        title: '开票方式',
                        align: 'center',
                        minWidth: 100,
                        key: 'invoiceTypeName'
                    },
                    {
                        title: '出库类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'outboundTypeName'
                    },
                    {
                        title: '核算年月',
                        align: 'center',
                        minWidth: 100,
                        // key: 'accountingDate'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.accountingDate, 'long')
                            );
                        }
                    },
                    {
                        title: '订单摘要',
                        align: 'center',
                        minWidth: 100,
                        key: 'orderRemark'
                    },
                    {
                        title: '制单人',
                        align: 'center',
                        minWidth: 100,
                        key: 'operatorName'
                    },
                    {
                        title: '制单日期',
                        align: 'center',
                        minWidth: 100,
                        // key: 'createTime'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '明细数',
                        align: 'center',
                        minWidth: 100,
                        key: 'totalItems'
                    },
                    {
                        title: '附件数',
                        align: 'center',
                        minWidth: 100,
                        key: 'totalAttachs'
                    },
                    {
                        title: '总金额',
                        align: 'center',
                        minWidth: 100,
                        key: 'totalAmount'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'statusDescription'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 180,
                        fixed: 'right',
                        // key: ''
                        render: (h, params) => {
                            let temp = null;
                            let element = null;
                            if (params.row.orderStatus !== 0) {
                                element = [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                size: 'small',
                                                type: 'success'
                                            },
                                            class: 'mr6',
                                            on: {
                                                click: () => {
                                                    this.readonly = true;
                                                    this.getAllSelectData();
                                                    this.editTableData(
                                                        params,
                                                        `订单编号:${
                                                            params.row.orderNo
                                                        }`,
                                                        this.formatTime
                                                    );
                                                    this.getOrderDetail(); // 获取订单明细
                                                    this.getCustomerMaterial(true); // 获取客户物料
                                                    this.licenseModel.saleOrderId = this.formAttr.id; // 更新凭证的订单id
                                                    this.status =
                                                        params.row.statusDescription; // 更新状态
                                                }
                                            }
                                        },
                                        '查看'
                                    )
                                ];
                            }
                            if (params.row.orderStatus === 0) {
                                temp = [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                size: 'small',
                                                type: 'info'
                                            },
                                            class: 'mr6',
                                            on: {
                                                click: () => {
                                                    this.submit(params.row.id);
                                                }
                                            }
                                        },
                                        '提交'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                size: 'small',
                                                type: 'primary'
                                            },
                                            class: 'mr6',
                                            on: {
                                                click: () => {
                                                    this.getAllSelectData();
                                                    this.editTableData(
                                                        params,
                                                        `订单编号:${
                                                            params.row.orderNo
                                                        }`,
                                                        this.formatTime
                                                    );
                                                    this.getOrderDetail(); // 获取订单明细
                                                    this.getCustomerMaterial(); // 获取客户物料
                                                    this.licenseModel.saleOrderId = this.formAttr.id; // 更新凭证的订单id
                                                    this.status =
                                                        params.row.statusDescription; // 更新状态
                                                }
                                            }
                                        },
                                        '编辑'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                size: 'small',
                                                type: 'error'
                                            },
                                            class: 'mr6',
                                            on: {
                                                click: () => {
                                                    this.orderDel(params.row);
                                                }
                                            }
                                        },
                                        '删除'
                                    )
                                ];
                            }
                            if (params.row.orderStatus === 1) {
                                temp = [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                size: 'small',
                                                type: 'info'
                                            },
                                            class: 'mr6',
                                            on: {
                                                click: () => {
                                                    this.orderPass(params.row.id);
                                                }
                                            }
                                        },
                                        '审核'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                size: 'small',
                                                type: 'success'
                                            },
                                            class: 'mr6',
                                            on: {
                                                click: () => {
                                                    this.orderRevert(params.row.id);
                                                }
                                            }
                                        },
                                        '撤回'
                                    )
                                ];
                            }
                            return h('div', {}, [temp, element]);
                        }
                    }
                ],
                ruleValidate: {
                    orderType: [
                        {
                            required: true,
                            message: '订单类型不可为空'
                        }
                    ],
                    customerId: [
                        {
                            required: true,
                            message: '客户不可为空'
                        }
                    ],
                    saleDepartment: [
                        {
                            required: true,
                            message: '销售部门不可为空'
                        }
                    ],
                    invoiceType: [
                        {
                            required: false,
                            message: '开票方式不可为空'
                        }
                    ],
                    outboundType: [
                        {
                            required: true,
                            message: '出库类型不可为空'
                        }
                    ],
                    accountingDate: [
                        {
                            required: true,
                            message: '核算年月不可为空'
                        }
                    ],
                    salerId: [
                        {
                            required: true,
                            message: '业务员不可为空'
                        }
                    ]
                }
            };
        },
        methods: {
            // 新增
            add () {
                this.addItem('订单编号');
                this.getAllSelectData();
                this.formAttr.accountingDate = new Date();
            },

            // 销售订单保存
            async save () {
                // 计划外不校验计划剩余数，计划内校验
                const isOut = this.tableDetail.length && this.tableDetail.every(item => {
                    return (
                        item.isPlaned &&
                        item.isPlaned === 1 &&
                        Number(item.quantity) > Number(item.planLeftQuantity)
                    );
                });
                if (isOut) {
                    this.$Message.error('计划内订单数量超过剩余计划数');
                    return;
                }
                if (this.isRed) {
                    // 合并数据
                    this.combineForm();
                    const res = await redOrderSave(
                        Object.assign({}, this.formAttr, {
                            accountingDate: this.getDate(
                                new Date(this.formAttr.accountingDate).valueOf()
                            )
                        })
                    );
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                        this.onClose();
                    }
                } else {
                    let result = this.checkForm();
                    if (result) return;
                    // 校验明细
                    let isReq = this.tableDetail.every(item => {
                        return (
                            item.customerCommodityId &&
                            (item.salePrice ||
                            item.salePrice === 0 ||
                            item.salePrice === '0')
                        );
                    });
                    if (!isReq) {
                        this.$Message.error('请将订单明细数据填充完整');
                        return;
                    }
                    this.$refs['formValidate'].validate(async valid => {
                        if (!valid) {
                            return this.changeLoading();
                        }
                        // 合并数据
                        this.combineForm();
                        const res = await saleOrderSave(
                            Object.assign({}, this.formAttr, {
                                accountingDate: this.getDate(
                                    new Date(this.formAttr.accountingDate).valueOf()
                                )
                            })
                        );
                        if (res.status === this.code) {
                            this.formAttr.id = res.content.id;
                            this.customerId = res.content.id;
                            this.licenseModel.saleOrderId = res.content.id;
                            this.todoOver(res.msg);
                            this.onClose();
                        }
                    });
                }
            },

            // 合并明细数据
            combineForm () {
                const copy = this.tableDetail.map(item => {
                    const { quantity, effectiveDate, ...arg } = item;
                    return Object.assign({}, arg, {
                        quantity: Number(quantity),
                        effectiveDate: new Date(item.effectiveDate).valueOf()
                    });
                });
                this.formAttr.items = copy;
            },

            // 获取所有审核已通过的订单明细
            async getAllDetail () {
                this.redLoading = true;
                const params = Object.assign({}, this.detailAttr, this.detailPage, {
                    isRed: 1,
                    operatorId: this.salerId,
                    startDate: this.getDate(this.detailAttr.startDate),
                    endDate: this.getDate(this.detailAttr.endDate)
                });
                const res = await getOrderDetail(params);
                if (res.status === this.code) {
                    this.redLoading = false;
                    this.TableRed = res.content.list || res.content;
                    this.detailPage.total = res.content.total;
                } else {
                    this.redLoading = false;
                }
            },
            // 红单搜索
            redSearch () {
                this.detailPage.pageNo = 1;
                this.getAllDetail();
            },
            // 新增红字
            addRed () {
                this.redModal = true;
                this.getCustomer(); // 获取销售员对应的客户
                this.getAllDetail(); // 获取所有已审核通过订单的明细
            },
            // 红字订单明细多选操作
            redselectionChange (e) {
                this.redSelect = e;
            },
            // 红单弹框关闭
            redClose () {
                this.redModal = false;
                this.redSelect = [];
            },
            // 红单分页事件
            redPageChange (val) {
                this.detailPage.pageNo = val;
                this.getAllDetail();
            },

            redSizeChange (val) {
                this.detailPage.pageSize = val;
                this.getAllDetail();
            },

            // 红字订单确认操作
            redOk () {
                // 判断已选明细是否为同一销售订单
                if (this.redSelect.length) {
                    let orderId = this.redSelect[0].saleOrderId;
                    let isSame = this.redSelect.every(item => {
                        return item.saleOrderId === orderId;
                    });
                    if (!isSame) {
                        this.$Message.error('只能选择同一个销售订单下的明细');
                    } else {
                        // 执行红字订单编辑逻辑
                        this.isRed = true;
                        this.redModal = false;
                        this.getOrderHeader(orderId);
                        this.redSelect.forEach((item, index) => {
                            this.tableDetail[index] = item;
                            this.tableDetail[index].redOrderItemId = item.id;
                        });
                        // resetObj(this.detailAttr);
                        this.detailAttr.customerId = '';
                        this.detailAttr.customerEnableCode = '';
                        this.detailAttr.startDate = '';
                        this.detailAttr.endDate = '';
                    }
                } else {
                    this.redModal = false;
                }
            },

            // 根据明细获取订单头信息
            async getOrderHeader (orderId) {
                if (!orderId) return;
                const params = { id: orderId };
                const res = await getOrderHead(params);
                if (res.status === this.code) {
                    // 生成红单时选择明细，根据明细查单头信息，此处执行编辑逻辑
                    this.getAllSelectData(); // 获取系统字段，下拉数据
                    this.editTableData(
                        { row: res.content },
                        `订单编号:${res.content.orderNo}`,
                        this.formatTime
                    );
                    this.status = res.content.statusDescription;
                    this.readonly = true;
                    this.customerId = orderId;
                    this.formAttr.id = null;
                    this.formAttr.redOrderId = orderId;
                    // 所选明细数据 ,格式化日期;
                    this.tableDetail = this.redSelect.map(item => {
                        const { effectiveDate, arriveDate, ...arg } = item;
                        return Object.assign({}, arg, {
                            effectiveDate: this.getDate(item.effectiveDate),
                            arriveDate: this.getDate(item.arriveDate)
                        });
                    });
                }
            },

            // 编辑页新增功能
            tabAdd () {
                if (this.tabIndex) {
                    this.licenseModal = true;
                    this.getLicenseType();
                } else {
                    if (!this.formAttr.customerId) {
                        this.$Message.error('请选择客户');
                        return;
                    }
                    if (!this.formAttr.accountingDate) {
                        this.$Message.error('请选择核算年月');
                        return;
                    }
                    this.materialModal = true;
                    this.materialTable = [...this.materialArr];
                // this.tableDetail.push({
                //     customerCommodityId: '',
                //     quantity: 0,
                //     isPlaned: 2,
                //     // salePrice: null,
                //     effectiveDate: '',
                //     arriveDate: '',
                //     currencyName: ''
                // });
                }
            },

            tabsBind (e) {
                if (e) {
                    // 获取证照列表
                    this.getLicenseList();
                }
            },

            // 选择客户物料
            chooseMaterial (params) {
                this.mUpdateModal = true;
                this.materialIndex = params.index;
                this.updateSearch();
            // this.materialTable = [...this.materialArr];
            },

            // 选择物料确认
            materialOk () {
                this.materialSelectData.forEach(item => {
                    this.tableDetail.push({
                        ...item,
                        isPlaned: 2, // 默认计划外
                        customerCommodityId: item.id,
                        quantity: 0
                    });
                });
                this.tableDetail.forEach((item, index) => {
                    // 获取销售单价
                    this.getPrice({ row: item, index: index });

                    // 获取计划剩余数
                    this.getRemainNumber(item, index);
                });
                // resetObj(this.searchAttr);
                this.searchAttr.commodityName = '';
                this.searchAttr.specializedGroupName = '';
            },

            // 获取计划剩余数
            async getRemainNumber (item, index) {
                const params = {
                    customerCommodityId: item.id,
                    salerId: this.salerId,
                    accountingDate: this.getDate(
                        new Date(this.formAttr.accountingDate)
                    ).slice(0, 7)
                };
                const res = await getRemain(params);
                if (res.status === this.code && res.content) {
                    this.$set(
                        this.tableDetail[index],
                        'planLeftQuantity',
                        res.content.totalLeft || 0
                    );
                } else {
                    this.$set(this.tableDetail[index], 'planLeftQuantity', 0);
                }
            },

            // 物料关闭
            materialClose () {
                this.materialTable = [];
                resetObj(this.searchAttr);
            },

            // 订单凭证编辑
            licenseEdit (row) {
                this.licenseModal = true;
                this.licenseId = row.id;
                this.getLicenseType();
                this.getFile(row);
                Object.assign(this.licenseModel, row);
            },

            // 编辑时获取已上传文件记录
            async getFile (row) {
                const res = await getRecordList({ documentId: row.documentId });
                if (res.status === this.code) {
                    this.fileData = res.content;
                }
            },
            // 凭证modal关闭
            licenseClose () {
                resetObj(this.licenseModel);
                this.licenseModal = false;
                this.licenseId = null;
                this.fileData = [];
            },
            // 上传前置钩子
            handleBeforeUpload (file) {
                const curFile = this.fileData.filter(item => {
                    return item.documentName === file.name;
                });
                if (curFile.length === 0) this.uploadFile(file);
                return false;
            },
            // 文件上传
            async uploadFile (file) {
                let formData = new FormData();
                formData.append('files', file);
                this.fileData.push({
                    documentName: file.name
                });
                const res = await uploadFile(formData);
                if (res.status === this.code) {
                    this.fileData = this.fileData.map(item => {
                        if (
                            item.documentName + '' ===
                            res.content[0].documentName + ''
                        ) {
                            item = Object.assign(item, res.content[0]);
                        }
                        return item;
                    });
                    this.licenseModel.records.push(res.content[0]);
                }
            },

            // 物料选择框搜索
            async searchMaterial () {
                this.materialLoading = true;
                this.searchAttr.pageNo = 1;
                const params = Object.assign({}, this.searchAttr, {
                    salerId: this.salerId,
                    customerEnableCode: this.formAttr.customerEnableCode
                });
                const res = await getCustomerInfo(params);
                if (res.status === this.code) {
                    this.materialLoading = false;
                    this.materialTable = res.content.list;
                    this.searchAttr.total = res.content.total;
                } else {
                    this.materialLoading = false;
                }
            },

            // 物料搜索分页事件
            materialPageChange (val) {
                this.searchAttr.pageNo = val;
                this.searchMaterial();
            },
            // 物料搜索分页事件
            materialSizeChange (val) {
                this.searchAttr.pageSize = val;
                this.searchMaterial();
            },

            // 获取物料所对应的销售单价
            getAllPrice (params) {
                this.priceModal = true;
                this.priceIndex = params.index;
                this.getPrice(params); // 通过物料id查询单价
            },

            // 物料单个修改操作
            updatePageChange (val) {
                this.updateAttr.pageNo = val;
                this.updateSearch();
            },

            updateSizeChange (val) {
                this.updateAttr.pageSize = val;
                this.updateSearch();
            },

            async updateSearch () {
                this.updateLoading = true;
                this.searchAttr.pageNo = 1;
                const params = Object.assign({}, this.updateAttr, {
                    salerId: this.salerId,
                    customerEnableCode: this.formAttr.customerEnableCode
                });
                const res = await getCustomerInfo(params);
                if (res.status === this.code) {
                    this.updateLoading = false;
                    this.updateTable = res.content.list;
                } else {
                    this.updateLoading = false;
                }
            },

            // 单个物料更新操作
            materialUpdate (row) {
                const { effectiveDate, id, ...arg } = row;
                let date = this.getDate(new Date());
                // 当物料上有天数时
                if (row.effectiveDate) {
                    date = this.getDate(new Date(row.effectiveDate));
                } else {
                    if (row.minimumEffectiveDays) {
                        date = this.getDate(
                            new Date(
                                new Date().valueOf() +
                                    Number(row.minimumEffectiveDays) * 26 * 60 * 60
                            )
                        );
                    }
                }
                Object.keys(arg).forEach(item => {
                    this.$set(
                        this.tableDetail[this.materialIndex],
                        item,
                        row[item]
                    );
                });
                this.$set(
                    this.tableDetail[this.materialIndex],
                    'customerCommodityId',
                    id
                );
                this.$set(
                    this.tableDetail[this.materialIndex],
                    'effectiveDate',
                    date
                );

                // 选择物料以后需要更新单价相关数据
                const priceKey = [
                    'salePrice',
                    'currencyName',
                    'currencyId',
                    'taxRate',
                    'unitName',
                    'amount'
                ];
                priceKey.forEach(item => {
                    this.$set(this.tableDetail[this.materialIndex], item, null);
                });
                // 获取剩余计划数
                this.getRemainNumber(row, this.materialIndex);
                // 获取销售单价
                this.getPrice({
                    row: Object.assign({}, row, { customerCommodityId: id }),
                    index: this.materialIndex
                });

                // 重置和关闭弹框
                this.updateAttr.commodityName = '';
                this.updateAttr.specializedGroupName = '';
                this.mUpdateModal = false;
            },

            // 单价选择
            priceSelect (row) {
                if (this.priceIndex > -1) {
                    const updateKey = ['currencyId', 'currencyName', 'packageId', 'price', 'saleOrganizationId', 'taxRate', 'unitCode', 'unitId'];
                    updateKey.forEach(item => {
                        this.$set(
                            this.tableDetail[this.priceIndex],
                            item,
                            row[item]
                        );
                    });
                    // 使用单价上的price字段
                    this.$set(
                        this.tableDetail[this.priceIndex],
                        'salePrice',
                        row.price
                    );
                    this.priceModal = false;
                }
            },

            // 获取物料所有已审核通过的单价
            async getPrice (arg) {
                if (!arg) return;
                const params = {
                    customerCommodityId: arg.row.customerCommodityId
                };
                this.pricelLoading = true;
                const res = await getSalePriceUnSafe(params);
                if (res.status === this.code) {
                    this.pricelLoading = false;
                    this.priceData = res.content;
                    // 当单价只有一条数据时，带上此数据
                    if (res.content.length === 1) {
                        let data = res.content[0];
                        Object.keys(data).forEach(item => {
                            this.$set(
                                this.tableDetail[arg.index],
                                item,
                                data[item]
                            );
                        });
                        // 使用单价上的price字段
                        this.$set(
                            this.tableDetail[arg.index],
                            'salePrice',
                            data.price
                        );
                    }
                } else {
                    this.pricelLoading = false;
                }
            },

            // 获取销售订单明细
            async getOrderDetail () {
                const params = {
                    saleOrderId: this.formAttr.id
                };
                const res = await getOrderDetail(params);
                if (res.status === this.code) {
                    this.tableDetail = res.content.map(item => {
                        return {
                            ...item,
                            total: item.amount
                        };
                    });
                }
            },

            // 物料多选
            materialSelectChange (val) {
                this.materialSelectData = val;
            },
            // 编辑弹框关闭
            onClose () {
                this.modalCancel();
                this.tableDetail = [];
                this.formAttr.id = null;
                this.tabIndex = 0;
                this.isRed = false;
                this.status = '';
                this.readonly = false;
                this.tableLicense = [];
                this.status = '未提交';
            },
            // 表单校验
            checkForm () {
                let valid = false;
                // 借货 领用 赠送必须上传凭证
                let temp = this.orderTypeArr.filter(item => {
                    return item.id === this.formAttr.orderType;
                });
                // let needLicense = ['借货', '领用', '赠送'];
                if (
                    temp.length &&
                    (temp[0].valueCode === 4 ||
                    temp[0].valueCode === 5 ||
                    temp[0].valueCode === 7)
                ) {
                    this.$Message.error('请上传订单凭证');
                    valid = true;
                }
                return valid;
            },
            // 批量提交
            async mulSubmit () {
                if (!this.tableSelectList.length) {
                    this.$Message.error('请选择数据');
                    return;
                }
                const isEqual = this.tableSelectList.every(item => {
                    return item.orderStatus === 0;
                });
                if (!isEqual) {
                    this.$Message.error('请选择状态为未提交的数据');
                    return;
                }
                const params = { ids: this.tableSelectValue };
                const res = await saleOrderSubmitMul(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            // 批量撤回
            async mulReturn () {
                if (!this.tableSelectList.length) {
                    this.$Message.error('请选择数据');
                    return;
                }
                const isEqual = this.tableSelectList.every(item => {
                    return item.orderStatus === 1;
                });
                if (!isEqual) {
                    this.$Message.error('请选择状态为已审核的数据');
                    return;
                }
                const params = { ids: this.tableSelectValue };
                const res = await saleOrderRevertMul(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            // 批量删除
            mulDel () {
                if (!this.tableSelectList.length) {
                    this.$Message.error('请选择数据');
                    return;
                }
                this.$Modal.confirm({
                    title: '确认删除已选择的数据吗',
                    onOk: async () => {
                        const params = { ids: this.tableSelectValue };
                        const res = await saleOrderDelMul(params);
                        if (res.status === this.code) {
                            this.todoOver(res.msg);
                        }
                    }
                });
            },

            // 批量审核
            async mulAudit () {
                if (!this.tableSelectList.length) {
                    this.$Message.error('请选择数据');
                    return;
                }
                const isEqual = this.tableSelectList.every(item => {
                    return item.orderStatus === 1;
                });
                if (!isEqual) {
                    this.$Message.error('请选择状态为审核中的数据');
                    return;
                }
                const params = { ids: this.tableSelectValue };
                const res = await saleOrderPassMul(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },
            accMul (arg1, arg2) {
                let m = 0;
                let s1 = arg1.toString();
                let s2 = arg2.toString();
                try {
                    m += s1.split('.')[1].length;
                } catch (e) {}
                try {
                    m += s2.split('.')[1].length;
                } catch (e) {}
                return (
                    (Number(s1.replace('.', '')) * Number(s2.replace('.', ''))) /
                    Math.pow(10, m)
                );
            },

            // 获取已选择客户有效物料
            async getCustomerMaterial () {
                // 选择客户以后，更新客户所对应的销售部门 取客户的saleDepartment字段
                let saleDep = this.customerArr.filter(item => {
                    return item.id === this.formAttr.customerId;
                });
                if (saleDep.length) {
                    this.formAttr.saleDepartment = saleDep[0].saleDepartment;
                }

                // 用customerEnableCode查物料
                let code = this.customerArr.filter(item => {
                    return item.customerId === this.formAttr.customerId;
                });
                if (code.length) {
                    this.formAttr.customerEnableCode = code[0].customerEnableCode;
                    const params = Object.assign({}, this.searchAttr, {
                        customerEnableCode: code[0].customerEnableCode,
                        salerId: this.salerId
                    });
                    const res = await getCustomerInfo(params);
                    if (res.status === this.code) {
                        this.materialArr = res.content.list;
                        this.searchAttr.total = res.content.total;
                    }
                }
            },

            // 销售订单提交审核
            async submit (id) {
                const params = {
                    id: this.formAttr.id || id
                };
                console.log(id);
                if (!params.id) {
                    this.$Message.error('请先点击保存');
                    return;
                }
                const res = await saleOrderSubmit(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);

                    // 清空formAttr的id
                    this.formAttr.id = null;
                }
            },

            // 订单明细删除
            detailDel (row, index) {
                this.tableDetail.splice(index, 1);
            },

            // 文件删除
            async delFile (e) {
                if (e.id) {
                    const params = {
                        id: e.id
                    };
                    const res = await delRecord(params); // 原先的文件删除接口
                    // 使用ducumentHash作为唯一判断
                    let index = null;
                    this.fileData.forEach((item, i) => {
                        if (item.ducumentHash === e.ducumentHash) {
                            index = i;
                        }
                    });
                    this.fileData.splice(index, 1);
                    if (res.status === this.code) {
                        this.$Message.success(res.msg);
                    }
                } else {
                    let index = null;
                    this.fileData.forEach((item, i) => {
                        if (item.ducumentHash === e.ducumentHash) {
                            index = i;
                        }
                    });
                    this.fileData.splice(index, 1);
                }
            },

            // 订单明细插入
            detailInsert (row, index) {
                const { effectiveDate, arriveDate } = this.tableDetail[index];
                this.tableDetail.splice(index, 0, {
                    effectiveDate: effectiveDate,
                    arriveDate: arriveDate
                });
            },

            // 销售订单审核通过
            async orderPass (id) {
                const res = await saleOrderPass({ id: id });
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },
            // 销售订单撤回
            async orderRevert (id) {
                const res = await saleOrderRevert({ id: id });
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },
            // 销售订单删除
            orderDel (row) {
                this.$Modal.confirm({
                    title: '是否确认删除',
                    onOk: async () => {
                        const res = await saleOrderDel({ id: row.id });
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getTableList();
                        }
                    }
                });
            },

            // 获取业务员下拉数据(当前公司下的销售员)
            async getSaleMan () {
                const params = {};
                const res = await getCompanySalesmanList(params);
                if (res.status === this.code) {
                    this.saleArr = res.content;
                }
            },

            // 获取客户下拉数据
            async getCustomer () {
                const params = {
                    salerId: this.salerId
                };
                const res = await getSaveCustomerList(params);
                if (res.status === this.code) {
                    this.customerArr = res.content;
                    return res;
                }
            },
            // 获取订单凭证列表
            async getLicenseList () {
                const params = { saleOrderId: this.formAttr.id };
                const res = await saleOrderLicense(params);
                if (res.status === this.code) {
                    this.tableLicense = res.content;
                }
            },

            // 订单凭证保存
            async licenseOk () {
                let res = null;
                if (this.licenseId) {
                    this.licenseModel.records = this.fileData;
                    res = await licenseUpdate(this.licenseModel);
                } else {
                    res = await licenseAdd(this.licenseModel);
                }
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.licenseClose();
                    this.getLicenseList();
                }
            },

            // 订单凭证删除
            async licenseDel (row) {
                this.$Modal.confirm({
                    title: '确认删除吗？',
                    onOk: async () => {
                        const res = await licenseDel({ id: row.id });
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getLicenseList();
                        }
                    }
                });
            },

            // 格式化时间
            formatTime () {
                this.formAttr.accountingDate = this.getDate(
                    new Date(this.formAttr.accountingDate).valueOf()
                );
            },
            // 销售订单类型和出库类型偶合
            typeChange (val) {
                let order = this.orderTypeArr.filter(item => {
                    return item.id === val;
                });
                if (order.length) {
                    let out = this.outSourceArr.filter(item => {
                        return item.valueCode === order[0].valueCode;
                    });
                    this.outboundTypeArr = out;
                    if (out.length === 1) {
                        this.formAttr.outboundType = out[0].id;
                    }
                    if (!out.length) {
                        this.formAttr.outboundType = '';
                    }
                }
            },
            // 获取订单凭证下拉框数据;
            getLicenseType () {
                this.getFieldValuesData('sale_order_attach_type', 'licenseTypeArr');
            },

            // 获取下拉框数据
            getAllSelectData () {
                this.getFieldValuesData('outbound_order_type', 'outboundTypeArr'); // 出库单类型
                this.getFieldValuesData('outbound_order_type', 'outSourceArr'); // 出库单类型
                this.getFieldValuesData('order_type', 'orderTypeArr'); // 订单类型
                this.getFieldValuesData('invoice_type', 'invoiceArr'); // 开票方式
                this.getFieldValuesData('sale_department', 'departmentArr'); // 获取销售部门
                this.getSaleMan(); // 获取销售员
                this.getCustomer(); // 获取客户
            },
            // 初始化列表
            getTableList () {
                this.getTableListFn(async getListMixin => {
                    if (!this.tableQueryAttr.customerId) {
                        this.tableLoading = false;
                        return;
                    }
                    let query = {
                        startDate: this.getDate(this.tableQueryAttr.startDate),
                        endDate: this.getDate(this.tableQueryAttr.endDate),
                        orderStatus: this.tableQueryAttr.orderStatus,
                        customerId: this.tableQueryAttr.customerId
                    };
                    const params = Object.assign({}, this.tableComAttr, query);
                    const res = await getOrderList(params);
                    getListMixin(res);
                });
            }
        }
    };
</script>

<style scoped lang="less">
/deep/ .ivu-table-cell {
    .redOrder {
        color: #e53935;
    }
}
</style>
