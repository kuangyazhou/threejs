<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-08 17:31:52
 * @LastEditTime: 2019-08-15 22:30:07
 * @LastEditors: Please set LastEditors
 -->
<template>
    <div class="material-change-purchase">
        <!-- <h1>物料变更申请-采购</h1> -->
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon> 查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        placeholder="常用名称"
                        v-model="tableQueryAttr.commodityName"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        placeholder="物料品牌"
                        v-model="tableQueryAttr.brandName"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.statusList"
                        @on-change="getTableList"
                        placeholder="选择状态"
                    >
                        <Option
                            v-for="item in statusList"
                            :key="item.index"
                            :value="item.value"
                        >{{ item.label }}</Option>
                    </Select>
                </Col>
            </Row>
        </Card>

        <Modal v-model="modalImport" title="物料选择" width="960" :mask-closable="maskClosable">
            <Row class="mb10" :gutter="12">
                <Col span="6">
                    <Input v-model="materialSearch.registerName" placeholder="注册证名称"></Input>
                </Col>
                <Col span="6">
                    <Input v-model="materialSearch.registerNumber" placeholder="注册证号"></Input>
                </Col>
                <Col span="6">
                    <Button type="primary" @click="searchMaterial">搜索</Button>
                </Col>
            </Row>
            <div class="clearfix">
                <Table :data="tableImport" :columns="titleImport">
                    <template slot-scope="{ row }" slot="operate">
                        <Button @click="importSelect(row)" size="small" type="success">选择</Button>
                    </template>
                </Table>
                <div class="wrapper-page">
                    <Page
                        :current="materialPage.pageNo"
                        @on-change="supplierChangePage"
                        @on-page-size-change="supplierChangePageSize"
                        show-sizer
                        :total="materialTotal"
                        show-elevator
                    ></Page>
                </div>
            </div>
            <div slot="footer">
                <Button
                    @click="
                        getTableList();
                        modalImport = false;
                    "
                >关闭</Button>
            </div>
        </Modal>

        <Card>
            <p slot="title"><Icon type="md-list"></Icon>物料变更申请列表</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button
                        @click="bringIn"
                        v-has="btnRightList.materialChangeAdd"
                        icon="md-add"
                    >新增变更</Button>
                    <Button
                        @click="edit"
                        v-has="btnRightList.materialChangeAdd"
                        icon="ios-create-outline"
                    >编辑</Button>
                    <Button
                        @click="approve"
                        v-has="btnRightList.materialChangeAudit"
                        icon="md-send"
                    >发起审批</Button>
                    <Button
                        @click="del"
                        v-has="btnRightList.materialChangeDel"
                        icon="ios-trash-outline"
                    >删除</Button>
                </ButtonGroup>
            </div>
            <erp-table
                ref="managerTable"
                @on-current-change="currentChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                highlight
            ></erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            fullscreen
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="materialModalCancel"
        >
            <Tabs v-model="tabIndex" type="card" @on-click="tabsBind">
                <TabPane label="基础信息">
                    <BaseInfoForm
                        ref="baseInfoForm"
                        @changeLoading="changeLoading"
                        @changeCurrentId="changeCurrentId"
                        @getTableList="getTableList"
                        @isSave="setSave"
                        :oldFormAttr="formAttr"
                        :LevelOneArr="Level1Arr"
                        :LevelTwoArr="Level2Arr"
                        :brandNameArr="brandNameArr"
                        :accountArr="accountArr"
                        :commodityTypeNameArr="commodityTypeNameArr"
                        :deviceClassifyTypeArr="deviceClassifyTypeArr"
                        :deviceClassifyCodeArr="deviceClassifyCodeArr"
                        :coldChainMarkIdArr="coldChainMarkIdArr"
                        :specialGroupArr="specialGroupArr"
                        :organizationId="currentOrganization"
                        :commodityId="commodityId"
                        :qualityChangeReadonly="true"
                        :isChange="true"
                        :readonly="readonly"
                    ></BaseInfoForm>
                </TabPane>
                <template v-if="currentId">
                    <TabPane label="资料上传">
                        <Upload
                            @updateTable="uploadList"
                            :uploadTable="uploadTable"
                            :radioData="radioData"
                            :commodityId="commodityId"
                            :organizationId="currentOrganization"
                            :readonly="readonly"
                        ></Upload>
                    </TabPane>
                    <TabPane label="包装信息">
                        <Package
                            @updateTable="getPackageList"
                            :packageArr="packageArr"
                            :commodityId="commodityId"
                            :organizationId="currentOrganization"
                            :unitArr="unitArr"
                            :readonly="readonly"
                            :isChange="true"
                        ></Package>
                    </TabPane>
                </template>
            </Tabs>
            <div slot="footer">
                    <Button @click="materialModalCancel">取消</Button>
                    <Button @click="modalOk">保存</Button>
                    <Button @click="sendAudit" type="primary">发起审批</Button>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import materialMixin from '@/mixins/materialMixin';

    import { materialImport } from '@/api/material/materialadd';
    import {
        materialChangeList,
        materialChangeSubmit,
        materialChangePass
    } from '@/api/material/materialchange';

    import { BaseInfoForm, Package, Upload } from '_c/material';
    import { getDate } from '@/libs/tools';
    export default {
        components: { ErpTable, BaseInfoForm, Package, Upload },
        mixins: [tableMixin, materialMixin],
        data () {
            return {
                tabIndex: 0,
                tableQueryAttr: {
                    statusList: '',
                    organizationId: '',
                    createUser: ''
                },
                materialPage: {
                    pageNo: 1,
                    pageSize: 10
                },
                materialSearch: {
                    registerName: '',
                    registerNumber: ''
                },
                materialTotal: 0,
                modalImport: false,
                tableImport: [],
                titleImport: [
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '注册证号',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerNumber'
                    },
                    {
                        title: '物料规格',
                        align: 'center',
                        minWidth: 80,
                        key: 'commoditySpec'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 80,
                        key: 'brandName'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 80,
                        slot: 'operate'
                    }
                ],
                erpTableTitle: [
                    {
                        title: '公司',
                        align: 'center',
                        minWidth: 100,
                        key: 'enterpriseName'
                    },
                    {
                        title: '常用名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'registerName'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '分类一级',
                        align: 'center',
                        minWidth: 100,
                        key: 'classifyNameLevel1'
                    },
                    {
                        title: '分类二级',
                        align: 'center',
                        minWidth: 100,
                        key: 'classifyNameLevel2'
                    },
                    {
                        title: '创建人员',
                        align: 'center',
                        minWidth: 100,
                        key: 'createName'
                    },
                    {
                        title: '创建时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '审批状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'statusDescription'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        fixed: 'right',
                        render: (h, params) => {
                            let element = null;
                            if (params.row.status === 1) {
                                element = h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'warning',
                                            size: 'small'
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList
                                                    .materialChangePass
                                            }
                                        ],
                                        on: {
                                            click: (e) => {
                                                if (e && e.stopPropagation) {
                                                    // 非IE
                                                    e.stopPropagation();
                                                } else {
                                                    // IE
                                                    window.event.cancelBubble = true;
                                                }
                                                this.auditPass(params.row);
                                            }
                                        }
                                    },
                                    '通过'
                                );
                            }
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'success',
                                            size: 'small'
                                        },
                                        class: 'mr6',
                                        on: {
                                            click: (e) => {
                                                if (e && e.stopPropagation) {
                                                    // 非IE
                                                    e.stopPropagation();
                                                } else {
                                                    // IE
                                                    window.event.cancelBubble = true;
                                                }
                                                this.editTableData({ row: params.row }, '查看');
                                                this.commodityId = params.row.commodityId;
                                                this.readonly = true;
                                            }
                                        }
                                    },
                                    '查看'
                                ),
                                element
                            ]);
                        }
                    }
                ]
            };
        },
        methods: {
            modalOk () {
                switch (this.tabIndex) {
                    case 0:
                        this.$refs.baseInfoForm.changeSave();
                        break;
                }
            },
            tabsBind (e) {
                switch (e) {
                    case 0:
                        break;
                    case 1:
                        this.uploadList();
                        this.getOldUpload();
                        this.getRadioArr();
                        break;
                    case 2:
                        this.getPackageList();
                        this.getOldPackage();
                        break;
                }
            },

            // 选择引入单据
            importSelect (item) {
                this.getAllSelectData();
                this.editTableData({ row: item }, '物料变更');

                this.commodityId = item.id;
                this.currentId = null;
                this.getOldBaseInfo();
            // console.log(this.formAttr);
            },

            // 获取保存成功返回的id
            changeCurrentId (e) {
                this.currentId = e.id; // 单据ID
                this.commodityId = e.commodityId; // 物料ID
            },

            // 引入物料
            async bringIn () {
                this.modalImport = true;
                const params = {
                    organizationId: this.currentOrganization.id,
                    inEnterpriseId: this.currentDepartment.id
                };
                const res = await materialImport(
                    Object.assign(
                        {},
                        params,
                        this.materialSearch,
                        this.materialPage
                    )
                );
                if (res.status === this.code) {
                    this.tableImport = res.content.list;
                    this.materialTotal = res.content.total;
                }
            },
            searchMaterial () {
                this.materialPage.pageNo = 1;
                this.bringIn();
            },
            supplierChangePage (value) {
                this.materialPage.pageNo = value;
                this.bringIn();
            },

            supplierChangePageSize (value) {
                this.materialPage.pageNo = 1;
                this.materialPage.pageSize = value;
                this.bringIn();
            },
            // 判断基础信息是否保存
            setSave (e) {
                this.hasSaved = e;
                this.getOldBase({ id: this.commodityId }); // 变更后获取基础信息
            },

            // 物料变更审核通过
            async auditPass (row) {
                const params = { id: row.id };
                const res = await materialChangePass(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },
            // 发起审批
            async sendAudit () {
                if (!this.hasSaved) {
                    this.$Message.error('请先点击保存');
                    return;
                }
                const params = {
                    id: this.currentId
                };
                const res = await materialChangeSubmit(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            getTableList () {
                this.getTableListFn(async call => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await materialChangeList(params);
                    call(res);
                });
            }
        }
    };
</script>
