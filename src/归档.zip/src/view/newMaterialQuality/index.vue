<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-10 14:39:46
 * @LastEditTime: 2019-08-15 11:21:31
 * @LastEditors: Please set LastEditors
 -->
<template>
    <div>
        <!-- <h1>新增物料申请-质管</h1> -->
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon> 查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        placeholder="常用名称"
                        v-model="tableQueryAttr.commodityName"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        placeholder="物料品牌"
                        v-model="tableQueryAttr.brandName"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.statusList"
                        @on-change="getTableList"
                        placeholder="选择状态"
                    >
                        <Option
                            v-for="item in typeList"
                            :key="item.index"
                            :value="item.value"
                        >{{ item.label }}</Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card>
            <p slot="title"><Icon type="md-list"></Icon>物料新增申请表</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button
                        @click="edit"
                        v-has="btnRightList.materialQualitySave"
                        icon="ios-create-outline"
                    >编辑</Button>
                    <Button
                        @click="backUp"
                        v-has="btnRightList.materialBackUp"
                        icon="ios-arrow-back"
                    >打回</Button>
                    <Button
                        @click="auditStart"
                        v-has="btnRightList.materialAddAudit"
                        icon="md-send"
                    >发起审批</Button>
                    <Button
                        @click="auditPass"
                        v-has="btnRightList.materialPass"
                        icon="md-arrow-forward"
                    >审批通过</Button>
                </ButtonGroup>
            </div>
            <erp-table
                ref="managerTable"
                @on-current-change="currentChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                highlight
            ></erp-table>
        </Card>

        <Modal v-model="modalImport" title="物料选择" width="600" :mask-closable="false">
            <Table :data="tableImport" :columns="titleImport">
                <template slot-scope="{ row }" slot="operate">
                    <Button @click="importSelect(row)" type="success">选择</Button>
                </template>
            </Table>
            <div slot="footer">
                <Button>关闭</Button>
            </div>
        </Modal>

        <Modal
            v-model="modalShowFlag"
            fullscreen
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="materialModalCancel"
        >
            <Tabs v-model="tabIndex" type="card" @on-click="tabsBind">
                <TabPane label="基础信息">
                    <BaseInfoForm
                        ref="baseInfoForm"
                        @changeLoading="changeLoading"
                        @getTableList="getTableList"
                        :isImport="isImport"
                        :oldFormAttr="formAttr"
                        :LevelOneArr="Level1Arr"
                        :LevelTwoArr="Level2Arr"
                        :brandNameArr="brandNameArr"
                        :accountArr="accountArr"
                        :commodityTypeNameArr="commodityTypeNameArr"
                        :deviceClassifyTypeArr="deviceClassifyTypeArr"
                        :deviceClassifyCodeArr="deviceClassifyCodeArr"
                        :coldChainMarkIdArr="coldChainMarkIdArr"
                        :specialGroupArr="specialGroupArr"
                        :organizationId="currentOrganization"
                        :qualityReadonly="true"
                    ></BaseInfoForm>
                </TabPane>
                <TabPane label="资料上传">
                    <Upload
                        @updateTable="uploadList"
                        :uploadTable="uploadTable"
                        :radioData="radioData"
                        :commodityId="commodityId"
                    ></Upload>
                </TabPane>
                <TabPane label="包装信息">
                    <Package
                        @updateTable="getPackageList"
                        :organizationId="currentOrganization"
                        :packageArr="packageArr"
                        :unitArr="unitArr"
                        :commodityId="commodityId"
                    ></Package>
                </TabPane>
            </Tabs>
        </Modal>
    </div>
</template>
<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import materialMixin from '@/mixins/materialMixin';

    import { BaseInfoForm, Package, Upload } from '_c/material';

    import {
        materialList,
        materialBackUp,
        materialAudit,
        materialPass
    } from '@/api/material/materialadd';

    export default {
        components: { ErpTable, BaseInfoForm, Package, Upload },
        mixins: [tableMixin, materialMixin],
        data () {
            return {
                tabIndex: 0,
                tableImport: [], // 引入物料数据源
                modalImport: false,
                tableQueryAttr: {
                    statusList: 1,
                    organizationId: '',
                    createUser: ''
                },
                titleImport: [
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '注册证号',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerNumber'
                    },
                    {
                        title: '物料规格',
                        align: 'center',
                        minWidth: 80,
                        key: 'commoditySpec'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 80,
                        key: 'brandName'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 80,
                        slot: 'operate'
                    }
                ], // 引入物料表头
                erpTableTitle: [
                    {
                        title: '公司',
                        align: 'center',
                        minWidth: 100,
                        key: 'enterpriseName'
                    },
                    {
                        title: '常用名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'registerName'
                    },
                    {
                        title: '分类一级',
                        align: 'center',
                        minWidth: 100,
                        key: 'classifyNameLevel1'
                    },
                    {
                        title: '分类二级',
                        align: 'center',
                        minWidth: 100,
                        key: 'classifyNameLevel2'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '药品剂型',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityTypeName'
                    },
                    {
                        title: '简易征收',
                        align: 'center',
                        minWidth: 100,
                        // key: 'isSimplelevy'
                        render: (h, params) => {
                            const s = params.row.isSimplelevy;
                            return h('span', {}, s ? '是' : '否');
                        }
                    },
                    {
                        title: '有无配套',
                        align: 'center',
                        minWidth: 100,
                        key: 'hasSet',
                        render: (h, params) => {
                            const s = params.row.hasSet;
                            return h('span', {}, s ? '有' : '无');
                        }
                    },
                    {
                        title: '冷链标识',
                        align: 'center',
                        minWidth: 100,
                        key: 'coldChainMarkName'
                    },
                    {
                        title: '器械类别',
                        align: 'center',
                        minWidth: 100,
                        key: 'deviceClassifyTypeName'
                    },
                    {
                        title: '质保效期',
                        align: 'center',
                        minWidth: 120,
                        // key: 'effectiveDays'
                        render: (h, params) => {
                            let text = null;
                            if (params.row.effectiveDaysShow) {
                                let data = params.row.effectiveDaysShow.split('_');
                                Number(data[0])
                                    ? (text = data[0] + '月')
                                    : (text = `${data[1] || 0}天`);
                            } else {
                                text = params.row.effectiveDays || 0 + '天';
                            }
                            return h('span', {}, text);
                        }
                    },
                    {
                        title: '生产厂家',
                        align: 'center',
                        minWidth: 100,
                        key: 'manufacturerName'
                    },
                    {
                        title: '生产许可',
                        align: 'center',
                        minWidth: 100,
                        key: 'productionLicense'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroup'
                    },
                    {
                        title: '核算人份',
                        align: 'center',
                        minWidth: 100,
                        key: 'accountingOne'
                    },
                    {
                        title: '核算毫升',
                        align: 'center',
                        minWidth: 100,
                        key: 'accountingMl'
                    },
                    {
                        title: '核算名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'accountingName'
                    },
                    {
                        title: '产地属性',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            const s = params.row.isImported;
                            return h('span', {}, s ? '进口' : '国产');
                        }
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'statusDescription',
                        fixed: 'right'
                    }
                ]
            };
        },
        methods: {
            edit () {
                let valid = this.validCurrent();
                if (!valid) return false;
                // 判断订单状态，质管只能编辑质管录入的数据
                if (this.currentRow.status !== 1) {
                    this.$Message.error('只可编辑状态为质管录入的数据');
                    return false;
                }
                this.$refs.managerTable.clearCurrentTableRow();
                this.getAllSelectData();
                this.editTableData({ row: this.currentRow }, '编辑物料');
                this.commodityId = this.currentRow.commodityId;
            },

            // 打回
            async backUp () {
                let valid = this.validCurrent();
                if (!valid) return false;
                this.$refs.managerTable.clearCurrentTableRow();
                const params = {
                    id: this.currentId
                };
                const res = await materialBackUp(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                    this.$refs.managerTable.clearCurrentTableRow();
                    this.getAllSelectData();
                }
            },
            // 选择引入物料
            importSelect (item) {
                this.isImport = true;
                this.getAllSelectData();
                this.editTableData({ row: item }, '新增物料');
                this.currentId = null;
                this.formAttr.commodityId = item.id;
                this.commodityId = item.id;
            },

            // 审批通过
            async auditPass () {
                let valid = this.validCurrent();
                if (!valid) return false;
                this.$refs.managerTable.clearCurrentTableRow();
                const params = {
                    id: this.currentId
                };
                const res = await materialPass(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            modalOk () {
                switch (this.tabIndex) {
                    case 0:
                        this.$refs['baseInfoForm'].save();
                        break;
                    case 1:
                        this.getPackageList();
                        break;
                    case 2:
                        this.changeLoading();
                }
            },

            tabsBind (name) {
                switch (name) {
                    case 0:
                        // this.$refs.baseInfo.save();
                        break;
                    case 1:
                        this.getRadioArr();
                        this.uploadList();
                        break;
                    case 2:
                        this.getPackageList();
                        break;
                }
            },
            // 审核通过
            async auditStart () {
                let valid = this.validCurrent();
                if (!valid) return false;
                this.$refs.managerTable.clearCurrentTableRow();
                const params = {
                    id: this.currentId
                };
                const res = await materialAudit(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },
            getTableList () {
                this.getTableListFn(async call => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await materialList(params);
                    call(res);
                });
            }
        }
    };
</script>
