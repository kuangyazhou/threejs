<template>
    <div class="group-machine">
        <!-- <h1>器械分类-集团</h1> -->
        <Card :border="false" class="wrapper-query">
            <p slot="title"><Icon type="ios-search"></Icon> 查询条件</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="4">
                    <Input placeholder="银行名称"></Input>
                </Col>
                <Col span="4">
                    <Input placeholder="银行名称"></Input>
                </Col>
                <Col span="4">
                    <Select
                        filterable
                        placeholder="所有类型"
                        @on-change="selectSearch"
                        v-model="tableQueryAttr.status"
                    >
                        <Option
                            v-for="(item, index) in slectList"
                            :label="item.label"
                            :value="item.value"
                            :key="index"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card :border="false">
            <p slot="title">银行列表</p>
            <div slot="extra">
                <Button @click="add">新增</Button>
            </div>
            <erp-table
                :erpTableTitle="bankTitle"
                :erpTableData="bankData"
            ></erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-cancel="modalCancel"
            @on-ok="modalOk"
        >
            <div class="erp-modal-content">
                <Form
                    :modal="formAttr"
                    :rules="ruleValidate"
                    ref="formValidate"
                    :label-width="120"
                >
                    <FormItem label="银行名称" prop="bankName">
                        <Input placeholder="银行名称"></Input>
                    </FormItem>
                    <FormItem label="银行行号" prop="bankNumber">
                        <Input placeholder="银行行号"></Input>
                    </FormItem>
                    <FormItem label="银行类型" prop="bankType"></FormItem>
                    <div v-show="currentId">
                        <FormItem label="状态"></FormItem>
                        <FormItem label="创建时间">
                            <Input
                                v-model="formAttr.createTime"
                                disabled
                                placeholder="创建时间"
                            ></Input>
                        </FormItem>
                        <FormItem label="创建人">
                            <Input
                                v-model="formAttr.createUserRealName"
                                disabled
                                placeholder="创建人"
                            ></Input>
                        </FormItem>
                        <FormItem label="最后修改时间">
                            <Input
                                v-model="formAttr.updateTime"
                                disabled
                                placeholder="最后修改时间"
                            ></Input>
                        </FormItem>
                        <FormItem label="最后修改人">
                            <Input
                                v-model="formAttr.updateUserRealName"
                                disabled
                                placeholder="最后修改人"
                            ></Input>
                        </FormItem>
                    </div>
                </Form>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { getDate } from '@/libs/tools';

    export default {
        components: { ErpTable },
        mixins: [tableMixin],

        data () {
            return {
                formAttr: {
                    createTime: '',
                    createUserRealName: '',
                    updateTime: '',
                    updateUserRealName: ''
                },
                tableQueryAttr: {},
                ruleValidate: {
                    bankName: [
                        {
                            required: true,
                            message: '银行名称不能为空'
                        }
                    ],
                    bankNumber: [
                        {
                            required: true,
                            message: '银行行号不能为空'
                        }
                    ],
                    bankType: [
                        {
                            required: true,
                            message: '银行类型不能为空',
                            type: 'number'
                        }
                    ]
                },
                slectList: [],
                bankData: [],
                bankTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '银行名称',
                        align: 'center',
                        minWidth: 180,
                        key: 'organizationName'
                    },
                    {
                        title: '银行行号',
                        align: 'center',
                        minWidth: 100,
                        key: 'organizationName'
                    },
                    {
                        title: '银行类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'organizationName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'organizationName',
                        render: (h, params) => {
                            const status = params.row.status === 1;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: status ? 'success' : 'default'
                                    }
                                },
                                status ? '有效' : '无效'
                            );
                        }
                    },
                    {
                        title: '最后更新人',
                        align: 'center',
                        minWidth: 100,
                        key: 'organizationName'
                    },
                    {
                        title: '最后更新时间',
                        align: 'center',
                        minWidth: 150,
                        key: 'organizationName',
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                params.row.updateTime
                                    ? getDate(params.row.updateTime, 'long')
                                    : ''
                            );
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {
                                        type: 'primary',
                                        size: 'small',
                                        icon: 'ios-create-outline'
                                    },
                                    on: {
                                        click: () => {
                                            this.editTableData(params, '银行编辑');
                                        }
                                    }
                                },
                                '编辑'
                            );
                        }
                    }
                ]
            };
        },
        methods: {
            add () {
                this.addItem('银行新增');
            },
            modalOk () {},
            getTableList () {},
            selectSearch () {}
        }
    };
</script>
