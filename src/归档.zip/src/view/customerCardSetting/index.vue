<template>
    <div class="content-role" ref="erp">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Select
                        @on-change="selectSearch"
                        placeholder="客户类型"
                        remote
                        v-model="tableQueryAttr.customerType"
                    >
                        <Option
                            v-for="item in customerTypeArr"
                            :label="item.fieldValue"
                            :value="item.id"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                证照类别设置
                <span></span>
            </p>
            <div slot="extra"></div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
            >
            </erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel"
        >
            <div class="erp-modal-content">
                <Form :model="formAttr" ref="formValidate">
                    <FormItem
                        v-for="item in formAttr.LicenseTypes"
                        :key="item.id"
                    >
                        <Checkbox
                            v-model="item.check"
                            :true-value="transNumber.one"
                            >{{ item.dataTypeName }}</Checkbox
                        >
                        <Checkbox
                            v-model="item.isMust"
                            :true-value="transNumber.one"
                            >必填</Checkbox
                        >
                        <Checkbox
                            v-model="item.isOrganization"
                            :true-value="transNumber.one"
                            >集团</Checkbox
                        >
                    </FormItem>
                </Form>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        getCustomerCardList,
        editCustomerCard
    } from '@/api/masterData/customer';

    export default {
        name: 'customerCardSetting',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    customerType: ''
                }, // 表格查询条件
                formAttr: {
                    customerTypeId: '',
                    LicenseTypes: []
                }, // modal 值对象
                ruleValidate: {}, // modal 表单验证
                erpTableTitle: [
                    {
                        type: 'index',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '客户类型',
                        align: 'center',
                        minWidth: 120,
                        key: 'customerTypeName'
                    },
                    {
                        title: '证照类型数量',
                        align: 'center',
                        minWidth: 120,
                        key: 'dataNum'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 100,
                        fixed: 'right',
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        style: {
                                            marginRight: '5px'
                                        },
                                        on: {
                                            click: () => {
                                                this.editTableData(
                                                    params,
                                                    '设置证照类型',
                                                    this.formatData
                                                );
                                            }
                                        }
                                    },
                                    '编辑'
                                )
                            ]);
                        }
                    }
                ], // 表格标题
                transNumber: {
                    one: 1,
                    zero: 0
                },
                cardTypeList: [], // 证照类型
                customerTypeArr: [] // 客户类型
            };
        },
        created () {
            this.getAllSelectData();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign({}, this.tableQueryAttr, {
                        organizationId: this.currentOrganization.id
                    });
                    const res = await getCustomerCardList(params);
                    if (res.status === this.code) getListMixin(res);
                });
            },
            // 新增编辑确认按钮
            async modalOk () {
                if (!this.judgeBtnRight('customerCardEdit')) {
                    this.changeLoading();
                    this.modalCancel();
                    return;
                }
                const licenseTypes = this.formAttr.LicenseTypes.filter(item => {
                    return item.check;
                });
                const params = Object.assign({}, this.formAttr, {
                    organizationId: this.currentOrganization.id,
                    LicenseTypes: licenseTypes
                });
                const res = await editCustomerCard(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                } else {
                    this.changeLoading();
                }
            },
            // 获取该页面所有下拉框数据
            getAllSelectData () {
                this.getFieldValuesData('data_type', 'cardTypeList');
                this.getFieldValuesData('customer_type', 'customerTypeArr');
            },
            // 编辑前格式化数据
            formatData (data) {
                this.formAttr.customerTypeId = data.customerType;
                this.formAttr.LicenseTypes = this.cardTypeList.map(item => {
                    const licenseType = {
                        dataType: item.id,
                        isMust: 0,
                        isOrganization: 0,
                        dataTypeName: item.fieldValue,
                        check: 0
                    };
                    data.dataTypes.forEach(option => {
                        if (option.dataType === item.id) {
                            Object.assign(licenseType, option, {
                                check: 1
                            });
                        }
                    });
                    return licenseType;
                });
            }
        }
    };
</script>

<style scoped lang="less"></style>
