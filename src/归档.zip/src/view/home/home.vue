<template>
    <div>
        欢迎您！
    </div>
</template>

<script>
    export default {};
</script>

<style lang="less">
.count-style {
    font-size: 50px;
}
</style>
