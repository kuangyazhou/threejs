<template>
    <div class="group-users">
        <!-- <h1>客户查询-集团</h1> -->
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16" class="mb10">
                <Col span="5" class="maxWidth">
                    <Input v-model="tableQueryAttr.enterpriseName" @on-search="search"
                        search placeholder="公司名称"><Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button></Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input v-model="tableQueryAttr.customerName" @on-search="search"
                        search placeholder="客户名称"><Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button></Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input v-model="tableQueryAttr.customerAreaName" placeholder="客户区域" @on-search="search"
                        search><Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button></Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.customerClassifyIds"
                        placeholder="客户分类"
                        multiple
                    >
                        <Option
                            v-for="(option, index) in customerClassifyArr"
                            :value="option.id"
                            :label="option.fieldValue"
                            :key="index"
                        ></Option>
                    </Select>
                </Col>
                </Row><Row :gutter="12">
                <Col span="5" class="maxWidth">
                    <Select v-model="tableQueryAttr.customerTypeIds" placeholder="客户类型" multiple>
                        <Option
                            v-for="(option, index) in customerTypeArr"
                            :value="option.id"
                            :label="option.fieldValue"
                            :key="index"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title"><Icon type="md-list"></Icon>客户列表</p>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                @on-current-change="currentChange"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
                ref="managerTable"
            ></erp-table>
        </Card>
        <Modal
            @on-ok="modalOk"
            @on-cancel="customerModalCancel"
            fullscreen
            v-model="modalShowFlag"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
        >
            <Tabs v-model="tabIndex" type="card" @on-click="tabsBind">
                <TabPane label="基础信息">
                    <BaseInFoForm
                        ref="baseInfoForm"
                        :oldFormAttr="formAttr"
                        :customerAreaArr="customerAreaArr"
                        :customerTypeArr="customerTypeArr"
                        :customerClassifyArr="customerClassifyArr"
                        :saleMethodArr="saleMethodArr"
                        :saleModeArr="saleModeArr"
                        :saleDepartmentArr="saleDepartmentArr"
                        :customerLevelArr="customerLevelArr"
                        :baseInfoReadOnly="true"
                    ></BaseInFoForm>
                </TabPane>
                <TabPane label="器械分类">
                    <MachineClass
                        ref="machineClass"
                        :materialCheckbox="materialList"
                        :machineCheckbox="machineList"
                        :selectData="infoData"
                        :taskInstanceId="taskInstanceId"
                        :selectedMachine="selectedMachine"
                        :selectedMaterial="selectedMaterial"
                        :machineReadonly="true"
                    ></MachineClass>
                </TabPane>
                <TabPane label="上传资料">
                    <UploadData
                        ref="uploadData"
                        @updateTable="updateTable"
                        :radioData="infoData"
                        :taskInstanceId="taskInstanceId"
                        :uploadTable="uploadTable"
                        :uploadReadonly="false"
                    ></UploadData>
                </TabPane>
                <TabPane label="收货地址">
                    <ReceiveAddress
                        ref="receiveAddress"
                        :customerAddressList="customerAddressList"
                        :taskInstanceId="taskInstanceId"
                        :addressReadonly="false"
                    ></ReceiveAddress>
                </TabPane>
                <TabPane label="联系人">
                    <Contact
                        ref="contact"
                        :customerContactList="customerContactList"
                        :taskInstanceId="taskInstanceId"
                        :concatReadonly="false"
                    ></Contact>
                </TabPane>
            </Tabs>
            <div slot="footer">
                <Button @click="modalCancel" type="primary">取消</Button>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import statusMixin from '@/mixins/statusMixin';

    import { getCompanyUser } from '@/api/masterData/userselect';

    import { BaseInFoForm, Contact, MachineClass, ReceiveAddress, UploadData } from '_c/customer';
    import { getDate } from '@/libs/tools';

    export default {
        mixins: [tableMixin, statusMixin],
        components: {
            ErpTable,
            BaseInFoForm,
            MachineClass,
            UploadData,
            ReceiveAddress,
            Contact
        },
        data () {
            return {
                tabIndex: 0,
                tableQueryAttr: {
                    customerName: '',
                    customerAreaName: '',
                    customerClassifyIds: [],
                    customerTypeIds: [],
                    enterpriseName: ''
                },
                erpTableTitle: [
                    {
                        title: '公司名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'enterpriseName'
                    },
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerName'
                    },
                    {
                        title: '编号',
                        align: 'center',
                        minWidth: 80,
                        key: 'customerCode'
                    },
                    // { title: '物料', align: 'center', minWidth: 80, key: '' },
                    // { title: '资料', align: 'center', minWidth: 80, key: '' },
                    {
                        title: '区域',
                        align: 'center',
                        minWidth: 80,
                        key: 'customerAreaName'
                    },
                    {
                        title: '分类',
                        align: 'center',
                        minWidth: 80,
                        key: 'customerClassifyName'
                    },
                    {
                        title: '类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerTypeName'
                    },
                    {
                        title: '上级',
                        align: 'center',
                        minWidth: 80,
                        key: 'parentName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 80,
                        key: 'statusName'
                    },
                    {
                        title: '创建人员',
                        align: 'center',
                        minWidth: 100,
                        key: 'createName'
                    },
                    {
                        title: '创建时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        fixed: 'right',
                        minWidth: 100,
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {
                                        type: 'success',
                                        size: 'small'
                                    },
                                    on: {
                                        click: e => {
                                            if (e && e.stopPropagation) {
                                                // 非IE
                                                e.stopPropagation();
                                            } else {
                                                // IE
                                                window.event.cancelBubble = true;
                                            }
                                            this.getAllSelectData();
                                            this.editTableData(params, '查看客户');
                                            this.taskInstanceId =
                                                params.row.taskInstanceId;
                                        }
                                    }
                                },
                                '查看'
                            );
                        }
                    }
                ]
            };
        },
        methods: {
            modalOk () {
            },
            tabsBind (name) {
                switch (name) {
                    case 0:
                        break;
                    case 1:
                        this.getMachineCheckbox();
                        this.getInfoRadio();
                        this.getSelectedMaterial();
                        this.getSelectedMachine();
                        break;
                    case 2:
                        this.getInfoRadio();
                        this.getUploadTabe();
                        break;
                    case 3:
                        this.getCustomerAddressList();
                        break;
                    case 4:
                        this.getCustomerContactList();
                        break;
                }
            },
            // 更新表格数据
            updateTable (e) {
                this.getUploadTabe(e);
            },
            getTableList () {
                this.getAllSelectData();
                this.getTableListFn(async calll => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr,
                        {
                            customerClassifyIds: this.tableQueryAttr.customerClassifyIds.join(
                                ','
                            ),
                            customerTypeIds: this.tableQueryAttr.customerTypeIds.join(
                                ','
                            )
                        }
                    );
                    const res = await getCompanyUser(params);
                    calll(res);
                });
            }
        }
    };
</script>
