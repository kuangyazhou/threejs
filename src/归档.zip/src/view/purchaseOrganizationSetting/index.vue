<template>
    <div class="erp-content" ref="erp">
        <Row :gutter="20">
            <Col span="10">
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="md-list"></Icon>
                        采购组织架构
                        <span></span>
                    </p>
                    <div slot="extra"></div>
                    <div class="wrapper-tree">
                        <div class="col-tree-view">
                            <Tree
                                :data="orgTreeData"
                                :render="orgRenderContent"
                            ></Tree>
                        </div>
                    </div>
                </Card>
            </Col>
            <Col span="14">
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="md-list"></Icon>
                        采购组织架构信息
                        <span></span>
                    </p>
                    <div slot="extra"></div>
                    <Form
                        v-if="formAttr.parentName"
                        class="org-form"
                        :model="formAttr"
                        :rules="ruleValidate"
                        ref="formValidate"
                        :label-width="120"
                    >
                        <FormItem label="名称" prop="purchaseOrganizationName">
                            <Input
                                v-model="formAttr.purchaseOrganizationName"
                                placeholder="请输入采购组织名称"
                            ></Input>
                        </FormItem>
                        <FormItem label="编码" prop="purchaseOrganizationCode">
                            <Input
                                v-model="formAttr.purchaseOrganizationCode"
                                placeholder="请输入采购组织编码"
                            ></Input>
                        </FormItem>
                        <FormItem label="状态" prop="status">
                            <RadioGroup v-model="formAttr.status">
                                <Radio
                                    v-for="item in statusArr"
                                    :label="item.id"
                                    :key="item.id"
                                    >{{ item.fieldValue }}
                                </Radio>
                            </RadioGroup>
                        </FormItem>
                        <FormItem label="上级" prop="parentName">
                            <Input
                                v-model="formAttr.parentName"
                                disabled
                                placeholder="请输入上级"
                            ></Input>
                        </FormItem>
                        <FormItem label="组织节点">
                            <Button
                                @click="handleSelectCompany"
                                class="form-button-select"
                                icon="ios-arrow-down"
                                >{{
                                    formAttr.nodeId
                                        ? formAttr.nodeName
                                        : '请选择组织节点'
                                }}
                            </Button>
                        </FormItem>
                        <template v-if="currentId">
                            <FormItem label="创建时间">
                                <Input
                                    v-model="formAttr.createTime"
                                    disabled
                                    placeholder="请输入创建时间"
                                ></Input>
                            </FormItem>
                            <FormItem label="创建人">
                                <Input
                                    v-model="formAttr.createName"
                                    disabled
                                    placeholder="请输入创建人"
                                ></Input>
                            </FormItem>
                            <FormItem label="更新时间">
                                <Input
                                    v-model="formAttr.updateTime"
                                    disabled
                                    placeholder="请输入更新时间"
                                ></Input>
                            </FormItem>
                            <FormItem label="更新人">
                                <Input
                                    v-model="formAttr.updateName"
                                    disabled
                                    placeholder="请输入更新人"
                                ></Input>
                            </FormItem>
                        </template>
                        <FormItem class="tr">
                            <Button
                                v-if="
                                    judgeBtnRight('purchaseOrgaAdd') ||
                                        judgeBtnRight('purchaseOrgaEdit')
                                "
                                type="primary"
                                @click="modalOk"
                                >保存
                            </Button>
                        </FormItem>
                    </Form>
                </Card>
            </Col>
        </Row>

        <!--公司节点弹窗-->
        <Modal
            v-model="companyShowFlag"
            width="850"
            height="400"
            title="公司选择"
            :mask-closable="maskClosable"
            footer-hide
            draggable
        >
            <div>
                <div class="clearfix">
                    <Table
                        border
                        :columns="companyTableTitle"
                        :data="companyTableData"
                        :tableLoading="companyTableLoading"
                    ></Table>
                </div>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        addSalesNode,
        editSalesNode,
        getSalesTree,
        getCompanyList
    } from '@/api/setting/purchase';
    import { getDate, resetObj } from '@/libs/tools';

    export default {
        name: 'purchaseOrganizationSetting',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {}, // 表格查询条件
                formAttr: {
                    purchaseOrganizationCode: '',
                    purchaseOrganizationName: '',
                    status: '',
                    parentId: '',
                    parentName: '',
                    createTime: '',
                    createName: '',
                    updateTime: '',
                    updateUser: '',
                    nodeId: '',
                    nodeName: ''
                }, // modal 值对象
                ruleValidate: {
                    purchaseOrganizationName: [
                        {
                            required: true,
                            message: '采购组织名称不能为空',
                            trigger: 'blur'
                        }
                    ],
                    purchaseOrganizationCode: [
                        { required: true, message: '编号不能为空', trigger: 'blur' }
                    ],
                    status: [
                        {
                            required: true,
                            type: 'number',
                            message: '状态不能为空',
                            trigger: 'change'
                        }
                    ],
                    parentName: [
                        { required: true, message: '上级不能为空', trigger: 'blur' }
                    ]
                }, // modal 表单验证
                orgTreeData: [],
                buttonProps: {
                    type: 'default',
                    size: 'small'
                },
                topTreeTitle: '采购组织树',
                companyTableTitle: [
                    {
                        title: '名称',
                        align: 'center',
                        minWidth: 140,
                        key: 'enterpriseName'
                    },
                    {
                        title: '操作',
                        minWidth: 100,
                        align: 'center',
                        fixed: 'right',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'success',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.selectionCompany(params.row);
                                            }
                                        }
                                    },
                                    '选择'
                                )
                            ]);
                        }
                    }
                ],
                companyTableData: [],
                companyTableLoading: false,
                companyShowFlag: false,
                statusArr: [] // 状态数组
            };
        },
        created () {
            this.getFieldValuesData('status_code', 'statusArr');
        },
        methods: {
            // 获取组织树
            async getTableList () {
                const res = await getSalesTree();
                if (res.status === this.code) {
                    this.formatOrganizationTree(res.content);
                }
            },
            // 保存部门信息
            modalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res;
                    let params;
                    if (this.currentId) {
                        params = Object.assign({}, this.formAttr, {
                            isDeleted: 1,
                            id: this.currentId
                        });
                        res = await editSalesNode(params);
                    } else {
                        params = Object.assign({}, this.formAttr);
                        res = await addSalesNode(params);
                    }
                    if (res.status === this.code) {
                        this.refreshToken();
                        this.todoOver(res.msg);
                    } else {
                        this.changeLoading();
                    }
                });
            },
            orgRenderContent (h, { data }) {
                return h(
                    'span',
                    {
                        style: {
                            display: 'inline-block',
                            width: '100%'
                        }
                    },
                    [
                        h(
                            'span',
                            {
                                class: {
                                    'tree-node-hover': true
                                },
                                on: {
                                    click: () => {
                                        this.handleEdit(data);
                                    }
                                }
                            },
                            [
                                h('Icon', {
                                    props: {
                                        type: 'ios-paper-outline'
                                    },
                                    style: {
                                        marginRight: '8px'
                                    }
                                }),
                                h('span', data.title)
                            ]
                        ),
                        h(
                            'span',
                            {
                                style: {
                                    display: 'inline-block',
                                    float: 'right',
                                    marginRight: '32px'
                                }
                            },
                            [
                                h('Button', {
                                    props: Object.assign({}, this.buttonProps, {
                                        icon: 'ios-add'
                                    }),
                                    style: {
                                        width: '50px'
                                    },
                                    on: {
                                        click: () => {
                                            this.handleAdd(data);
                                        }
                                    },
                                    directives: [
                                        {
                                            name: 'has',
                                            value: this.btnRightList.purchaseOrgaAdd
                                        }
                                    ]
                                })
                            ]
                        )
                    ]
                );
            },
            // 格式化组织树
            formatOrganizationTree (tree) {
                this.orgTreeData = [
                    {
                        children: this.backendResourcesToTrees(tree),
                        expand: true,
                        id: 0,
                        nodeId: 0,
                        parentId: 0,
                        title: this.topTreeTitle,
                        render: (h, { data }) => {
                            return h(
                                'span',
                                {
                                    style: {
                                        display: 'inline-block',
                                        width: '100%'
                                    }
                                },
                                [
                                    h(
                                        'span',
                                        {
                                            class: {
                                                'tree-node-hover': true
                                            },
                                            on: {
                                                click: () => {
                                                    // this.handleEdit(data);
                                                }
                                            }
                                        },
                                        [
                                            h('Icon', {
                                                props: {
                                                    type: 'ios-folder-outline'
                                                },
                                                style: {
                                                    marginRight: '8px'
                                                }
                                            }),
                                            h('span', data.title)
                                        ]
                                    ),
                                    h(
                                        'span',
                                        {
                                            style: {
                                                display: 'inline-block',
                                                float: 'right',
                                                marginRight: '32px'
                                            }
                                        },
                                        [
                                            h('Button', {
                                                props: Object.assign(
                                                    {},
                                                    this.buttonProps,
                                                    {
                                                        icon: 'ios-add'
                                                    }
                                                ),
                                                style: {
                                                    width: '50px'
                                                },
                                                on: {
                                                    click: () => {
                                                        this.handleAdd(data);
                                                    }
                                                },
                                                directives: [
                                                    {
                                                        name: 'has',
                                                        value: this.btnRightList.purchaseOrgaAdd
                                                    }
                                                ]
                                            })
                                        ]
                                    )
                                ]
                            );
                        }
                    }
                ];
            },
            backendResourcesToTrees (list) {
                let data = [];
                if (list && Array.isArray(list)) {
                    list.forEach(item => {
                        // 将后端数据转换成tree
                        let treeItem = this.backendResourceToTree(item);
                        // 如果后端数据有下级，则递归处理下级
                        if (item.children && item.children.length !== 0) {
                            treeItem.children = this.backendResourcesToTrees(
                                item.children
                            );
                        }
                        data.push(treeItem);
                    });
                }
                return data;
            },
            backendResourceToTree (item) {
                // const hasChild = item.children && item.children.length !== 0;
                let obj = {
                    title: item.name,
                    expand: false,
                    parentId: item.parentId,
                    parentEdId: item.parentEdId,
                    treeCode: item.purchaseOrganizationCode,
                    id: item.id,
                    nodeId: item.nodeId
                };
                obj = Object.assign({}, obj, item);
                return obj;
            },
            // 点击tree新增按钮
            handleAdd (data) {
                this.currentId = null;
                resetObj(this.formAttr);
                this.$refs['formValidate'] &&
                    this.$refs['formValidate'].resetFields();
                this.formAttr = Object.assign(
                    {},
                    {
                        parentId: data.id,
                        parentName: data.title,
                        nodeId: ''
                    }
                );
            },
            // 点击tree查看节点信息
            async handleEdit (data) {
                this.currentId = data.id;
                this.formAttr = Object.assign({}, data, {
                    purchaseOrganizationName: data.title,
                    parentId: data.parentId ? data.parentId : 0,
                    parentName: data.parentName
                        ? data.parentName
                        : this.topTreeTitle,
                    purchaseOrganizationCode: data.purchaseOrganizationCode,
                    nodeId: data.nodeId ? data.nodeId : '',
                    createTime: getDate(data.createTime, 'long'),
                    createName: data.createName,
                    updateTime: getDate(data.updateTime, 'long'),
                    updateName: data.updateName
                });
            },
            // 点击打开公司列表弹窗
            handleSelectCompany () {
                this.getCompanyList();
                this.companyShowFlag = true;
            },
            selectionCompany (row) {
                this.formAttr.nodeId = row.nodeId;
                this.formAttr.nodeName = row.enterpriseName;
                this.companyShowFlag = false;
            },
            // 获取可关联的公司
            async getCompanyList () {
                this.companyTableLoading = true;
                const res = await getCompanyList();
                this.companyTableLoading = false;
                if (res.status === this.code) {
                    this.companyTableData = res.content;
                }
            }
        }
    };
</script>

<style scoped lang="less">
.col-tree-view {
    padding: 10px;
    border: 1px solid #dcdee2;
}

.org-form {
    padding: 0 100px 0 10px;
}

.tr {
    text-align: right;
}

/deep/ .tree-node-hover {
    cursor: pointer;
}
</style>
