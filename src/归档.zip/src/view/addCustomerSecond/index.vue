<template>
    <!-- <div>新增客户-客管</div> -->
    <div class="add-user-manager">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon> 查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.customerName"
                        @on-search="search"
                        search
                        placeholder="客户名称"
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.statusArr"
                        multiple
                        @on-change="searchStatus"
                        :max-tag-count="4"
                        placeholder="状态"
                    >
                        <Option
                            v-for="item in typeList"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}</Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title"><Icon type="md-list"></Icon>客户列表</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button icon="md-log-in" @click="edit">
                        {{
                        currentRow.status === 6 ? '查看' : '编辑'
                        }}
                    </Button>
                    <Button
                        v-has="btnRightList.customerSecondSubmit"
                        @click="submit"
                        icon="md-thumbs-down"
                    >下一步</Button>
                    <Button v-has="btnRightList.customerBackUp" @click="backUp(1)" icon="md-send">退回</Button>
                    <Button v-has="btnRightList.customerInValid" @click="inValid" icon="md-undo">无效</Button>
                </ButtonGroup>
            </div>
            <erp-table
                ref="managerTable"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                @on-current-change="currentChange"
                highlight
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
            ></erp-table>
        </Card>
        <!-- 新增客户-质管专员弹框 -->
        <Modal
            @on-ok="modalOk"
            @on-cancel="modalCancel"
            fullscreen
            v-model="modalShowFlag"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
        >
            <Tabs v-model="tabIndex" type="card" @on-click="tabsBind">
                <TabPane label="基础信息">
                    <BaseInFoForm
                        ref="baseInfoForm"
                        @changeLoading="changeLoading"
                        :oldFormAttr="formAttr"
                        :customerAreaArr="customerAreaArr"
                        :customerTypeArr="customerTypeArr"
                        :customerClassifyArr="customerClassifyArr"
                        :saleMethodArr="saleMethodArr"
                        :saleModeArr="saleModeArr"
                        :saleDepartmentArr="saleDepartmentArr"
                        :customerLevelArr="customerLevelArr"
                        :baseInfoReadOnly="isPass"
                    ></BaseInFoForm>
                </TabPane>
                <template v-if="currentId">
                    <TabPane label="器械分类">
                        <MachineClass
                            ref="machineClass"
                            @changeLoading="changeLoading"
                            :materialCheckbox="materialList"
                            :machineCheckbox="machineList"
                            :selectData="infoData"
                            :taskInstanceId="currentId"
                            :selectedMachine="selectedMachine"
                            :selectedMaterial="selectedMaterial"
                            :machineReadonly="isPass"
                        ></MachineClass>
                    </TabPane>
                    <TabPane label="上传资料">
                        <UploadData
                            ref="uploadData"
                            @updateTable="updateTable"
                            :radioData="infoData"
                            :taskInstanceId="currentId"
                            :uploadTable="uploadTable"
                            :uploadReadonly="!isPass"
                        ></UploadData>
                    </TabPane>
                    <TabPane label="收货地址">
                        <ReceiveAddress
                            ref="receiveAddress"
                            @addressList="getCustomerAddressList"
                            :customerAddressList="customerAddressList"
                            :taskInstanceId="currentId"
                            :addressReadonly="!isPass"
                        ></ReceiveAddress>
                    </TabPane>
                    <TabPane label="联系人">
                        <Contact
                            ref="contact"
                            @contactList="getCustomerContactList"
                            :customerContactList="customerContactList"
                            :taskInstanceId="currentId"
                            :concatReadonly="!isPass"
                        ></Contact>
                    </TabPane>
                </template>
            </Tabs>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import statusMixin from '@/mixins/statusMixin';
    import {
        BaseInFoForm,
        MachineClass,
        UploadData,
        ReceiveAddress,
        Contact
    } from '_c/customer';

    import {
        getCustomerManage,
        submitQualitySpecial
    } from '@/api/masterData/customer';
    import { getDate } from '@/libs/tools';

    export default {
        mixins: [tableMixin, statusMixin],
        components: {
            ErpTable,
            BaseInFoForm,
            MachineClass,
            UploadData,
            ReceiveAddress,
            Contact
        },
        data () {
            return {
                // 客户申请单状态
                tableQueryAttr: {
                    customerName: '',
                    status: '1',
                    statusArr: [1]
                },
                erpTableTitle: [
                    {
                        title: '公司',
                        align: 'center',
                        minWidth: 140,
                        key: 'enterpriseName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 90,
                        key: 'statusDescription'
                    },
                    {
                        title: '编号',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerCode'
                    },
                    {
                        title: '名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerName'
                    },
                    {
                        title: '区域',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerAreaName'
                    },
                    {
                        title: '分类',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerClassifyName'
                    },
                    {
                        title: '类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerTypeName'
                    },
                    {
                        title: '上级',
                        align: 'center',
                        minWidth: 100,
                        key: 'parentName'
                    },
                    {
                        title: '创建人员',
                        align: 'center',
                        minWidth: 90,
                        key: 'createName'
                    },
                    {
                        title: '创建时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    }
                ]
            };
        },
        methods: {
            // 编辑数据
            edit () {
                // 检验是否选中数据
                let valid = this.validCurrent();
                if (!valid) return false;
                // 清空选中行
                this.$refs.managerTable.clearCurrentTableRow();
                // 获取下拉框数据
                this.getAllSelectData();
                this.editTableData({ row: this.currentRow }, '编辑客户');
            },

            // 下一步
            submit () {
                this.submitFn(async call => {
                    const params = {
                        id: this.currentId
                    };
                    const res = await submitQualitySpecial(params);
                    call(res);
                });
            },
            // tab点击
            tabsBind (name) {
                switch (name) {
                    case 0:
                        break;
                    case 1:
                        this.getMachineCheckbox();
                        this.getInfoRadio();
                        this.getSelectedMaterial();
                        this.getSelectedMachine();
                        break;
                    case 2:
                        this.getInfoRadio();
                        this.getUploadTabe();
                        break;
                    case 3:
                        this.getCustomerAddressList();
                        break;
                    case 4:
                        this.getCustomerContactList();
                        break;
                }
            },
            modalOk () {
                switch (this.tabIndex) {
                    case 0:
                        if (this.judgeBtnRight('customerInfoSave')) {
                            this.$refs.baseInfoForm.saveInfo();
                        } else {
                            this.changeLoading();
                        }
                        break;
                    case 1:
                        if (
                            this.judgeBtnRight('customerGoodsTypeSave') &&
                            this.judgeBtnRight('customerClassifySave')
                        ) {
                            this.$refs.machineClass.saveData();
                        } else {
                            this.changeLoading();
                        }
                        break;
                    case 2:
                        this.changeLoading();
                        break;
                    case 3:
                        this.changeLoading();
                        break;
                    case 4:
                        this.changeLoading();
                        break;
                }
            },
            // 更新已上传资料表格数据
            updateTable (e) {
                this.getUploadTabe(e);
            },
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getCustomerManage(params);
                    getListMixin(res);
                });
            }
        }
    };
</script>

<style scoped></style>
