<template>
    <div class="content-resource" ref="erp">
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                菜单管理列表
                <span></span>
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button
                        v-has="btnRightList.resourceDel"
                        @click="remove"
                        icon="md-trash"
                        >删除</Button
                    >
                </ButtonGroup>
            </div>
            <div class="wrapper-tree">
                <Row :gutter="16">
                    <Col span="8" class="col-tree-view">
                        <Tree
                            @on-check-change="checkTree"
                            ref="tree"
                            :data="resourceList"
                            show-checkbox
                        ></Tree>
                    </Col>
                    <Col span="16">
                        <Table
                            border
                            :columns="erpTableTitle"
                            :data="selectTableList"
                        ></Table>
                    </Col>
                </Row>
                <!--:render="renderContent"-->
            </div>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancelSelf"
        >
            <div class="erp-modal-content">
                <Form
                    v-if="addFunctionFlag && !editFlag"
                    :model="formAttr"
                    :rules="ruleValidate"
                    ref="formValidateAdd"
                    :label-width="120"
                >
                    <FormItem
                        label="页面现有功能"
                        v-if="addFunctionFlag"
                        prop="other"
                    >
                        <Tag
                            v-if="modalFunctionList.length > 0"
                            v-for="(item, index) in modalFunctionList"
                            :key="index"
                            :name="item.name"
                            >{{ item.name }}
                        </Tag>
                        <div v-if="modalFunctionList.length === 0">
                            暂无功能
                        </div>
                    </FormItem>
                    <FormItem label="新增功能名称" prop="pageFunction">
                        <Input
                            v-model="formAttr.pageFunction"
                            placeholder="请输入新增功能名称"
                        ></Input>
                    </FormItem>
                    <FormItem label="新增功能url" prop="addUrl">
                        <Input
                            v-model="formAttr.addUrl"
                            placeholder="请输入新增功能url"
                        ></Input>
                    </FormItem>
                </Form>
                <Form
                    v-else
                    :model="formAttr"
                    :rules="ruleValidate"
                    ref="formValidate"
                    :label-width="120"
                >
                    <FormItem label="菜单名称" prop="resourceName">
                        <Input
                            v-model="formAttr.resourceName"
                            placeholder="请输入菜单名称"
                        ></Input>
                    </FormItem>
                    <FormItem label="菜单url" prop="url">
                        <Input
                            v-model="formAttr.url"
                            placeholder="请输入菜单url"
                        ></Input>
                    </FormItem>
                    <FormItem label="菜单类型" prop="type">
                        <Input
                            v-if="editFlag"
                            v-model="formAttr.type"
                            disabled
                        ></Input>
                        <Select
                            v-else
                            placeholder="全部菜单类型"
                            remote
                            v-model="formAttr.type"
                        >
                            <Option
                                v-for="(item, index) in typeList"
                                :label="item.label"
                                :disabled="item.disabled"
                                :value="item.name"
                                :key="index"
                            ></Option>
                        </Select>
                    </FormItem>
                    <FormItem label="图标" prop="icon">
                        <Input
                            class="input70"
                            v-model="formAttr.icon"
                            placeholder="请输入菜单图标名称"
                        ></Input>
                        <a
                            class="icon-a"
                            target="_blank"
                            href="https://www.iviewui.com/components/icon#SYTB"
                            >点击查看参考范围</a
                        >
                    </FormItem>
                    <FormItem label="排序值" prop="sort">
                        <InputNumber
                            class="input70"
                            :max="10000"
                            :min="1"
                            v-model="formAttr.sort"
                            placeholder="请输入排序值"
                        ></InputNumber>
                    </FormItem>
                    <FormItem label="菜单等级" prop="level">
                        <Input
                            v-if="editFlag"
                            v-model="formAttr.level"
                            disabled
                        ></Input>
                        <Select
                            v-else
                            placeholder="全部菜单等级"
                            remote
                            v-model="formAttr.level"
                        >
                            <Option
                                v-for="(item, index) in levelList"
                                :label="item.label"
                                :disabled="item.disabled"
                                :value="item.name"
                                :key="index"
                            ></Option>
                        </Select>
                        <span
                            >(
                            注：一级顶层菜单，如基础设置；二级过渡菜单；三级页面菜单，如页面
                            )</span
                        >
                    </FormItem>
                    <FormItem v-if="!topFlag" label="所属父级" prop="parentId">
                        <Select
                            placeholder="全部父级菜单"
                            remote
                            v-model="formAttr.parentId"
                        >
                            <Option
                                v-for="(item, index) in parentIdList"
                                :label="item.label"
                                :disabled="item.disabled"
                                :value="item.name"
                                :key="index"
                            ></Option>
                        </Select>
                        <span
                            >(
                            注：一级顶层菜单，如基础设置；二级过渡菜单；三级页面菜单，如页面
                            )</span
                        >
                    </FormItem>
                    <FormItem label="页面功能">
                        <Tag
                            v-if="modalFunctionList.length > 0"
                            v-for="(item, index) in modalFunctionList"
                            :key="index"
                            :name="item.name"
                            closable
                            @on-close="functionClose"
                            >{{ item.name }}
                        </Tag>
                        <div v-if="modalFunctionList.length === 0">
                            暂无功能
                        </div>
                    </FormItem>
                </Form>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        addResource,
        deleteResource,
        editResource,
        getResourceList
    } from '@/api/setting/resource';
    import { resetObj, transformData } from '@/libs/tools';

    export default {
        name: 'menuManage',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                // tableQueryAttr: {
                //     jobCode: '',
                //     jobName: '',
                //     status: ''
                // }, // 表格查询条件
                formAttr: {
                    resourceName: '',
                    url: '',
                    type: '',
                    icon: '',
                    sort: 1,
                    level: '',
                    parentId: '', // 当前新增或者编辑的parentId
                    pageFunction: '', // 新增功能名称
                    addUrl: '' // 新增功能名称
                }, // modal 值对象
                ruleValidate: {
                    resourceName: [
                        {
                            required: true,
                            message: '菜单名称不能为空',
                            trigger: 'blur'
                        }
                    ],
                    url: [
                        {
                            required: true,
                            message: '菜单url不能为空',
                            trigger: 'blur'
                        }
                    ],
                    type: [
                        {
                            required: true,
                            message: '类型不能为空',
                            trigger: 'change'
                        }
                    ],
                    icon: [
                        { required: true, message: '图标不能为空', trigger: 'blur' }
                    ],
                    sort: [
                        {
                            required: true,
                            type: 'number',
                            message: '排序值不能为空',
                            trigger: 'blur'
                        }
                    ],
                    level: [
                        {
                            required: true,
                            message: '菜单等级不能为空',
                            trigger: 'change'
                        }
                    ],
                    parentId: [
                        {
                            required: true,
                            message: '所属父级不能为空',
                            trigger: 'change'
                        }
                    ],
                    pageFunction: [
                        {
                            required: true,
                            message: '新增功能名称不能为空',
                            trigger: 'blur'
                        }
                    ],
                    addUrl: [
                        {
                            required: true,
                            message: '新增功能url不能为空',
                            trigger: 'blur'
                        }
                    ]
                }, // modal 表单验证
                typeList: [
                    {
                        name: '菜单',
                        value: 0,
                        label: '菜单'
                    },
                    {
                        name: '功能',
                        value: 1,
                        label: '功能'
                    }
                ],
                levelList: [
                    {
                        name: '一级菜单',
                        value: 1,
                        label: '一级菜单'
                    },
                    {
                        name: '二级菜单',
                        value: 2,
                        label: '二级菜单'
                    },
                    {
                        name: '三级菜单',
                        value: 3,
                        label: '三级菜单'
                    }
                ],
                erpTableTitle: [
                    {
                        title: '菜单名称',
                        align: 'center',
                        key: 'title'
                    },
                    {
                        title: '菜单类型',
                        align: 'center',
                        render: (h, params) => {
                            const typeInfo = () => {
                                switch (params.row.level) {
                                    case 1:
                                        return {
                                            name: '一级菜单'
                                        };
                                    case 2:
                                        return {
                                            name: '二级菜单'
                                        };
                                    case 3:
                                        return {
                                            name: '三级菜单'
                                        };
                                    default:
                                        return {
                                            name: '顶级菜单'
                                        };
                                }
                            };
                            return h('span', {}, typeInfo().name);
                        }
                    },
                    {
                        title: '菜单图标',
                        align: 'center',
                        render: (h, params) => {
                            return h('Icon', {
                                props: {
                                    type: params.row.icon
                                }
                            });
                        }
                    },
                    {
                        title: '菜单url',
                        align: 'center',
                        key: 'url'
                    },
                    {
                        title: '排序值',
                        align: 'center',
                        key: 'sort'
                    },
                    {
                        title: '三级菜单功能',
                        align: 'center',
                        render: (h, params) => {
                            let btnList =
                                params.row.resourceList &&
                                params.row.resourceList.map(item => {
                                    return h(
                                        'Tag',
                                        {
                                            props: {
                                                color: 'default'
                                            },
                                            style: {
                                                marginBottom: '10px',
                                                cursor: 'default'
                                            },
                                            class: 'no-hover'
                                        },
                                        item.name
                                    );
                                });
                            return h(
                                'div',
                                { style: { marginTop: '10px' } },
                                btnList
                            );
                        }
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 200,
                        align: 'center',
                        render: (h, params) => {
                            let edit =
                                params.row.level > -1
                                    ? h(
                                        'Button',
                                        {
                                            props: {
                                                size: 'small',
                                                icon: 'ios-create-outline'
                                            },
                                            style: {
                                                marginRight: '5px'
                                            },
                                            on: {
                                                click: () => {
                                                    this.resourceEditTableData(
                                                        params.row,
                                                        '编辑菜单'
                                                    );
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList
                                                        .resourceUpdate
                                                }
                                            ]
                                        },
                                        '编辑'
                                    )
                                    : null;
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type:
                                                params.row.level === 3
                                                    ? 'primary'
                                                    : 'info',
                                            size: 'small',
                                            icon: 'ios-add'
                                        },
                                        style: {
                                            marginRight: '5px'
                                        },
                                        on: {
                                            click: () => {
                                                if (params.row.level === 3) {
                                                    this.addFunction(
                                                        params.row,
                                                        '新增菜单'
                                                    );
                                                } else {
                                                    this.addMenu(
                                                        params.row,
                                                        '新增菜单'
                                                    );
                                                }
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList
                                                    .resourceCreate
                                            }
                                        ]
                                    },
                                    params.row.level === 3 ? '新增功能' : '新增菜单'
                                ),
                                edit
                            ]);
                        }
                    }
                ], // 表格标题
                resourceList: [], // tree data
                buttonProps: {
                    type: 'default',
                    size: 'small'
                },
                selectRemoveList: [], // 要删除的节点
                selectTableList: [], // 要展示的节点
                editFlag: false, // 判断编辑或者新增开关
                parentIdList: [], // 非页面菜单
                topFlag: false, // 是否是顶层菜单新增，顶层菜单新增时，所属父级隐藏
                addFunctionFlag: false, // modal是否新增功能
                modalFunctionList: [], // 三级菜单功能集合,modal展示用
                currentIndex: -1, // 当前操作table的index
                authorityScope: '' // 0-platform与oganization共有，1-platform,2-organization
            };
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.tableLoading = true;
                const res = await getResourceList();
                this.tableLoading = false;
                if (res.status === this.code) {
                    const content = res.content;
                    // 树数据
                    if (this.resourceList.length) {
                        const newResourceList = [
                            {
                                children: this.backendResourcesToTrees(content),
                                expand: true,
                                icon: 'md-home',
                                id: 1,
                                nodeKey: 0,
                                parentId: 0,
                                level: -1,
                                title: '塞力斯仓库管理系统'
                            }
                        ];
                        this.resourceList = this.cover(
                            this.resourceList,
                            newResourceList
                        );
                        setTimeout(() => {
                            this.selectTableList = this.$refs.tree.getCheckedNodes();
                        }, 100);
                    } else {
                        this.resourceList = [
                            {
                                children: this.backendResourcesToTrees(res.content),
                                expand: true,
                                icon: 'md-home',
                                id: 1,
                                nodeKey: 0,
                                parentId: 0,
                                level: -1,
                                title: '塞力斯仓库管理系统'
                            }
                        ];
                    }
                    // 父级列表数据，仅限一级二级
                    this.parentIdList = [];
                    this.getparentIdList(res.content);
                    this.parentIdList.push({
                        name: '塞力斯仓库管理系统',
                        value: 1,
                        label: '塞力斯仓库管理系统'
                    });
                }
            },
            cover (oldList, newList) {
                if (!Array.isArray(oldList) || !Array.isArray(newList)) return [];
                const arr = [];
                newList.forEach((item, index) => {
                    let treeItem = Object.assign(
                        {},
                        Array.isArray(oldList) && oldList[index],
                        item, {
                            children: []
                        }
                    );
                    if (item.children && item.children.length !== 0) {
                        treeItem.children = this.cover(
                            oldList[index].children,
                            item.children
                        );
                    }
                    arr.push(treeItem);
                });
                return arr;
            },
            /**
             * 格式化树形组件所需data
             * @param list
             */
            backendResourcesToTrees (list) {
                let data = [];
                if (list && Array.isArray(list)) {
                    list.forEach(item => {
                        // 将后端数据转换成tree
                        let treeItem = this.backendResourceToTree(item);
                        // 如果后端数据有下级，则递归处理下级
                        if (item.children && item.children.length !== 0) {
                            treeItem.children = this.backendResourcesToTrees(
                                item.children
                            );
                        }
                        item.type === 0 && data.push(treeItem);
                    });
                }

                return data;
            },
            backendResourceToTree (item) {
                // const hasChild = item.children && item.children.length !== 0;
                const pageLevel = item.level === 3;
                let obj = {
                    title: item.meta.title,
                    expand: false,
                    icon: item.meta.icon,
                    parentId: item.parentId,
                    id: item.id,
                    level: item.level,
                    sort: item.sort,
                    type: item.type
                };
                if (item.name.indexOf('/') === -1) {
                    obj.url = item.name;
                }
                if (pageLevel) {
                    obj.resourceList =
                        item.children &&
                        item.children.map(item => {
                            return {
                                name: item.meta.title,
                                url: item.name,
                                id: item.id
                            };
                    });
                }
                return obj;
            },

            getparentIdList (list) {
                let arr = [];
                if (list && Array.isArray(list)) {
                    list.map(item => {
                        if (item.children && item.children.length !== 0) {
                            this.getparentIdList(item.children);
                        }
                        if (item.level !== 3 && item.level !== 0) {
                            const levelName = item.level === 1 ? '(一级)' : '(二级)';
                            this.parentIdList.push({
                                name: item.meta.title,
                                value: item.id,
                                parentId: item.parentId,
                                label: item.meta.title + levelName
                            });
                        }
                    });
                }
                return arr;
            },
            // 树形选择
            checkTree (value) {
                this.selectTableList = value;
                this.selectRemoveList =
                    value &&
                    value.map(item => {
                        return item.id;
                });
            },
            // 新增编辑确认功能
            modalOk () {
                if (this.addFunctionFlag && !this.editFlag) {
                    this.$refs['formValidateAdd'].validate(async valid => {
                        if (!valid) {
                            return this.changeLoading();
                        }
                        const params = Object.assign({}, this.formAttr, {
                            // eslint-disable-next-line
                            parentId: this.currentId || 1, // eslint-disable-next-line
                            level: 0, // eslint-disable-next-line
                            type: 1, // eslint-disable-next-line
                            url: this.formAttr.addUrl,
                            resourceName: this.formAttr.pageFunction,
                            authorityScope: 0
                        }); // eslint-disable-next-line;
                        const res = await addResource(params);
                        if (res.status === this.code) {
                            this.modalShowFlag = false; // 关闭弹窗
                            this.$Message.success(res.msg); // 提示消息
                            this.tableComAttr.pageNo = 1;
                            this.getTableList();
                            setTimeout(() => {
                                this.currentId = null;
                                resetObj(this.formAttr);
                                this.$refs['formValidateAdd'] &&
                                    this.$refs['formValidateAdd'].resetFields();
                            }, 300);
                        } else {
                            this.changeLoading();
                        }
                    });
                } else {
                    this.$refs['formValidate'].validate(async valid => {
                        if (!valid) {
                            return this.changeLoading();
                        }
                        let res;
                        let params;
                        if (this.currentId) {
                            params = Object.assign({}, this.formAttr, {
                                parentId:
                                    transformData(
                                        this.formAttr.parentId,
                                        this.parentIdList
                                    ) || 1,
                                level: transformData(
                                    this.formAttr.level,
                                    this.levelList
                                ),
                                id: this.currentId,
                                type: transformData(
                                    this.formAttr.type,
                                    this.typeList
                                )
                            });
                            res = await editResource(params);
                        } else {
                            params = Object.assign({}, this.formAttr, {
                                parentId:
                                    transformData(
                                        this.formAttr.parentId,
                                        this.parentIdList
                                    ) || 1,
                                level: transformData(
                                    this.formAttr.level,
                                    this.levelList
                                ),
                                type: transformData(
                                    this.formAttr.type,
                                    this.typeList
                                ),
                                authorityScope: 0
                            });
                            res = await addResource(params);
                        }
                        if (res.status === this.code) {
                            this.todoOver(res.msg);
                            // this.selectTableList[this.currentIndex].resourceList = this.modalFunctionList;
                            this.$store.dispatch('getRouters');
                        // this.$store.commit('setHasGetRouter', false);
                        } else {
                            this.changeLoading();
                        }
                    });
                }
            },
            /**
             * 编辑当前菜单
             * @param data
             * @param modalTitle
             */
            resourceEditTableData (data, modalTitle) {
                this.addFunctionFlag = data.level === 3;
                this.modalTitle = modalTitle; // 设置标题
                this.currentId = data.id; // 设置当前编辑的id
                this.editFlag = true; // 设置编辑开关
                this.topFlag = false; // 不是顶级菜单
                this.currentIndex = data._index;
                this.modalFunctionList = data.resourceList || [];
                this.formAttr.resourceName = data.title;
                this.formAttr.url = data.url;
                this.formAttr.type = transformData(data.type, this.typeList, true);
                this.formAttr.icon = data.icon;
                this.formAttr.sort = data.sort;
                this.formAttr.level = transformData(
                    data.level,
                    this.levelList,
                    true
                );
                this.formAttr.parentId = transformData(
                    data.parentId,
                    this.parentIdList,
                    true
                );
                this.modalShowFlag = true; // 开启modal
            },
            // 页面新增功能
            addFunction (data) {
                this.addFunctionFlag = true;
                this.currentIndex = data._index;
                this.addItem(`新增功能（${data.title}）`);
                this.currentId = data.id;
                this.editFlag = false;
                this.formAttr.type = '功能';
                this.typeList[0].disabled = true;
                this.topFlag = false; // 不是顶级菜单
                this.formAttr.resourceName = data.title;
                this.modalFunctionList = data.resourceList;
                this.formAttr.url = data.url;
                this.formAttr.type = transformData(data.type, this.typeList, true);
                this.formAttr.icon = data.icon;
                this.formAttr.sort = data.sort;
                this.formAttr.level = transformData(
                    data.level,
                    this.levelList,
                    true
                );
                this.formAttr.parentId = transformData(
                    data.parentId,
                    this.parentIdList,
                    true
                );
            },
            // 菜单新建子菜单
            addMenu (data) {
                this.addFunctionFlag = false;
                this.currentIndex = data._index;
                this.addItem('新增菜单');
                this.currentId = null;
                this.editFlag = false;
                this.formAttr.type = '菜单';
                this.typeList[1].disabled = true;
                switch (data.level) {
                    case 1:
                        this.topFlag = false;
                        this.levelList[0].disabled = true;
                        break;
                    case 2:
                        this.topFlag = false;
                        this.levelList[0].disabled = true;
                        // this.levelList[1].disabled = true;
                        break;
                    case -1:
                        this.topFlag = true;
                        this.currentId = 0;
                        break;
                    default:
                        this.topFlag = false;
                }
            },
            // 编辑页面时候删除功能
            functionClose (e, name) {
                this.$Modal.confirm({
                    title: `确认删除该功能吗？`,
                    onOk: async () => {
                        for (let i in this.modalFunctionList) {
                            if (this.modalFunctionList[i].name === name) {
                                const res = await deleteResource([
                                    this.modalFunctionList[i].id
                                ]);
                                if (res.status === this.code) {
                                    this.$Message.success(res.msg);
                                    this.modalFunctionList.splice(i, 1);
                                }
                            }
                        }
                    }
                });
            },
            // 节点删除
            async remove () {
                if (!this.selectRemoveList.length) {
                    this.$Message.error('删除至少勾选一项');
                    return;
                }
                this.$Modal.confirm({
                    title: `确认删除所勾选菜单吗？`,
                    onOk: async () => {
                        const res = await deleteResource(this.selectRemoveList);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getTableList();
                            this.$store.dispatch('getRouters');
                            this.$store.commit('setHasGetRouter', false);
                        }
                    }
                });
            },
            modalCancelSelf () {
                setTimeout(() => {
                    this.currentId = null;
                    resetObj(this.formAttr);
                    this.formAttr.sort = 1;
                    this.currentIndex = -1;
                    this.resetListDisabled(this.typeList);
                    this.resetListDisabled(this.levelList);
                    this.$refs['formValidateAdd'] &&
                        this.$refs['formValidateAdd'].resetFields();
                    this.$refs['formValidate'] &&
                        this.$refs['formValidate'].resetFields();
                    this.modalFunctionList = [];
                    this.addFunctionFlag = false;
                }, 300);
            },
            resetListDisabled (arr) {
                arr.forEach(item => {
                    item.disabled = false;
                });
            }
        }
    };
</script>

<style scoped lang="less">
.wrapper-tree {
    //.clearfix();
    .fl {
        float: left;
        width: 30%;
        margin-bottom: 30px;
    }

    .fr {
        float: right;
        width: 70%;
        min-width: 600px;
    }
}
</style>
<style lang="less">
.content-resource {
    .wrapper-tree {
        .ivu-tree-arrow,
        .ivu-checkbox-wrapper {
            position: relative;
            top: 4px;
        }
    }

    .ivu-table {
        width: auto;
    }
}

.input70 {
    width: 70%;
}

.icon-a {
    margin-left: 10px;
    color: #515a6e;
    text-decoration: underline;

    &:hover {
        color: #2d8cf0;
        text-decoration: underline;
    }
}

.chooseBtn {
    float: right;

    a {
        color: #515a6e;
        display: block;
        width: 100%;
        height: 100%;
    }
}

.no-hover {
    &:hover {
        cursor: default;
        opacity: 1;
    }
}

.ivu-tree-title {
    font-size: 14px;
    position: relative;
    top: 3px;
}

.col-tree-view {
    padding: 10px;
    border: 1px solid #dcdee2;
}
</style>
