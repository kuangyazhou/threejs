<template>
    <div class="erp-content" ref="erp">
        <Row :gutter="20">
            <Col span="10">
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="md-list"></Icon>
                        组织架构
                        <span></span>
                    </p>
                    <div slot="extra"></div>
                    <div class="wrapper-tree">
                        <div class="col-tree-view">
                            <Tree
                                :data="orgTreeData"
                                :render="orgRenderContent"
                            ></Tree>
                        </div>
                    </div>
                </Card>
            </Col>
            <Col span="14">
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="md-list"></Icon>
                        组织架构信息
                        <span></span>
                    </p>
                    <div slot="extra"></div>
                    <Form
                        v-if="formAttr.parentDepartName"
                        class="org-form"
                        :model="formAttr"
                        :rules="ruleValidate"
                        ref="formValidate"
                        :label-width="120"
                    >
                        <FormItem label="名称" prop="departmentName">
                            <Input
                                v-model="formAttr.departmentName"
                                placeholder="请输入名称"
                            ></Input>
                        </FormItem>
                        <FormItem label="编号" prop="departmentCode">
                            <Input
                                v-model="formAttr.departmentCode"
                                placeholder="请输入编号"
                            ></Input>
                        </FormItem>
                        <FormItem label="状态" prop="status">
                            <RadioGroup v-model="formAttr.status">
                                <Radio
                                    v-for="item in statusList"
                                    :label="item.value"
                                    :key="item.value"
                                    >{{ item.label }}
                                </Radio>
                            </RadioGroup>
                        </FormItem>
                        <FormItem label="上级" prop="parentDepartName">
                            <Input
                                v-model="formAttr.parentDepartName"
                                disabled
                            ></Input>
                        </FormItem>
                        <FormItem label="节点类型" prop="departmentType">
                            <Select
                                placeholder="请选择节点类型"
                                remote
                                v-model="formAttr.departmentType"
                            >
                                <Option
                                    v-for="item in departmentTypeArr"
                                    :label="item.label"
                                    :value="item.value"
                                    :key="item.id"
                                ></Option>
                            </Select>
                        </FormItem>
                        <template v-if="currentId">
                            <FormItem label="创建时间">
                                <Input
                                    v-model="formAttr.createTime"
                                    disabled
                                    placeholder="请输入创建时间"
                                ></Input>
                            </FormItem>
                            <FormItem label="创建人">
                                <Input
                                    v-model="formAttr.createUserRealName"
                                    disabled
                                    placeholder="请输入创建人"
                                ></Input>
                            </FormItem>
                            <FormItem label="更新时间">
                                <Input
                                    v-model="formAttr.updateTime"
                                    disabled
                                    placeholder="请输入更新时间"
                                ></Input>
                            </FormItem>
                            <FormItem label="更新人">
                                <Input
                                    v-model="formAttr.updateUserRealName"
                                    disabled
                                    placeholder="请输入更新人"
                                ></Input>
                            </FormItem>
                        </template>
                        <FormItem class="tr">
                            <Button
                                v-if="
                                    judgeBtnRight('departmentAdd') ||
                                        judgeBtnRight('departmentEdit')
                                "
                                type="primary"
                                @click="modalOk"
                                >保存
                            </Button>
                        </FormItem>
                    </Form>
                </Card>
            </Col>
        </Row>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        addDepartNode,
        deleteDepartment,
        editDepartNode,
        getDepartTree,
        getDepartInfo
    } from '@/api/setting/organization';
    import { getDate, resetObj } from '@/libs/tools';

    export default {
        name: 'sOrganization',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {}, // 表格查询条件
                formAttr: {
                    departmentCode: '',
                    departmentName: '',
                    status: '',
                    parentId: '',
                    parentDepartName: '',
                    departmentType: '',
                    createTime: '',
                    createUserRealName: '',
                    updateTime: '',
                    updateUserRealName: '',
                    parentNodeId: ''
                }, // modal 值对象
                ruleValidate: {
                    departmentName: [
                        { required: true, message: '名称不能为空', trigger: 'blur' }
                    ],
                    departmentCode: [
                        { required: true, message: '编号不能为空', trigger: 'blur' }
                    ],
                    status: [
                        {
                            required: true,
                            type: 'number',
                            message: '状态不能为空',
                            trigger: 'change'
                        }
                    ],
                    parentDepartName: [
                        { required: true, message: '上级不能为空', trigger: 'blur' }
                    ],
                    departmentType: [
                        {
                            required: true,
                            type: 'number',
                            message: '节点类型不能为空',
                            trigger: 'change'
                        }
                    ]
                }, // modal 表单验证
                orgTreeData: [],
                buttonProps: {
                    type: 'default',
                    size: 'small'
                },
                departmentTypeArr: [
                    {
                        id: 1,
                        value: 1,
                        label: '部门'
                    },
                    {
                        id: 2,
                        value: 2,
                        label: '公司'
                    }
                ]
            };
        },
        methods: {
            // 获取组织树
            async getTableList () {
                const params = {
                    organizationId: this.currentOrganization.id
                };
                const res = await getDepartTree(params);
                if (res.status === this.code) {
                    this.formatOrganizationTree(res.content);
                }
            },
            // 保存部门信息
            modalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res;
                    let params;
                    if (this.currentId) {
                        params = Object.assign({}, this.formAttr, {
                            organizationId: this.currentOrganization.id,
                            id: this.currentId
                        });
                        res = await editDepartNode(params);
                    } else {
                        params = Object.assign({}, this.formAttr, {
                            organizationId: this.currentOrganization.id
                        });
                        res = await addDepartNode(params);
                    }
                    if (res.status === this.code) {
                        this.refreshToken().then(() => {
                            this.todoOver(res.msg);
                        });
                    } else {
                        this.changeLoading();
                    }
                });
            },
            del (data) {
                if (data.id) {
                    this.$Modal.confirm({
                        title: '确认删除所选项吗？',
                        onOk: async () => {
                            const params = {
                                id: data.edId,
                                type: data.type
                            };
                            const res = await deleteDepartment(params);
                            this.$Message.success(res.msg);
                            if (res.status === this.code) this.getTableList();
                        }
                    });
                }
            },
            orgRenderContent (h, { data }) {
                return h(
                    'span',
                    {
                        style: {
                            display: 'inline-block',
                            width: '100%'
                        }
                    },
                    [
                        h(
                            'span',
                            {
                                class: {
                                    'tree-node-hover': true
                                },
                                on: {
                                    click: () => {
                                        this.handleEdit(data);
                                    }
                                }
                            },
                            [
                                h('Icon', {
                                    props: {
                                        type: 'ios-paper-outline'
                                    },
                                    style: {
                                        marginRight: '8px'
                                    }
                                }),
                                h('span', data.title)
                            ]
                        ),
                        h(
                            'span',
                            {
                                style: {
                                    display: 'inline-block',
                                    float: 'right',
                                    marginRight: '32px'
                                }
                            },
                            [
                                h('Button', {
                                    props: Object.assign({}, this.buttonProps, {
                                        icon: 'ios-add'
                                    }),
                                    style: {
                                        marginRight: '8px'
                                    },
                                    on: {
                                        click: () => {
                                            this.handleAdd(data);
                                        }
                                    },
                                    directives: [
                                        {
                                            name: 'has',
                                            value: this.btnRightList.departmentAdd
                                        }
                                    ]
                                }),
                                h('Button', {
                                    props: Object.assign({}, this.buttonProps, {
                                        icon: 'ios-remove'
                                    }),
                                    on: {
                                        click: () => {
                                            this.del(data);
                                        }
                                    },
                                    directives: [
                                        {
                                            name: 'has',
                                            value: this.btnRightList.departmentDel
                                        }
                                    ]
                                })
                            ]
                        )
                    ]
                );
            },
            // 格式化组织树
            formatOrganizationTree (tree) {
                this.orgTreeData = [
                    {
                        children: this.backendResourcesToTrees(tree[0].children),
                        expand: true,
                        id: tree[0].id,
                        edId: tree[0].edId,
                        parentId: tree[0].parentId,
                        parentEdId: tree[0].parentEdId,
                        parentName: tree[0].name,
                        title: tree[0].name,
                        type: tree[0].type,
                        render: (h, { data }) => {
                            return h(
                                'span',
                                {
                                    style: {
                                        display: 'inline-block',
                                        width: '100%'
                                    }
                                },
                                [
                                    h(
                                        'span',
                                        {
                                            class: {
                                                'tree-node-hover': true
                                            },
                                            on: {
                                                click: () => {
                                                    this.handleEdit(data);
                                                }
                                            }
                                        },
                                        [
                                            h('Icon', {
                                                props: {
                                                    type: 'ios-folder-outline'
                                                },
                                                style: {
                                                    marginRight: '8px'
                                                }
                                            }),
                                            h('span', data.title)
                                        ]
                                    ),
                                    h(
                                        'span',
                                        {
                                            style: {
                                                display: 'inline-block',
                                                float: 'right',
                                                marginRight: '32px'
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList
                                                        .departmentAdd
                                                }
                                            ]
                                        },
                                        [
                                            h('Button', {
                                                props: Object.assign(
                                                    {},
                                                    this.buttonProps,
                                                    {
                                                        icon: 'ios-add'
                                                    }
                                                ),
                                                style: {
                                                    width: '64px'
                                                },
                                                on: {
                                                    click: () => {
                                                        this.handleAdd(data);
                                                    }
                                                }
                                            })
                                        ]
                                    )
                                ]
                            );
                        }
                    }
                ];
            },
            backendResourcesToTrees (list) {
                let data = [];
                if (list && Array.isArray(list)) {
                    list.forEach(item => {
                        // 将后端数据转换成tree
                        let treeItem = this.backendResourceToTree(item);
                        // 如果后端数据有下级，则递归处理下级
                        if (item.children && item.children.length !== 0) {
                            treeItem.children = this.backendResourcesToTrees(
                                item.children
                            );
                        }
                        data.push(treeItem);
                    });
                }
                return data;
            },
            backendResourceToTree (item) {
                // const hasChild = item.children && item.children.length !== 0;
                const obj = {
                    title: item.name,
                    expand: false,
                    parentId: item.parentId,
                    parentEdId: item.parentEdId,
                    parentName: item.parentName,
                    id: item.id,
                    edId: item.edId,
                    type: item.type
                };
                return obj;
            },
            // 点击tree新增按钮
            handleAdd (data) {
                this.currentId = null;
                resetObj(this.formAttr);
                this.$refs['formValidate'] &&
                    this.$refs['formValidate'].resetFields();
                this.formAttr = Object.assign(
                    {},
                    {
                        parentId: data.edId,
                        parentType: data.type,
                        parentDepartName: data.title,
                        parentNodeId: data.id
                    }
                );
            },
            // 点击tree查看节点信息
            async handleEdit (data) {
                const params = {
                    id: data.edId,
                    type: data.type
                };
                const res = await getDepartInfo(params);
                if (res.status === this.code) {
                    this.currentId = res.content.id;
                    this.formAttr = Object.assign({}, this.formAttr, res.content, {
                        createTime: getDate(res.content.createTime, 'long'),
                        updateTime: getDate(res.content.updateTime, 'long'),
                        parentDepartName: data.parentName,
                        parentId: res.content.parentId,
                        parentNodeId: data.parentId,
                        nodeId: data.id
                    });
                }
            }
        }
    };
</script>

<style scoped lang="less">
.col-tree-view {
    padding: 10px;
    border: 1px solid #dcdee2;
}

.org-form {
    padding: 0 100px 0 10px;
}

.tr {
    text-align: right;
}

/deep/ .tree-node-hover {
    cursor: pointer;
}
</style>
