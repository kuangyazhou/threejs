<template>
    <div class="inventoryInit">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.inventoryOrganizationId"
                        @on-change="searchInventory"
                        placeholder="请选择库存组织"
                    >
                        <Option
                            v-for="item in inventoryOrganizationArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.warehouseId"
                        :disabled="!tableQueryAttr.inventoryOrganizationId"
                        @on-change="selectSearch"
                        placeholder="请选择仓库"
                    >
                        <Option
                            v-for="item in warehouseArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.customerName"
                        @on-search="search"
                        search
                        placeholder="客户名称"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        placeholder="请选择单据状态"
                        @on-change="selectSearch"
                        remote
                        v-model="tableQueryAttr.orderStatus"
                    >
                        <Option
                            v-for="item in statusArr"
                            :label="item.label"
                            :value="item.value"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                销售退货单列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button v-has="btnRightList.salesRefundAdd" @click="openSendModal"
                        icon="md-add"
                    >新增</Button>
                    <Button
                        v-has="btnRightList.salesRefundEdit"
                        @click="openOutOrderModal"
                        icon="ios-create-outline"
                    >编辑</Button>
                    <Button
                        v-has="btnRightList.salesRefundSubmit"
                        @click="submitSalesRefundOrder"
                        icon="md-send"
                    >提交</Button>
                    <Button
                        v-has="btnRightList.salesRefundCancel"
                        @click="cancelSalesRefundOrder"
                        icon="md-undo"
                    >撤回</Button>
                    <Button
                        v-has="btnRightList.salesRefundApprove"
                        @click="approveSalesRefundOrder"
                        icon="md-redo"
                    >审核</Button>
                </ButtonGroup>
            </div>
            <erp-table
                highlight
                ref="salesTable"
                @on-current-change="currentChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>
<!--        选择销售出库单弹窗-->
        <Modal
            v-model="sendShowFlag"
            width="900"
            title="选择销售出库单明细"
            :loading="sendModelLoading"
            :mask-closable="false"
            @on-ok="sendModalOk"
            @on-cancel="sendModalCancel"
        >
            <Row :gutter="10" class="mb20">
                <Col span="4">
                    <Select
                        v-model="sendQueryAttr.inventoryOrganizationId"
                        @on-change="searchInventory"
                        placeholder="请选择库存组织"
                    >
                        <Option
                            v-for="item in inventoryOrganizationArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="4">
                    <Select
                        v-model="sendQueryAttr.warehouseId"
                        :disabled="!sendQueryAttr.inventoryOrganizationId"
                        @on-change="sendSearch"
                        placeholder="请选择仓库"
                    >
                        <Option
                            v-for="item in warehouseArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="4">
                    <Input
                        v-model="sendQueryAttr.customerName"
                        placeholder="客户名称"
                    ></Input>
                </Col>
                <Col span="4">
                    <DatePicker
                        v-model="sendQueryAttr.beginDate"
                        format="yyyy-MM-dd"
                        type="date"
                        @on-change="beginDateChange"
                        placeholder="制单开始日期"
                    ></DatePicker>
                </Col>
                <Col span="4">
                    <DatePicker
                        v-model="sendQueryAttr.endDate"
                        format="yyyy-MM-dd"
                        type="date"
                        @on-change="endDateChange"
                        placeholder="制单结束日期"
                    ></DatePicker>
                </Col>
                <Col span="4">
                    <Button @click="sendSearch">搜索</Button>
                </Col>
            </Row>
            <erp-table
                @on-selection-change="sendSelection"
                @on-page-no-change="salePageNoChange"
                :erpTableTitle="sendTableTitle"
                :erpTableData="sendTableData"
                :tableLoading="saleTableLoading"
                :current="saleComAttr.pageNo"
                :total="saleTotal"
                :showSizer='false'
                :showElevator='false'
            >
            </erp-table>
        </Modal>
<!--        新增编辑出库单弹窗-->
        <Modal
            v-model="modalShowFlag"
            width="1000"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-cancel="modalCancel(clearCurrent)"
        >
            <div>
                <Form
                    :model="formAttr"
                    ref="formValidate"
                    :rules="ruleValidate"
                    :label-width="120"
                >
                    <Row>
                        <Col span="12">
                            <FormItem label="销售退货单号">
                                <Input
                                    disabled
                                    v-model="formAttr.saleReturnOrderNo"
                                    placeholder="销售退货单号"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="库存组织">
                                <Input
                                    disabled
                                    v-model="formAttr.inventoryOrganizationName"
                                    placeholder="请输入库存组织"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="仓库" prop="warehouseId">
                                <Select
                                    :disabled="curStatus !== 1"
                                    v-model="formAttr.warehouseId"
                                    placeholder="请选择仓库"
                                >
                                    <Option
                                        v-for="item in warehouseArr"
                                        :value="item.value"
                                        :key="item.value"
                                    >{{ item.label }}
                                    </Option
                                    >
                                </Select>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="客户">
                                <Input
                                    disabled
                                    v-model="formAttr.customerName"
                                    placeholder="请输入客户"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="退货时间">
                                <DatePicker
                                    :disabled="curStatus !== 1"
                                    v-model="formAttr.returnTime"
                                    format="yyyy-MM-dd"
                                    type="date"
                                    placeholder="退货时间"
                                ></DatePicker>
                            </FormItem>
                        </Col>
                        <Col span="24">
                            <FormItem label="备注">
                                <Input
                                    :disabled="curStatus !== 1"
                                    v-model="formAttr.remark"
                                    placeholder="请输入备注"
                                ></Input>
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="md-list"></Icon>
                        销售退货明细列表
                    </p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button :disabled="curStatus !== 1" @click="detailOrderAdd">新增</Button>
                        </ButtonGroup>
                    </div>
                    <Table border :columns="orderDetailTableTitle" :data="orderDetailTableData">
                    </Table>
                </Card>
            </div>
            <div slot="footer">
                <Button @click="modalCancel(clearCurrent)">取消</Button>
                <Button v-if="curStatus === 1" @click="modalOk(1)">保存</Button>
                <Button v-if="curStatus === 1" type="primary" @click="modalOk(2)">提交</Button>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { getOrganizationDropList, getWarehouseDropList } from '@/api/inventory/inventory';
    import { getSalesReturnDetailList, getSalesOutboundDetailList, addSalesRefundOrder, getSalesRefundDetail, editSalesRefundOrder, submitSalesRefundOrder, cancelSalesRefundOrder, approveSalesRefundOrder, delSalesRefundOrderDetail } from '@/api/saleManage/salesReturn';
    import { getDate, resetObj } from '@/libs/tools';

    export default {
        name: 'salesReturnOrder',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    inventoryOrganizationId: '',
                    warehouseId: '',
                    customerName: '',
                    orderStatus: ''
                },
                inventoryOrganizationArr: [], // 库存组织下拉
                warehouseArr: [], // 仓库列表下拉
                erpTableTitle: [
                    {
                        title: '退货单号',
                        align: 'center',
                        minWidth: 120,
                        key: 'saleReturnOrderNo'
                    },
                    {
                        title: '库存组织',
                        align: 'center',
                        minWidth: 120,
                        key: 'inventoryOrganizationName'
                    },
                    {
                        title: '仓库',
                        align: 'center',
                        minWidth: 120,
                        key: 'warehouseName'
                    },
                    {
                        title: '客户',
                        align: 'center',
                        minWidth: 120,
                        key: 'customerName'
                    },
                    {
                        title: '退货时间',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.returnTime)
                            );
                        }
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityName'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brand'
                    },
                    {
                        title: '退货数量',
                        align: 'center',
                        minWidth: 90,
                        key: 'quantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 90,
                        key: 'unit'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    {
                        title: '有效期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.effectiveDate)
                            );
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '原出库单明细号',
                        align: 'center',
                        minWidth: 130,
                        key: 'outboundOrderNo'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        fixed: 'right',
                        render: (h, params) => {
                            const status =
                                params.row.orderStatus === 1 ? '未提交' : params.row.orderStatus === 2 ? '已提交' : '已审核';
                            return h('span', {}, status);
                        }
                    }
                ],
                statusArr: [
                    {
                        id: 1,
                        label: '未提交',
                        value: 1
                    },
                    {
                        id: 2,
                        label: '已提交',
                        value: 2
                    },
                    {
                        id: 3,
                        label: '已审核',
                        value: 3
                    }
                ],
                sendShowFlag: false, // 销售出库单弹窗开关
                sendModelLoading: false,
                sendQueryAttr: {
                    inventoryOrganizationId: '',
                    warehouseId: '',
                    beginDate: '',
                    endDate: '',
                    customerName: ''
                }, // 销售出库单搜索
                sendTableTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center',
                        fixed: 'left'
                    },
                    {
                        title: '出库单号',
                        align: 'center',
                        minWidth: 110,
                        key: 'outboundOrderNo'
                    },
                    {
                        title: '客户',
                        align: 'center',
                        minWidth: 110,
                        key: 'customerName'
                    },
                    {
                        title: '出库类型',
                        align: 'center',
                        minWidth: 100,
                        render: (h) => {
                            return h(
                                'span',
                                {},
                                '销售出库'
                            );
                        }
                    },
                    {
                        title: '库存组织',
                        align: 'center',
                        minWidth: 120,
                        key: 'inventoryOrganizationName'
                    },
                    {
                        title: '仓库',
                        align: 'center',
                        minWidth: 120,
                        key: 'warehouseName'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 110,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 90,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brand'
                    },
                    {
                        title: '数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'quantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 90,
                        key: 'unit'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    {
                        title: '生产日期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.producedDate)
                            );
                        }
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.effectiveDate)
                            );
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '录入时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.recordTime)
                            );
                        }
                    }
                ], // 销售出库单明细栏目
                sendTableData: [], // 销售出库单明细数据
                saleTableLoading: false,
                saleTotal: 0,
                saleComAttr: {
                    pageNo: 1,
                    pageSize: 10
                },
                curSendData: [], // 选中的销售出库单
                formAttr: {
                    saleReturnOrderNo: '',
                    inventoryOrganizationName: '',
                    warehouseId: '',
                    customerName: '',
                    returnTime: '',
                    remark: '',
                    itemQuantity: [],
                    orderStatus: ''
                },
                ruleValidate: {
                    warehouseId: [
                        {
                            required: true,
                            type: 'number',
                            message: '仓库不能为空',
                            trigger: 'change'
                        }
                    ]
                },
                orderDetailTableTitle: [
                    {
                        title: '来源类型',
                        align: 'center',
                        minWidth: 100,
                        render: (h) => {
                            return h(
                                'span',
                                {},
                                '销售出库'
                            );
                        }
                    },
                    {
                        title: '来源单据号',
                        align: 'center',
                        minWidth: 110,
                        key: 'outboundOrderNo'
                    },
                    {
                        title: '物料编码',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityCode'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 110,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 90,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brand'
                    },
                    {
                        title: '退货数量',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h('Input', {
                                props: {
                                    type: 'number',
                                    value: params.row.quantity
                                },
                                on: {
                                    'on-blur': (val) => {
                                        const value = val.target.value;
                                        if (!value || value === '') {
                                            return this.$Message.error('退货数量不能为空');
                                        }
                                        if (value > params.row.leftQuantity) {
                                            this.$Message.error('退货数量不能大于剩余数量');
                                            params.row.quantity = '';
                                            this.orderDetailTableData[params.index].quantity = '';
                                        } else {
                                            params.row.quantity = value;
                                            this.orderDetailTableData[params.index].quantity = value;
                                        }
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '剩余数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'leftQuantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 90,
                        key: 'unit'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.effectiveDate)
                            );
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '录入时间',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.recordTime, 'long')
                            );
                        }
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            const status =
                                params.row.auditStatus === 1 ? '未提交' : params.row.auditStatus === 2 ? '已提交' : '已审核';
                            return h('span', {}, status);
                        }
                    },
                    {
                        title: '操作',
                        key: 'action',
                        minWidth: 130,
                        align: 'center',
                        fixed: 'right',
                        render: (h, params) => {
                            return h('div', [
                                h('Button', {
                                    props: {
                                        type: 'info',
                                        size: 'small'
                                    },
                                    attrs: {
                                        disabled: this.curStatus !== 1
                                    },
                                    style: {
                                        marginRight: '5px'
                                    },
                                    on: {
                                        click: () => {
                                            this.curIndex = params.index;
                                            const excludeIds = this.orderDetailTableData.map(item => {
                                                return item.outboundOrderItemId;
                                            }).join();
                                            this.sendQueryAttr = Object.assign({}, this.sendQueryAttr, {
                                                inventoryOrganizationId: this.tableQueryAttr.inventoryOrganizationId,
                                                warehouseId: this.tableQueryAttr.warehouseId,
                                                outboundOrderId: params.row.outboundOrderId,
                                                excludeIds
                                            });
                                            this.getSalesOutboundDetailList();
                                            this.sendShowFlag = true;
                                        }
                                    }
                                }, '插入'),
                                h('Button', {
                                    props: {
                                        type: 'error',
                                        size: 'small'
                                    },
                                    attrs: {
                                        disabled: this.curStatus !== 1
                                    },
                                    on: {
                                        click: () => {
                                            this.delOrderDetail(params);
                                        }
                                    },
                                    directives: [
                                        {
                                            name: 'has',
                                            value: this.btnRightList.salesRefundDel
                                        }
                                    ]
                                }, '删除')
                            ]);
                        }
                    }
                ], // 出库单明细表栏目
                orderDetailTableData: [], // 出库单明细表数据
                curIndex: null, // 新增插入的当前行号
                curRow: null,
                curStatus: 1 // 1未提交2已提交3已审核
            };
        },
        created () {
            this.getAllSelectData();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                if (!this.tableQueryAttr.warehouseId && !this.tableQueryAttr.inventoryOrganizationId) return;
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr, {
                            orderStatus: this.tableQueryAttr.orderStatus ? this.tableQueryAttr.orderStatus : 1
                        }
                    );
                    const res = await getSalesReturnDetailList(params);
                    getListMixin(res);
                });
            },
            getAllSelectData () {
                this.getInventoryOrganizationList();
            },
            // 库存组织下拉
            async getInventoryOrganizationList () {
                const res = await getOrganizationDropList();
                if (res.status === this.code) {
                    this.inventoryOrganizationArr = res.content.map(item => {
                        return {
                            label: item.inventoryOrganizationName,
                            value: item.id
                        };
                    });
                    if (this.inventoryOrganizationArr.length && !this.tableQueryAttr.inventoryOrganizationId) {
                        this.tableQueryAttr.inventoryOrganizationId = this.inventoryOrganizationArr[0].value;
                        this.getWarehouseList(this.tableQueryAttr.inventoryOrganizationId);
                    }
                }
            },
            // 获取库存组织关联的仓库
            async getWarehouseList (id) {
                if (!id) return;
                const params = Object.assign({}, {
                    inventoryOrganizationId: id
                });
                const res = await getWarehouseDropList(params);
                if (res.status === this.code) {
                    this.warehouseArr = res.content.map(item => {
                        return {
                            label: item.warehouseName,
                            value: item.id
                        };
                    });
                    if (this.warehouseArr.length) {
                        this.tableQueryAttr.warehouseId = this.warehouseArr[0].value;
                        if (this.tableQueryAttr.warehouseId && this.tableQueryAttr.inventoryOrganizationId && !this.sendModelLoading) {
                            this.getTableList();
                        }
                        if (this.sendModelLoading) {
                            this.sendQueryAttr.warehouseId = this.warehouseArr[0].value;
                            this.getSalesOutboundDetailList();
                        }
                    }
                }
            },
            // 选择库存之后
            searchInventory (val) {
                this.getWarehouseList(val);
            },
            // 选中单行后
            currentChange (val) {
                this.curRow = val;
                this.curStatus = val.orderStatus;
                this.currentId = val.saleReturnOrderId;
            },
            // 打开出库单明细弹窗
            openSendModal () {
                this.clearCurrent();
                this.sendQueryAttr = Object.assign({}, this.sendQueryAttr, {
                    inventoryOrganizationId: this.tableQueryAttr.inventoryOrganizationId,
                    warehouseId: this.tableQueryAttr.warehouseId
                });
                this.curStatus = 1;
                this.getSalesOutboundDetailList();
                this.sendShowFlag = true;
            },
            // 取消单行选中
            clearCurrent () {
                this.currentId = null;
                this.curRow = null;
                this.orderDetailTableData = [];
                this.$refs.salesTable.clearCurrentTableRow();
            },
            // 确认选中销售出库单明细
            async sendModalOk () {
                if (this.curSendData.length === 0) {
                    this.$Message.error('请先勾选销售出库单明细');
                    return this.changeLoading('sendModelLoading');
                }
                if (!this.currentId) {
                    let sameOrder = true;
                    let items = [];
                    this.curSendData.forEach(item => {
                        if (item.outboundOrderId !== this.curSendData[0].outboundOrderId) {
                            sameOrder = false;
                        } else {
                            items.push(item.outboundOrderItemId);
                        }
                    });
                    if (!sameOrder) {
                        this.$Message.error('只能选择同一个销售出库单的明细');
                        return this.changeLoading('sendModelLoading');
                    }
                    const params = {
                        outboundOrderItemIds: items
                    };
                    const res = await addSalesRefundOrder(params);
                    this.changeLoading('sendModelLoading');
                    if (res.status === this.code) {
                        this.$Message.success(res.msg);
                        this.currentId = res.content.id;
                        this.sendModalCancel();
                        this.openOutOrderModal();
                    }
                } else {
                    let addItems = [];
                    addItems = this.curSendData.map(item => {
                        return Object.assign({}, item, {
                            quantity: 0
                        });
                    });
                    if (this.curIndex === null) {
                        this.orderDetailTableData = this.orderDetailTableData.concat(addItems);
                    } else {
                        addItems.unshift(this.curIndex + 1, 0);
                        Array.prototype.splice.apply(this.orderDetailTableData, addItems);
                    }
                    this.changeLoading('sendModelLoading');
                    this.sendModalCancel();
                }
            },
            // 关闭销售出库单明细弹窗
            sendModalCancel () {
                this.curSendData = [];
                this.sendShowFlag = false;
                this.saleComAttr.pageNo = 1;
                resetObj(this.sendQueryAttr);
            },
            // 获取销售出库单明细
            async getSalesOutboundDetailList () {
                if (!this.sendQueryAttr.warehouseId && !this.sendQueryAttr.inventoryOrganizationId) return;
                this.saleTableLoading = true;
                const params = Object.assign({}, this.saleComAttr, this.sendQueryAttr);
                const res = await getSalesOutboundDetailList(params);
                this.saleTableLoading = false;
                if (res.status === this.code) {
                    this.sendTableData = res.content.list;
                    this.saleTotal = res.content.total;
                }
            },
            // 格式化制单开始时间
            beginDateChange (value) {
                this.sendQueryAttr.beginDate = value;
            },
            // 格式化制单结束时间
            endDateChange (value) {
                this.sendQueryAttr.endDate = value;
            },
            sendSearch () {
                this.getSalesOutboundDetailList();
            },
            // 销售出库单明细勾选
            sendSelection (value) {
                this.curSendData = value;
            },
            // 打开出库单弹窗
            openOutOrderModal () {
                if (!this.currentId) return this.$Message.error('请先选中销售退货单');
                this.getSalesRefundDetail();
                this.addItem('销售出库单编辑');
            },
            // 获取某条销售退货单明细
            async getSalesRefundDetail () {
                const params = Object.assign({}, {
                    id: this.currentId
                });
                const res = await getSalesRefundDetail(params);
                if (res.status === this.code) {
                    const data = res.content;
                    this.formAttr = Object.assign({}, this.formAttr, {
                        saleReturnOrderNo: data.saleReturnOrderNo,
                        inventoryOrganizationName: data.inventoryOrganizationName,
                        warehouseId: data.warehouseId,
                        customerName: data.customerName,
                        returnTime: data.returnTime ? getDate(data.returnTime) : '',
                        remark: data.remark ? data.remark : ''
                    });
                    this.orderDetailTableData = data.itemDetailList.map(item => {
                        return Object.assign({}, item, {
                            quantity: item.quantity ? item.quantity : 0
                        });
                    });
                }
            },
            // 保存销售退货单明细
            async modalOk (type) {
                let returnTime = this.formAttr.returnTime;
                if (returnTime instanceof Date) {
                    returnTime = getDate(returnTime);
                }
                let judgeNum = false;
                const itemQuantity = this.orderDetailTableData.map(item => {
                    if (!item.quantity) judgeNum = true;
                    return Object.assign({}, {
                        outboundOrderItemId: item.outboundOrderItemId,
                        quantity: item.quantity
                    });
                });
                if (judgeNum) {
                    this.changeLoading();
                    this.$Message.error('退货数量不能为空');
                    return;
                }
                let params = Object.assign({}, this.formAttr, {
                    orderStatus: type,
                    returnTime,
                    id: this.currentId,
                    itemQuantity: [...itemQuantity]
                });
                if (this.orderDetailTableData.length === 0) {
                    this.changeLoading();
                    this.$Message.error('至少要有一条销售退货单明细');
                    return;
                }
                const res = await editSalesRefundOrder(params);
                this.changeLoading();
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.tableComAttr.pageNo = 1;
                    this.getTableList();
                    if (type === 2) this.modalShowFlag = false;
                }
            },
            // 删除出库单明细
            delOrderDetail (data) {
                this.$Modal.confirm({
                    title: '是否确认删除',
                    onOk: async () => {
                        const params = {
                            id: data.row.outboundOrderItemId
                        };
                        const res = await delSalesRefundOrderDetail(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.orderDetailTableData.splice(params.index, 1);
                        }
                    }
                });
            },
            // 出库单弹窗中点击新增
            detailOrderAdd () {
                this.curIndex = null;
                const excludeIds = this.orderDetailTableData.map(item => {
                    return item.outboundOrderItemId;
                }).join();
                this.sendQueryAttr = Object.assign({}, this.sendQueryAttr, {
                    inventoryOrganizationId: this.tableQueryAttr.inventoryOrganizationId,
                    warehouseId: this.tableQueryAttr.warehouseId,
                    outboundOrderId: this.orderDetailTableData.length ? this.orderDetailTableData[0].outboundOrderId : '',
                    excludeIds
                });
                this.getSalesOutboundDetailList();
                this.sendShowFlag = true;
            },
            // 提交
            async submitSalesRefundOrder () {
                if (!this.currentId) {
                    return this.$Message.error('请先选择需要提交的订单');
                }
                if (this.curStatus !== 1) {
                    return this.$Message.error('只有未提交的单据允许提交');
                }
                const params = {
                    id: this.currentId
                };
                const res = await submitSalesRefundOrder(params);
                if (res.status === this.code) {
                    this.clearCurrent();
                    this.todoOver(res.msg);
                }
            },
            // 撤回
            async cancelSalesRefundOrder () {
                if (!this.currentId) {
                    return this.$Message.error('请先选择需要撤回的订单');
                }
                if (this.curStatus !== 2) {
                    return this.$Message.error('只有已提交的单据允许撤回');
                }
                const params = {
                    id: this.currentId
                };
                const res = await cancelSalesRefundOrder(params);
                if (res.status === this.code) {
                    this.clearCurrent();
                    this.todoOver(res.msg);
                }
            },
            // 审核
            async approveSalesRefundOrder () {
                if (!this.currentId) {
                    return this.$Message.error('请先选择需要审核的订单');
                }
                if (this.curStatus !== 2) {
                    return this.$Message.error('只有已提交的单据允许审核');
                }
                const params = {
                    id: this.currentId
                };
                const res = await approveSalesRefundOrder(params);
                if (res.status === this.code) {
                    this.clearCurrent();
                    this.todoOver(res.msg);
                }
            },
            salePageNoChange (value) {
                this.saleComAttr.pageNo = value;
                this.getSalesOutboundDetailList();
            }
        }
    };
</script>

<style scoped lang="less">
    /deep/ .ivu-table-cell{
        padding: 4px;
    }
</style>
