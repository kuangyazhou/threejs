<template>
    <div class="erp-content" ref="erp">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Select
                        filterable
                        placeholder="系统字段"
                        @on-change="selectSearch"
                        remote
                        v-model="tableQueryAttr.systemFieldId"
                    >
                        <Option
                            v-for="item in systemFieldArr"
                            :label="item.fieldName"
                            :value="item.id"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        placeholder="级别"
                        @on-change="selectSearch"
                        remote
                        v-model="tableQueryAttr.levelId"
                    >
                        <Option
                            label="组织级"
                            :value="currentOrganization.id"
                        ></Option>
                        <Option
                            label="公司级"
                            :value="currentDepartment.id"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                系统字典资料列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button v-has="btnRightList.systemFieldAdd" @click="add" icon="md-add">新增</Button>
                    <Button v-has="btnRightList.systemFieldDel" @click="del" icon="md-trash">删除</Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-selection-change="selectionChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel"
        >
            <div class="erp-modal-content">
                <Form
                    :model="formAttr"
                    :rules="ruleValidate"
                    ref="formValidate"
                    :label-width="120"
                >
                    <FormItem label="系统字段" prop="systemFieldId">
                        <Select
                            placeholder="请选择系统字段"
                            remote
                            @on-change="afterChangeSystem"
                            v-model="formAttr.systemFieldId"
                        >
                            <Option
                                v-for="item in systemFieldArr"
                                :label="item.fieldName"
                                :value="item.id"
                                :key="item.id"
                            ></Option>
                        </Select>
                    </FormItem>
                    <FormItem label="显示值" prop="fieldValue">
                        <Input
                            v-model="formAttr.fieldValue"
                            placeholder="请输入显示值"
                        ></Input>
                    </FormItem>
                    <FormItem label="标志值">
                        <Input
                            v-model="formAttr.valueCode"
                            placeholder="请输入标志值"
                        ></Input>
                    </FormItem>
                </Form>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        addFieldValues,
        deleteFieldValues,
        editFieldValues,
        getFieldValuesList,
        getFieldList
    } from '@/api/setting/systemFields';
    import { getDate } from '@/libs/tools';

    export default {
        name: 'systemFieldData',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    systemFieldId: '',
                    levelId: ''
                }, // 表格查询条件
                formAttr: {
                    systemFieldId: '',
                    fieldValue: '',
                    levelId: '',
                    valueCode: ''
                }, // modal 值对象
                ruleValidate: {
                    systemFieldId: [
                        {
                            required: true,
                            type: 'number',
                            message: '系统字段编号不能为空',
                            trigger: 'blur'
                        }
                    ],
                    fieldValue: [
                        {
                            required: true,
                            message: '显示值不能为空',
                            trigger: 'blur'
                        }
                    ]
                }, // modal 表单验证
                erpTableTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '系统字段',
                        align: 'center',
                        minWidth: 120,
                        key: 'fieldName'
                    },
                    {
                        title: '系统字段代码',
                        align: 'center',
                        minWidth: 120,
                        key: 'fieldCode'
                    },
                    {
                        title: '显示值',
                        align: 'center',
                        minWidth: 120,
                        key: 'fieldValue'
                    },
                    {
                        title: '级别',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            const level = params.row.level;
                            let levelName;
                            if (level === 0) {
                                levelName = '系统级';
                            } else if (level === 1) {
                                levelName = '组织级';
                            } else if (level === 2) {
                                levelName = '公司级';
                            }
                            return h('span', {}, levelName);
                        }
                    },
                    {
                        title: '标志值',
                        align: 'center',
                        minWidth: 90,
                        key: 'valueCode'
                    },
                    {
                        title: '更新人',
                        align: 'center',
                        minWidth: 120,
                        key: 'updateName'
                    },
                    {
                        title: '更新时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.updateTime, 'long')
                            );
                        }
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 100,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.editTableData(
                                                    params,
                                                    '编辑系统字典资料'
                                                );
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.systemFieldEdit
                                            }
                                        ]
                                    },
                                    '编辑'
                                )
                            ]);
                        }
                    }
                ], // 表格标题
                systemFieldArr: [] // 系统字段数组
            };
        },
        created () {
            this.getFieldList();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr,
                        {
                            levelId:
                                this.tableQueryAttr.levelId === -1
                                    ? ''
                                    : this.tableQueryAttr.levelId
                        }
                    );
                    const res = await getFieldValuesList(params);
                    getListMixin(res);
                });
            },
            // 新增编辑确认按钮
            modalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res;
                    const params = this.currentId
                        ? Object.assign({}, this.formAttr, {
                            id: this.currentId,
                            status: 3
                        })
                        : Object.assign({}, this.formAttr);
                    if (this.currentId) {
                        res = await editFieldValues(params);
                    } else {
                        res = await addFieldValues(params);
                    }
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    } else {
                        this.changeLoading();
                    }
                });
            },
            add () {
                if (this.tableQueryAttr.systemFieldId) {
                    this.formAttr = Object.assign({}, this.formAttr, {
                        systemFieldId: this.tableQueryAttr.systemFieldId
                    });
                    this.afterChangeSystem(this.tableQueryAttr.systemFieldId);
                }
                this.addItem('新增系统字典资料');
            },
            del () {
                const flag = this.delCheck();
                if (flag) {
                    this.$Modal.confirm({
                        title: '确认删除所选项吗？',
                        onOk: async () => {
                            const res = await deleteFieldValues(
                                this.tableSelectValue
                            );
                            if (res.status === this.code) {
                                this.$Message.success(res.msg);
                                this.tableSelectValue = [];
                                this.getTableList();
                            }
                        }
                    });
                }
            },
            // 获取全部字段列表
            async getFieldList () {
                const res = await getFieldList({});
                if (res.status === this.code) {
                    this.systemFieldArr = res.content;
                }
            },
            // 选中系统字典后
            afterChangeSystem (val) {
                if (!val) return;
                const curField = this.systemFieldArr.filter(item => {
                    return item.id === val;
                })[0];
                if (curField.level === 1) {
                    this.formAttr.levelId = this.currentOrganization.id;
                } else if (curField.level === 2) {
                    this.formAttr.levelId = this.currentDepartment.id;
                }
            }
        }
    };
</script>

<style scoped lang="less">
.erp-modal-content {
    overflow-y: visible;
}
</style>
