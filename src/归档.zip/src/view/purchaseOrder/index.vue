<template>
    <div>
        <!-- <h1>采购订单</h1> -->
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.supplierEnableCode"
                        @on-change="search"
                        placeholder="供应商"
                        filterable
                        ref="filter"
                    >
                        <Option
                            v-for="(item,index) in allSupplier"
                            :key="index"
                            :label="item.supplierName"
                            :value="item.supplierEnableCode"
                        ></Option>
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.orderNo"
                        @on-search="search"
                        search
                        placeholder="采购单号"
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.commodityName"
                        @on-search="search"
                        search
                        placeholder="物料名称"
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <DatePicker v-model="tableQueryAttr.date" placeholder="起止日期" type="daterange"></DatePicker>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>采购订单列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="add" v-has="btnRightList.purchaseOrderSave" icon="md-add">新增</Button>
                    <Button
                        @click="addRed"
                        v-has="btnRightList.purchaseRedSave"
                        icon="ios-add-circle"
                    >新增红字</Button>
                    <Button
                        @click="orderSubmit(currentRow)"
                        v-has="btnRightList.purchaseOrderSubmit"
                        icon="md-send"
                    >提交</Button>
                    <Button
                        @click="orderReturn(currentRow)"
                        v-has="btnRightList.purchaseOrderReturn"
                        icon="md-undo"
                    >撤回</Button>
                    <Button
                        @click="orderDel(currentRow)"
                        v-has="btnRightList.purchaseOrderDel"
                        icon="md-trash"
                    >删除</Button>
                    <Button
                        @click="orderAudit(currentRow)"
                        v-has="btnRightList.purchaseOrderPass"
                        icon="md-redo"
                    >审核</Button>
                    <Button
                        @click="edit(currentRow)"
                        v-has="btnRightList.purchaseOrderSave"
                        icon="ios-create-outline"
                    >编辑</Button>
                </ButtonGroup>
            </div>
            <erp-table
                ref="managerTable"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                @on-current-change="currentChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
                highlight
            ></erp-table>
        </Card>
        <!-- 选择供应商弹框-->
        <Modal v-model="supplierModal" title="供应商查询" width="960" :mask-closable="false">
            <Row :gutter="12" class="mb10">
                <Col span="8">
                    <Input v-model="supplierAttr.supplierName" placeholder="企业名称"></Input>
                </Col>
                <Col span="8">
                    <Input v-model="supplierAttr.supplierEnableCode" placeholder="企业代码"></Input>
                </Col>
                <Col span="4">
                    <Button type="primary" @click="getSupplier">查询</Button>
                </Col>
            </Row>
            <div class="clearfix">
                <Table :data="supplierData" :columns="supplierTitle"></Table>
                <div class="wrapper-page">
                    <Page
                        :current="supplierAttr.pageNo"
                        :total="supplierAttr.total"
                        @on-change="supplierPageChange"
                    ></Page>
                </div>
            </div>
            <div slot="footer"></div>
        </Modal>

        <!-- 选择物料 -->
        <Modal v-model="materialModal" title="物料查询" width="960" :mask-closable="false">
            <Row :gutter="12" class="mb10">
                <Col span="8">
                    <Input placeholder="物料名称" v-model="materialAttr.commodityName"></Input>
                </Col>
                <Col span="8">
                    <Input placeholder="专业分组" v-model="materialAttr.specializedGroup"></Input>
                </Col>
                <Col span="4">
                    <Button type="primary" @click="getMaterial">搜索</Button>
                </Col>
            </Row>
            <div class="clearfix">
                <Table :data="materialData" :columns="materialTitle"></Table>
                <div class="wrapper-page">
                    <Page
                        :current="materialAttr.pageNo"
                        :total="materialAttr.total"
                        @on-change="materialPageChange"
                    ></Page>
                </div>
            </div>
            <div slot="footer">
                <Button @click="materialModal=false">关闭</Button>
            </div>
        </Modal>

        <!-- 红字订单选择框 -->
        <Modal
            v-model="redModal"
            title="选择采购订单"
            width="960"
            :mask-closable="false"
            @on-ok="redOk"
            @on-cancel="redClose"
        >
            <Row :gutter="12" class="mb10">
                <Col span="5">
                    <Select
                        v-model="redAttr.supplierEnableCode"
                        filterable
                        @on-change="getPassOrder"
                        ref="filter"
                        placeholder="供应商"
                    >
                        <Option
                            v-for="(item,index) in supplierData"
                            :key="index"
                            :label="item.supplierName"
                            :value="item.supplierEnableCode"
                        ></Option>
                    </Select>
                </Col>
                <Col span="5">
                    <Input v-model="redAttr.commodityName" placeholder="物料名称"></Input>
                </Col>
                <Col span="4">
                    <DatePicker v-model="redAttr.startDate" placeholder="开始日期"></DatePicker>
                </Col>
                <Col span="4">
                    <DatePicker v-model="redAttr.endDate" placeholder="结束日期"></DatePicker>
                </Col>
                <Col span="4">
                    <Button type="primary" @click="getPassOrder">搜索</Button>
                </Col>
            </Row>
            <div class="clearfix">
                <Table :data="redTable" :columns="redTitle" @on-selection-change="redSelect"></Table>
                <div class="wrapper-page">
                    <Page
                        :current="redAttr.pageNo"
                        @on-change="redChangePage"
                        @on-page-size-change="redChangePageSize"
                        show-sizer
                        :total="redAttr.total"
                        show-elevator
                    />
                </div>
            </div>
        </Modal>

        <!-- 编辑框 -->
        <Modal
            v-model="modalShowFlag"
            width="960"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-cancel="modalCancel"
            @on-ok="modalOk"
            fullscreen
        >
            <Form :model="formAttr" :rules="ruleValidate" ref="formValidate" :label-width="100">
                <Row>
                    <Col span="8">
                        <FormItem label="单据类型" prop="orderType">
                            <Select v-model="formAttr.orderType" :disabled="isRed||readOnly">
                                <Option
                                    v-for="item in orderTypeArr"
                                    :value="item.id"
                                    :label="item.fieldValue"
                                    :key="item.id"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="16">
                        <FormItem label="供应商名称" prop="supplierName">
                            <!-- <Input placeholder="供应商名称"></Input> -->
                            {{formAttr.supplierName}}
                            <Button
                                @click="selectSupplier"
                                :disabled="isRed||readOnly"
                                type="success"
                            >选择</Button>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="8">
                        <FormItem label="采购单号">
                            <Input disabled v-model="formAttr.orderNo" placeholder="采购单号"></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="付款币种" prop="currencyId">
                            <Select
                                v-model="formAttr.currencyId"
                                :disabled="isRed||readOnly"
                                @on-change="currencyChange"
                            >
                                <Option
                                    v-for="item in currencyArr"
                                    :value="item.id"
                                    :label="item.fieldValue"
                                    :key="item.index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="汇率" prop="currencyRate">
                            <Input
                                v-model="formAttr.currencyRate"
                                :disabled="isRed||readOnly"
                                placeholder="汇率"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="制单日期">
                            <Input disabled placeholder="制单日期" :value="getDate(new Date()) "></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="制单人员">
                            <Input disabled placeholder="制单人员" :value="this.getUserName"></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="采购人员">
                            <Input disabled placeholder="采购人员" :value="this.getUserName"></Input>
                        </FormItem>
                    </Col>
                    <Col span="16">
                        <FormItem label="采购摘要">
                            <Input v-model="formAttr.orderRemark" :disabled="isRed||readOnly"></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="仓库" prop="warehouseId">
                            <Select
                                v-model="formAttr.warehouseId"
                                @on-change="selectHouse"
                                :disabled="isRed||readOnly"
                            >
                                <Option
                                    v-for="item in houseArr"
                                    :label="item.warehouseName"
                                    :value="item.id"
                                    :key="item.id"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                </Row>
            </Form>
            <Card dis-hover :bordered="false">
                <p slot="title">
                    <Icon type="md-list"></Icon>物料信息
                </p>
                <div slot="extra">
                    <Button v-if="!readOnly" @click="addDetail" icon="md-add">新增</Button>
                </div>
                <Table border :columns="detailTitle" :data="detailTable">
                    <template slot-scope="{row,index}" slot="price">
                        <span v-if="isRed||readOnly">{{row.taxPrice}}</span>
                        <!-- <Select
                            @on-change="value=>priceChange(value,row,index)"
                            v-model="detailTable[index]['purchasePriceId']"
                            :disabled="isRed||readOnly"
                            v-else
                        >
                            <Option
                                v-for="item in detailTable[index]['priceArr']"
                                :value="item.id"
                                :label="item.purchasePrice"
                                :key="item.id"
                            ></Option>
                        </Select>-->
                        <Button
                            v-else
                            size="small"
                            type="info"
                            @click="priceClick(row,index)"
                        >{{row.taxPrice||Number(row.taxPrice)===0 ?row.taxPrice :'选择含税单价'}}</Button>
                    </template>
                </Table>
            </Card>
        </Modal>
        <Modal v-model="priceModal" title="含税单价" :mask-closable="maskClosable" width="960">
            <Table :data="priceArr" :columns="priceTitle"></Table>
            <div slot="footer"></div>
        </Modal>
    </div>
</template>

<script>
    import { mapGetters } from 'vuex';

    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';

    import {
        purchaseOrderList,
        getOrderDetail,
        purchaseOrderSave,
        purchaseSubmit,
        purchaseReturn,
        purchasePass,
        purchaseDel,
        redSave
    } from '@/api/purchaseManage/purchaseOrder.js';

    import { getSaveSupplierList } from '@/api/purchaseManage/buyer.js';
    // import { getCompanyMaterialList } from '@/api/purchaseManage/channelPrice.js';
    import { getChannelPriceList } from '@/api/purchaseManage/channelPrice.js';
    import { getWarehouseList } from '@/api/inventory/warehouseList.js';
    import { getMaterialInfo } from '@/api/customerMaterial/materialInfo.js';
    import { resetObj } from '@/libs/tools';

    export default {
        mixins: [tableMixin],
        components: { ErpTable },
        computed: {
            ...mapGetters([
                'purchaserId',
                'inventoryOrganizationId',
                'getUserName',
                'purchaseOrganizationId'
            ])
        },
        data () {
            return {
                detailTable: [], // 明细数据
                supplierModal: false, // 供应商modal,
                supplierData: [], // 供应商数据
                allSupplier: [], // 供应商不分页数据
                materialModal: false,
                priceModal: false, // 含税单价modal
                redModal: false,
                priceArr: [], // 含税单价表格数据
                priceIndex: null,
                tableQueryAttr: {
                    supplierEnableCode: '', // 供应商生效对象编码
                    orderNo: '', // 采购单号
                    commodityName: '', // 物料名称
                    startDate: '',
                    endDate: '',
                    date: ''
                },
                currencyName: '', // 币种名称
                // 供应商查询条件
                supplierAttr: {
                    pageNo: 1,
                    pageSize: 10,
                    supplierEnableCode: '',
                    supplierName: ''
                },
                readOnly: false, // 是否查看
                orderTypeArr: [], // 订单类型数据
                supplierArr: [], // 供应商已选择数据
                currencyArr: [], // 币种数据
                houseArr: [], // 仓库列表
                materialData: [], // 物料数据
                redTable: [], // 红字订单数据源
                redSelectData: [], // 红字订单已选择数据
                // 红字订单搜索条件
                redAttr: {
                    supplierEnableCode: '',
                    startDate: '',
                    endDate: '',
                    commodityName: '',
                    pageNo: 1,
                    pageSize: 10
                },
                // 当前选中行
                currentRow: {},
                detailIndex: null,
                isRed: false,
                formAttr: {
                    id: null,
                    supplierName: '',
                    supplierEnableCode: '',
                    supplierId: '',
                    orderNo: '', // 采购单号
                    orderType: '', // 订单类型
                    currencyId: '', // 币种
                    currencyRate: '', // 税率
                    orderRemark: '', // 摘要
                    warehouseCode: '', // 仓库码
                    warehouseId: '', // 仓库id
                    inventoryOrganizationId: '',
                    inventoryOrganizationCode: ''
                },
                materialAttr: {
                    commodityName: '',
                    specializedGroup: '',
                    pageNo: 1,
                    pageSize: 10,
                    total: 0
                },
                ruleValidate: {
                    orderType: [
                        {
                            required: true,
                            message: '单据类型不可为空'
                        }
                    ],
                    supplierName: [
                        {
                            required: true,
                            message: '供应商不可为空'
                        }
                    ],
                    currencyId: [
                        {
                            required: true,
                            type: 'number',
                            message: '币种不可为空',
                            trigger: 'blur'
                        }
                    ],
                    currencyRate: [
                        {
                            required: true,
                            message: '税率不可为空'
                        }
                    ],
                    warehouseId: [
                        {
                            required: true,
                            message: '仓库不可为空'
                        }
                    ]
                },
                priceTitle: [
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 100,
                        key: 'supplierName'
                    },
                    {
                        title: '采购价格',
                        align: 'center',
                        minWidth: 100,
                        key: 'purchasePrice'
                    },

                    {
                        title: '币种',
                        align: 'center',
                        minWidth: 100,
                        key: 'currencyName'
                    },
                    {
                        title: '税率',
                        align: 'center',
                        minWidth: 100,
                        key: 'taxRate'
                    },
                    {
                        title: '包装单位',
                        align: 'center',
                        minWidth: 100,
                        key: 'unitName'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {
                                        type: 'success',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            this.priceSelect(params);
                                            this.priceModal = false;
                                        }
                                    }
                                },
                                '选择'
                            );
                        }
                    }
                ],
                // 红字订单表头
                redTitle: [
                    {
                        type: 'selection',
                        align: 'center',
                        minWidth: 60
                    },
                    {
                        title: '采购单号',
                        align: 'center',
                        minWidth: 100,
                        key: 'orderNo'
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 100,
                        key: 'supplierName'
                    },
                    {
                        title: '物料代码',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityCode'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '物料货号',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 100,
                        key: 'unitName'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '采购数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'quantity'
                    },
                    {
                        title: '含税单价',
                        align: 'center',
                        minWidth: 100,
                        key: 'taxPrice'
                    },
                    {
                        title: '税率',
                        align: 'center',
                        minWidth: 100,
                        key: 'taxRate'
                    },
                    {
                        title: '价税合计',
                        align: 'center',
                        minWidth: 100,
                        key: 'totalPrice'
                    },
                    {
                        title: '折扣',
                        align: 'center',
                        minWidth: 100,
                        key: 'discount'
                    },
                    {
                        title: '说明',
                        align: 'center',
                        minWidth: 100,
                        key: 'orderRemark'
                    }
                ],
                // 物料表头
                materialTitle: [
                    {
                        title: '常用名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '物料规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroup'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {
                                        type: 'success',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            this.materialClick(params);
                                        }
                                    }
                                },
                                '选择'
                            );
                        }
                    }
                ],
                // 供应商表头
                supplierTitle: [
                    {
                        title: '供应商名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'supplierName'
                    },
                    {
                        title: '供应商代码',
                        align: 'center',
                        minWidth: 100,
                        key: 'supplierEnableCode'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'mainBrand'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specialtyGroupName'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {
                                        type: 'success',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            this.supplierClick(params.row);
                                        }
                                    }
                                },
                                '选择'
                            );
                        }
                    }
                ],
                // 明细表头
                detailTitle: [
                    {
                        title: '物料代码',
                        align: 'center',
                        minWidth: 180,
                        // key: ''
                        render: (h, params) => {
                            const code = params.row.commodityCode;
                            return h(
                                'Button',
                                {
                                    props: {
                                        type: 'success',
                                        size: 'small',
                                        disabled: this.isRed
                                    },
                                    on: {
                                        click: () => {
                                            this.selectMaterial(params);
                                        }
                                    }
                                },
                                code
                                    ? code.length > 15
                                        ? code.slice(0, 4) +
                                            '...' +
                                            code.slice(code.length - 4)
                                        : code.length
                                    : '选择物料'
                            );
                        }
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '物料货号',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 100,
                        key: 'unitName'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '采购数量',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h('InputNumber', {
                                props: {
                                    type: 'number',
                                    value: params.row.quantity || 0,
                                    min: 0,
                                    disabled: this.readOnly
                                },
                                style: {
                                    textAlign: 'center'
                                },
                                on: {
                                    'on-change': val => {
                                        params.row.quantity = val;
                                        this.detailTable[params.index] = params.row;
                                        this.calcTotal(params.index);
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '含税单价',
                        align: 'center',
                        minWidth: 120,
                        slot: 'price'
                    },
                    {
                        title: '折扣',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h('InputNumber', {
                                props: {
                                    value: params.row.discount || 10,
                                    disabled: this.isRed || this.readOnly,
                                    min: 0,
                                    max: 10
                                },
                                style: {
                                    textAlign: 'center'
                                },
                                on: {
                                    'on-change': val => {
                                        console.log(val);
                                        params.row.discount = val;
                                        this.detailTable[params.index] = params.row;
                                        this.calcTotal(params.index);
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '税率',
                        align: 'center',
                        minWidth: 100,
                        key: 'taxRate'
                    },
                    {
                        title: '价税合计',
                        align: 'center',
                        minWidth: 100,
                        key: 'totalPrice'
                    //         render:(h,params)=>{
                    //             const x = Number(params.row.quantity || 0); // 数量
                    //             const y = Number(
                    //     params.row.purchasePrice ||
                    //         params.row.taxPrice ||
                    //         0
                    // ); // 含税单价
                    // const z =Number(params.row.discount || 10); // 折扣
                    // params.row.totalPrice=this.accMul(x,y,z);
                    //         }
                    },
                    {
                        title: '说明',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h('Input', {
                                props: {
                                    type: 'text',
                                    value: params.row.itemRemark,
                                    disabled: this.isRed || this.readOnly
                                },
                                on: {
                                    'on-blur': val => {
                                        const value = val.target.value;
                                        this.detailTable[params.index].itemRemark = value;
                                        this.detailTable[params.index].remark = value;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 120,
                        // key: ''
                        fixed: 'right',
                        render: (h, params) => {
                            return h('div', {}, [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            size: 'small',
                                            type: 'primary',
                                            disabled: this.isRed || this.readOnly
                                        },
                                        class: 'mr6',
                                        on: {
                                            click: () => {
                                                this.detailTable.splice(
                                                    params.index,
                                                    0,
                                                    this.detailTable[params.index]
                                                );
                                            }
                                        }
                                    },
                                    '插入'
                                ),
                                h(
                                    'Button',
                                    {
                                        props: {
                                            size: 'small',
                                            type: 'error',
                                            disabled: this.isRed || this.readOnly
                                        },
                                        on: {
                                            click: () => {
                                                this.$Modal.confirm({
                                                    title: '确定删除吗?',
                                                    onOk: async () => {
                                                        this.detailTable = this.delArrItemFormIndex(
                                                            this.detailTable,
                                                            params.index
                                                        );
                                                    }
                                                });
                                            }
                                        }
                                    },
                                    '删除'
                                )
                            ]);
                        }
                    }
                ],
                erpTableTitle: [
                    {
                        type: 'selection',
                        align: 'center',
                        minWidth: 60
                    },
                    {
                        title: '采购组织',
                        align: 'center',
                        minWidth: 100,
                        key: 'purchaseOrganizationName'
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 100,
                        key: 'supplierName'
                    },
                    {
                        title: '采购单号',
                        align: 'center',
                        minWidth: 180,
                        // key: 'orderNo'
                        render: (h, params) => {
                            return h(
                                'span',
                                {
                                    style: {
                                        color:
                                            params.row.isRedOrder === 1
                                                ? 'red'
                                                : null
                                    }
                                },
                                params.row.orderNo
                            );
                        }
                    },
                    {
                        title: '单据类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'orderTypeName'
                    },
                    {
                        title: '创建日期',
                        align: 'center',
                        minWidth: 100,
                        // key: 'createTime'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.createTime)
                            );
                        }
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '采购数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'quantity'
                    },
                    {
                        title: '含税单价',
                        align: 'center',
                        minWidth: 100,
                        key: 'taxPrice'
                    },
                    {
                        title: '税率',
                        align: 'center',
                        minWidth: 100,
                        key: 'taxRate'
                    },
                    {
                        title: '价税合计',
                        align: 'center',
                        minWidth: 100,
                        key: 'totalPrice'
                    },
                    {
                        title: '折扣',
                        align: 'center',
                        minWidth: 100,
                        key: 'discount'
                    },
                    {
                        title: '审核日期',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.updateTime)
                            );
                        }
                    },
                    {
                        title: '说明',
                        align: 'center',
                        minWidth: 100,
                        key: 'orderRemark'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        fixed: 'right',
                        key: 'statusDescription'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        fixed: 'right',
                        minWidth: 100,
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {
                                        type: 'success',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            this.viewOrder(params.row);
                                        }
                                    }
                                },
                                '查看'
                            );
                        }
                    }
                ]
            };
        },
        methods: {
            // 订单保存
            modalOk () {
                console.log(this.formAttr);
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        this.changeLoading();
                        return;
                    }
                    let cur = this.currencyArr.filter(item => {
                        return item.id === this.formAttr.currencyId;
                    });
                    if (
                        cur.length &&
                        cur[0].valueCode !== 'rmb' &&
                        this.formAttr.currencyRate === '1'
                    ) {
                        this.$Message.error('请重新输入汇率');
                        this.changeLoading();
                        return;
                    }

                    // 判断所有物料是否为同一供应商
                    let isSameSupplier = this.detailTable.every(item => {
                        return (
                            item.supplierEnableCode ===
                            this.formAttr.supplierEnableCode
                        );
                    });
                    if (!isSameSupplier) {
                        this.$Message.error('请确认所有物料为当前供应商');
                        return;
                    }

                    let res = null;
                    let params = this.formAttr;
                    params.items = this.detailTable;
                    if (this.isRed) {
                        res = await redSave(params);
                    } else {
                        res = await purchaseOrderSave(params);
                    }
                    if (res.status === this.code) {
                        if (res.content && res.content.id) {
                            this.formAttr.id = res.content.id;
                        }
                        this.todoOver(res.msg);
                        this.isRed = false;
                        this.detailTable = [];
                    } else {
                        return this.changeLoading();
                    }
                });
            },

            // 编辑关闭
            modalCancel () {
                this.currentId = null;
                this.taskInstanceId = null;
                this.$refs['formValidate'] &&
                    this.$refs['formValidate'].resetFields();
                this.formAttr && resetObj(this.formAttr);
                this.formAttr.id = null;
                if (typeof callBack === 'function') callBack();
                if (this.modalShowFlag) this.modalShowFlag = false;
                this.detailTable = [];
                this.$refs.managerTable.clearCurrentTableRow();
                this.readOnly = false;
                this.currencyName = '';
                this.formAttr.currencyId = '';
            },
            // 新增
            add () {
                this.getHouse();
                this.getAllSelect();
                this.addItem('采购订单信息');
                this.getFieldValuesData('currency', 'currencyArr');
            },

            // 新增红字订单
            addRed () {
                this.redModal = true;
                this.isRed = true;
                this.getPassOrder(); // 获取已审核订单
            },

            // 明细添加行
            addDetail () {
                if (!this.formAttr.supplierEnableCode) {
                    this.$Message.error('请选择供应商');
                    return;
                }
                this.detailTable.push({});
            },
            // 选择供应商
            selectSupplier () {
                this.supplierModal = true;
                this.getSupplier();
            },
            // 选择物料按钮
            selectMaterial (params) {
                // console.log(row);
                this.materialModal = true;
                this.detailIndex = params.index;
                this.getMaterial();
            },

            // 含税单价选择
            priceSelect (params) {
                Object.keys(params.row).forEach(item => {
                    if (item !== 'id') {
                        this.$set(
                            this.detailTable[this.detailIndex],
                            item,
                            params.row[item]
                        );
                    }
                });
                this.$set(
                    this.detailTable[this.detailIndex],
                    'taxPrice',
                    params.row.purchasePrice
                );
                this.$set(
                    this.detailTable[this.detailIndex],
                    'purchasePriceId',
                    params.row.id
                );
                this.calcTotal(this.detailIndex);
            },

            // 确认物料
            materialClick (params) {
                // 更新表格详情对应的物料信息
                Object.keys(params.row).forEach(item => {
                    this.$set(
                        this.detailTable[this.detailIndex],
                        item,
                        params.row[item]
                    );
                });
                // 获取物料单价
                this.getPrice(params);
                this.materialModal = false;
            },
            // 供应商多选事件
            supplierSelect (val) {
                this.supplierArr = val;
            },

            // 选择含税单价
            priceClick (row, index) {
                this.priceModal = true;

                this.detailIndex = index;
                this.getPrice({ row: row, index: index });
            },

            // 红字关闭
            redClose () {
                this.redModal = false;
                this.isRed = false;
                this.redSelectData = [];
            },

            // 点击单行选中
            currentChange (row) {
                this.currentId = row.id;
                this.currentRow = row;
            },

            // 查看
            viewOrder (row) {
                this.readOnly = true;
                this.editTableData({ row: row }, '采购订单信息');
                this.formAttr.currencyId = row.currencyId;
                this.getDetail(row); // 获取订单明细
                this.getAllSelect();
                this.getHouse();
            },

            // 红字选择确认s
            redOk () {
                if (this.redSelectData.length !== 1) {
                    this.$Message.error('请选择一条数据');
                    return;
                }
                this.editTableData({ row: this.redSelectData[0] }, '新增红字订单');
                this.detailTable = this.redSelectData.map(item => {
                    const { orderItemId, ...arg } = item;
                    return Object.assign({}, arg, { redOrderItemId: orderItemId });
                });
                this.formAttr.redOrderId = this.redSelectData[0].orderId;
                this.getHouse(); // 获取仓储数据
                this.getAllSelect(); // 获取下拉框数据
            },

            // 编辑时获取明细物料单价
            getDetailPrice (data) {
                data.forEach(async (item, index) => {
                    const params = {
                        commodityCode: item.commodityCode,
                        status: 2,
                        supplierEnableCode: this.formAttr.supplierEnableCode
                    };
                    const res = await getChannelPriceList(params);
                    if (res.status === this.code) {
                        this.$set(this.detailTable[index], 'priceArr', res.content);
                    }
                });
            },

            // 获取物料单价
            async getPrice (params) {
                const res = await getChannelPriceList({
                    commodityCode: params.row.commodityCode,
                    status: 2,
                    supplierEnableCode: this.formAttr.supplierEnableCode
                });
                if (res.status === this.code) {
                    this.priceArr = res.content;
                    if (res.content.length === 1) {
                        this.priceSelect({ row: res.content[0] });
                    }
                }
            },

            redSelect (val) {
                this.redSelectData = val;
            },

            // 单价选择框
            priceChange (val, row, index) {
                const temp = this.detailTable[index]['priceArr'].filter(item => {
                    // return item.purchaserId === val;
                    return item.id === val;
                });
                if (temp.length) {
                    Object.keys(temp[0]).forEach(item => {
                        this.$set(this.detailTable[index], item, temp[0][item]);
                    });
                }
                this.$set(
                    this.detailTable[index],
                    'taxPrice',
                    temp[0]['purchasePrice']
                );
                this.calcTotal(index);
            },

            // 计算总金额
            calcTotal (index) {
                const x = Number(this.detailTable[index].quantity || 0); // 数量
                const y = Number(
                    this.detailTable[index].purchasePrice ||
                        this.detailTable[index].taxPrice ||
                        0
                ); // 含税单价
                let z = Number(this.detailTable[index].discount || 10); // 折扣
                if (this.detailTable[index].discount === 0) z = 0;
                const total = this.accMul(x, y, z);
                this.detailTable[index].totalPrice = total / 10;
            // this.$set(this.detailTable[index], 'totalPrice', total / 10);
            },
            accMul (arg1, arg2, arg3) {
                let m = 0;
                let s1 = arg1.toString();
                let s2 = arg2.toString();
                let s3 = arg3.toString();
                try {
                    m += s1.split('.')[1].length;
                } catch (e) {}
                try {
                    m += s2.split('.')[1].length;
                } catch (e) {}
                try {
                    m += s3.split('.')[1].length;
                } catch (e) {}
                return (
                    (Number(s1.replace('.', '')) *
                    Number(s2.replace('.', '')) *
                    Number(s3.replace('.', ''))) /
                    Math.pow(10, m)
                );
            },
            // 供应商确认
            // supplierOk() {
            //     if (this.supplierArr.length !== 1) {
            //         return this.$Message.error('请选择一条数据');
            //     }
            //     this.formAttr.supplierName = this.supplierArr[0].supplierName;
            //     this.formAttr.supplierEnableCode = this.supplierArr[0].supplierEnableCode;
            //     this.formAttr.supplierId = this.supplierArr[0].supplierId;
            //     this.supplierModal = false;
            // },

            // 供应商确认
            supplierClick (row) {
                this.formAttr.supplierName = row.supplierName;
                this.formAttr.supplierEnableCode = row.supplierEnableCode;
                this.formAttr.supplierId = row.supplierId;
                this.supplierModal = false;
            },

            // 查询供应商
            async getSupplier () {
                const params = Object.assign({}, this.supplierAttr, {
                    purchaserId: this.purchaserId
                });
                const res = await getSaveSupplierList(params);
                if (res.status === this.code) {
                    this.supplierData = res.content.list;
                    this.supplierAttr.total = res.content.total;
                }
            },

            // 获取所有供应商，不分页
            async getAllsupplier () {
                const params = {
                    purchaserId: this.purchaserId
                };
                const res = await getSaveSupplierList(params);
                if (res.status === this.code) {
                    this.allSupplier = res.content;
                }
            },

            // 供应商分页
            supplierPageChange (e) {
                this.supplierAttr.pageNo = e;
                this.getSupplier();
            },

            delArrItemFormIndex (arr, index) {
                let res = [];
                if (Array.isArray(arr)) {
                    arr.forEach((item, i) => {
                        if (index !== i) {
                            res.push(item);
                        }
                    });
                }
                return res;
            },

            // 订单编辑
            edit (row) {
                if (!this.currentRow.id) {
                    this.$Message.error('请先选择数据');
                    return;
                }
                this.getAllSelect();
                this.getHouse();
                this.editTableData({ row: row }, '采购订单信息');
                this.getDetail(row); // 获取订单明细
                this.formAttr.currencyId = row.currencyId;
            },
            // 订单删除
            async orderDel (row) {
                if (!this.currentRow.id) {
                    this.$Message.error('请先选择数据');
                    return;
                }
                const params = { id: row.id };
                const res = await purchaseDel(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                    this.$refs.managerTable.clearCurrentTableRow();
                }
            },

            // 订单提交
            async orderSubmit (row) {
                if (!this.currentRow.id) {
                    this.$Message.error('请先选择数据');
                    return;
                }
                const params = { id: row.id };
                const res = await purchaseSubmit(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                    this.$refs.managerTable.clearCurrentTableRow();
                }
            },

            // 订单撤回
            async orderReturn (row) {
                if (!this.currentRow.id) {
                    this.$Message.error('请先选择数据');
                    return;
                }
                const params = { id: row.id };
                const res = await purchaseReturn(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                    this.$refs.managerTable.clearCurrentTableRow();
                }
            },

            materialPageChange (e) {
                this.materialAttr = pageNo = e;
                this.getMaterial();
            },

            // 订单审核
            async orderAudit (row) {
                if (!this.currentRow.id) {
                    this.$Message.error('请先选择数据');
                    return;
                }
                const params = { id: row.id };
                const res = await purchasePass(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                    this.$refs.managerTable.clearCurrentTableRow();
                }
            },

            // 编辑时获取明细
            async getDetail (row) {
                const params = { purchaseOrderId: row.id };
                const res = await getOrderDetail(params);
                if (res.status === this.code) {
                    // console.log(res);
                    this.detailTable = res.content;
                    this.getDetailPrice(this.detailTable);
                }
            },

            // 获取公司物料
            async getMaterial () {
                const res = await getMaterialInfo(
                    Object.assign({}, this.materialAttr, {
                        supplierEnableCode: this.formAttr.supplierEnableCode,
                        purchaseOrganizationId: this.purchaseOrganizationId
                    })
                );
                if (res.status === this.code) {
                    this.materialData = res.content.list;
                    this.materialAttr.total = res.content.total;
                }
            },

            // 当币种为人民币的时候，汇率为1;
            currencyChange (val) {
                if (val) {
                    // this.currencyId = val;
                    let cur = this.currencyArr.filter(item => {
                        return item.id === val;
                    });
                    if (cur.length && cur[0].valueCode === 'rmb') {
                        this.formAttr.currencyRate = 1;
                    } else {
                        this.formAttr.currencyRate = '';
                    }
                }
            // if (val && val.label) {
            //     this.currencyName = val.label;
            // }
            // if (val && val.label === '人民币') {
            //     this.formAttr.currencyRate = 1;
            // } else {
            //     this.formAttr.currencyRate = null;
            // }
            },

            // 选择仓库,添加仓库code
            selectHouse (val) {
                const arr = this.houseArr.filter(item => {
                    return item.id === val;
                });
                if (arr.length) {
                    this.formAttr.warehouseCode = arr[0].warehouseCode;
                }
            },
            // 获取仓库列表
            async getHouse () {
                // const params={id:this.inventoryOrganizationId};
                const params = {};
                const res = await getWarehouseList(params);
                if (res.status === this.code) {
                    this.houseArr = res.content.filter(item => {
                        if (!item.warehouseName.includes('赊销')) {
                            return item;
                        }
                    });
                }
            },
            // 获取系统字段
            getAllSelect () {
                this.getFieldValuesData('purchaser_order_type', 'orderTypeArr');
                this.getFieldValuesData('currency', 'currencyArr');
            },

            // 新增红字订单时，获取已审核通过订单
            async getPassOrder () {
                const params = Object.assign({}, this.redAttr, {
                    orderItemStatus: 2,
                    isRed: 1,
                    purchaseId: this.purchaserId,
                    startDate: this.getDate(this.redAttr.startDate),
                    endDate: this.getDate(this.redAttr.endDate)
                });
                // console.log(this.redAttr);
                const res = await getOrderDetail(params);
                if (res.status === this.code) {
                    this.redTable = res.content.list;
                }
            },
            // 红单查询分页事件
            redChangePage (val) {
                this.redAttr.pageNo = val;
                this.getPassOrder();
            },
            redChangePageSize (val) {
                this.redAttr.pageSize = val;
                this.getPassOrder();
            },
            getTableList () {
                // this.getSupplier();
                this.getAllsupplier();
                this.getTableListFn(async call => {
                    // console.log(this.tableQueryAttr.date);
                    if (this.tableQueryAttr.date) {
                        this.tableQueryAttr.startDate = this.getDate(
                            this.tableQueryAttr.date[0]
                        );
                        this.tableQueryAttr.endDate = this.getDate(
                            this.tableQueryAttr.date[1]
                        );
                    }
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await purchaseOrderList(params);
                    call(res);
                });
            }
        }
    };
</script>
