<template>
    <div class="erp-content" ref="erp">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.realName"
                        @on-search="search"
                        search
                        placeholder="姓名"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                采购员列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button v-has="btnRightList.buyerAdd" @click="add" icon="md-add">新增</Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>
        <!--        用户列表弹窗-->
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel"
        >
            <div>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="ios-search"></Icon>
                        查询条件
                    </p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button @click="userSearch" icon="md-search"
                                >搜索
                            </Button>
                            <Button @click="userReset" icon="md-refresh"
                                >重置
                            </Button>
                        </ButtonGroup>
                    </div>
                    <Row :gutter="16">
                        <Col span="12" class="maxWidth">
                            <Input
                                v-model="userTableQuery.realName"
                                @on-search="userSearch"
                                search
                                placeholder="名称"
                            >
                                <Button
                                    @click="userSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                        <Col span="12">
                            <Input
                                v-model="userTableQuery.departmentName"
                                @on-search="userSearch"
                                search
                                placeholder="部门"
                            >
                                <Button
                                    @click="userSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                    </Row>
                </Card>
                <Table
                    border
                    @on-selection-change="selectionUser"
                    :columns="userTableTitle"
                    :data="userTableData"
                    :tableLoading="userTableLoading"
                ></Table>
            </div>
        </Modal>
        <!--专业分组弹窗-->
        <Modal
            v-model="groupShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="groupModalOk"
            @on-cancel="groupModalCancel"
        >
            <div>
                <Transfer
                    :data="specialtyGroupAllArr"
                    :target-keys="targetGroupArr"
                    filterable
                    :filter-placeholder="groupPlaceholder"
                    :filter-method="groupFilterMethod"
                    @on-change="handleChangeGroup"
                ></Transfer>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        addBuyer,
        getBuyerList,
        getUsersList,
        purchaserDisable,
        purchaserEnable,
        addSpecialtyGroup,
        getProfessionalList,
        getAllSupplierList,
        getSaveSupplierList,
        addSupplier
    } from '@/api/purchaseManage/buyer';
    import { getMachineType } from '@/api/common';
    import { resetObj } from '@/libs/tools';

    export default {
        name: 'buyerSetting',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    realName: ''
                }, // 表格查询条件
                formAttr: {
                    userList: []
                }, // modal 值对象
                erpTableTitle: [
                    {
                        title: '姓名',
                        align: 'center',
                        minWidth: 120,
                        key: 'realName'
                    },
                    {
                        title: '性别',
                        align: 'center',
                        minWidth: 90,
                        render: (h, params) => {
                            const sex = params.row.sex;
                            return h('span', {}, sex);
                        }
                    },
                    {
                        title: '专业',
                        align: 'center',
                        minWidth: 160,
                        render: (h, params) => {
                            const professionals = params.row.professionals.join(
                                '，'
                            );
                            return h('span', {}, professionals);
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 100,
                        key: 'supplierCount'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 160,
                        render: (h, params) => {
                            const validFlag = params.row.status === 3;
                            return h(
                                'Tag',
                                {
                                    props: {
                                        color: validFlag ? 'success' : 'default'
                                    }
                                },
                                validFlag ? '有效' : '无效'
                            );
                        }
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 220,
                        align: 'center',
                        render: (h, params) => {
                            let btnType;
                            if (params.row.status === 3) {
                                btnType = h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'warning',
                                            size: 'small'
                                        },
                                        style: {},
                                        on: {
                                            click: () => {
                                                this.statusSetInvalid(
                                                    params.row.id
                                                );
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.salersSetDisable
                                            }
                                        ]
                                    },
                                    '无效'
                                );
                            } else {
                                btnType = h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'success',
                                            size: 'small'
                                        },
                                        style: {},
                                        on: {
                                            click: () => {
                                                this.statusSetValid(
                                                    params.row.id
                                                );
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.salersSetEnable
                                            }
                                        ]
                                    },
                                    '恢复'
                                );
                            }
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'info',
                                            size: 'small'
                                        },
                                        style: {
                                            marginRight: '5px'
                                        },
                                        on: {
                                            click: () => {
                                                this.transferType = 1;
                                                this.getGroupFormatData();
                                                this.currentId = params.row.id;
                                                this.groupPlaceholder =
                                                    '请输入专业分组';
                                                this.modalTitle = '选择专业分组';
                                                this.getSaveGroupList();
                                                this.groupShowFlag = true;
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.buyerUnitGroup
                                            }
                                        ]
                                    },
                                    '专业'
                                ),
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        style: {
                                            marginRight: '5px'
                                        },
                                        on: {
                                            click: () => {
                                                this.transferType = 2;
                                                this.currentId = params.row.id;
                                                this.groupPlaceholder =
                                                    '请输入供应商名称';
                                                this.modalTitle = '选择供应商';
                                                this.getAllSupplierList();
                                                this.getSaveSupplierList();
                                                this.groupShowFlag = true;
                                            }
                                        },
                                        directives: [
                                            {
                                                name: 'has',
                                                value: this.btnRightList.buyerUnitSupplier
                                            }
                                        ]
                                    },
                                    '供应商'
                                ),
                                btnType
                            ]);
                        }
                    }
                ], // 表格标题
                userTableQuery: {
                    realName: '',
                    departmentName: ''
                }, // 用户弹窗搜索条件
                userTableTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '姓名',
                        align: 'center',
                        minWidth: 120,
                        key: 'realName'
                    },
                    {
                        title: '性别',
                        align: 'center',
                        minWidth: 90,
                        render: (h, params) => {
                            return h('span', {}, params.row.sex);
                        }
                    },
                    {
                        title: '部门',
                        align: 'center',
                        minWidth: 100,
                        key: 'departmentName'
                    },
                    {
                        title: '手机号',
                        align: 'center',
                        minWidth: 100,
                        key: 'mobile'
                    }
                ],
                userTableData: [],
                userTableLoading: false,
                groupShowFlag: false, // 专业分组弹窗开关
                specialtyGroupAllArr: [], // 专业分组源数据
                targetGroupArr: [], // 选中的专业分组
                groupPlaceholder: '', // 穿梭框搜索默认
                transferType: 0 // 1专业分组2供应商
            };
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getBuyerList(params);
                    getListMixin(res);
                });
            },
            add () {
                resetObj(this.userTableQuery);
                this.getUsersList();
                this.addItem('用户选择');
            },
            // 获取可新增的用户列表
            async getUsersList () {
                this.userTableLoading = true;
                const res = await getUsersList(this.userTableQuery);
                if (res.status === this.code) {
                    this.userTableData = res.content;
                    this.userTableLoading = false;
                }
            },
            // 搜索用户
            userSearch () {
                this.getUsersList();
            },
            // 重置用户
            userReset () {
                resetObj(this.userTableQuery);
                this.getUsersList();
            },
            // 选中新增用户
            selectionUser (val) {
                this.formAttr.userList = val.map(item => {
                    return {
                        departmentId: item.departmentId,
                        enterpriseId: item.enterpriseId,
                        organizationId: item.organizationId,
                        userId: item.userId
                    };
                });
            },
            // 保存新增采购员
            async modalOk () {
                if (this.formAttr.userList.length === 0) {
                    this.changeLoading();
                    return this.$Message.error('请先勾选用户');
                }
                const res = await addBuyer(this.formAttr);
                this.changeLoading();
                if (res.status === this.code) {
                    this.refreshToken().then(() => {
                        this.$Message.success(res.msg);
                        this.modalCancel();
                        this.getTableList();
                    });
                }
            },
            // 获取已关联的专业分组
            async getSaveGroupList () {
                const params = {
                    purchaserId: this.currentId
                };
                const res = await getProfessionalList(params);
                if (res.status === this.code) {
                    this.targetGroupArr = res.content.map(item => {
                        return item.professionalGroupId;
                    });
                }
            },
            // 保存专业分组
            async groupModalOk () {
                let res;
                if (this.transferType === 1) {
                    const params = {
                        purchaserId: this.currentId,
                        professionalGroupIds: this.targetGroupArr
                    };
                    res = await addSpecialtyGroup(params);
                } else if (this.transferType === 2) {
                    const params = {
                        purchaserId: this.currentId,
                        supplierEnableCodes: this.targetGroupArr
                    };
                    res = await addSupplier(params);
                }
                this.changeLoading();
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.groupShowFlag = false;
                    this.getTableList();
                }
            },
            // 关闭专业分组弹窗
            groupModalCancel () {
                this.groupShowFlag = false;
                this.specialtyGroupAllArr = [];
                this.targetGroupArr = [];
            },
            // 格式化分组数据
            async getGroupFormatData () {
                const params = {
                    level: 1,
                    levelId: this.currentOrganization.id,
                    fieldCode: 'purchaser_specialty_group'
                };
                const res = await getMachineType(params);
                if (res.status === this.code) {
                    this.specialtyGroupAllArr = res.content.map(item => {
                        return {
                            key: item.id,
                            label: item.fieldValue
                        };
                    });
                }
            },
            // 专业分组穿梭框改变
            handleChangeGroup (newTargetKeys) {
                this.targetGroupArr = newTargetKeys;
            },
            // 关键词搜索专业分组
            groupFilterMethod (data, query) {
                return data.label.indexOf(query) > -1;
            },
            // 状态有效无效
            statusSetInvalid (id) {
                this.$Modal.confirm({
                    title: '确认把该采购员状态设置为无效吗？',
                    onOk: async () => {
                        const params = {
                            id
                        };
                        const res = await purchaserDisable(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getTableList();
                        }
                    }
                });
            },
            // 状态有效有效
            statusSetValid (id) {
                this.$Modal.confirm({
                    title: '确认把该采购员状态恢复为有效吗？',
                    onOk: async () => {
                        const params = {
                            id
                        };
                        const res = await purchaserEnable(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.getTableList();
                        }
                    }
                });
            },
            // 获取该公司所有供应商
            async getAllSupplierList () {
                const res = await getAllSupplierList();
                if (res.status === this.code) {
                    this.specialtyGroupAllArr = res.content.map(item => {
                        return {
                            key: item.enableCode,
                            label: item.supplierName
                        };
                    });
                }
            },
            // 获取已关联的供应商列表
            async getSaveSupplierList () {
                const params = {
                    purchaserId: this.currentId
                };
                const res = await getSaveSupplierList(params);
                if (res.status === this.code) {
                    this.targetGroupArr = res.content.map(item => {
                        return item.supplierEnableCode;
                    });
                }
            }
        }
    };
</script>

<style scoped lang="less">
/deep/ .ivu-transfer-list {
    width: 250px;
    height: 400px;
}
/deep/ .ivu-transfer-operation {
    .ivu-btn {
        height: 60px;
    }
}
</style>
