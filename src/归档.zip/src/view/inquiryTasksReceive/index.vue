<template>
    <div class="erp-content" ref="erp">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="4" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.customerName"
                        @on-search="search"
                        search
                        placeholder="客户名称"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="4" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.createName"
                        @on-search="search"
                        search
                        placeholder="创建人员"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="4" class="maxWidth">
                    <DatePicker
                        :editable="false"
                        v-model="tableQueryAttr.startDate"
                        format="yyyy-MM-dd"
                        type="date"
                        @on-change="startDateChange"
                        placeholder="创建时间开始"
                    ></DatePicker>
                </Col>
                <Col span="4" class="maxWidth">
                    <DatePicker
                        :editable="false"
                        v-model="tableQueryAttr.endDate"
                        format="yyyy-MM-dd"
                        type="date"
                        @on-change="endDateChange"
                        placeholder="创建时间结束"
                    ></DatePicker>
                </Col>
                <Col span="4" class="maxWidth">
                    <Select
                        placeholder="状态"
                        @on-change="selectSearch"
                        remote
                        v-model="tableQueryAttr.receiveStatus"
                    >
                        <Option
                            v-for="item in receiveStatusArr"
                            :label="item.label"
                            :value="item.value"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                询价任务列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button v-has="btnRightList.inquiryTaskReceive" @click="receive" icon="md-body">批量领取</Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-selection-change="selectionChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>
        <!--        转交弹窗-->
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="transferModalOk"
            @on-cancel="modalCancel"
        >
            <div class="erp-modal-content">
                <Form
                    :model="formAttr"
                    :rules="ruleValidate"
                    ref="formValidate"
                    :label-width="120"
                >
                    <FormItem label="采购专员" prop="purchaserId">
                        <Select
                            placeholder="请选择采购员"
                            remote
                            v-model="formAttr.purchaserId"
                        >
                            <Option
                                v-for="item in buyerArr"
                                :label="item.realName"
                                :value="item.id"
                                :key="item.id"
                            ></Option>
                        </Select>
                    </FormItem>
                </Form>
            </div>
        </Modal>
        <!--        关联物料弹窗-->
        <Modal
            v-model="materialShowFlag"
            width="700"
            title="选择物料"
            :mask-closable="maskClosable"
            footer-hide
        >
            <div>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="ios-search"></Icon>
                        查询条件
                    </p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button @click="materialSearch" icon="md-search"
                            >搜索
                            </Button>
                            <Button @click="materialReset" icon="md-refresh"
                            >重置
                            </Button>
                        </ButtonGroup>
                    </div>
                    <Row :gutter="16">
                        <Col span="12" class="maxWidth">
                            <Input
                                v-model="materialTableQuery.commodityName"
                                @on-search="materialSearch"
                                search
                                placeholder="物料名称"
                            >
                                <Button
                                    @click="materialSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                    </Row>
                </Card>
                <erp-table
                    @on-page-no-change="materialPageNoChange"
                    @on-page-size-change="materialPageSizeChange"
                    :erpTableTitle="materialTableTitle"
                    :erpTableData="materialTableData"
                    :tableLoading="materialTableLoading"
                    :current="materialComAttr.pageNo"
                    :total="materialTotal"
                >
                </erp-table>
            </div>
        </Modal>
        <!--        关联询价弹窗-->
        <Modal
            v-model="inquiryShowFlag"
            width="700"
            title="选择询价任务"
            :mask-closable="maskClosable"
            footer-hide
        >
            <div>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="ios-search"></Icon>
                        查询条件
                    </p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button @click="inquirySearch" icon="md-search"
                            >搜索
                            </Button>
                            <Button @click="inquiryReset" icon="md-refresh"
                            >重置
                            </Button>
                        </ButtonGroup>
                    </div>
                    <Row :gutter="16">
                        <Col span="12" class="maxWidth">
                            <Input
                                v-model="inquiryTableQuery.commodityName"
                                @on-search="inquirySearch"
                                search
                                placeholder="物料名称"
                            >
                                <Button
                                    @click="inquirySearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                    </Row>
                </Card>
                <erp-table
                    @on-page-no-change="inquiryPageNoChange"
                    @on-page-size-change="inquiryPageSizeChange"
                    :erpTableTitle="inquiryTableTitle"
                    :erpTableData="inquiryTableData"
                    :tableLoading="inquiryTableLoading"
                    :current="inquiryComAttr.pageNo"
                    :total="inquiryTotal"
                >
                </erp-table>
            </div>
        </Modal>
        <!--        查看询价任务弹窗-->
        <Modal
            footer-hide
            width="800"
            v-model="inquiryInfoModalShowFlag"
            title="查看询价任务"
            :loading="modelLoading"
            :mask-closable="maskClosable"
        >
            <Tabs v-model="tabIndex" type="card" @on-click="tabsBind">
                <TabPane label="申请信息">
                    <first-apply
                        ref="firstApply"
                        :disabled="onlyReady"
                        :customerNameArr="customerNameArr"
                        :outboundMethodNameArr="outboundMethodNameArr"
                        :deliveryMethodNameArr="deliveryMethodNameArr"
                        :purchaseOrganizationArr="purchaseOrganizationArr"
                        :formAttr="inquiryFormAttr"></first-apply>
                </TabPane>
                <TabPane label="询价结果">
                    <Inquiry-result
                        :inquiryResult="inquiryResult"
                        :disabled="onlyReady"
                        :inquiryResultTitle="inquiryResultTitle"
                    ></Inquiry-result>
                </TabPane>
                <TabPane label="反馈信息">
                    <first-apply
                        ref="firstApply"
                        :disabled="onlyReady"
                        :customerNameArr="customerNameArr"
                        :outboundMethodNameArr="outboundMethodNameArr"
                        :deliveryMethodNameArr="deliveryMethodNameArr"
                        :purchaseOrganizationArr="purchaseOrganizationArr"
                        :formAttr="formAttrInquiryInfo"></first-apply>
                </TabPane>
            </Tabs>
        </Modal>
        <!--驳回弹窗-->
        <Modal
            v-model="rejectShowFlag"
            width="650"
            title="驳回"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="rejectModalOk"
            @on-cancel="rejectCancel"
        >
            <div class="erp-modal-content">
                <Form
                    :model="rejectFormAttr"
                    :rules="rejectRuleValidate"
                    ref="rejectFormValidate"
                    :label-width="120"
                >
                    <FormItem label="驳回原因" prop="rejectDescription">
                        <Input
                            v-model="rejectFormAttr.rejectDescription"
                            type="textarea"
                            placeholder="请输入驳回原因"
                        ></Input>
                    </FormItem>
                </Form>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import FirstApply from '@/components/firstMaterialApply/firstApply';
    import InquiryResult from '@/components/firstMaterialApply/inquiryResult';
    import { getCompanyBuyerList, getCompanyPurchaseOrganizationList } from '@/api/purchaseManage/purchaseGroup';
    import { getCompanyMaterialList } from '@/api/purchaseManage/channelPrice';
    import {
        getInquiryResult,
        getInquiryInfo
    } from '@/api/saleManage/firstMaterialApply';
    import {
        distributionInquiryTask,
        getInquiryTaskList,
        transferInquiryTask,
        returnInquiryTask,
        rejectInquiryTask,
        inquiryTaskRelationMaterial,
        inquiryTaskRelationInquiry,
        getInquiryTaskFirstInfo
    } from '@/api/purchaseManage/inquiryTask';
    import { getDate, resetObj } from '@/libs/tools';
    import { mapGetters } from 'vuex';

    export default {
        name: 'inquiryTasksReceive',
        mixins: [tableMixin],
        components: {
            ErpTable, FirstApply, InquiryResult
        },
        computed: {
            ...mapGetters(['purchaserId'])
        },
        data () {
            return {
                tableQueryAttr: {
                    receiveStatus: '',
                    customerName: '',
                    createName: '',
                    startDate: '',
                    endDate: ''
                }, // 表格查询条件
                formAttr: {
                    purchaserId: ''
                }, // modal 值对象
                ruleValidate: {
                    purchaserId: [
                        {
                            required: true,
                            type: 'number',
                            message: '采购员不能为空',
                            trigger: 'change'
                        }
                    ]
                }, // modal 表单验证
                erpTableTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        fixed: 'left',
                        align: 'center'
                    },
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 140,
                        key: 'customerName'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 150,
                        key: 'commodityName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroupName'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityBrand'
                    },
                    {
                        title: '仪器名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'instrumentName'
                    },
                    {
                        title: '出库方式',
                        align: 'center',
                        minWidth: 100,
                        key: 'outboundMethodName'
                    },
                    {
                        title: '发货方式',
                        align: 'center',
                        minWidth: 100,
                        key: 'deliveryMethodName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'statusDescription'
                    },
                    {
                        title: '创建人员',
                        align: 'center',
                        minWidth: 100,
                        key: 'createName'
                    },
                    {
                        title: '创建时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '询价结果数',
                        align: 'center',
                        minWidth: 100,
                        key: 'marketPriceCount'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 350,
                        align: 'center',
                        fixed: 'right',
                        render: (h, params) => {
                            if (params.row.receiveStatus === 0) {
                                return h('div', [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'success',
                                                size: 'small'
                                            },
                                            style: {
                                                marginRight: '5px'
                                            },
                                            on: {
                                                click: () => {
                                                    this.taskId = params.row.id;
                                                    this.openInquiryInfoModal();
                                                }
                                            }
                                        },
                                        '查看'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'info',
                                                size: 'small'
                                            },
                                            style: {},
                                            on: {
                                                click: () => {
                                                    this.tableSelectValue = [
                                                        params.row.id
                                                    ];
                                                    this.receiveTask();
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList.inquiryTaskReceive
                                                }
                                            ]
                                        },
                                        '领取'
                                    )
                                ]);
                            } else if (params.row.receiveStatus === 1) {
                                if (this.purchaserId === params.row.purchaserId) {
                                    return h('div', [
                                        h(
                                            'Button',
                                            {
                                                props: {
                                                    type: 'success',
                                                    size: 'small'
                                                },
                                                style: {
                                                    marginRight: '5px'
                                                },
                                                on: {
                                                    click: () => {
                                                        this.onlyReady = true;
                                                        this.taskId = params.row.id;
                                                        this.openInquiryInfoModal();
                                                    }
                                                }
                                            },
                                            '查看'
                                        ),
                                        h(
                                            'Button',
                                            {
                                                props: {
                                                    type: 'default',
                                                    size: 'small'
                                                },
                                                style: {
                                                    marginRight: '5px'
                                                },
                                                on: {
                                                    click: () => {
                                                        this.currentId =
                                                            params.row.id;
                                                        this.returnInquiryTask();
                                                    }
                                                },
                                                directives: [
                                                    {
                                                        name: 'has',
                                                        value: this.btnRightList.inquiryTaskReturn
                                                    }
                                                ]
                                            },
                                            '退回'
                                        ),
                                        h(
                                            'Button',
                                            {
                                                props: {
                                                    type: 'default',
                                                    size: 'small'
                                                },
                                                style: {
                                                    marginRight: '5px'
                                                },
                                                on: {
                                                    click: () => {
                                                        this.currentId =
                                                            params.row.id;
                                                        this.transfer();
                                                    }
                                                },
                                                directives: [
                                                    {
                                                        name: 'has',
                                                        value: this.btnRightList.inquiryTaskChange
                                                    }
                                                ]
                                            },
                                            '转交'
                                        ),
                                        h(
                                            'Button',
                                            {
                                                props: {
                                                    type: 'default',
                                                    size: 'small'
                                                },
                                                style: {
                                                    marginRight: '5px'
                                                },
                                                on: {
                                                    click: () => {
                                                        this.currentId =
                                                            params.row.id;
                                                        this.openRejectModal();
                                                    }
                                                },
                                                directives: [
                                                    {
                                                        name: 'has',
                                                        value: this.btnRightList.inquiryTaskReject
                                                    }
                                                ]
                                            },
                                            '驳回'
                                        ),
                                        h(
                                            'Button',
                                            {
                                                props: {
                                                    type: 'warning',
                                                    size: 'small'
                                                },
                                                style: {
                                                    marginRight: '5px'
                                                },
                                                on: {
                                                    click: () => {
                                                        this.currentId =
                                                            params.row.id;
                                                        this.openMaterialModal();
                                                    }
                                                },
                                                directives: [
                                                    {
                                                        name: 'has',
                                                        value: this.btnRightList.inquiryTaskRelationCommodity
                                                    }
                                                ]
                                            },
                                            '关联物料'
                                        ),
                                        h(
                                            'Button',
                                            {
                                                props: {
                                                    type: 'warning',
                                                    size: 'small'
                                                },
                                                style: {},
                                                on: {
                                                    click: () => {
                                                        this.currentId =
                                                            params.row.id;
                                                        this.openInquiryModal();
                                                    }
                                                },
                                                directives: [
                                                    {
                                                        name: 'has',
                                                        value: this.btnRightList.inquiryTaskRelationInquiry
                                                    }
                                                ]
                                            },
                                            '关联询价'
                                        )
                                    ]);
                                } else {
                                    return h('div', [
                                        h(
                                            'Button',
                                            {
                                                props: {
                                                    type: 'success',
                                                    size: 'small'
                                                },
                                                style: {
                                                    marginRight: '5px'
                                                },
                                                on: {
                                                    click: () => {
                                                        this.taskId = params.row.id;
                                                        this.openInquiryInfoModal();
                                                    }
                                                }
                                            },
                                            '查看'
                                        )
                                    ]);
                                }
                            }
                        }
                    }
                ], // 表格标题
                receiveStatusArr: [
                    {
                        id: 1,
                        label: '待领取',
                        value: 0
                    },
                    {
                        id: 2,
                        label: '已领取',
                        value: 1
                    }
                ], // 状态数组
                buyerArr: [], // 采购员数组
                materialShowFlag: false, // 物料弹窗开关
                materialTableTitle: [
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '常用名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityName'
                    },
                    {
                        title: '物料规格',
                        align: 'center',
                        minWidth: 90,
                        key: 'commoditySpec'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 90,
                        key: 'brandName'
                    },
                    {
                        title: '操作',
                        minWidth: 100,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'success',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.relationMaterial(
                                                    params.row.commodityCode
                                                );
                                            }
                                        }
                                    },
                                    '关联'
                                )
                            ]);
                        }
                    }
                ], // 物料表格栏目
                materialTableData: [],
                materialTableLoading: false,
                materialComAttr: {
                    pageNo: 1,
                    pageSize: 10
                },
                materialTotal: 0,
                materialTableQuery: {
                    commodityName: ''
                }, // 物料查询条件
                inquiryShowFlag: false, // 询价弹窗开关
                inquiryTableTitle: [
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 140,
                        key: 'commodityName'
                    },
                    {
                        title: '货号',
                        align: 'center',
                        minWidth: 90,
                        key: 'commodityNumber'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 90,
                        key: 'commodityBrand'
                    },
                    {
                        title: '操作',
                        minWidth: 140,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        style: {
                                            marginRight: '5px'
                                        },
                                        on: {
                                            click: () => {
                                                this.taskId = params.row.id;
                                                this.openInquiryInfoModal();
                                            }
                                        }
                                    },
                                    '查看'
                                ),
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'success',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.relationInquiry(params.row.id);
                                            }
                                        }
                                    },
                                    '关联'
                                )
                            ]);
                        }
                    }
                ], // 询价任务表格栏目
                inquiryTableData: [],
                inquiryTableLoading: false,
                inquiryComAttr: {
                    pageNo: 1,
                    pageSize: 10
                },
                inquiryTotal: 0,
                inquiryTableQuery: {
                    commodityName: ''
                }, // 物料查询条件
                inquiryInfoModalShowFlag: false, // 查看询价任务弹窗开关
                tabIndex: 0,
                customerNameArr: [], // 物料专业分组下拉
                outboundMethodNameArr: [], // 出库方式下拉
                deliveryMethodNameArr: [], // 发货方式下拉
                purchaseOrganizationArr: [], // 采购组织下拉
                inquiryFormAttr: {
                    customerName: '', // 客户名称
                    commodityName: '', // 物料名称
                    commodityBrand: '', // 物料品牌
                    commoditySpecializedGroupId: '', // 专业分组id
                    instrumentName: '', // 仪器名称
                    manufacturer: '', // 生产厂家
                    outboundMethodId: '', // 出库方式
                    deliveryMethodId: '', // 发货方式
                    commoditySpec: '', // 物料规格
                    commodityNumber: '', // 货号
                    commodityUnitName: '', // 物料单位
                    price: 0, // 销售价格
                    yearOrderNumber: 0, // 年订单量
                    yearTestNumber: 0, // 年测试数
                    metaSupplier: '', // 原供应商
                    purchaseOrganizationId: '', // 采购组织
                    writeDescription: '' // 录入摘要
                },
                formAttrInquiryInfo: {
                    customerName: '', // 客户名称
                    commodityName: '', // 物料名称
                    commodityBrand: '', // 物料品牌
                    commoditySpecializedGroupId: '', // 专业分组id
                    instrumentName: '', // 仪器名称
                    manufacturer: '', // 生产厂家
                    outboundMethodId: '', // 出库方式
                    deliveryMethodId: '', // 发货方式
                    commoditySpec: '', // 物料规格
                    commodityNumber: '', // 货号
                    commodityUnitName: '', // 物料单位
                    price: 0, // 销售价格
                    yearOrderNumber: 0, // 年订单量
                    yearTestNumber: 0, // 年测试数
                    metaSupplier: '', // 原供应商
                    purchaseOrganizationId: '', // 采购组织
                    writeDescription: '' // 录入摘要
                },
                inquiryResultTitle: [
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '包装单位 ',
                        align: 'center',
                        minWidth: 100,
                        key: 'unitName'
                    },
                    {
                        title: '税率',
                        align: 'center',
                        minWidth: 90,
                        key: 'taxRate'
                    },
                    {
                        title: '市场指导价',
                        align: 'center',
                        minWidth: 120,
                        key: 'marketPrice'
                    },
                    {
                        title: '币种',
                        align: 'center',
                        minWidth: 90,
                        key: 'currencyName'
                    },
                    {
                        title: '询价时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.inquiryTime, 'long')
                            );
                        }
                    },
                    {
                        title: '供应商选择',
                        type: 'selection',
                        align: 'center',
                        width: 60
                    }
                ],
                inquiryResult: {}, // 询价结果
                onlyReady: true,
                taskId: null, // 询价任务id
                rejectShowFlag: false, // 驳回弹窗开关
                rejectFormAttr: {
                    rejectDescription: ''
                },
                rejectRuleValidate: {
                    rejectDescription: [
                        {
                            required: true,
                            message: '驳回原因不能为空',
                            trigger: 'blur'
                        }
                    ]
                } // 驳回表单校验
            };
        },
        created () {
            this.getAllSelectData();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr);
                    const res = await getInquiryTaskList(params);
                    getListMixin(res);
                });
            },
            // 确认领取任务
            async receiveTask () {
                const params = Object.assign(
                    {},
                    {
                        inquiryIds: this.tableSelectValue
                    }
                );
                const res = await distributionInquiryTask(params);
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.tableSelectValue = [];
                    this.getTableList();
                }
            },
            // 批量领取
            receive () {
                if (this.tableSelectValue.length === 0) {
                    return this.$Message.error('请先勾选需要领取的任务');
                }
                this.receiveTask();
            },
            getAllSelectData () {
                this.getCompanyBuyerList();
                this.getFieldValuesData(
                    'commodity_specialized_group',
                    'customerNameArr'
                );
                this.getFieldValuesData('outbound_method', 'outboundMethodNameArr');
                this.getFieldValuesData('delivery_method', 'deliveryMethodNameArr');
                this.getCompanyPurchaseOrganizationList();
            },
            // 获取本公司所有采购员
            async getCompanyBuyerList () {
                const res = await getCompanyBuyerList({});
                if (res.status === this.code) {
                    this.buyerArr = res.content;
                }
            },
            // 开始时间格式化
            startDateChange (val) {
                this.tableQueryAttr.startDate = val;
                this.getTableList();
            },
            // 结束时间格式化
            endDateChange (val) {
                this.tableQueryAttr.endDate = val;
                this.getTableList();
            },
            // 点击转交
            transfer () {
                this.addItem('选择采购专员');
            },
            // 确认转交
            transferModalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    const params = Object.assign({}, this.formAttr, {
                        id: this.currentId
                    });
                    const res = await transferInquiryTask(params);
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                        this.tableSelectValue = [];
                        this.tableSelectList = [];
                    } else {
                        this.changeLoading();
                    }
                });
            },
            // 退回任务
            returnInquiryTask () {
                this.$Modal.confirm({
                    title: '确认退回询价任务吗？',
                    onOk: async () => {
                        const params = {
                            id: this.currentId
                        };
                        const res = await returnInquiryTask(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.currentId = [];
                            this.getTableList();
                        }
                    }
                });
            },
            // 打开驳回弹窗
            openRejectModal () {
                this.rejectShowFlag = true;
            },
            // 确认驳回
            rejectModalOk () {
                this.$refs['rejectFormValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    const params = {
                        id: this.currentId,
                        rejectDescription: this.rejectFormAttr.rejectDescription
                    };
                    const res = await rejectInquiryTask(params);
                    if (res.status === this.code) {
                        this.$Message.success(res.msg);
                        this.getTableList();
                        this.rejectCancel();
                    } else {
                        this.changeLoading();
                    }
                });
            },
            // 关闭驳回弹窗
            rejectCancel () {
                this.rejectShowFlag = false;
                this.currentId = null;
                this.$refs['rejectFormValidate'].resetFields();
                resetObj(this.rejectFormAttr);
            },
            // 获取本公司的物料列表
            async getCompanyMaterialList () {
                this.materialTableLoading = true;
                const params = Object.assign(
                    {},
                    this.materialComAttr,
                    this.materialTableQuery
                );
                const res = await getCompanyMaterialList(params);
                this.materialTableLoading = false;
                if (res.status === this.code) {
                    this.materialTableData = res.content.list;
                    this.materialTotal = res.content.total;
                }
            },
            // 搜索物料列表
            materialSearch () {
                this.getCompanyMaterialList();
            },
            // 重置物料搜索
            materialReset () {
                resetObj(this.materialTableQuery);
                this.materialComAttr.pageNo = 1;
                this.getCompanyMaterialList();
            },
            // 改变物料每页数量
            materialPageSizeChange (value) {
                this.materialComAttr.pageNo = 1;
                this.materialComAttr.pageSize = value;
                this.getCompanyMaterialList();
            },
            // 改变物料页码
            materialPageNoChange (value) {
                this.materialComAttr.pageNo = value;
                this.getCompanyMaterialList();
            },
            // 打开物料弹窗
            openMaterialModal () {
                this.materialShowFlag = true;
                this.getCompanyMaterialList();
            },
            // 关联物料
            async relationMaterial (code) {
                const params = {
                    id: this.currentId,
                    commodityCode: code
                };
                const res = await inquiryTaskRelationMaterial(params);
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.currentId = null;
                    this.getCompanyMaterialList();
                    this.materialShowFlag = false;
                }
            },
            // 获取询价任务列表
            async getCompanyInquiryList () {
                this.inquiryTableLoading = true;
                const params = Object.assign(
                    {},
                    this.inquiryComAttr,
                    this.inquiryTableQuery,
                    {
                        status: 2
                    }
                );
                const res = await getInquiryTaskList(params);
                this.inquiryTableLoading = false;
                if (res.status === this.code) {
                    this.inquiryTableData = res.content.list;
                    this.inquiryTotal = res.content.total;
                }
            },
            // 搜索询价列表
            inquirySearch () {
                this.getCompanyInquiryList();
            },
            // 重置询价搜索
            inquiryReset () {
                resetObj(this.inquiryTableQuery);
                this.inquiryComAttr.pageNo = 1;
                this.getCompanyInquiryList();
            },
            // 改变询价每页数量
            inquiryPageSizeChange (value) {
                this.inquiryComAttr.pageNo = 1;
                this.inquiryComAttr.pageSize = value;
                this.getCompanyInquiryList();
            },
            // 改变询价页码
            inquiryPageNoChange (value) {
                this.inquiryComAttr.pageNo = value;
                this.getCompanyInquiryList();
            },
            // 打开询价弹窗
            openInquiryModal () {
                this.inquiryShowFlag = true;
                this.getCompanyInquiryList();
            },
            // 关联询价
            async relationInquiry (id) {
                const params = {
                    id: this.currentId,
                    relationInquiryId: id
                };
                const res = await inquiryTaskRelationInquiry(params);
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.currentId = null;
                    this.getCompanyInquiryList();
                }
            },
            // 获取当前公司的采购组织
            async getCompanyPurchaseOrganizationList () {
                const res = await getCompanyPurchaseOrganizationList();
                if (res.status === this.code) {
                    this.purchaseOrganizationArr = res.content;
                }
            },
            // 打开查看询价任务弹窗
            openInquiryInfoModal () {
                this.getInquiryTaskFirstInfo();
                this.inquiryInfoModalShowFlag = true;
            },
            // 获取询价任务首营信息
            async getInquiryTaskFirstInfo () {
                const params = {
                    id: this.taskId
                };
                const res = await getInquiryTaskFirstInfo(params);
                if (res.status === this.code) {
                    const formAttr = res.content;
                    for (let key in formAttr) {
                        this.inquiryFormAttr[key] = formAttr[key];
                    }
                }
            },
            // 获取询价任务的询价结果
            async getInquiryResult () {
                const res = await getInquiryResult(this.taskId);
                if (res.status === this.code) {
                    if (res.content) {
                        if (Array.isArray(res.content.items)) {
                            this.inquiryResult = {
                                ...res.content,
                                items: res.content.items.map(item => {
                                    return {
                                        ...item,
                                        _checked: item.isChecked === 1,
                                        _disabled: true
                                    };
                                })
                            };
                        }
                    }
                }
            },
            // 获取询价任务的反馈信息
            async getInquiryInfo () {
                const res = await getInquiryInfo(this.taskId);
                if (res.status === this.code) {
                    this.formAttrInquiryInfo = res.content || {};
                }
            },
            // tab点击
            tabsBind (name) {
                switch (name) {
                    case 0:
                        this.getInquiryTaskFirstInfo();
                        break;
                    case 1:
                        this.getInquiryResult();
                        break;
                    case 2:
                        this.getInquiryInfo();
                        break;
                }
            }
        }
    };
</script>

<style scoped lang="less">
    .erp-modal-content {
        overflow-y: visible;
    }
</style>
