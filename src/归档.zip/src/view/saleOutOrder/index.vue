<template>
    <div class="inventoryInit">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.inventoryOrganizationId"
                        @on-change="searchInventory"
                        placeholder="库存组织"
                    >
                        <Option
                            v-for="item in inventoryOrganizationArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.warehouseId"
                        :disabled="!tableQueryAttr.inventoryOrganizationId"
                        @on-change="selectSearch"
                        placeholder="仓库"
                    >
                        <Option
                            v-for="item in warehouseArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        placeholder="单据类型"
                        @on-change="selectSearch"
                        remote
                        v-model="tableQueryAttr.orderType"
                    >
                        <Option
                            v-for="item in orderTypeArr"
                            :label="item.label"
                            :value="item.value"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                销售出库单明细列表
            </p>
            <div slot="extra">
<!--                <ButtonGroup>-->
<!--                    <Button @click="openSendModal"-->
<!--                        icon="md-add"-->
<!--                    >新增</Button>-->
<!--                    <Button-->
<!--                        icon="ios-create-outline"-->
<!--                    >编辑</Button>-->
<!--                    <Button-->
<!--                        icon="md-send"-->
<!--                    >提交</Button>-->
<!--                    <Button-->
<!--                        icon="md-undo"-->
<!--                    >撤回</Button>-->
<!--                    <Button-->
<!--                        icon="md-redo"-->
<!--                    >审核</Button>-->
<!--                    <Button-->
<!--                        icon="ios-key"-->
<!--                    >增加红字</Button>-->
<!--                </ButtonGroup>-->
            </div>
            <erp-table
                highlight
                ref="salesTable"
                @on-current-change="currentChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>
<!--        选择发货通知单弹窗-->
        <Modal
            v-model="sendShowFlag"
            width="800"
            title="选择发货通知"
            :loading="sendModelLoading"
            :mask-closable="false"
            @on-ok="sendModalOk"
            @on-cancel="sendModalCancel"
        >
            <Row :gutter="16" class="mb20">
                <Col span="5">
                    <Select
                        v-model="sendQueryAttr.inventoryOrganizationId"
                        @on-change="searchInventory"
                        placeholder="请选择库存组织"
                    >
                        <Option
                            v-for="item in inventoryOrganizationArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5">
                    <Select
                        v-model="sendQueryAttr.warehouseId"
                        :disabled="!sendQueryAttr.inventoryOrganizationId"
                        @on-change="sendSearch"
                        placeholder="请选择仓库"
                    >
                        <Option
                            v-for="item in warehouseArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <DatePicker
                        v-model="sendQueryAttr.shipmentDate"
                        format="yyyy-MM-dd"
                        type="date"
                        @on-change="shipmentDateChange"
                        placeholder="发货时间"
                    ></DatePicker>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        placeholder="请选择"
                        @on-change="sendSearch"
                        remote
                        v-model="sendQueryAttr.shipmentTime"
                    >
                        <Option
                            v-for="item in shipmentTimeArr"
                            :label="item.label"
                            :value="item.value"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
                <Col span="4">
                    <Button @click="sendSearch">搜索</Button>
                </Col>
            </Row>
            <Table
                :columns="sendTableTitle"
                :data="sendTableData"
                @on-selection-change="sendSelection"
                height="400"
                border
            ></Table>
        </Modal>
<!--        新增编辑出库单弹窗-->
        <Modal
            v-model="modalShowFlag"
            width="1000"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-cancel="modalCancel"
        >
            <div>
                <Form
                    :model="formAttr"
                    ref="formValidate"
                    :label-width="120"
                >
                    <Row>
                        <Col span="12">
                            <FormItem label="出库单号">
                                <Input
                                    disabled
                                    v-model="formAttr.orderNo"
                                    placeholder="出库单号"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="出库类型">
                                <Input
                                    disabled
                                    :class="{ redOrder: Boolean(formAttr.isRedOrder) }"
                                    v-model="formAttr.orderType"
                                    placeholder="请输入出库类型"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="库存组织">
                                <Input
                                    disabled
                                    v-model="formAttr.inventoryOrganizationName"
                                    placeholder="请输入库存组织"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="仓库">
                                <Input
                                    disabled
                                    v-model="formAttr.warehouse"
                                    placeholder="请输入仓库"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="客户">
                                <Input
                                    disabled
                                    v-model="formAttr.customerName"
                                    placeholder="请输入客户"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="收货地址">
                                <Input
                                    disabled
                                    v-model="formAttr.customerAddress"
                                    placeholder="请输入收货地址"
                                ></Input>
                            </FormItem>
                        </Col>
                        <Col span="12">
                            <FormItem label="识别码">
                                <Input
                                    disabled
                                    v-model="formAttr.identificationCode"
                                    placeholder="请输入识别码"
                                ></Input>
                            </FormItem>
                        </Col>
                    </Row>
                </Form>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="md-list"></Icon>
                        出库单明细列表
                    </p>
                    <div slot="extra">
<!--                        <ButtonGroup>-->
<!--                            <Button @click="detailOrderAdd">新增</Button>-->
<!--                        </ButtonGroup>-->
                    </div>
                    <Table border :columns="orderDetailTableTitle" :data="orderDetailTableData">
                    </Table>
                </Card>
            </div>
            <div slot="footer">
                <Button @click="modalCancel">取消</Button>
<!--                <Button @click="modalOk">保存</Button>-->
<!--                <Button type="primary">提交</Button>-->
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { getOrganizationDropList, getWarehouseDropList } from '@/api/inventory/inventory';
    import { getSalesOutboundOrderDetailList, getOutboundNoticeOrderDetail, addSaleOutboundOrder, getSalesOutboundOrderDetail, editSaleOutboundOrder } from '@/api/inventory/outboundBusiness/saleOutOrder';
    import { getDate } from '@/libs/tools';

    export default {
        name: 'saleOutOrder',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    inventoryOrganizationId: '',
                    warehouseId: '',
                    auditStatus: ''
                },
                inventoryOrganizationArr: [], // 库存组织下拉
                warehouseArr: [], // 仓库列表下拉
                erpTableTitle: [
                    {
                        title: '出库单号',
                        align: 'center',
                        minWidth: 120,
                        key: 'orderNo'
                    },
                    {
                        title: '出库类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'orderTypeDesc'
                    },
                    {
                        title: '来源单据号',
                        align: 'center',
                        minWidth: 120,
                        key: 'sourceOrderNo'
                    },
                    {
                        title: '库存组织',
                        align: 'center',
                        minWidth: 120,
                        key: 'inventoryOrganizationName'
                    },
                    {
                        title: '仓库',
                        align: 'center',
                        minWidth: 120,
                        key: 'warehouse'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityName'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brand'
                    },
                    {
                        title: '数量',
                        align: 'center',
                        minWidth: 90,
                        key: 'quantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 90,
                        key: 'unit'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    {
                        title: '生产日期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.producedDate)
                            );
                        }
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.effectiveDate)
                            );
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '来源',
                        align: 'center',
                        minWidth: 90,
                        key: 'sourceType'
                    },
                    {
                        title: '录入时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.recordTime, 'long')
                            );
                        }
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            const status =
                                params.row.auditStatus === 1 ? '未提交' : params.row.auditStatus === 2 ? '已提交' : '已审核';
                            return h('span', {}, status);
                        }
                    },
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 140,
                        key: 'customerName'
                    },
                    {
                        title: '客户地址',
                        align: 'center',
                        minWidth: 140,
                        key: 'customerAddress'
                    }
                    // {
                    //     title: '操作',
                    //     key: 'action',
                    //     width: 100,
                    //     align: 'center',
                    //     fixed: 'right',
                    //     render: (h, params) => {
                    //         return h('div', [
                    //             h(
                    //                 'Button',
                    //                 {
                    //                     props: {
                    //                         type: 'success',
                    //                         size: 'small'
                    //                     },
                    //                     style: {
                    //                         marginRight: '5px'
                    //                     },
                    //                     on: {
                    //                         click: () => {
                    //                             this.currentId = params.row.orderId;
                    //                             this.openOutOrderModal();
                    //                         }
                    //                     }
                    //                 },
                    //                 '查看'
                    //             )
                    //         ]);
                    // if (params.row.auditStatus === 1) {
                    //     return h('div', [
                    //         h(
                    //             'Button',
                    //             {
                    //                 props: {
                    //                     type: 'primary',
                    //                     size: 'small'
                    //                 },
                    //                 style: {
                    //                     marginRight: '5px'
                    //                 },
                    //                 on: {
                    //                     click: () => {
                    //                         this.currentId = params.row.orderId;
                    //                         this.openOutOrderModal();
                    //                     }
                    //                 }
                    //             },
                    //             '编辑'
                    //         ),
                    //         h(
                    //             'Button',
                    //             {
                    //                 props: {
                    //                     type: 'success',
                    //                     size: 'small'
                    //                 },
                    //                 style: {},
                    //                 on: {
                    //                     click: () => {
                    //
                    //                     }
                    //                 }
                    //             },
                    //             '提交'
                    //         )
                    //     ]);
                    // } else if (params.row.auditStatus === 2) {
                    //     return h('div', [
                    //         h(
                    //             'Button',
                    //             {
                    //                 props: {
                    //                     type: 'primary',
                    //                     size: 'small'
                    //                 },
                    //                 style: {
                    //                     marginRight: '5px'
                    //                 },
                    //                 on: {
                    //                     click: () => {
                    //                         this.editTableData(
                    //                             params,
                    //                             '编辑采购渠道',
                    //                             this.editBefore
                    //                         );
                    //                     }
                    //                 }
                    //             },
                    //             '查看'
                    //         ),
                    //         h(
                    //             'Button',
                    //             {
                    //                 props: {
                    //                     type: 'success',
                    //                     size: 'small'
                    //                 },
                    //                 style: {},
                    //                 on: {
                    //                     click: () => {
                    //
                    //                     }
                    //                 }
                    //             },
                    //             '审核'
                    //         ),
                    //         h(
                    //             'Button',
                    //             {
                    //                 props: {
                    //                     type: 'error',
                    //                     size: 'small'
                    //                 },
                    //                 style: {},
                    //                 on: {
                    //                     click: () => {
                    //
                    //                     }
                    //                 }
                    //             },
                    //             '撤回'
                    //         )
                    //     ]);
                    // } else if (params.row.auditStatus === 3) {
                    //     return h('div', [
                    //         h(
                    //             'Button',
                    //             {
                    //                 props: {
                    //                     type: 'primary',
                    //                     size: 'small'
                    //                 },
                    //                 style: {
                    //                     marginRight: '5px'
                    //                 },
                    //                 on: {
                    //                     click: () => {
                    //
                    //                     }
                    //                 }
                    //             },
                    //             '查看'
                    //         )
                    //     ]);
                    // }
                    //     }
                    // }
                ],
                orderTypeArr: [
                    {
                        id: 1,
                        label: '销售出库',
                        value: 1
                    },
                    {
                        id: 2,
                        label: '采购退货',
                        value: 2
                    },
                    {
                        id: 3,
                        label: '测试出库',
                        value: 3
                    },
                    {
                        id: 4,
                        label: '借货出库',
                        value: 4
                    }
                ],
                sendShowFlag: false, // 发货通知单弹窗开关
                sendModelLoading: false,
                sendQueryAttr: {
                    inventoryOrganizationId: '',
                    warehouseId: '',
                    shipmentDate: '',
                    shipmentTime: ''
                }, // 发货通知单搜索
                sendTableTitle: [
                    // {
                    //     type: 'selection',
                    //     width: 60,
                    //     align: 'center'
                    // },
                    {
                        title: '来源类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'sourceType'
                    },
                    {
                        title: '来源单据号',
                        align: 'center',
                        minWidth: 110,
                        key: 'sourceOrderNo'
                    },
                    {
                        title: '物料编码',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityCode'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 110,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 90,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brand'
                    },
                    {
                        title: '发货数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'quantity'
                    },
                    {
                        title: '剩余数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'leftQuantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 90,
                        key: 'unit'
                    },
                    {
                        title: '发货日期',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.shipmentDate)
                            );
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    {
                        title: '生产日期',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.producedDate)
                            );
                        }
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.effectiveDate)
                            );
                        }
                    }
                ], // 发货通知单明细栏目
                sendTableData: [], // 发货通知单明细数据
                curSendData: [], // 选中的发货通知单
                formAttr: {
                    orderId: '',
                    orderType: '',
                    orderNo: '',
                    inventoryOrganizationName: '',
                    warehouse: '',
                    customerName: '',
                    customerAddress: '',
                    identificationCode: '',
                    isRedOrder: '',
                    addItems: [],
                    deleteItems: [],
                    updateItems: []
                },
                shipmentTimeArr: [
                    {
                        id: 1,
                        value: 2,
                        label: '上午'
                    },
                    {
                        id: 2,
                        value: 3,
                        label: '下午'
                    }
                ],
                orderDetailTableTitle: [
                    {
                        title: '来源类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'sourceType'
                    },
                    {
                        title: '来源单据号',
                        align: 'center',
                        minWidth: 110,
                        key: 'sourceOrderNo'
                    },
                    {
                        title: '物料编码',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityCode'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 110,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 90,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brand'
                    },
                    {
                        title: '数量',
                        align: 'center',
                        minWidth: 100,
                        render: (h, params) => {
                            return h('Input', {
                                props: {
                                    type: 'text',
                                    value: params.row.quantity
                                },
                                on: {
                                    'on-blur': (val) => {
                                        const value = val.target.value;
                                        params.row.quantity = value;
                                        this.orderDetailTableData[params.index].quantity = value;
                                    }
                                }
                            });
                        }
                    },
                    {
                        title: '剩余数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'leftQuantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 90,
                        key: 'unit'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    {
                        title: '生产日期',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.producedDate)
                            );
                        }
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.effectiveDate)
                            );
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '发货日期',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.recordTime)
                            );
                        }
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 120,
                        render: (h, params) => {
                            const status =
                                params.row.auditStatus === 1 ? '未提交' : params.row.auditStatus === 2 ? '已提交' : '已审核';
                            return h('span', {}, status);
                        }
                    }
                    // {
                    //     title: '操作',
                    //     key: 'action',
                    //     minWidth: 120,
                    //     align: 'center',
                    //     fixed: 'right',
                    //     render: (h, params) => {
                    //         return h('div', [
                    //             h('Button', {
                    //                 props: {
                    //                     type: 'info',
                    //                     size: 'small'
                    //                 },
                    //                 style: {
                    //                     marginRight: '5px'
                    //                 },
                    //                 on: {
                    //                     click: () => {
                    //                         this.curIndex = params.index;
                    //                         this.sendQueryAttr = Object.assign({}, this.sendQueryAttr, {
                    //                             customerAddressId: params.row.customerAddressId
                    //                         });
                    //                         this.getOutboundNoticeOrderDetail();
                    //                         this.sendShowFlag = true;
                    //                     }
                    //                 }
                    //             }, '插入'),
                    //             h('Button', {
                    //                 props: {
                    //                     type: 'error',
                    //                     size: 'small'
                    //                 },
                    //                 style: {},
                    //                 on: {
                    //                     click: () => {
                    //                         this.delOrderDetail(params);
                    //                     }
                    //                 }
                    //             }, '删除')
                    //         ]);
                    //     }
                    // }
                ], // 出库单明细表栏目
                orderDetailTableData: [], // 出库单明细表数据
                curIndex: null // 新增插入的当前行号
            };
        },
        created () {
            this.getAllSelectData();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                if (!this.tableQueryAttr.warehouseId && !this.tableQueryAttr.inventoryOrganizationId) return;
                if (!this.tableQueryAttr.orderType) this.tableQueryAttr.orderType = 1;
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getSalesOutboundOrderDetailList(params);
                    getListMixin(res);
                });
            },
            getAllSelectData () {
                this.getInventoryOrganizationList();
            },
            // 库存组织下拉
            async getInventoryOrganizationList () {
                const res = await getOrganizationDropList();
                if (res.status === this.code) {
                    this.inventoryOrganizationArr = res.content.map(item => {
                        return {
                            label: item.inventoryOrganizationName,
                            value: item.id
                        };
                    });
                    if (this.inventoryOrganizationArr.length && !this.tableQueryAttr.inventoryOrganizationId) {
                        this.tableQueryAttr.inventoryOrganizationId = this.inventoryOrganizationArr[0].value;
                        this.getWarehouseList(this.tableQueryAttr.inventoryOrganizationId);
                    }
                }
            },
            // 获取库存组织关联的仓库
            async getWarehouseList (id) {
                if (!id) return;
                const params = Object.assign({}, {
                    inventoryOrganizationId: id
                });
                const res = await getWarehouseDropList(params);
                if (res.status === this.code) {
                    this.warehouseArr = res.content.map(item => {
                        return {
                            label: item.warehouseName,
                            value: item.id
                        };
                    });
                    if (this.warehouseArr.length) {
                        this.tableQueryAttr.warehouseId = this.warehouseArr[0].value;
                        if (this.tableQueryAttr.warehouseId && this.tableQueryAttr.inventoryOrganizationId && !this.sendModelLoading) {
                            this.getTableList();
                        }
                        if (this.sendModelLoading) {
                            this.sendQueryAttr.warehouseId = this.warehouseArr[0].value;
                            this.getOutboundNoticeOrderDetail();
                        }
                    }
                }
            },
            // 选择库存之后
            searchInventory (val) {
                this.getWarehouseList(val);
            },
            // 选中单行后
            currentChange (val) {
                this.currentId = val.orderId;
            },
            // 打开发货通知单弹窗
            openSendModal () {
                this.sendQueryAttr = Object.assign({}, this.sendQueryAttr, {
                    inventoryOrganizationId: this.tableQueryAttr.inventoryOrganizationId,
                    warehouseId: this.tableQueryAttr.warehouseId
                });
                this.getOutboundNoticeOrderDetail();
                this.sendShowFlag = true;
            },
            // 确认选中发货通知单
            async sendModalOk () {
                if (this.curSendData.length === 0) {
                    this.$Message.error('请先勾选发货通知单');
                    return this.sendChangeLoading();
                }
                if (!this.currentId) {
                    const params = {
                        orderType: 1,
                        sourceType: 1,
                        orderSourceItem: this.curSendData
                    };
                    const res = await addSaleOutboundOrder(params);
                    this.sendChangeLoading();
                    if (res.status === this.code) {
                        this.$Message.success(res.msg);
                        this.currentId = res.content;
                        this.sendModalCancel();
                        this.openOutOrderModal();
                    }
                } else {
                    const detailIds = this.orderDetailTableData.map(item => {
                        return item.noticeItemId;
                    });
                    let addItems = [];
                    this.curSendData.forEach(item => {
                        if (!detailIds.includes(item.noticeItemId)) {
                            addItems.push(Object.assign({}, item, {
                                detailType: 1
                            }));
                        }
                    });
                    if (this.curIndex === null) {
                        this.orderDetailTableData = this.orderDetailTableData.concat(addItems);
                    } else {
                        addItems.unshift(this.curIndex + 1, 0);
                        Array.prototype.splice.apply(this.orderDetailTableData, addItems);
                    }
                    this.sendChangeLoading();
                    this.sendModalCancel();
                }
            },
            // 关闭发货通知单弹窗
            sendModalCancel () {
                this.curSendData = [];
                this.sendShowFlag = false;
            },
            // 处理modal确认异步
            sendChangeLoading () {
                this.sendModelLoading = false;
                this.$nextTick(() => {
                    this.sendModelLoading = true;
                });
            },
            // 获取已审核的发货通知单
            async getOutboundNoticeOrderDetail () {
                const params = Object.assign({}, this.sendQueryAttr, {
                    shipmentTime: this.sendQueryAttr.shipmentTime ? this.sendQueryAttr.shipmentTime : 1
                });
                const res = await getOutboundNoticeOrderDetail(params);
                if (res.status === this.code) {
                    this.sendTableData = res.content;
                }
            },
            // 格式化发货时间
            shipmentDateChange (value) {
                this.sendQueryAttr.shipmentDate = value;
                this.getOutboundNoticeOrderDetail();
            },
            sendSearch () {
                this.getOutboundNoticeOrderDetail();
            },
            // 发货通知单勾选
            sendSelection (value) {
                this.curSendData = value.map((item, index) => {
                    return {
                        orderSourceItemId: item.noticeItemId,
                        seqNo: index
                    };
                });
            },
            // 打开出库单弹窗
            openOutOrderModal () {
                this.getSalesOutboundOrderDetail();
                this.addItem('销售出库单编辑');
            },
            // 获取出库单明细
            async getSalesOutboundOrderDetail () {
                const params = Object.assign({}, {
                    id: this.currentId
                });
                const res = await getSalesOutboundOrderDetail(params);
                if (res.status === this.code) {
                    const data = res.content;
                    this.formAttr = Object.assign({}, {
                        orderId: data.orderId,
                        orderNo: data.orderNo,
                        inventoryOrganizationName: data.inventoryOrganizationName,
                        warehouse: data.warehouse,
                        customerName: data.customerName,
                        customerAddress: data.customerAddress,
                        customerAddressId: data.customerAddressId,
                        identificationCode: data.identificationCode,
                        isRedOrder: data.isRedOrder
                    });
                    this.orderDetailTableData = data.itemList.map(item => {
                        return Object.assign({}, item, {
                            detailType: 0
                        });
                    });
                }
            },
            // 保存出库单
            async modalOk () {
                let params = Object.assign({}, this.formAttr);
                if (this.orderDetailTableData.length === 0) {
                    this.changeLoading();
                    this.$Message.error('至少要有一条出库单明细');
                    return;
                }
                this.orderDetailTableData.forEach((item, index) => {
                    if (item.detailType === 0) {
                        params.updateItems.push({
                            itemId: item.orderItemId,
                            quantity: item.quantity,
                            seqNo: index
                        });
                    } else if (item.detailType === 1) {
                        params.addItems.push({
                            itemId: item.orderItemId,
                            quantity: item.quantity,
                            seqNo: index
                        });
                    }
                    params.deleteItems = this.formAttr.deleteItems.filter(option => {
                        return option !== item.noticeItemId;
                    });
                });
                const res = await editSaleOutboundOrder(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                } else {
                    this.changeLoading();
                }
            },
            // 删除出库单明细
            delOrderDetail (params) {
                this.$Modal.confirm({
                    title: '是否确认删除',
                    onOk: () => {
                        this.orderDetailTableData.splice(params.index, 1);
                        if (params.row.detailType === 0) {
                            this.formAttr.deleteItems.push({
                                itemId: item.orderItemId
                            });
                        }
                    }
                });
            },
            // 出库单弹窗中点击新增
            detailOrderAdd () {
                this.curIndex = null;
                this.sendQueryAttr = Object.assign({}, this.sendQueryAttr, {
                    customerAddressId: params.row.customerAddressId
                });
                this.getOutboundNoticeOrderDetail();
                this.sendShowFlag = true;
            }
        }
    };
</script>

<style scoped lang="less">
.redOrder{
    color: red;
}
</style>
