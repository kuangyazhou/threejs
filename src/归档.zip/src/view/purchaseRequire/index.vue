<template>
    <div class="purchase-require">
        <!-- <h1>采购需求</h1> -->
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="4" class="maxWidth">
                    <Select v-model="tableQueryAttr.bizType" placeholder="请选择来源类型">
                        <Option
                            v-for="item in sourceTypeArr"
                            :label="item.fieldValue"
                            :value="item.id"
                            :key="item.index"
                        ></Option>
                    </Select>
                </Col>
                <Col span="4" class="maxWidth">
                    <Select v-model="tableQueryAttr.specializedGroupId" placeholder="请选择专业分组">
                        <Option
                            v-for="item in specialGroupArr"
                            :label="item.fieldValue"
                            :value="item.id"
                            :key="item.index"
                        ></Option>
                    </Select>
                </Col>
                <Col span="4" class="maxWidth">
                    <Input placeholder="物料名称" v-model="tableQueryAttr.commodityName"></Input>
                </Col>
                <Col span="4" class="maxWidth">
                    <Select v-model="tableQueryAttr.processed">
                        <Option label="待处理需求" :value="0"></Option>
                        <Option label="已处理需求" :value="1"></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card :border="false">
            <p slot="title">采购需求列表</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" type="success" icon="ios-search">刷新</Button>
                    <Button @click="match" v-has="btnRightList.purchaseReqMatch" type="primary">匹配库存</Button>
                    <Button @click="createOrder" v-has="btnRightList.purchaseReqOrder" type="info">生成订单</Button>
                </ButtonGroup>
            </div>
            <erp-table
                ref="managerTable"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
            ></erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            width="960"
            @on-cancel="modalCancel"
        >
            <Card>
                <Table :data="detailData" :columns="detailTitle"></Table>
            </Card>
            <div slot="footer"></div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';

    import {
        reqList,
        viewDetail,
        matchInve,
        createPurchase
    } from '@/api/purchaseManage/purchaseReq.js';
    export default {
        mixins: [tableMixin],
        components: { ErpTable },
        data () {
            return {
                // 来源类型数据
                sourceTypeArr: [],
                // 专业分组数据
                specialGroupArr: [],
                detailModal: false,
                detailData: [], // 明细数据
                // 搜索参数
                tableQueryAttr: {
                    bizType: '', // 来源类型
                    specializedGroupId: '', // 专业分组
                    commodityName: '', // 物料名称
                    processed: 0 // 状态
                },
                erpTableTitle: [
                    {
                        title: '来源类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'sourceType'
                    },
                    {
                        title: '业务类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'bizType'
                    },
                    {
                        title: '来源编号',
                        align: 'center',
                        minWidth: 100,
                        key: 'sourceOrderNo'
                    },
                    {
                        title: '物料编码',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityCode'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 100,
                        key: 'registerNumber'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroupName'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '客户',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerName'
                    },
                    {
                        title: '确认数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'confirmQuantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 100,
                        key: 'unitName'
                    },
                    {
                        title: '确认效期',
                        align: 'center',
                        minWidth: 100,
                        // key: 'feedBackEffectiveDate'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.feedBackEffectiveDate)
                            );
                        }
                    },
                    {
                        title: '到货日期',
                        align: 'center',
                        minWidth: 100,
                        // key: 'arriveDate'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.arriveDate)
                            );
                        }
                    },
                    {
                        title: '生成时间',
                        align: 'center',
                        minWidth: 100,
                        // key: 'createTime'
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                this.getDate(params.row.createTime)
                            );
                        }
                    },
                    {
                        title: '库存数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'matchNum'
                    },
                    {
                        title: '待采数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'purchaseNum'
                    },
                    {
                        title: '库存明细',
                        align: 'center',
                        minWidth: 100,
                        fixed: 'right',
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {},
                                    on: {
                                        click: () => {
                                            this.viewDetail(params.row);
                                        }
                                    }
                                },
                                '查看'
                            );
                        }
                    }
                ],
                // 明细表头
                detailTitle: [
                    {
                        title: '入库来源',
                        align: 'center',
                        minWidth: 100,
                        key: 'inboundSource'
                    },
                    {
                        title: '库存类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'inventoryType'
                    },
                    {
                        title: '采购订单明细',
                        align: 'center',
                        minWidth: 100,
                        key: 'orderNo'
                    },
                    {
                        title: '库存组织',
                        align: 'center',
                        minWidth: 100,
                        key: 'inventoryOrganizationName'
                    },
                    {
                        title: '仓库',
                        align: 'center',
                        minWidth: 100,
                        key: 'warehouseName'
                    },
                    {
                        title: '采购组织',
                        align: 'center',
                        minWidth: 100,
                        key: 'purchaseOrganizationName'
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 100,
                        key: 'supplierName'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 100,
                        key: 'batchNo'
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 100,
                        // key: 'effectiveDate'
                        render: (h, params) => {
                            return h('span', {}, this.getDate(params.row.effectiveDate));
                        }
                    },
                    {
                        title: '到货日期',
                        align: 'center',
                        minWidth: 100,
                        // key: 'arriveDate'
                        render: (h, params) => {
                            return h('span', {}, this.getDate(params.row.arriveDate));
                        }
                    },
                    {
                        title: '数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'totalNum'
                    },
                    {
                        title: '可发数量',
                        align: 'center',
                        minWidth: 100,
                        key: 'matchNum'
                    },
                    {
                        title: '订单状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'orderStatusName'
                    }
                ]
            };
        },
        methods: {
            // 查看明细
            async viewDetail (row) {
                this.addItem('采购需求明细');
                const res = await viewDetail({ id: row.id });
                if (res.status === this.code) {
                    this.detailData = res.content;
                }
            },

            // 匹配库存
            async match () {
                const res = await matchInve();
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },
            // 生成订单
            async createOrder () {
                const res = await createPurchase();
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            // 获取系统字典值
            getAllSelect () {
                this.getFieldValuesData('specialty_group', 'specialGroupArr'); // 专业分组
                this.getFieldValuesData('order_type', 'sourceTypeArr'); // 订单类型
            },

            getTableList () {
                this.getAllSelect();
                const params = Object.assign(
                    {},
                    this.tableComAttr,
                    this.tableQueryAttr,
                    {
                        processed: this.tableQueryAttr.processed
                            ? this.tableQueryAttr.processed
                            : 0
                    }
                );
                this.getTableListFn(async call => {
                    const res = await reqList(params);
                    call(res);
                });
            }
        }
    };
</script>
