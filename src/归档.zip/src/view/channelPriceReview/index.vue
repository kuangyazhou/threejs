<template>
    <div class="erp-content" ref="erp">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Select
                        placeholder="供应商"
                        @on-change="selectSearch"
                        remote
                        filterable
                        clearable
                        v-model="tableQueryAttr.supplierEnableCode"
                    >
                        <Option
                            v-for="item in supplierArr"
                            :label="item.supplierName"
                            :value="item.enableCode"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.commodityName"
                        @on-search="search"
                        search
                        placeholder="物料名称"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.specializedGroupName"
                        @on-search="search"
                        search
                        placeholder="专业分组"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        placeholder="请选择状态"
                        @on-change="selectSearch"
                        remote
                        v-model="tableQueryAttr.status"
                    >
                        <Option
                            v-for="item in statusArr"
                            :label="item.label"
                            :value="item.value"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                采购渠道列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button v-has="btnRightList.channelPriceApprove" @click="approveChannelPrice" icon="md-redo"
                        >审核</Button
                    >
                    <Button v-has="btnRightList.channelPriceUnapprove" @click="unapproveChannelPrice" icon="md-undo"
                        >取消审核</Button
                    >
                </ButtonGroup>
            </div>
            <erp-table
                @on-selection-change="selectionChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-cancel="modalCancel"
            footer-hide
        >
            <div class="erp-modal-content">
                <Form
                    :model="formAttr"
                    :rules="ruleValidate"
                    ref="formValidate"
                    :label-width="120"
                >
                    <FormItem label="物料" prop="commodityCode">
                        <Button
                            @click="openMaterialModal"
                            class="form-button-select"
                            icon="ios-arrow-down"
                            disabled
                            >{{
                                formAttr.commodityCode
                                    ? formAttr.commodityName
                                    : '请选择物料'
                            }}
                        </Button>
                    </FormItem>
                    <FormItem label="供应商" prop="supplierEnableCode">
                        <Select
                            placeholder="请选择供应商"
                            remote
                            disabled
                            v-model="formAttr.supplierEnableCode"
                        >
                            <Option
                                v-for="item in supplierArr"
                                :label="item.supplierName"
                                :value="item.enableCode"
                                :key="item.id"
                            ></Option>
                        </Select>
                    </FormItem>
                    <FormItem
                        label="采购组织"
                        prop="selectPurchaseOrganizationId"
                    >
                        <Select
                            disabled
                            placeholder="请选择采购组织"
                            remote
                            v-model="formAttr.selectPurchaseOrganizationId"
                        >
                            <Option
                                v-for="item in purchaseOrganizationArr"
                                :label="item.purchaseOrganizationName"
                                :value="item.id"
                                :key="item.id"
                            ></Option>
                        </Select>
                    </FormItem>
                    <FormItem label="采购单价" prop="purchasePrice">
                        <Input
                            disabled
                            v-model="formAttr.purchasePrice"
                            placeholder="请输入采购单价"
                        ></Input>
                    </FormItem>
                    <FormItem label="单位" prop="unitCode">
                        <Select
                            placeholder="请选择单位"
                            remote
                            disabled
                            v-model="formAttr.unitCode"
                        >
                            <Option
                                v-for="item in unitArr"
                                :label="item.unitName"
                                :value="item.unitCode"
                                :key="item.id"
                            ></Option>
                        </Select>
                    </FormItem>
                    <FormItem label="币种" prop="currencyId">
                        <Select
                            disabled
                            placeholder="请选择币种"
                            remote
                            v-model="formAttr.currencyId"
                        >
                            <Option
                                v-for="item in currencyArr"
                                :label="item.fieldValue"
                                :value="item.id"
                                :key="item.id"
                            ></Option>
                        </Select>
                    </FormItem>
                    <FormItem label="市场指导价">
                        <Input
                            disabled
                            v-model="formAttr.marketPrice"
                            :placeholder="!Boolean(formAttr.marketPrice)?'':'请输入市场指导价'"
                        ></Input>
                    </FormItem>
                    <FormItem label="询价时间">
                        <DatePicker
                            disabled
                            v-model="formAttr.inquiryTime"
                            format="yyyy-MM-dd"
                            type="date"
                            :placeholder="!Boolean(formAttr.inquiryTime)?'':'请选择询价时间'"
                        ></DatePicker>
                    </FormItem>
                    <FormItem label="税率" prop="taxRate">
                        <Input
                            disabled
                            v-model="formAttr.taxRate"
                            placeholder="请输入税率"
                        ></Input>
                    </FormItem>
                    <FormItem label="采购周期">
                        <Input
                            disabled
                            v-model="formAttr.purchaseCycle"
                            :placeholder="!Boolean(formAttr.purchaseCycle)?'':'请输入采购周期'"
                            type="number"
                        >
                            <span slot="append">月</span></Input>
                    </FormItem>
                </Form>
            </div>
        </Modal>
        <!--        物料弹窗-->
        <Modal
            v-model="materialShowFlag"
            width="700"
            title="选择物料"
            :mask-closable="maskClosable"
            footer-hide
        >
            <div>
                <Card dis-hover :bordered="false">
                    <p slot="title">
                        <Icon type="ios-search"></Icon>
                        查询条件
                    </p>
                    <div slot="extra">
                        <ButtonGroup>
                            <Button @click="materialSearch" icon="md-search"
                                >搜索
                            </Button>
                            <Button @click="materialReset" icon="md-refresh"
                                >重置
                            </Button>
                        </ButtonGroup>
                    </div>
                    <Row :gutter="16">
                        <Col span="12" class="maxWidth">
                            <Input
                                v-model="materialTableQuery.commodityName"
                                @on-search="materialSearch"
                                search
                                placeholder="物料名称"
                            >
                                <Button
                                    @click="materialSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                        <Col span="12">
                            <Input
                                v-model="materialTableQuery.specializedGroup"
                                @on-search="materialSearch"
                                search
                                placeholder="专业分组"
                            >
                                <Button
                                    @click="materialSearch"
                                    slot="append"
                                    icon="ios-search"
                                ></Button>
                            </Input>
                        </Col>
                    </Row>
                </Card>
                <erp-table
                    @on-page-no-change="materialPageNoChange"
                    @on-page-size-change="materialPageSizeChange"
                    :tableWidth="tableWidth"
                    :erpTableTitle="materialTableTitle"
                    :erpTableData="materialTableData"
                    :tableLoading="materialTableLoading"
                    :current="materialComAttr.pageNo"
                    :total="materialTotal"
                >
                </erp-table>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import {
        getChannelPriceList,
        getCompanyMaterialList,
        getMaterialUnitList,
        approveChannelPrice,
        unapproveChannelPrice
    } from '@/api/purchaseManage/channelPrice';
    import { getAllSupplierList } from '@/api/purchaseManage/buyer';
    import { getCompanyPurchaseOrganizationList } from '@/api/purchaseManage/purchaseGroup';
    import { resetObj, getDate } from '@/libs/tools';

    export default {
        name: 'channelPriceReview',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    supplierEnableCode: '',
                    commodityName: '',
                    specializedGroupName: '',
                    status: 1
                }, // 表格查询条件
                formAttr: {
                    commodityCode: '',
                    commodityName: '',
                    supplierEnableCode: '',
                    selectPurchaseOrganizationId: '',
                    purchasePrice: '',
                    unitCode: '',
                    currencyId: '',
                    marketPrice: '',
                    inquiryTime: '',
                    taxRate: '',
                    purchaseCycle: ''
                }, // modal 值对象
                ruleValidate: {
                    commodityCode: [
                        {
                            required: true,
                            message: '物料不能为空',
                            trigger: 'blur'
                        }
                    ],
                    supplierEnableCode: [
                        {
                            required: true,
                            message: '供应商不能为空',
                            trigger: 'change'
                        }
                    ],
                    selectPurchaseOrganizationId: [
                        {
                            required: true,
                            type: 'number',
                            message: '采购组织不能为空',
                            trigger: 'change'
                        }
                    ],
                    purchasePrice: [
                        {
                            required: true,
                            message: '采购单价不能为空',
                            trigger: 'blur'
                        }
                    ],
                    unitCode: [
                        {
                            required: true,
                            message: '单位不能为空',
                            trigger: 'change'
                        }
                    ],
                    currencyId: [
                        {
                            required: true,
                            type: 'number',
                            message: '币种不能为空',
                            trigger: 'change'
                        }
                    ],
                    marketPrice: [
                        {
                            required: true,
                            message: '市场指导价不能为空',
                            trigger: 'blur'
                        }
                    ],
                    inquiryTime: [
                        {
                            required: true,
                            type: 'date',
                            message: '询价时间不能为空',
                            trigger: 'change'
                        }
                    ],
                    taxRate: [
                        {
                            required: true,
                            message: '税率不能为空',
                            trigger: 'blur'
                        }
                    ],
                    purchaseCycle: [
                        {
                            required: true,
                            message: '采购周期不能为空',
                            trigger: 'blur'
                        }
                    ]
                }, // modal 表单验证
                erpTableTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '采购组织',
                        align: 'center',
                        minWidth: 120,
                        key: 'selectPurchaseOrganizationName'
                    },
                    {
                        title: '物料常用名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityName'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 80,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 90,
                        key: 'brandName'
                    },
                    // {
                    //     title: '厂家',
                    //     align: 'center',
                    //     minWidth: 120
                    // },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 120,
                        key: 'specializedGroupName'
                    },
                    {
                        title: '包装单位',
                        align: 'center',
                        minWidth: 100,
                        key: 'unitName'
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '采购价格',
                        align: 'center',
                        minWidth: 100,
                        key: 'purchasePrice'
                    },
                    {
                        title: '币种',
                        align: 'center',
                        minWidth: 90,
                        key: 'currencyName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 90,
                        key: 'statusDescription'
                    },
                    {
                        title: '操作',
                        key: 'action',
                        width: 140,
                        align: 'center',
                        fixed: 'right',
                        render: (h, params) => {
                            if (params.row.taskStatus === 0) {
                                return h('div', [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'success',
                                                size: 'small'
                                            },
                                            style: {
                                                marginRight: '5px'
                                            },
                                            on: {
                                                click: () => {
                                                    this.editTableData(
                                                        params,
                                                        '查看采购渠道',
                                                        this.editBefore
                                                    );
                                                }
                                            }
                                        },
                                        '查看'
                                    )
                                ]);
                            } else if (params.row.taskStatus === 1) {
                                return h('div', [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'success',
                                                size: 'small'
                                            },
                                            style: {
                                                marginRight: '5px'
                                            },
                                            on: {
                                                click: () => {
                                                    this.editTableData(
                                                        params,
                                                        '编辑采购渠道',
                                                        this.editBefore
                                                    );
                                                }
                                            }
                                        },
                                        '查看'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'warning',
                                                size: 'small'
                                            },
                                            style: {},
                                            on: {
                                                click: () => {
                                                    this.tableSelectValue = [
                                                        params.row.id
                                                    ];
                                                    this.approveChannelPrice();
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList.channelPriceApprove
                                                }
                                            ]
                                        },
                                        '审核'
                                    )
                                ]);
                            } else if (params.row.taskStatus === 2) {
                                return h('div', [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'success',
                                                size: 'small'
                                            },
                                            style: {
                                                marginRight: '5px'
                                            },
                                            on: {
                                                click: () => {
                                                    this.editTableData(
                                                        params,
                                                        '编辑采购渠道',
                                                        this.editBefore
                                                    );
                                                }
                                            }
                                        },
                                        '查看'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'default',
                                                size: 'small'
                                            },
                                            style: {},
                                            on: {
                                                click: () => {
                                                    this.tableSelectValue = [
                                                        params.row.id
                                                    ];
                                                    this.unapproveChannelPrice();
                                                }
                                            },
                                            directives: [
                                                {
                                                    name: 'has',
                                                    value: this.btnRightList.channelPriceUnapprove
                                                }
                                            ]
                                        },
                                        '取消审核'
                                    )
                                ]);
                            }
                        }
                    }
                ], // 表格标题
                supplierArr: [], // 供应商数组
                statusArr: [
                    {
                        id: 1,
                        label: '未提交',
                        value: 0
                    },
                    {
                        id: 2,
                        label: '审核中',
                        value: 1
                    },
                    {
                        id: 3,
                        label: '已审核',
                        value: 2
                    }
                ],
                unitArr: [], // 物料包装单位数组
                purchaseOrganizationArr: [], // 采购组织数组
                currencyArr: [], // 币种数组
                materialShowFlag: false, // 物料弹窗开关
                materialTableTitle: [
                    {
                        title: '常用名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityName'
                    },
                    {
                        title: '物料规格',
                        align: 'center',
                        minWidth: 90,
                        key: 'commoditySpec'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 90,
                        key: 'brandName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 90,
                        key: 'specializedGroup'
                    },
                    {
                        title: '操作',
                        minWidth: 100,
                        align: 'center',
                        render: (h, params) => {
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'success',
                                            size: 'small'
                                        },
                                        on: {
                                            click: () => {
                                                this.formAttr.commodityCode =
                                                    params.row.commodityCode;
                                                this.formAttr.commodityName =
                                                    params.row.commodityName;
                                                this.formAttr.commodityId =
                                                    params.row.commodityId;
                                                this.getMaterialUnitList();
                                                this.materialShowFlag = false;
                                            }
                                        }
                                    },
                                    '选择'
                                )
                            ]);
                        }
                    }
                ], // 物料表格栏目
                materialTableData: [],
                materialTableLoading: false,
                materialComAttr: {
                    pageNo: 1,
                    pageSize: 10
                },
                materialTotal: 0,
                materialTableQuery: {
                    commodityName: '',
                    specializedGroup: ''
                }
            };
        },
        created () {
            this.getAllSelectData();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr,
                        {
                            levelId:
                                this.tableQueryAttr.levelId === -1
                                    ? ''
                                    : this.tableQueryAttr.levelId
                        }
                    );
                    const res = await getChannelPriceList(params);
                    getListMixin(res);
                });
            },
            // 新增编辑确认按钮
            modalOk () {
                this.changeLoading();
                this.modalCancel();
            },
            // 获取该页面所有下拉框数据
            getAllSelectData () {
                this.getAllSupplierList();
                this.getFieldValuesData('currency', 'currencyArr');
                this.getCompanyPurchaseOrganizationList();
            },
            // 获取公司全部供应商列表
            async getAllSupplierList () {
                const res = await getAllSupplierList();
                if (res.status === this.code) {
                    this.supplierArr = res.content;
                }
            },
            // 获取物料包装单位
            async getMaterialUnitList () {
                if (this.formAttr.commodityCode) {
                    const params = {
                        commodityCode: this.formAttr.commodityCode
                    };
                    const res = await getMaterialUnitList(params);
                    if (res.status === this.code) {
                        this.unitArr = res.content;
                    }
                }
            },
            // 获取当前公司的采购组织
            async getCompanyPurchaseOrganizationList () {
                const res = await getCompanyPurchaseOrganizationList();
                if (res.status === this.code) {
                    this.purchaseOrganizationArr = res.content;
                }
            },
            // 获取本公司的物料列表
            async getCompanyMaterialList () {
                this.materialTableLoading = true;
                const params = Object.assign(
                    {},
                    this.materialComAttr,
                    this.materialTableQuery
                );
                const res = await getCompanyMaterialList(params);
                this.materialTableLoading = false;
                if (res.status === this.code) {
                    this.materialTableData = res.content.list;
                    this.materialTotal = res.content.total;
                }
            },
            // 搜索物料列表
            materialSearch () {
                this.getCompanyMaterialList();
            },
            // 重置物料搜索
            materialReset () {
                resetObj(this.materialTableQuery);
                this.materialComAttr.pageNo = 1;
                this.getCompanyMaterialList();
            },
            // 改变物料每页数量
            materialPageSizeChange (value) {
                this.materialComAttr.pageNo = 1;
                this.materialComAttr.pageSize = value;
                this.getCompanyMaterialList();
            },
            // 改变物料页码
            materialPageNoChange (value) {
                this.materialComAttr.pageNo = value;
                this.getCompanyMaterialList();
            },
            // 打开物料弹窗
            openMaterialModal () {
                this.materialShowFlag = true;
                this.getCompanyMaterialList();
            },
            // 编辑前格式化数据
            editBefore (data) {
                this.formAttr = Object.assign({}, this.formAttr, {
                    inquiryTime: data.inquiryTime ? getDate(data.inquiryTime) : '',
                    purchasePrice: String(data.purchasePrice),
                    marketPrice: String(data.marketPrice || ''),
                    taxRate: String(data.taxRate),
                    purchaseCycle: String(data.purchaseCycle || '')
                });
                this.getMaterialUnitList();
            },
            // 审核
            async approveChannelPrice () {
                if (this.tableSelectValue.length === 0) { return this.$Message.error('请先勾选一项'); }
                if (this.judgeStatus(1)) { return this.$Message.error('只有审核中状态才能审核'); }
                const params = {
                    ids: this.tableSelectValue
                };
                const res = await approveChannelPrice(params);
                this.successBack(res);
            },
            // 取消审核
            async unapproveChannelPrice () {
                if (this.tableSelectValue.length === 0) { return this.$Message.error('请先勾选一项'); }
                if (this.judgeStatus(2)) { return this.$Message.error('只有审核通过状态才能取消审核'); }
                const params = {
                    ids: this.tableSelectValue
                };
                const res = await unapproveChannelPrice(params);
                this.successBack(res);
            },
            // 提交审核取消审核成功
            successBack (res) {
                this.tableSelectValue = [];
                this.tableSelectList = [];
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                    this.getTableList();
                }
            },
            // 判断订单状态
            judgeStatus (num) {
                const orderNum = this.tableSelectList.some(item => {
                    return item.taskStatus !== num;
                });
                if (orderNum) {
                    this.getTableList();
                    this.tableSelectValue = [];
                    this.tableSelectList = [];
                    return true;
                } else {
                    return false;
                }
            }
        }
    };
</script>

<style scoped lang="less">
</style>
