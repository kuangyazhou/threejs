<template>
    <div class="sales-change">
        <!-- <h1>客户变更-销售</h1> -->
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon> 查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.customerName"
                        placeholder="客户名称"
                        @on-search="search"
                        search
                    >
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title"><Icon type="md-list"></Icon>变更列表</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button
                        @click="addCustomer"
                        icon="md-log-in"
                        v-has="btnRightList.saleChangeAdd"
                    >新增变更</Button>
                    <Button
                        icon="md-send"
                        @click="sendAudit"
                        v-has="btnRightList.saleChangeAudit"
                    >发起审批</Button>
                    <Button @click="delAudit" icon="md-trash" v-has="btnRightList.saleChangeDel">删除</Button>
                </ButtonGroup>
            </div>
            <!--  -->
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                @on-current-change="currentChange"
                highlight
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
                ref="managerTable"
            ></erp-table>
        </Card>
        <!-- 客户选择Modal -->
        <Modal
            v-model="customerModal"
            width="650"
            title="选择客户"
            :loading="customerLoading"
            :mask-closable="false"
            @on-cancel="customerCancel"
            @on-ok="customerOk"
        >
            <Row :gutter="16" class="search-container">
                <Col span="8">
                    <Input v-model="formAttr.customerName" placeholder="客户名称"></Input>
                </Col>
                <Col span="8">
                    <Input v-model="formAttr.uniqueCode" placeholder="唋一识别码"></Input>
                </Col>
                <Col span="8">
                    <Button @click="cusSearch">搜索</Button>
                </Col>
            </Row>
            <div class="clearfix">
                <Table :columns="cusColumns" :data="cusData" border>
                    <template slot-scope="{ row }" slot="operate">
                        <Button
                            @click="edit(row)"
                            type="primary"
                            icon="ios-create-outline"
                            size="small"
                        >修改</Button>
                    </template>
                </Table>
                <div class="wrapper-page">
                    <Page
                        :current="customerPage.pageNo"
                        :total="customerPage.total"
                        show-sizer
                        show-elevator
                        @on-change="cusPageChange"
                        @on-page-size-change="cusSizeChange"
                    ></Page>
                </div>
            </div>
        </Modal>
        <Modal
            @on-cancel="onClose"
            @on-ok="modalOk"
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            fullscreen
        >
            <Tabs v-model="tabIndex" type="card" @on-click="tabsBind">
                <TabPane label="基础信息">
                    <BaseInFoForm
                        ref="baseInfoForm"
                        @changeLoading="changeLoading"
                        @isSave="setSave"
                        @changeCurrentId="changeCurrentId"
                        :oldFormAttr="formAttr"
                        :customerAreaArr="customerAreaArr"
                        :customerTypeArr="customerTypeArr"
                        :customerClassifyArr="customerClassifyArr"
                        :saleMethodArr="saleMethodArr"
                        :saleModeArr="saleModeArr"
                        :saleDepartmentArr="saleDepartmentArr"
                        :customerLevelArr="customerLevelArr"
                        :isChange="true"
                        :oldBaseInfo="oldBaseInfo"
                    ></BaseInFoForm>
                </TabPane>
                <template v-if="hasSaved">
                    <TabPane label="器械分类">
                        <MachineClass
                            ref="machineClass"
                            @changeLoading="changeLoading"
                            :materialCheckbox="materialList"
                            :machineCheckbox="machineList"
                            :selectData="infoData"
                            :taskInstanceId="currentId"
                            :selectedMachine="selectedMachine"
                            :selectedMaterial="selectedMaterial"
                            :machineReadonly="true"
                        ></MachineClass>
                    </TabPane>
                    <TabPane label="上传资料">
                        <UploadData
                            ref="uploadData"
                            @updateTable="updateTable"
                            :radioData="infoData"
                            :taskInstanceId="currentId"
                            :uploadTable="uploadTable"
                            :oldLicense="oldLicenseArr"
                            :uploadReadonly="!firstImport && !firstSub"
                            :isChange="true"
                        ></UploadData>
                    </TabPane>
                    <TabPane label="收货地址">
                        <ReceiveAddress
                            ref="receiveAddress"
                            @addressList="getCustomerAddressList"
                            :customerAddressList="customerAddressList"
                            :taskInstanceId="currentId"
                            :oldAdress="oldAddressArr"
                            :isChange="true"
                        ></ReceiveAddress>
                    </TabPane>
                    <TabPane label="联系人">
                        <Contact
                            ref="contact"
                            @contactList="getCustomerContactList"
                            :customerContactList="customerContactList"
                            :taskInstanceId="currentId"
                            :oldContact="oldContactArr"
                            :isChange="true"
                        ></Contact>
                    </TabPane>
                </template>
            </Tabs>
            <div slot="footer">
                <Button @click="onClose">取消</Button>
                <Button @click="modalOk">保存</Button>
                <Button @click="sendAudit" type="primary">发起审批</Button>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import statusMixin from '@/mixins/statusMixin';

    import { getDate } from '@/libs/tools';
    import {
        salesChangeList,
        customerList,
        oldBaseInfo,
        oldLicense,
        oldAddress,
        oldContact
    } from '@/api/masterData/userchange';

    import {
        BaseInFoForm,
        MachineClass,
        UploadData,
        ReceiveAddress,
        Contact
    } from '_c/customer';

    export default {
        mixins: [tableMixin, statusMixin],
        components: {
            ErpTable,
            BaseInFoForm,
            MachineClass,
            UploadData,
            ReceiveAddress,
            Contact
        },
        data () {
            return {
                oldLicenseArr: [],
                oldAddressArr: [],
                oldContactArr: [],
                oldBaseInfo: {},
                tableQueryAttr: {
                    customerName: '',
                    status: ''
                },
                formAttr: {
                    customerName: '',
                    customerCode: '',
                    customerArea: '',
                    customerType: '',
                    customerClassify: '',
                    contractPaymentMonth: '',
                    saleMethod: '',
                    saleMode: '',
                    parentId: '',
                    saleDepartment: '',
                    customerLevel: '',
                    licenseRegistrationCode: '',
                    customerAddress: '',
                    unifiedSocialCreditCode: '',
                    dutyParagraph: '',
                    bankName: '',
                    bankCode: '',
                    bankAccount: '',
                    bankType: '',
                    invoiceDescription: '',
                    invoiceAddress: '',
                    customerDescription: '',
                    warehouseAddress: '',
                    id: '',
                    uniqueCode: '',
                    customerId: ''
                },
                customerPage: {
                    pageNo: 1,
                    pageSize: 10,
                    total: 0
                },
                hasSaved: false, // 基础信息是否保存
                tabIndex: 0,
                customerModal: false, // 客户选择弹框
                customerLoading: false, // 客户选择loading
                cusData: [], // 可选择客户列表
                erpTableTitle: [
                    {
                        title: '公司',
                        align: 'center',
                        minWidth: 100,
                        key: 'enterpriseName'
                    },
                    {
                        title: '编号',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerCode'
                    },
                    {
                        title: '名称',
                        align: 'center',
                        minWidth: 140,
                        key: 'customerName'
                    },
                    {
                        title: '区域',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerAreaName'
                    },
                    {
                        title: '分类',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerClassifyName'
                    },
                    {
                        title: '类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerTypeName'
                    },
                    {
                        title: '上级',
                        align: 'center',
                        minWidth: 100,
                        key: 'parentName'
                    },
                    {
                        title: '创建人',
                        align: 'center',
                        minWidth: 100,
                        key: 'createName'
                    },
                    {
                        title: '创建时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '审批状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'status',
                        render: (h, params) => {
                            const map = {
                                0: '待发起',
                                1: '审批中',
                                2: '审核通过',
                                3: '打回'
                            };
                            return h('span', {}, map[params.row.status]);
                        }
                    },
                    // {
                    //     title: '流程详情',
                    //     align: 'center',
                    //     minWidth: 100
                    // },
                    {
                        title: '操作',
                        align: 'center',
                        fixed: 'right',
                        minWidth: 100,
                        // slot: 'operate'
                        render: (h, params) => {
                            return h(
                                'Button',
                                {
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    on: {
                                        click: e => {
                                            if (e && e.stopPropagation) {
                                                // 非IE
                                                e.stopPropagation();
                                            } else {
                                                // IE
                                                window.event.cancelBubble = true;
                                            }
                                            this.editTableData(params, '修改客户');
                                            this.getOldBaseInfo();
                                            this.getAllSelectData();
                                            this.customerModal = false;
                                            // this.edit(params);
                                            this.hasSaved = true; // 显示其他资料
                                            if (params.row.parentId) {
                                                this.firstSub = true;
                                            } else {
                                                this.firstSub = false;
                                            }
                                        }
                                    },
                                    directives: [
                                        {
                                            name: 'has',
                                            value: this.btnRightList
                                                .saleChangeUpdate
                                        }
                                    ]
                                },
                                '编辑'
                            );
                        }
                    }
                ],
                cusColumns: [
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'customerName'
                    },
                    {
                        title: '区域',
                        align: 'center',
                        minWidth: 80,
                        key: 'customerAreaName'
                    },
                    {
                        title: '执业许可登记号',
                        align: 'center',
                        minWidth: 120,
                        key: 'licenseRegistrationCode'
                    },
                    {
                        title: '统一社会信用码',
                        align: 'center',
                        minWidth: 120,
                        key: 'unifiedSocialCreditCode'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        slot: 'operate'
                    }
                ]
            };
        },
        methods: {
            add () {
                this.addItem('客户选择');
            },
            // 修改客户信息
            edit (row) {
                // this.taskInstanceId = row.taskInstanceId;
                row.customerId = row.id;
                this.editTableData({ row }, '修改客户');
                this.formAttr.id = null; // 新增时不带id，修改时带id
                // this.getOldBaseInfo();
                this.getAllSelectData();
                this.customerModal = false;

                // 判断是否为子客户
                if (row.parentId) {
                    this.firstSub = true;
                } else {
                    this.firstSub = false;
                }
            },
            onClose () {
                this.hasSaved = false;
                this.modalShowFlag = false;
                this.tabIndex = 0;
                this.oldBaseInfo = {};
                this.modalCancel();
                this.getTableList();
            },
            // 保存按钮
            async modalOk () {
                switch (this.tabIndex) {
                    case 0:
                        this.$refs['baseInfoForm'].changeSave();
                        break;
                }
            },
            getTableList () {
                this.getTableListFn(async call => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await customerList(params);
                    call(res);
                });
            },
            // 客户选择
            addCustomer () {
                this.customerModal = true;
                this.$refs.managerTable.clearCurrentTableRow();
                this.isPass = false;
                this.currentId = null;
                this.getCustomer();
            },

            customerCancel () {
                this.customerPage.pageNo = 1;
                Object.keys(this.formAttr).forEach(item => {
                    this.formAttr[item] = '';
                });
            },
            customerOk () {},
            // tab点击
            tabsBind (name) {
                switch (name) {
                    case 0:
                        // this.getOldBaseInfo();
                        break;
                    case 1:
                        this.getMachineCheckbox();
                        this.getInfoRadio();
                        this.getSelectedMaterial();
                        this.getSelectedMachine();
                        break;
                    case 2:
                        this.getInfoRadio();
                        this.getUploadTabe();
                        this.getOldLicense();
                        break;
                    case 3:
                        this.getCustomerAddressList();
                        this.getOldAdress();
                        break;
                    case 4:
                        this.getCustomerContactList();
                        this.getOldContact();
                        break;
                }
            },

            // 判断基础信息是否保存
            setSave (e) {
                this.hasSaved = e;
                this.getOldBaseInfo(); // 获取变更前基础信息
            },
            // 更新表格数据
            updateTable (e) {
                this.getUploadTabe(e);
            },

            // 获取子组件传来的id
            changeCurrentId (id) {
                this.currentId = id;
            },

            async getOldBaseInfo () {
                const params = { id: this.currentId };
                const res = await oldBaseInfo(params);
                if (res.status === this.code) {
                    this.oldBaseInfo = res.content;
                }
            },
            async getOldLicense () {
                const params = { taskInstanceId: this.currentId };
                const res = await oldLicense(params);
                if (res.status === this.code) {
                    this.oldLicenseArr = res.content;
                }
            },
            async getOldAdress () {
                const params = { taskInstanceId: this.currentId };
                const res = await oldAddress(params);
                if (res.status === this.code) {
                    this.oldAddressArr = res.content;
                }
            },
            async getOldContact () {
                const params = { taskInstanceId: this.currentId };
                const res = await oldContact(params);
                if (res.status === this.code) {
                    this.oldContactArr = res.content;
                }
            },

            //
            cusPageChange (e) {
                this.customerPage.pageNo = e;
                this.getCustomer();
            },

            cusSizeChange (e) {
                this.customerPage.pageSize = e;
                this.getCustomer();
            },

            cusSearch () {
                this.customerPage.pageNo = 1;
                this.getCustomer();
            },
            // 获取可选择客户list
            async getCustomer () {
                this.customerLoading = true;
                const params = Object.assign({}, this.formAttr, this.customerPage);
                const res = await salesChangeList(params);
                if (res.status === this.code) {
                    this.customerLoading = false;
                    this.cusData = res.content.list;
                    this.customerPage.total = res.content.total;
                }
            }
        }
    };
</script>

<style scoped>
.search-container {
    margin-bottom: 16px;
}
</style>
