<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-10 14:43:41
 * @LastEditTime: 2019-08-16 09:27:07
 * @LastEditors: Please set LastEditors
 -->
<template>
    <!-- <h1>销售价格管理</h1> -->
    <div class="sale-price-manage">
        <Card :border="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon> 查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="4" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.customerEnableCode"
                        placeholder="请选择客户"
                        @on-change="getTableList"
                        filterable
                        ref="filter"
                    >
                        <Option
                            v-for="item in customerArr"
                            :key="item.index"
                            :label="item.customerName"
                            :value="item.customerEnableCode"
                        ></Option>
                    </Select>
                </Col>
                <Col span="4">
                    <Input v-model="tableQueryAttr.commodityName" placeholder="物料名称" search>
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="4">
                    <Input v-model="tableQueryAttr.specializedGroupName" placeholder="专业分组">
                        <Button @click="search" slot="append" icon="ios-search"></Button>
                    </Input>
                </Col>
                <Col span="4">
                    <Select
                        v-model="tableQueryAttr.taskStatus"
                        placeholder="请选择状态"
                        @on-change="getTableList"
                    >
                        <Option
                            v-for="item in typeList"
                            :key="item.index"
                            :label="item.label"
                            :value="item.value"
                        ></Option>
                    </Select>
                </Col>
            </Row>
        </Card>

        <Card :border="false">
            <p slot="title"><Icon type="md-list"></Icon>客户物料列表</p>
            <div slot="extra">
                <ButtonGroup>
                    <Button v-has="btnRightList.materilMoneyAdd" @click="add" icon="md-checkmark">添加</Button>
                    <Button
                        @click="multipleSubmit"
                        v-has="btnRightList.materilMoneySubmitMul"
                        icon="md-checkmark"
                    >提交</Button>
                    <Button
                        @click="multipleAudit"
                        v-has="btnRightList.materilMoneyAuditMul"
                        icon="ios-checkbox-outline"
                    >审核</Button>
                    <Button
                        @click="multipleCancel"
                        v-has="btnRightList.materilMoneyReturnMul"
                        icon="md-checkmark"
                    >取消审核</Button>
                    <Button
                        @click="multipleCancel"
                        v-has="btnRightList.materilMoneyReturnMul"
                        icon="ios-checkbox-outline"
                    >撤回</Button>
                </ButtonGroup>
            </div>
            <erp-table
                ref="managerTable"
                @on-selection-change="selectionChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :total="total"
                :current="tableComAttr.pageNo"
            ></erp-table>
        </Card>
        <Modal
            @on-ok="modalOk"
            @on-cancel="modalCancel"
            v-model="modalShowFlag"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            width="650"
        >
            <Form :model="formAttr" :rules="ruleValidate" ref="formValidate" :label-width="120">
                <FormItem label="客户物料" prop="commodityName">
                    <span class="mr6">{{ formAttr.commodityName }}</span>
                    <Button @click="chooseMaterial" type="success" size="small">选择</Button>
                </FormItem>
                <FormItem label="客户">
                    <!-- <Select>
                        <Option
                            v-for="item in customerArr"
                            :key="item.index"
                            :label="item.customerName"
                            :value="item.customerEnableCode"
                        ></Option>
                    </Select>-->
                    <Input v-model="formAttr.customerName" placeholder="客户" disabled></Input>
                </FormItem>
                <FormItem label="销售组织">
                    <Input v-model="formAttr.saleOrganizationName" placeholder="销售组织" disabled></Input>
                </FormItem>
                <FormItem label="开票名称">
                    <Input v-model="formAttr.invoiceName" placeholder="开票名称" disabled></Input>
                </FormItem>
                <FormItem label="单价" prop="price">
                    <Input v-model="formAttr.price" type="number" placeholder="单价"></Input>
                </FormItem>
                <FormItem label="单位" prop="unitCode">
                    <Select v-model="formAttr.unitCode" placeholder="单位">
                        <Option
                            v-for="item in packageArr"
                            :key="item.index"
                            :label="item.unitName"
                            :value="item.unitCode"
                        ></Option>
                    </Select>
                </FormItem>
                <FormItem label="币种" prop="currencyId">
                    <Select v-model="formAttr.currencyId" placeholder="币种">
                        <Option
                            v-for="item in curArr"
                            :key="item.index"
                            :label="item.fieldValue"
                            :value="item.id"
                        ></Option>
                    </Select>
                </FormItem>
                <FormItem label="税率" prop="taxRate">
                    <Input v-model="formAttr.taxRate" type="number" placeholder="税率"></Input>
                </FormItem>
            </Form>
        </Modal>

        <!-- 物料Modal -->
        <Modal
            v-model="modalMaterial"
            title="客户物料选择"
            :mask-closable="maskClosable"
            width="950"
            @on-cancel="materialClose"
            @on-ok="materialClose"
        >
            <Card>
                <div slot="title">
                    <Row :gutter="12">
                        <Col span="5">
                            <!-- <Input placeholder="选择客户"></Input> -->
                            <Select
                                v-model="searchQuery.customerEnableCode"
                                placeholder="请选择客户"
                                filterable
                            ref="filter"
                            >
                                <Option
                                    v-for="item in customerArr"
                                    :key="item.index"
                                    :label="item.customerName"
                                    :value="item.customerEnableCode"
                                ></Option>
                            </Select>
                        </Col>
                        <Col span="5">
                            <Input v-model="searchQuery.commodityName" placeholder="物料名称"></Input>
                        </Col>
                        <Col span="5">
                            <Input v-model="searchQuery.specializedGroupName" placeholder="专业分组"></Input>
                        </Col>
                        <Col span="4">
                            <Button @click="getMaterialList()" type="primary">搜索</Button>
                        </Col>
                    </Row>
                </div>
                <Table :columns="materialTitle" :data="materialData">
                    <template slot-scope="{ row }" slot="operate">
                        <Button @click="materilSelect(row)" type="success" size="small">选择</Button>
                    </template>
                </Table>
            </Card>
        </Modal>
    </div>
</template>

<script>
    import { mapGetters } from 'vuex';
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';

    import { getCustomerInfo } from '@/api/customerMaterial/materialInfo';
    import { getSaveCustomerList } from '@/api/saleManage/sale';
    import {
        salePriceAdd,
        salePriceList,
        salePriceUpdate,
        salePriceSubmit,
        salePriceAudit,
        salePriceReturn,
        salePriceSubmitMul,
        salePriceAuditMul,
        salePriceReturnMul
    } from '@/api/customerMaterial/materialMoney';

    import { getMaterialUnitList } from '@/api/purchaseManage/channelPrice.js';
    import { resetObj } from '@/libs/tools';

    export default {
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        computed: {
            ...mapGetters(['salerId', 'saleOrganizationId'])
        },
        data () {
            return {
                customerArr: [], // 客户下拉数据
                modalMaterial: false, // 物料Modal
                materialData: [], // 物料数据
                curArr: [], // 币种下拉框数据
                packageArr: [], // 包装单位下拉框数据
                tableQueryAttr: {
                    taskStatus: '',
                    commodityName: '',
                    specializedGroupName: '',
                    customerEnableCode: '',
                    saleOrganizationId: ''
                },
                formAttr: {
                    customerCommodityId: '',
                    commodityName: '',
                    commodityCode: '',
                    commodityId: '',
                    customerName: '',
                    unitCode: '',
                    invoiceName: '',
                    price: '',
                    currencyId: '',
                    taxRate: '',
                    saleOrganizationName: '',
                    saleOrganizationId: '',
                    id: ''
                },
                // 物料搜索条件
                searchQuery: {
                    customerEnableCode: '',
                    specializedGroupName: '',
                    commodityName: ''
                },
                // 审核状态数据
                typeList: [
                    { label: '未提交', value: 0 },
                    { label: '审核中', value: 1 },
                    { label: '已审核', value: 2 }
                ],
                ruleValidate: {
                    commodityName: [
                        {
                            required: true,
                            message: '客户物料不可为空'
                        }
                    ],
                    price: [
                        {
                            required: true,
                            message: '单价不可为空'
                        }
                    ],
                    unitCode: [
                        {
                            required: true,
                            message: '单位不可为空'
                        }
                    ],
                    currencyId: [
                        {
                            required: true,
                            message: '币种不可为空'
                        }
                    ],
                    taxRate: [
                        {
                            required: true,
                            message: '税率不可为空'
                        }
                    ]
                },
                erpTableTitle: [
                    {
                        type: 'selection',
                        minWidth: 60,
                        align: 'center',
                        fixed: 'left'
                    },
                    {
                        title: '销售组织',
                        align: 'center',
                        minWidth: 100,
                        key: 'saleOrganizationName'
                    },
                    {
                        title: '客户',
                        align: 'center',
                        minWidth: 100,
                        key: 'customerName'
                    },
                    {
                        title: '物料常用名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '厂家',
                        align: 'center',
                        minWidth: 100,
                        key: 'manufacturerName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroupName'
                    },
                    {
                        title: '包装单位',
                        align: 'center',
                        minWidth: 100,
                        key: 'unitName'
                    },
                    {
                        title: '销售价格',
                        align: 'center',
                        minWidth: 100,
                        key: 'price'
                    },
                    {
                        title: '币种',
                        align: 'center',
                        minWidth: 100,
                        key: 'currencyName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'statusDescription'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        fixed: 'right',
                        minWidth: 200,
                        render: (h, params) => {
                            let temp = null;
                            if (params.row.taskStatus === 0) {
                                temp = h(
                                    'Button',
                                    {
                                        props: { type: 'success', size: 'small' },
                                        on: {
                                            click: () => {
                                                this.submit(params.row);
                                            }
                                        },
                                        class: 'mr6',
                                        directives: {
                                            name: 'has',
                                            value: this.btnRightList
                                                .materilMoneySubmit
                                        }
                                    },
                                    '提交'
                                );
                            }
                            if (params.row.taskStatus === 1) {
                                temp = [
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'warning',
                                                size: 'small'
                                            },
                                            on: {
                                                click: () => {
                                                    this.cacelAudit(params.row);
                                                }
                                            },
                                            class: 'mr6',
                                            directives: {
                                                name: 'has',
                                                value: this.btnRightList
                                                    .materilMoneyReturn
                                            }
                                        },
                                        '撤回'
                                    ),
                                    h(
                                        'Button',
                                        {
                                            props: {
                                                type: 'success',
                                                size: 'small'
                                            },
                                            on: {
                                                click: () => {
                                                    this.salePriceAudit(params.row);
                                                }
                                            },
                                            class: 'mr6',
                                            directives: {
                                                name: 'has',
                                                value: this.btnRightList
                                                    .materilMoneyReturn
                                            }
                                        },
                                        '审核'
                                    )
                                ];
                            }
                            if (params.row.taskStatus === 2) {
                                temp = h(
                                    'Button',
                                    {
                                        props: {
                                            type: 'primary',
                                            size: 'small'
                                        },
                                        attrs: { ghost: true },
                                        on: {
                                            click: () => {
                                                this.cacelAudit(params.row);
                                            }
                                        },
                                        class: 'mr6',
                                        directives: {
                                            name: 'has',
                                            value: this.btnRightList
                                                .materilMoneyReturn
                                        }
                                    },
                                    '取消审核'
                                );
                            }
                            return h('div', [
                                h(
                                    'Button',
                                    {
                                        props: { type: 'primary', size: 'small' },
                                        on: {
                                            click: () => {
                                                this.editTableData(
                                                    params,
                                                    '编辑销售价格'
                                                );
                                                // 获取单位和币种下拉数据
                                                this.getPackageData();
                                                this.getAllSelectData();
                                            }
                                        },
                                        class: 'mr6',
                                        directives: {
                                            name: 'has',
                                            value: this.btnRightList
                                                .materilMoneyUpdate
                                        }
                                    },
                                    '编辑'
                                ),
                                // h(
                                //     'Button',
                                //     {
                                //         props: { type: 'info', size: 'small' },
                                //         on:{
                                //             click:()=>{
                                //                 this.submit(params.row)
                                //             }
                                //         }
                                //     },
                                //     '审核'
                                // ),
                                temp //
                            ]);
                        }
                    }
                ],
                // 物料表头
                materialTitle: [
                    {
                        title: '常用名称',
                        align: 'center',
                        minWidth: 100,
                        key: 'commodityName'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroupName'
                    },
                    {
                        title: '操作',
                        align: 'center',
                        minWidth: 100,
                        slot: 'operate'
                    }
                ]
            };
        },
        methods: {
            modalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    let res = null;

                    if (this.currentId) {
                        const params = Object.assign({}, this.formAttr, {
                            id: this.currentId
                        });
                        res = await salePriceUpdate(params);
                    } else {
                        const params = Object.assign({}, this.formAttr);
                        res = await salePriceAdd(params);
                    }
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    } else {
                        this.changeLoading();
                    }
                });
            },

            add () {
                this.addItem('添加销售价格');
                this.getAllSelectData();
            },
            // 提交
            async submit (row) {
                const params = {
                    id: row.id
                };
                const res = await salePriceSubmit(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            // 取消审核
            async cacelAudit (row) {
                const params = {
                    id: row.id
                };
                const res = await salePriceReturn(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            // 通过
            async salePriceAudit (row) {
                const params = {
                    id: row.id
                };
                const res = await salePriceAudit(params);
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                }
            },

            chooseMaterial () {
                this.modalMaterial = true;
                const params = Object.assign(
                    {},
                    { salerId: this.salerId, status: 3 }
                );
                this.getMaterialList(params);
            },

            // 批量提交
            async multipleSubmit () {
                if (this.delCheck('请至少选择一项')) {
                    const isEqual = this.tableSelectList.every(item => {
                        return item.taskStatus === 0;
                    });
                    if (!isEqual) {
                        return this.$Message.error('请选择状态为未提交的数据');
                    }
                    const params = { ids: this.tableSelectValue };
                    const res = await salePriceSubmitMul(params);
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    }
                }
            },

            // 批量审核
            async multipleAudit () {
                if (this.delCheck('请至少选择一项')) {
                    const isEqual = this.tableSelectList.every(item => {
                        return item.taskStatus === 1;
                    });
                    if (!isEqual) {
                        return this.$Message.error('请选择状态为审核中的数据');
                    }
                    const params = { ids: this.tableSelectValue };
                    const res = await salePriceAuditMul(params);
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    }
                }
            },

            // 批量取消
            async multipleCancel () {
                if (this.delCheck('请至少选择一项')) {
                    const isEqual = this.tableSelectList.every(item => {
                        return item.taskStatus === 2;
                    });
                    if (!isEqual) {
                        return this.$Message.error('请选择状态为已审核的数据');
                    }
                    const params = { ids: this.tableSelectValue };
                    const res = await salePriceReturnMul(params);
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                    }
                }
            },

            // 获取客户列表
            async getCustomerData () {
                const params = {
                    salerId: this.salerId
                };
                const res = await getSaveCustomerList(params);
                if (res.status === this.code) {
                    this.customerArr = res.content;
                }
            },
            // 获取当前企业下的物料信息
            async getMaterialList (arg) {
                this.materialData = [];
                const params = Object.assign({}, arg, this.searchQuery, {
                    salerId: this.salerId,
                    saleOrganizationId: this.saleOrganizationId,
                    status: 3
                });
                console.log(this.salerId, this.saleOrganizationId, params);
                const res = await getCustomerInfo(params);
                if (res.status === this.code) {
                    this.materialData = res.content;
                }
            },

            // 物料选择关闭
            materialClose () {
                this.materialData = [];
                resetObj(this.searchQuery);
            },

            materilSelect (row) {
                Object.assign(this.formAttr, row);
                this.formAttr.customerCommodityId = row.id;
                this.modalMaterial = false;
                this.getPackageData(); // 获取物料包装单位
            },

            async getPackageData () {
                const params = {
                    commodityId: this.formAttr.commodityId,
                    status: 3,
                    isDeleted: 1,
                    isDefault: 1
                };
                const res = await getMaterialUnitList(params);
                if (res.status === this.code) {
                    this.packageArr = res.content;
                }
            },

            getAllSelectData () {
                this.getFieldValuesData('currency', 'curArr');
            // this.getFieldValuesData('package_unit', 'packageArr');
            },

            // 获取表格数据
            getTableList () {
                // 获取客户数据
                this.getCustomerData();
                this.getTableListFn(async call => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await salePriceList(params);
                    call(res);
                });
            }
        }
    };
</script>
