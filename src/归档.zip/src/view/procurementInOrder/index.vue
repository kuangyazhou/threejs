<template>
    <div class="inventoryInit">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.inventoryOrganizationId"
                        @on-change="searchInventory"
                        placeholder="请选择库存组织"
                    >
                        <Option
                            v-for="item in inventoryOrganizationArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Select
                        v-model="tableQueryAttr.warehouseId"
                        :disabled="!tableQueryAttr.inventoryOrganizationId"
                        @on-change="selectSearch"
                        placeholder="请选择仓库"
                    >
                        <Option
                            v-for="item in warehouseArr"
                            :value="item.value"
                            :key="item.value"
                        >{{ item.label }}
                        </Option
                        >
                    </Select>
                </Col>
                <Col span="5" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.inboundOrderCode"
                        @on-search="search"
                        search
                        placeholder="入库单号"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                采购入库单列表
            </p>
            <div slot="extra">
<!--                <ButtonGroup>-->
<!--                    <Button @click="openSendModal"-->
<!--                        icon="md-add"-->
<!--                    >新增</Button>-->
<!--                    <Button-->
<!--                        icon="ios-create-outline"-->
<!--                    >编辑</Button>-->
<!--                    <Button-->
<!--                        icon="md-send"-->
<!--                    >提交</Button>-->
<!--                    <Button-->
<!--                        icon="md-undo"-->
<!--                    >撤回</Button>-->
<!--                    <Button-->
<!--                        icon="md-redo"-->
<!--                    >审核</Button>-->
<!--                    <Button-->
<!--                        icon="ios-key"-->
<!--                    >增加红字</Button>-->
<!--                </ButtonGroup>-->
            </div>
            <erp-table
                ref="salesTable"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { getOrganizationDropList, getWarehouseDropList } from '@/api/inventory/inventory';
    import { getPurchaseInboundList } from '@/api/inventory/inbound';
    import { getDate } from '@/libs/tools';

    export default {
        name: 'procurementInOrder',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    inventoryOrganizationId: '',
                    warehouseId: '',
                    inboundOrderCode: ''
                },
                inventoryOrganizationArr: [], // 库存组织下拉
                warehouseArr: [], // 仓库列表下拉
                erpTableTitle: [
                    {
                        title: '入库单号',
                        align: 'center',
                        minWidth: 120,
                        key: 'inboundOrderCode'
                    },
                    {
                        title: '入库类型',
                        align: 'center',
                        minWidth: 100,
                        key: 'orderTypeName'
                    },
                    {
                        title: '库存组织',
                        align: 'center',
                        minWidth: 120,
                        key: 'inventoryOrganizationName'
                    },
                    {
                        title: '仓库',
                        align: 'center',
                        minWidth: 120,
                        key: 'warehouseName'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityName'
                    },
                    {
                        title: '注册证名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerName'
                    },
                    {
                        title: '注册证编码',
                        align: 'center',
                        minWidth: 120,
                        key: 'registerNumber'
                    },
                    {
                        title: '规格',
                        align: 'center',
                        minWidth: 100,
                        key: 'commoditySpec'
                    },
                    {
                        title: '品牌',
                        align: 'center',
                        minWidth: 100,
                        key: 'brandName'
                    },
                    {
                        title: '数量',
                        align: 'center',
                        minWidth: 90,
                        key: 'quantity'
                    },
                    {
                        title: '单位',
                        align: 'center',
                        minWidth: 90,
                        key: 'unitName'
                    },
                    {
                        title: '批号',
                        align: 'center',
                        minWidth: 120,
                        key: 'batchNo'
                    },
                    {
                        title: '生产日期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            let producedDate = getDate(params.row.producedDate);
                            if (params.row.producedDateFormat === 'yyyy-MM') {
                                producedDate = producedDate.slice(0, 7);
                            }
                            return h(
                                'span',
                                {},
                                producedDate
                            );
                        }
                    },
                    {
                        title: '效期',
                        align: 'center',
                        minWidth: 110,
                        render: (h, params) => {
                            let effectiveDate = getDate(params.row.effectiveDate);
                            if (params.row.effectiveDateFormat === 'yyyy-MM') {
                                effectiveDate = effectiveDate.slice(0, 7);
                            }
                            return h(
                                'span',
                                {},
                                effectiveDate
                            );
                        }
                    },
                    {
                        title: '供应商',
                        align: 'center',
                        minWidth: 120,
                        key: 'supplierName'
                    },
                    {
                        title: '来源',
                        align: 'center',
                        minWidth: 90,
                        key: 'sourceTypeName'
                    },
                    {
                        title: '录入时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    }
                    // {
                    //     title: '操作',
                    //     key: 'action',
                    //     width: 120,
                    //     align: 'center',
                    //     fixed: 'right',
                    //     render: (h, params) => {
                    //         return h('div', [
                    //             h(
                    //                 'Button',
                    //                 {
                    //                     props: {
                    //                         type: 'primary',
                    //                         size: 'small'
                    //                     },
                    //                     style: {},
                    //                     on: {
                    //                         click: () => {
                    //                             this.currentId = params.row.orderId;
                    //                             this.openOutOrderModal();
                    //                         }
                    //                     }
                    //                 },
                    //                 '查看'
                    //             )
                    //         ]);
                    //     }
                    // }
                ]
            };
        },
        created () {
            this.getAllSelectData();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                if (!this.tableQueryAttr.warehouseId && !this.tableQueryAttr.inventoryOrganizationId) return;
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getPurchaseInboundList(params);
                    getListMixin(res);
                });
            },
            getAllSelectData () {
                this.getInventoryOrganizationList();
            },
            // 库存组织下拉
            async getInventoryOrganizationList () {
                const res = await getOrganizationDropList();
                if (res.status === this.code) {
                    this.inventoryOrganizationArr = res.content.map(item => {
                        return {
                            label: item.inventoryOrganizationName,
                            value: item.id
                        };
                    });
                    if (this.inventoryOrganizationArr.length && !this.tableQueryAttr.inventoryOrganizationId) {
                        this.tableQueryAttr.inventoryOrganizationId = this.inventoryOrganizationArr[0].value;
                        this.getWarehouseList(this.tableQueryAttr.inventoryOrganizationId);
                    }
                }
            },
            // 获取库存组织关联的仓库
            async getWarehouseList (id) {
                if (!id) return;
                const params = Object.assign({}, {
                    inventoryOrganizationId: id
                });
                const res = await getWarehouseDropList(params);
                if (res.status === this.code) {
                    this.warehouseArr = res.content.map(item => {
                        return {
                            label: item.warehouseName,
                            value: item.id
                        };
                    });
                    if (this.warehouseArr.length) {
                        this.tableQueryAttr.warehouseId = this.warehouseArr[0].value;
                        if (this.tableQueryAttr.warehouseId && this.tableQueryAttr.inventoryOrganizationId) {
                            this.getTableList();
                        }
                    }
                }
            },
            // 选择库存之后
            searchInventory (val) {
                this.getWarehouseList(val);
            }
        }
    };
</script>

<style scoped lang="less">
    /deep/ .ivu-table-cell{
        padding: 4px;
    }
</style>
