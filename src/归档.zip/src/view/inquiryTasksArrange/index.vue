<template>
    <div class="erp-content" ref="erp">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="ios-search"></Icon>
                查询条件
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button @click="search" icon="md-search">搜索</Button>
                    <Button @click="reset" icon="md-refresh">重置</Button>
                </ButtonGroup>
            </div>
            <Row :gutter="16">
                <Col span="4" class="maxWidth">
                    <Select
                        placeholder="状态"
                        @on-change="selectSearch"
                        remote
                        v-model="tableQueryAttr.receiveStatus"
                    >
                        <Option
                            v-for="item in receiveStatusArr"
                            :label="item.label"
                            :value="item.value"
                            :key="item.id"
                        ></Option>
                    </Select>
                </Col>
                <Col span="4" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.specializedGroupName"
                        @on-search="search"
                        search
                        placeholder="专业分组"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="4" class="maxWidth">
                    <Input
                        v-model="tableQueryAttr.purchaserName"
                        @on-search="search"
                        search
                        placeholder="处理人"
                    >
                        <Button
                            @click="search"
                            slot="append"
                            icon="ios-search"
                        ></Button>
                    </Input>
                </Col>
                <Col span="4" class="maxWidth">
                    <DatePicker
                        :editable="false"
                        v-model="tableQueryAttr.startDate"
                        format="yyyy-MM-dd"
                        type="date"
                        @on-change="startDateChange"
                        placeholder="创建时间开始"
                    ></DatePicker>
                </Col>
                <Col span="4" class="maxWidth">
                    <DatePicker
                        :editable="false"
                        v-model="tableQueryAttr.endDate"
                        format="yyyy-MM-dd"
                        type="date"
                        @on-change="endDateChange"
                        placeholder="创建时间结束"
                    ></DatePicker>
                </Col>
            </Row>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                询价任务列表
            </p>
            <div slot="extra">
                <ButtonGroup>
                    <Button v-has="btnRightList.inquiryTaskReceive" @click="distribution" icon="md-hammer">分配</Button>
                </ButtonGroup>
            </div>
            <erp-table
                @on-selection-change="selectionChange"
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :tableWidth="tableWidth"
                :erpTableTitle="erpTableTitle"
                :erpTableData="erpTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
            >
            </erp-table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel"
        >
            <div class="erp-modal-content">
                <Form
                    :model="formAttr"
                    :rules="ruleValidate"
                    ref="formValidate"
                    :label-width="120"
                >
                    <FormItem label="采购专员" prop="purchaserId">
                        <Select
                            placeholder="请选择采购员"
                            remote
                            v-model="formAttr.purchaserId"
                        >
                            <Option
                                v-for="item in buyerArr"
                                :label="item.realName"
                                :value="item.id"
                                :key="item.id"
                            ></Option>
                        </Select>
                    </FormItem>
                </Form>
            </div>
        </Modal>
    </div>
</template>

<script>
    import ErpTable from '_c/erp-table';
    import tableMixin from '@/mixins/tableMixin';
    import { getCompanyBuyerList } from '@/api/purchaseManage/purchaseGroup';
    import {
        distributionInquiryTask,
        getInquiryTaskList
    } from '@/api/purchaseManage/inquiryTask';
    import { getDate } from '@/libs/tools';

    export default {
        name: 'inquiryTasksArrange',
        mixins: [tableMixin],
        components: {
            ErpTable
        },
        data () {
            return {
                tableQueryAttr: {
                    receiveStatus: 0,
                    specializedGroupName: '',
                    purchaserName: '',
                    startDate: '',
                    endDate: ''
                }, // 表格查询条件
                formAttr: {
                    purchaserId: ''
                }, // modal 值对象
                ruleValidate: {
                    purchaserId: [
                        {
                            required: true,
                            type: 'number',
                            message: '采购员不能为空',
                            trigger: 'change'
                        }
                    ]
                }, // modal 表单验证
                erpTableTitle: [
                    {
                        type: 'selection',
                        width: 60,
                        align: 'center'
                    },
                    {
                        title: '客户名称',
                        align: 'center',
                        minWidth: 140,
                        key: 'customerName'
                    },
                    {
                        title: '物料名称',
                        align: 'center',
                        minWidth: 150,
                        key: 'commodityName'
                    },
                    {
                        title: '专业分组',
                        align: 'center',
                        minWidth: 100,
                        key: 'specializedGroupName'
                    },
                    {
                        title: '物料品牌',
                        align: 'center',
                        minWidth: 120,
                        key: 'commodityBrand'
                    },
                    {
                        title: '仪器名称',
                        align: 'center',
                        minWidth: 120,
                        key: 'instrumentName'
                    },
                    {
                        title: '出库方式',
                        align: 'center',
                        minWidth: 100,
                        key: 'outboundMethodName'
                    },
                    {
                        title: '发货方式',
                        align: 'center',
                        minWidth: 100,
                        key: 'deliveryMethodName'
                    },
                    {
                        title: '状态',
                        align: 'center',
                        minWidth: 100,
                        key: 'statusDescription'
                    },
                    {
                        title: '创建人员',
                        align: 'center',
                        minWidth: 100,
                        key: 'createName'
                    },
                    {
                        title: '创建时间',
                        align: 'center',
                        minWidth: 150,
                        render: (h, params) => {
                            return h(
                                'span',
                                {},
                                getDate(params.row.createTime, 'long')
                            );
                        }
                    },
                    {
                        title: '处理人',
                        align: 'center',
                        minWidth: 90,
                        key: 'purchaserName'
                    }
                ], // 表格标题
                receiveStatusArr: [
                    {
                        id: 1,
                        label: '未分配',
                        value: 0
                    },
                    {
                        id: 2,
                        label: '已分配',
                        value: 1
                    }
                ], // 状态数组
                buyerArr: [] // 采购员数组
            };
        },
        created () {
            this.getAllSelectData();
        },
        methods: {
            /**
             * 获取表格数据
             */
            async getTableList () {
                this.getTableListFn(async getListMixin => {
                    const params = Object.assign(
                        {},
                        this.tableComAttr,
                        this.tableQueryAttr
                    );
                    const res = await getInquiryTaskList(params);
                    getListMixin(res);
                });
            },
            // 新增编辑确认按钮
            modalOk () {
                this.$refs['formValidate'].validate(async valid => {
                    if (!valid) {
                        return this.changeLoading();
                    }
                    const params = Object.assign({}, this.formAttr, {
                        inquiryIds: this.tableSelectValue
                    });
                    const res = await distributionInquiryTask(params);
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                        this.tableSelectValue = [];
                    } else {
                        this.changeLoading();
                    }
                });
            },
            // 分配
            distribution () {
                if (this.tableSelectValue.length === 0) { return this.$Message.error('请先勾选需要分配的任务'); }
                this.addItem('选择采购专员');
            },
            getAllSelectData () {
                this.getCompanyBuyerList();
            },
            // 获取本公司所有采购员
            async getCompanyBuyerList () {
                const res = await getCompanyBuyerList({});
                if (res.status === this.code) {
                    this.buyerArr = res.content;
                }
            },
            // 开始时间格式化
            startDateChange (val) {
                this.tableQueryAttr.startDate = val;
                this.getTableList();
            },
            // 结束时间格式化
            endDateChange (val) {
                this.tableQueryAttr.endDate = val;
                this.getTableList();
            }
        }
    };
</script>

<style scoped lang="less">
.erp-modal-content {
    overflow-y: visible;
}
</style>
