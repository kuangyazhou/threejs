/*
 * @Description: 销售计划接口
 * @Author: kuangyazhou
 * @Date: 2019-08-12 19:21:22
 * @LastEditTime: 2019-08-12 20:03:30
 * @LastEditors: Please set LastEditors
 */
import axios from '@/libs/api.request';

/**
 * @description: 销售计划物料列表
 * @param {type} registerName 注册证名称
 * @param {type} supplierName 供应商名称
 * @param {type} pageNo
 * @return:
 */
export const getMaterialList = ({ registerName, supplierName, pageNo, pageSize }) => {
    const data = { registerName, supplierName, pageNo, pageSize };
    return axios.request({
        url: 'commodity/plan/setting/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 查询销售计划设置列表
 * @param {type} pageNo
 * @return:
 */
export const salePlanSetList = ({ pageNo }) => {
    const data = {
        pageNo
    };
    return axios.request({
        url: 'sale/plan/setting/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 创建销售计划
 * @param {type} monthDay
 * @param {type} commodities 物料列表
 * @return:
 */
export const salePlanSetAdd = ({ monthDay, commodities }) => {
    const data = {
        monthDay,
        commodities
    };
    return axios.request({
        url: 'sale/plan/setting/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 销售计划更新
 * @param {type} monthDay
 * @param {type} commodities 物料列表
 * @param {type} id
 * @return:
 */
export const salePlanSetUpdate = ({ monthDay, commodities, id }) => {
    const data = {
        monthDay,
        commodities,
        id
    };
    return axios.request({
        url: 'sale/plan/setting/update',
        data,
        method: 'post'
    });
};

/**
 * @description: 销售计划删除
 * @return:
 */
export const salePlanSetDel = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/plan/setting/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 销售计划列表
 * @param {type} customerEnableCode 客户唯一编码
 * @param {type} commodityName 物料名称
 * @param {type} dateTimeStr 查询时间：yyyy-MM-dd  dd日数合逻辑即可，比如可取1
 * @return:
 */
export const salePlanList = ({ customerEnableCode, commodityName, dateTimeStr }) => {
    const data = {
        customerEnableCode,
        commodityName,
        dateTimeStr
    };
    return axios.request({
        url: 'sale/plan/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 销售计划生效
 * @param {type} id
 * @return:
 */
export const salePlanSetValid = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/plan/setting/valid',
        data,
        method: 'post'
    });
};

/**
 * @description: 销售计划失效
 * @param {type} id
 * @return:
 */
export const salePlanSetInValid = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/plan/setting/invalid',
        data,
        method: 'post'
    });
};

/**
 * @description: 编辑销售计划列表
 * @param {type} customerEnableCode 客户唯一编号
 * @return:
 */
export const salePlanEditList = ({ customerEnableCode }) => {
    const data = {
        customerEnableCode
    };
    return axios.request({
        url: 'sale/plan/edit/select',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 保存销售计划
 * @param {type} salePlans
 * @return:
 */
export const salePlanUpdate = ({ salePlans }) => {
    const data = {
        salePlans
    };
    return axios.request({
        url: 'sale/plan/update',
        data,
        method: 'post'
    });
};

/**
 * @description: 提交销售计划
 * @param {type} salePlanIds
 * @return:
 */
export const salePlanSubmit = ({ salePlanIds, salePlans }) => {
    const data = {
        salePlanIds,
        salePlans
    };
    return axios.request({
        url: 'sale/plan/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 撤销销售计划
 * @param {type} salePlanIds
 * @return:
 */
export const salePlanReturn = ({ salePlanIds, salePlans }) => {
    const data = {
        salePlanIds,
        salePlans
    };
    return axios.request({
        url: 'sale/plan/revocation',
        data,
        method: 'post'
    });
};
