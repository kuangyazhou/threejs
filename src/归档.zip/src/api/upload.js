import axios from 'axios';
import { getToken, getSSOToken } from '@/libs/util';
import { environmentConfig } from '@/libs/tools';

const BASE_URL = environmentConfig('baseUrl');

/**
 * 上传文件
 * @param files
 * @returns {Promise<any>}
 */
export const uploadFile = files => {
    const token = getToken();
    const ssoToken = getSSOToken();
    const config = {
        headers: {
            'Access-Token-Erp': token,
            'Access-SSOToken-Chain': ssoToken
        }
    };
    return new Promise((resolve, reject) => {
        axios.post(`${BASE_URL}document/upload`, files, config).then(
            response => {
                resolve(response.data);
            },
            err => {
                reject(err);
            }
        );
    });
};

/**
 * 导入文件通用
 * @param formdata
 * @returns {Promise<any>}
 */
export const importFile = (formdata, startUrl) => {
    const token = getToken();
    const ssoToken = getSSOToken();
    const config = {
        headers: {
            'Access-Token': token,
            'Access-SSOToken-Chain': ssoToken
        }
    };
    return new Promise((resolve, reject) => {
        axios.post(`${BASE_URL}${startUrl}/import`, formdata, config).then(
            response => {
                resolve(response.data);
            },
            err => {
                reject(err);
            }
        );
    });
};
