/*
 * @Description: 客户变更接口
 * @Author: kuang
 * @Date: 2019-07-15 10:16:01
 * @LastEditTime: 2019-08-06 09:15:32
 * @LastEditors: Please set LastEditors
 */
import axios from '@/libs/api.request';

/**
 * @description: 客户变更-销售部门
 * @param {type} customerName 客户名称
 * @param {type} uniqueCode 唯一识别码
 * @param {type} pageNo
 * @param {type} pageSize
 * @return:
 */
export const salesChangeList = ({ customerName, uniqueCode, pageNo, pageSize }) => {
    const data = { customerName, uniqueCode, pageNo, pageSize };
    return axios.request({
        url: 'customer/enterprise/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 获取客户变更记录
 * @param {type} status 状态
 * @param {type} customerName 客户名称
 * @return:
 */
export const customerList = ({ status, customerName }) => {
    const data = {
        status,
        customerName
    };
    return axios.request({
        url: 'task/instance/customer/change/create/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 保存客户变更（编辑）
 * @param {type} customerId 变更客户ID
 * @param customerName
 * @param parentId
 * @param id
 * @param customerArea
 * @param customerClassify
 * @param customerType
 * @param contractPaymentMonth
 * @param saleMethod
 * @param saleMode
 * @param saleDepartment
 * @param customerLevel
 * @param unifiedSocialCreditCode
 * @param licenseRegistrationCode
 * @param customerAddress
 * @param dutyParagraph
 * @param bankAccount
 * @param bankName
 * @param bankCode
 * @param bankType
 * @param invoiceDescription
 * @param invoiceAddress
 * @param customerDescription
 * @param warehouseAddress
 * @param isImport 是否引入客户（0否1是）
 * @return:
 */

export const saveChangeData = ({
    customerId,
    customerName,
    parentId,
    id,
    customerArea,
    customerClassify,
    customerType,
    contractPaymentMonth,
    saleMethod,
    saleMode,
    saleDepartment,
    customerLevel,
    unifiedSocialCreditCode,
    licenseRegistrationCode,
    customerAddress,
    dutyParagraph,
    bankAccount,
    bankName,
    bankCode,
    bankType,
    invoiceDescription,
    invoiceAddress,
    customerDescription,
    warehouseAddress,
    isImport
}) => {
    const data = {
        customerId,
        customerName,
        parentId,
        id,
        customerArea,
        customerClassify,
        customerType,
        contractPaymentMonth,
        saleMethod,
        saleMode,
        saleDepartment,
        customerLevel,
        unifiedSocialCreditCode,
        licenseRegistrationCode,
        customerAddress,
        dutyParagraph,
        bankAccount,
        bankName,
        bankCode,
        bankType,
        invoiceDescription,
        invoiceAddress,
        customerDescription,
        warehouseAddress,
        isImport
    };
    return axios.request({
        url: 'task/instance/change/customer/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 审批变更删除
 * @param {type} id
 * @return:
 */
export const auditDel = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'task/instance/change/customer/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 发起变更审批
 * @param {type}  id
 * @return:
 */
export const startAudit = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'task/instance/change/customer/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 获取变更前基础资料
 * @param {type} id
 * @return:
 */
export const oldBaseInfo = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'task/instance/before/customer/change/get',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 获取变更前证照信息
 * @param {type} taskInstanceId
 * @return:
 */
export const oldLicense = ({ taskInstanceId }) => {
    const data = { taskInstanceId };
    return axios.request({
        url: 'customer/license/before/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 变更删除证照
 * @param {type}  id
 * @return:
 */
export const changeDelLicense = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'customer/license/change/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 变更删除证照恢复
 * @param {type}  id
 * @return:
 */
export const changeRevertLicense = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'customer/license/change/revert',
        data,
        method: 'post'
    });
};

/**
 * @description: 变更删除文件
 * @param {type}  id
 * @return:
 */
export const changeDelFile = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'document/change/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 变更假删除文件恢复
 * @param {type} id
 * @return:
 */
export const changeFileRevert = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'document/change/revert',
        data,
        method: 'post'
    });
};

/**
 * @description: 获取变更前收货地址
 * @param {type} taskInstanceId
 * @return:
 */
export const oldAddress = ({ taskInstanceId }) => {
    const data = { taskInstanceId };
    return axios.request({
        url: 'customer/address/before/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 变更删除收货地址
 * @param {type}  id
 * @return:
 */
export const changeDelAddress = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'customer/address/change/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 变更删除收货地址恢复
 * @param {type}  id
 * @return:
 */
export const changeRevertAddress = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'customer/address/change/revert',
        data,
        method: 'post'
    });
};

/**
 * @description: 获取变更前联系人
 * @param {type} taskInstanceId
 * @return:
 */
export const oldContact = ({ taskInstanceId }) => {
    const data = { taskInstanceId };
    return axios.request({
        url: 'customer/contact/before/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 变更删除联系人
 * @param {type}  id
 * @return:
 */
export const changeDelContact = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'customer/contact/change/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 变更删除联系人恢复
 * @param {type}  id
 * @return:
 */
export const changeRevertContact = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'customer/contact/change/revert',
        data,
        method: 'post'
    });
};

/**
 * @description: 客户变更申请打回
 * @param {type}  id
 * @return:
 */
export const changeBackUp = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'task/instance/change/customer/return',
        data,
        method: 'post'
    });
};

/**
 * @description: 变更申请审批通过
 * @param {type} id
 * @return:
 */
export const changeAuditPass = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'task/instance/change/customer/approve',
        data,
        method: 'post'
    });
};

/**
 * @description: 获取变更前物料类型
 * @param {type} taskInstanceId
 * @return:
 */
export const oldMaterial = ({ taskInstanceId }) => {
    const data = { taskInstanceId };
    return axios.request({
        url: 'customer/commodity/type/before/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 获取变更前器械分类
 * @param {type} taskInstanceId
 * @return:
 */
export const oldMachineclass = ({ taskInstanceId }) => {
    const data = { taskInstanceId };
    return axios.request({
        url: 'customer/device/classify/before/task/list',
        params: data,
        method: 'get'
    });
};
