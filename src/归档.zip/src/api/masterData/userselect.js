/*
 * @Description: 客户查询接口
 * @Author: kuang
 * @Date: 2019-07-15 10:16:01
 * @LastEditTime: 2019-07-26 16:12:13
 * @LastEditors: Please set LastEditors
 */
import axios from '@/libs/api.request';

/**
 * @description: 客户查询-公司
 * @param {type} customerName 客户名称
 * @param {type} enterpriseName 公司名称
 * @param {type} customerAreaName 客户区域
 * @param {type} customerClassifyIds 客户分类
 * @param {type} customerTypeIds 客户类型
 * @param {type} customerCode 客户编码
 * @param {type} pageNo
 * @param {type} pageSize
 * @return:
 */
export const getCompanyUser = ({
    enterpriseName,
    customerName,
    customerAreaName,
    customerClassifyIds,
    customerTypeIds,
    customerCode,
    pageNo,
    pageSize
}) => {
    const data = {
        enterpriseName,
        customerName,
        customerAreaName,
        customerClassifyIds,
        customerCode,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'customer/enterprise/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 客户查询-集团
 * @param {type} customerName 客户名称
 * @param {type} customerArea 客户区域
 * @param {type} customerClassifyIds 客户分类
 * @param {type} customerTypeIds 客户类型
 * @return:
 */
export const getGroupUser = ({
    customerName,
    customerArea,
    customerClassifyIds,
    customerTypeIds
}) => {
    const data = {
        customerName,
        customerArea,
        customerClassifyIds,
        customerTypeIds
    };
    return axios.request({
        url: 'customer/organization/list',
        params: data,
        method: 'get'
    });
};
