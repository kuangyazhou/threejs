import axios from '@/libs/api.request';

/**
 * 查询供应商证照类型列表
 * @param organizationId
 * @param supplierTypeName  供应商种类
 * @param supplierCategoryName  供应商类别
 * @returns {*|never}
 */
export const getSupplierCardList = ({
    organizationId,
    supplierTypeName,
    supplierCategoryName
}) => {
    const data = {
        organizationId,
        supplierTypeName,
        supplierCategoryName
    };
    return axios.request({
        url: 'supplier/type/category/list',
        params: data,
        method: 'get'
    });
};

/**
 * 编辑客户证照类别
 * @param supplierType
 * @param licenses
 * @param supplierCategory
 * @returns {*|never}
 */
export const editCustomerCard = ({
    supplierType,
    licenses,
    supplierCategory
}) => {
    const data = {
        supplierType,
        licenses,
        supplierCategory
    };
    return axios.request({
        url: 'supplier/type/category/updateTypeCategoryLicense',
        data,
        method: 'post'
    });
};

/**
 * 获取供应商新增列表
 * @param pageNo
 * @param pageSize
 * @param taskStatus
 * @param specialtyGroup
 * @param supplierName
 * @returns {*|never}
 */
export const getSupplierCreateList = ({
    pageNo,
    pageSize,
    taskStatus,
    specialtyGroup,
    supplierName
}) => {
    const data = {
        pageNo,
        pageSize,
        specialtyGroup,
        taskStatus,
        supplierName
    };
    return axios.request({
        url: 'supplier/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取已存在的专业分组
 * @returns {*|never}
 */
export const getSpecialtyGroupList = () => {
    const data = {};
    return axios.request({
        url: 'supplier/task/listSpecialtyGroup',
        params: data,
        method: 'get'
    });
};

/**
 * 获取已填写的银行列表
 * @param bankName
 * @returns {*|never}
 */
export const getBankList = ({ bankName }) => {
    const data = { bankName };
    return axios.request({
        url: 'supplier/bank/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增供应商证照
 * @param taskInstanceId
 * @param expiryDateStr
 * @param licenseCode 证照编号
 * @param dataType
 * @param records 上传文件记录
 * @returns {*|never}
 */
export const addSupplierLicense = ({
    taskInstanceId,
    expiryDateStr,
    licenseCode,
    dataType,
    records
}) => {
    const data = {
        taskInstanceId,
        expiryDateStr,
        licenseCode,
        dataType,
        records
    };
    return axios.request({
        url: 'supplier/license/save',
        data,
        method: 'post'
    });
};

/**
 * 获取供应商资料类型列表
 * @param taskInstanceId
 * @returns {*|never}
 */
export const getSupplierDataTypeList = ({ taskInstanceId }) => {
    const data = { taskInstanceId };
    return axios.request({
        url: 'supplier/type/category/license/task/list/license',
        params: data,
        method: 'get'
    });
};

/**
 * 获取供应商证照列表
 * @param taskInstanceId
 * @param dataType
 * @returns {*|never}
 */
export const getSupplierLicenseList = ({ taskInstanceId, dataType }) => {
    const data = { taskInstanceId, dataType };
    return axios.request({
        url: 'supplier/license/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取证照文件url
 * @param taskInstanceId
 * @param dataType
 * @param documentId
 * @returns {*|never}
 */
export const getSupplierLicenseFile = ({
    taskInstanceId,
    dataType,
    documentId
}) => {
    const data = { taskInstanceId, dataType, documentId };
    return axios.request({
        url: 'supplier/task/url/list',
        params: data,
        method: 'get'
    });
};

/**
 * 编辑供应商证照
 * @param taskInstanceId
 * @param expiryDateStr
 * @param licenseCode
 * @param dataType
 * @param records
 * @param id
 * @param documentId  文件对象ID
 * @param status 状态：3-有效，4-无效
 * @returns {*|never}
 */
export const editSupplierLicense = ({
    taskInstanceId,
    expiryDateStr,
    licenseCode,
    dataType,
    records,
    id,
    documentId,
    status
}) => {
    const data = {
        taskInstanceId,
        expiryDateStr,
        licenseCode,
        dataType,
        records,
        id,
        documentId,
        status
    };
    return axios.request({
        url: 'supplier/license/update',
        data,
        method: 'post'
    });
};

/**
 * 删除供应商资料
 * @param id
 * @returns {*|never}
 */
export const delSupplierLicense = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'supplier/license/delete',
        data,
        method: 'post'
    });
};

/**
 * 保存器械生产信息
 * @param taskInstanceId
 * @param deviceClassifyList
 * @returns {*|never}
 */
export const saveSupplierProductionInfo = ({
    taskInstanceId,
    deviceClassifyList
}) => {
    const data = {
        taskInstanceId,
        deviceClassifyList
    };
    return axios.request({
        url: 'supplier/production/device/classify/save',
        data,
        method: 'post'
    });
};

/**
 * 保存器械运营信息
 * @param taskInstanceId
 * @param deviceClassifyList
 * @returns {*|never}
 */
export const saveSupplierManagementInfo = ({
    taskInstanceId,
    deviceClassifyList
}) => {
    const data = {
        taskInstanceId,
        deviceClassifyList
    };
    return axios.request({
        url: 'supplier/manage/device/classify/save',
        data,
        method: 'post'
    });
};

/**
 * 获取已保存的器械生产信息列表
 * @param taskInstanceId
 * @returns {*|never}
 */
export const getSupplierProductionInfoList = ({ taskInstanceId }) => {
    const data = { taskInstanceId };
    return axios.request({
        url: 'supplier/production/device/classify/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取变更前已保存的器械生产信息列表
 * @param taskInstanceId
 * @returns {*|never}
 */
export const getOldSupplierProductionInfoList = ({ taskInstanceId }) => {
    const data = { taskInstanceId };
    return axios.request({
        url: 'supplier/change/before/change/list/production',
        params: data,
        method: 'get'
    });
};

/**
 * 获取已保存的器械运营信息列表
 * @param taskInstanceId
 * @returns {*|never}
 */
export const getSupplierManagementInfoList = ({ taskInstanceId }) => {
    const data = { taskInstanceId };
    return axios.request({
        url: 'supplier/manage/device/classify/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取变更前已保存的器械运营信息列表
 * @param taskInstanceId
 * @returns {*|never}
 */
export const getOldSupplierManagementInfoList = ({ taskInstanceId }) => {
    const data = { taskInstanceId };
    return axios.request({
        url: 'supplier/change/before/change/list/manage',
        params: data,
        method: 'get'
    });
};

/**
 * 获取联系人列表
 * @param taskInstanceId
 * @returns {*|never}
 */
export const getSupplierContactList = ({ taskInstanceId }) => {
    const data = { taskInstanceId };
    return axios.request({
        url: 'supplier/contact/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取变更前联系人列表
 * @param taskInstanceId
 * @returns {*|never}
 */
export const getOldSupplierContactList = ({ taskInstanceId }) => {
    const data = { taskInstanceId };
    return axios.request({
        url: 'supplier/change/before/change/list/contact',
        params: data,
        method: 'get'
    });
};

/**
 * 新增联系人
 * @param taskInstanceId
 * @param contactName
 * @param contactJob
 * @param contactPhone
 * @param contactDepartment
 * @returns {*|never}
 */
export const addSupplierContact = ({
    taskInstanceId,
    contactName,
    contactJob,
    contactPhone,
    contactDepartment
}) => {
    const data = {
        taskInstanceId,
        contactName,
        contactJob,
        contactPhone,
        contactDepartment
    };
    return axios.request({
        url: 'supplier/contact/save',
        data,
        method: 'post'
    });
};

/**
 * 修改联系人
 * @param id
 * @param contactName
 * @param contactJob
 * @param contactPhone
 * @param contactDepartment
 * @returns {*|never}
 */
export const editSupplierContact = ({
    id,
    contactName,
    contactJob,
    contactPhone,
    contactDepartment
}) => {
    const data = {
        id,
        contactName,
        contactJob,
        contactPhone,
        contactDepartment
    };
    return axios.request({
        url: 'supplier/contact/update',
        data,
        method: 'post'
    });
};

/**
 * 删除联系人
 * @param id
 * @returns {*|never}
 */
export const delSupplierContact = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'supplier/contact/delete',
        data,
        method: 'post'
    });
};

/**
 * 假删除原有联系人
 * @param id
 * @returns {*|never}
 */
export const delOldSupplierContact = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'supplier/change/contact/delete',
        data,
        method: 'post'
    });
};

/**
 * 假删除原有联系人
 * @param id
 * @returns {*|never}
 */
export const revertOldSupplierContact = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'supplier/change/contact/revert',
        data,
        method: 'post'
    });
};

/**
 * 获取供应商列表
 * @param supplierName
 * @param pageNo
 * @param pageSize
 * @param unifiedSocialCreditCode
 * @param type 0引入供应商弹窗，1子供应商弹窗
 * @returns {*|never}
 */
export const getSelectSupplierList = (
    { supplierName, pageNo, pageSize, unifiedSocialCreditCode },
    type
) => {
    const data = { supplierName, pageNo, pageSize, unifiedSocialCreditCode };
    return axios.request({
        url: type ? 'supplier/select/list' : 'supplier/import/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增供应商新增单
 * @param supplierName
 * @param supplierAbbreviation 供应商简称
 * @param supplierClassify 供应商分类
 * @param supplierNature 供应商性质
 * @param supplierLevel 供应商等级
 * @param unifiedSocialCreditCode 统一社会信用社代码
 * @param parentId
 * @param supplierAddress
 * @param warehouseAddress
 * @param supplierType 供应商种类
 * @param supplierCategory 供应商类别
 * @param specialtyGroup 专业分组
 * @param payCondition 付款条件
 * @param negotiator 谈判人员
 * @param bankName
 * @param bankAccount
 * @param bankCode
 * @param mainBrand 主营品牌
 * @param supplierDescription 备注
 * @param isImport 0-否，1-引入供应商
 * @param supplierId
 * @returns {*|never}
 */
export const addSupplierApply = ({
    supplierName,
    supplierAbbreviation,
    supplierClassify,
    supplierNature,
    supplierLevel,
    unifiedSocialCreditCode,
    parentId,
    supplierAddress,
    warehouseAddress,
    supplierType,
    supplierCategory,
    specialtyGroup,
    payCondition,
    negotiator,
    bankName,
    bankAccount,
    bankCode,
    mainBrand,
    supplierDescription,
    isImport,
    supplierId
}) => {
    const data = {
        supplierName,
        supplierAbbreviation,
        supplierClassify,
        supplierNature,
        supplierLevel,
        unifiedSocialCreditCode,
        parentId,
        supplierAddress,
        warehouseAddress,
        supplierType,
        supplierCategory,
        specialtyGroup,
        payCondition,
        negotiator,
        bankName,
        bankAccount,
        bankCode,
        mainBrand,
        supplierDescription,
        isImport,
        supplierId
    };
    return axios.request({
        url: 'supplier/task/save',
        data,
        method: 'post'
    });
};

/**
 * 编辑供应商新增单
 * @param supplierName
 * @param supplierAbbreviation
 * @param supplierClassify
 * @param supplierNature
 * @param supplierLevel
 * @param unifiedSocialCreditCode
 * @param parentId
 * @param supplierAddress
 * @param warehouseAddress
 * @param supplierType
 * @param supplierCategory
 * @param specialtyGroup
 * @param payCondition
 * @param negotiator
 * @param bankName
 * @param bankAccount
 * @param bankCode
 * @param mainBrand
 * @param supplierDescription
 * @param isImport
 * @param supplierId
 * @param id
 * @returns {*|never}
 */
export const editSupplierApply = ({
    supplierName,
    supplierAbbreviation,
    supplierClassify,
    supplierNature,
    supplierLevel,
    unifiedSocialCreditCode,
    parentId,
    supplierAddress,
    warehouseAddress,
    supplierType,
    supplierCategory,
    specialtyGroup,
    payCondition,
    negotiator,
    bankName,
    bankAccount,
    bankCode,
    mainBrand,
    supplierDescription,
    isImport,
    supplierId,
    id
}) => {
    const data = {
        supplierName,
        supplierAbbreviation,
        supplierClassify,
        supplierNature,
        supplierLevel,
        unifiedSocialCreditCode,
        parentId,
        supplierAddress,
        warehouseAddress,
        supplierType,
        supplierCategory,
        specialtyGroup,
        payCondition,
        negotiator,
        bankName,
        bankAccount,
        bankCode,
        mainBrand,
        supplierDescription,
        isImport,
        supplierId,
        id
    };
    return axios.request({
        url: 'supplier/task/update',
        data,
        method: 'post'
    });
};

/**
 * 提交新增供应商申请
 * @param taskInstanceId
 * @returns {*|never}
 */
export const addSuppliersApply = ({ taskInstanceId }) => {
    const data = {
        taskInstanceId
    };
    return axios.request({
        url: 'supplier/task/submit/approve',
        data,
        method: 'post'
    });
};

/**
 * 删除新增供应商申请
 * @param taskInstanceId
 * @returns {*|never}
 */
export const delSuppliersApply = ({ taskInstanceId }) => {
    const data = {
        taskInstanceId
    };
    return axios.request({
        url: 'supplier/task/delete',
        data,
        method: 'post'
    });
};

/**
 * 获取供应商变更单列表
 * @param pageNo
 * @param pageSize
 * @param supplierName
 * @returns {*|never}
 */
export const getSupplierChangeList = ({ pageNo, pageSize, supplierName }) => {
    const data = {
        pageNo,
        pageSize,
        supplierName
    };
    return axios.request({
        url: 'supplier/purchase/change/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取可以变更信息的供应商列表
 * @param pageNo
 * @param pageSize
 * @param supplierName
 * @param unifiedSocialCreditCode
 * @returns {*|never}
 */
export const getCanChangeSupplierList = ({
    pageNo,
    pageSize,
    supplierName,
    unifiedSocialCreditCode
}) => {
    const data = {
        pageNo,
        pageSize,
        supplierName,
        unifiedSocialCreditCode
    };
    return axios.request({
        url: 'supplier/purchase/change/select/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取供应商变更前的基本数据
 * @param id
 * @returns {*|never}
 */
export const getOldSupplierData = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'supplier/change/before/change/supplier',
        params: data,
        method: 'get'
    });
};

/**
 * 新增供应商变更单
 * @param supplierName
 * @param supplierAbbreviation
 * @param supplierClassify
 * @param supplierNature
 * @param supplierLevel
 * @param unifiedSocialCreditCode
 * @param parentId
 * @param supplierAddress
 * @param warehouseAddress
 * @param supplierType
 * @param supplierCategory
 * @param specialtyGroup
 * @param payCondition
 * @param negotiator
 * @param bankName
 * @param bankAccount
 * @param bankCode
 * @param mainBrand
 * @param supplierDescription
 * @param isImport
 * @param supplierId
 * @returns {*|never}
 */
export const addSupplierChange = ({
    supplierName,
    supplierAbbreviation,
    supplierClassify,
    supplierNature,
    supplierLevel,
    unifiedSocialCreditCode,
    parentId,
    supplierAddress,
    warehouseAddress,
    supplierType,
    supplierCategory,
    specialtyGroup,
    payCondition,
    negotiator,
    bankName,
    bankAccount,
    bankCode,
    mainBrand,
    supplierDescription,
    isImport,
    supplierId
}) => {
    const data = {
        supplierName,
        supplierAbbreviation,
        supplierClassify,
        supplierNature,
        supplierLevel,
        unifiedSocialCreditCode,
        parentId,
        supplierAddress,
        warehouseAddress,
        supplierType,
        supplierCategory,
        specialtyGroup,
        payCondition,
        negotiator,
        bankName,
        bankAccount,
        bankCode,
        mainBrand,
        supplierDescription,
        isImport,
        supplierId
    };
    return axios.request({
        url: 'supplier/purchase/change/task/save',
        data,
        method: 'post'
    });
};

/**
 * 编辑供应商变更单
 * @param supplierName
 * @param supplierAbbreviation
 * @param supplierClassify
 * @param supplierNature
 * @param supplierLevel
 * @param unifiedSocialCreditCode
 * @param parentId
 * @param supplierAddress
 * @param warehouseAddress
 * @param supplierType
 * @param supplierCategory
 * @param specialtyGroup
 * @param payCondition
 * @param negotiator
 * @param bankName
 * @param bankAccount
 * @param bankCode
 * @param mainBrand
 * @param supplierDescription
 * @param isImport
 * @param supplierId
 * @param id
 * @returns {*|never}
 */
export const editSupplierChange = ({
    supplierName,
    supplierAbbreviation,
    supplierClassify,
    supplierNature,
    supplierLevel,
    unifiedSocialCreditCode,
    parentId,
    supplierAddress,
    warehouseAddress,
    supplierType,
    supplierCategory,
    specialtyGroup,
    payCondition,
    negotiator,
    bankName,
    bankAccount,
    bankCode,
    mainBrand,
    supplierDescription,
    isImport,
    supplierId,
    id
}) => {
    const data = {
        supplierName,
        supplierAbbreviation,
        supplierClassify,
        supplierNature,
        supplierLevel,
        unifiedSocialCreditCode,
        parentId,
        supplierAddress,
        warehouseAddress,
        supplierType,
        supplierCategory,
        specialtyGroup,
        payCondition,
        negotiator,
        bankName,
        bankAccount,
        bankCode,
        mainBrand,
        supplierDescription,
        isImport,
        supplierId,
        id
    };
    return axios.request({
        url: 'supplier/purchase/change/task/update',
        data,
        method: 'post'
    });
};

/**
 * 获取变更前供应商证照列表
 * @param taskInstanceId
 * @param dataType
 * @returns {*|never}
 */
export const getOldSupplierLicenseList = ({ taskInstanceId, dataType }) => {
    const data = { taskInstanceId, dataType };
    return axios.request({
        url: 'supplier/change/before/change/license/list',
        params: data,
        method: 'get'
    });
};

/**
 * 删除已存在的供应商资料
 * @param id
 * @returns {*|never}
 */
export const delOldSupplierLicense = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'supplier/change/delete/license',
        data,
        method: 'post'
    });
};

/**
 * 删除已存在的供应商资料
 * @param id
 * @returns {*|never}
 */
export const revertOldSupplierLicense = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'supplier/change/revert/license',
        data,
        method: 'post'
    });
};

/**
 * 提交供应商变更单申请
 * @param taskInstanceId
 * @returns {*|never}
 */
export const editSuppliersApply = ({ taskInstanceId }) => {
    const data = {
        taskInstanceId
    };
    return axios.request({
        url: 'supplier/purchase/change/submit',
        data,
        method: 'post'
    });
};

/**
 * 删除供应商变更单
 * @param taskInstanceId
 * @returns {*|never}
 */
export const delSuppliersChangeApply = ({ taskInstanceId }) => {
    const data = {
        taskInstanceId
    };
    return axios.request({
        url: 'supplier/purchase/change/task/delete',
        data,
        method: 'post'
    });
};

/**
 * 获取质管供应商变更单列表
 * @param pageNo
 * @param pageSize
 * @param supplierName
 * @returns {*|never}
 */
export const getSupplierQcChangeList = ({ pageNo, pageSize, supplierName }) => {
    const data = {
        pageNo,
        pageSize,
        supplierName
    };
    return axios.request({
        url: 'supplier/qc/change/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增质管供应商变更单
 * @param supplierName
 * @param supplierAbbreviation
 * @param supplierClassify
 * @param supplierNature
 * @param supplierLevel
 * @param unifiedSocialCreditCode
 * @param parentId
 * @param supplierAddress
 * @param warehouseAddress
 * @param supplierType
 * @param supplierCategory
 * @param specialtyGroup
 * @param payCondition
 * @param negotiator
 * @param bankName
 * @param bankAccount
 * @param bankCode
 * @param mainBrand
 * @param supplierDescription
 * @param isImport
 * @param supplierId
 * @param supplierStatus
 * @returns {*|never}
 */
export const addQcSupplierChange = ({
    supplierName,
    supplierAbbreviation,
    supplierClassify,
    supplierNature,
    supplierLevel,
    unifiedSocialCreditCode,
    parentId,
    supplierAddress,
    warehouseAddress,
    supplierType,
    supplierCategory,
    specialtyGroup,
    payCondition,
    negotiator,
    bankName,
    bankAccount,
    bankCode,
    mainBrand,
    supplierDescription,
    isImport,
    supplierId,
    supplierStatus
}) => {
    const data = {
        supplierName,
        supplierAbbreviation,
        supplierClassify,
        supplierNature,
        supplierLevel,
        unifiedSocialCreditCode,
        parentId,
        supplierAddress,
        warehouseAddress,
        supplierType,
        supplierCategory,
        specialtyGroup,
        payCondition,
        negotiator,
        bankName,
        bankAccount,
        bankCode,
        mainBrand,
        supplierDescription,
        isImport,
        supplierId,
        supplierStatus
    };
    return axios.request({
        url: 'supplier/qc/change/task/save',
        data,
        method: 'post'
    });
};
/**
 * 编辑质管供应商变更单
 * @param supplierName
 * @param supplierAbbreviation
 * @param supplierClassify
 * @param supplierNature
 * @param supplierLevel
 * @param unifiedSocialCreditCode
 * @param parentId
 * @param supplierAddress
 * @param warehouseAddress
 * @param supplierType
 * @param supplierCategory
 * @param specialtyGroup
 * @param payCondition
 * @param negotiator
 * @param bankName
 * @param bankAccount
 * @param bankCode
 * @param mainBrand
 * @param supplierDescription
 * @param isImport
 * @param supplierId
 * @param supplierStatus
 * @param id
 * @returns {*|never}
 */
export const editQcSupplierChange = ({
    supplierName,
    supplierAbbreviation,
    supplierClassify,
    supplierNature,
    supplierLevel,
    unifiedSocialCreditCode,
    parentId,
    supplierAddress,
    warehouseAddress,
    supplierType,
    supplierCategory,
    specialtyGroup,
    payCondition,
    negotiator,
    bankName,
    bankAccount,
    bankCode,
    mainBrand,
    supplierDescription,
    isImport,
    supplierId,
    supplierStatus,
    id
}) => {
    const data = {
        supplierName,
        supplierAbbreviation,
        supplierClassify,
        supplierNature,
        supplierLevel,
        unifiedSocialCreditCode,
        parentId,
        supplierAddress,
        warehouseAddress,
        supplierType,
        supplierCategory,
        specialtyGroup,
        payCondition,
        negotiator,
        bankName,
        bankAccount,
        bankCode,
        mainBrand,
        supplierDescription,
        isImport,
        supplierId,
        supplierStatus,
        id
    };
    return axios.request({
        url: 'supplier/qc/change/task/update',
        data,
        method: 'post'
    });
};

/**
 * 提交供应商变更单申请
 * @param taskInstanceId
 * @returns {*|never}
 */
export const editQcSuppliersApply = ({ taskInstanceId }) => {
    const data = {
        taskInstanceId
    };
    return axios.request({
        url: 'supplier/qc/change/submit',
        data,
        method: 'post'
    });
};

/**
 * 删除供应商变更单
 * @param taskInstanceId
 * @returns {*|never}
 */
export const delQcSuppliersChangeApply = ({ taskInstanceId }) => {
    const data = {
        taskInstanceId
    };
    return axios.request({
        url: 'supplier/qc/change/task/delete',
        data,
        method: 'post'
    });
};

/**
 * 采购审核通过变更单
 * @param taskInstanceId
 * @returns {*|never}
 */
export const editSuppliersApprove = ({ taskInstanceId }) => {
    const data = {
        taskInstanceId
    };
    return axios.request({
        url: 'supplier/purchase/change/approve',
        data,
        method: 'post'
    });
};

/**
 * 质管审核通过变更单
 * @param taskInstanceId
 * @returns {*|never}
 */
export const editQcSuppliersApprove = ({ taskInstanceId }) => {
    const data = {
        taskInstanceId
    };
    return axios.request({
        url: 'supplier/qc/change/approve',
        data,
        method: 'post'
    });
};
