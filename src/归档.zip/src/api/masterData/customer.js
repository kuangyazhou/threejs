/*
 * @Description: 新增客户接口
 * @Author: kuang
 * @Date: 2019-07-08 14:24:01
 * @LastEditTime: 2019-08-01 10:37:27
 * @LastEditors: Please set LastEditors
 */
import axios from '@/libs/api.request';

/**
 * 查询集团客户证照类别
 * @param organizationId
 * @param customerType
 * @returns {*|never}
 */
export const getCustomerCardList = ({ organizationId, customerType }) => {
    const data = {
        organizationId,
        customerType
    };
    return axios.request({
        url: 'license/type/list',
        params: data,
        method: 'get'
    });
};

/**
 * 编辑客户证照类别
 * @param customerTypeId
 * @param organizationId
 * @param LicenseTypes
 * @returns {*|never}
 */
export const editCustomerCard = ({
    customerTypeId,
    organizationId,
    LicenseTypes
}) => {
    const data = {
        customerTypeId,
        organizationId,
        LicenseTypes
    };
    return axios.request({
        url: 'license/type/update',
        data,
        method: 'post'
    });
};

/**
 * 获取客户申请单列表
 * @param pageNo
 * @param pageSize
 * @param status
 * @param customerName
 * @returns {*|never}
 */
export const getCustomerCreateList = ({
    pageNo,
    pageSize,
    status,
    customerName
}) => {
    const data = {
        pageNo,
        pageSize,
        customerName,
        status
    };
    return axios.request({
        url: 'task/instance/customer/save/create/list',
        params: data,
        method: 'get'
    });
};

/**
 *  新增临时用户、编辑基本信息
 * @param customerName
 * @param parentId
 * @param id
 * @param customerArea
 * @param customerClassify
 * @param customerType
 * @param contractPaymentMonth
 * @param saleMethod
 * @param saleMode
 * @param saleDepartment
 * @param customerLevel
 * @param unifiedSocialCreditCode
 * @param licenseRegistrationCode
 * @param customerAddress
 * @param dutyParagraph
 * @param bankAccount
 * @param bankName
 * @param bankCode
 * @param bankType
 * @param invoiceDescription
 * @param invoiceAddress
 * @param customerDescription
 * @param warehouseAddress
 * @param isImport 是否引入客户（0否1是）
 * @param customerId 引入客户的ID
 * @returns {*|never}
 */
export const saveCustomerInfo = ({
    customerName,
    parentId,
    id,
    customerArea,
    customerClassify,
    customerType,
    contractPaymentMonth,
    saleMethod,
    saleMode,
    saleDepartment,
    customerLevel,
    unifiedSocialCreditCode,
    licenseRegistrationCode,
    customerAddress,
    dutyParagraph,
    bankAccount,
    bankName,
    bankCode,
    bankType,
    invoiceDescription,
    invoiceAddress,
    customerDescription,
    warehouseAddress,
    isImport,
    customerId
}) => {
    const data = {
        customerName,
        parentId,
        id,
        customerArea,
        customerClassify,
        customerType,
        contractPaymentMonth,
        saleMethod,
        saleMode,
        saleDepartment,
        customerLevel,
        unifiedSocialCreditCode,
        licenseRegistrationCode,
        customerAddress,
        dutyParagraph,
        bankAccount,
        bankName,
        bankCode,
        bankType,
        invoiceDescription,
        invoiceAddress,
        customerDescription,
        warehouseAddress,
        isImport,
        customerId
    };
    return axios.request({
        url: 'task/instance/customer/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 保存客户物料类型
 * @param {type} taskInstanceId 任务实例ID
 * @param {type} commodityTypeList 物料类型ID （系统字典
 * @return:
 */
export const saveMaterialType = ({ taskInstanceId, commodityTypeList }) => {
    const data = {
        taskInstanceId,
        commodityTypeList
    };
    return axios.request({
        url: 'customer/commodity/type/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 获取客户选中的物料类型
 * @param {type} taskInstanceId 任务实例ID
 * @return:
 */

export const getSelectMaterial = ({ taskInstanceId }) => {
    const data = {
        taskInstanceId
    };
    return axios.request({
        url: 'customer/commodity/type/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 保存客户器械分类
 * @param {type} taskInstanceId 任务实例ID
 * @param {type} deviceClassifyList 器械分类ID （用户所在公司的器械分类中选择）
 * @return:
 */
export const saveSelectMachine = ({ taskInstanceId, deviceClassifyList }) => {
    const data = {
        taskInstanceId,
        deviceClassifyList
    };
    return axios.request({
        url: 'customer/device/classify/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 获取客户选中器械分类
 * @param {type} taskInstanceId 任务实例ID
 * @return:
 */
export const getSelectMachine = ({ taskInstanceId }) => {
    const data = {
        taskInstanceId
    };
    return axios.request({
        url: 'customer/device/classify/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 获取银行列表
 * @param {type} bankName 银行名称
 * @return:
 */
export const getBankList = ({ bankName }) => {
    const data = {
        bankName
    };
    return axios.request({
        url: 'bank/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 获取资料类型列表
 * @param {type} taskInstanceId 任务实例ID
 * @return:
 */
export const getInfoType = ({ taskInstanceId }) => {
    const data = {
        taskInstanceId
    };
    return axios.request({
        url: 'customer/license/type/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 新增客户证照
 * @param {type} taskInstanceId 任务实例ID
 * @param {type} expiryDateStr 有效期（yyyy-MM-dd）
 * @param {type} licenseCode 证照编号
 * @param {type} dataType 资料类型
 * @param {Array} records 上传文件记录
 * @param {type} documentName 文件名
 * @param {type} documentUrl 文件url
 * @param {type} ducumentHash 文件hash
 * @return:
 */
export const addCustomerLicense = ({
    taskInstanceId,
    expiryDateStr,
    licenseCode,
    dataType,
    records
}) => {
    const data = {
        taskInstanceId,
        expiryDateStr,
        licenseCode,
        dataType,
        records
    };
    return axios.request({
        url: 'customer/license/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 客户证照列表
 * @param {type} taskInstanceId 任务实例ID
 * @param {type} dataType 特料类型
 * @return:
 */
export const getCustomerLicense = ({ taskInstanceId, dataType = null }) => {
    const data = {
        taskInstanceId,
        dataType
    };
    return axios.request({
        url: 'customer/license/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 删除客户证照列表
 * @param {type} taskInstanceId 任务实例ID
 * @return:
 */
export const delCustomerLicense = ({ id, isChange }) => {
    const data = {
        id
    };
    return axios.request({
        url: isChange
            ? 'customer/license/change/delete' : 'customer/license/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 编辑客户证照
 * @param {type} id 证照ID
 * @param {type} taskInstanceId 单据实例ID
 * @param {type} expiryDateStr 有效日期(yyyy-MM-dd)
 * @param {type} licenseCode 证照编号
 * @param {type} dataType 资料类型
 * @param {type} records 上传文件记录
 * @param {type} documentId 文件对象ID
 * @return:
 */
export const saveCustomerLicense = ({
    id,
    taskInstanceId,
    expiryDateStr,
    licenseCode,
    dataType,
    records,
    documentId
}) => {
    const data = {
        id,
        taskInstanceId,
        expiryDateStr,
        licenseCode,
        dataType,
        records,
        documentId
    };
    return axios.request({
        url: 'customer/license/update',
        data,
        method: 'post'
    });
};

/**
 * @description: 获取文件列表
 * @param documentId 文件对象ID
 * @return:
 */
export const getRecordList = ({ documentId }) => {
    const data = {
        documentId
    };
    return axios.request({
        url: 'document/record/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 文件删除
 * @param {type} id 文件记录ID
 * @return:
 */
export const delRecord = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'document/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 新增收货地址
 * @param {type}  taskInstanceId 任务实例ID
 * @param {type}  receiveAddress 收货地址
 * @param {type}  receiveName 收货人姓名
 * @param {type}  receivePhone 收货人电话
 * @param {type}  identificationCode 识别码
 * @param {type}  remark 备注
 * @return:
 */
export const addAddress = ({
    taskInstanceId,
    receiveAddress,
    receiveName,
    receivePhone,
    identificationCode,
    remark
}) => {
    const data = {
        taskInstanceId,
        receiveAddress,
        receiveName,
        receivePhone,
        identificationCode,
        remark
    };
    return axios.request({
        url: 'customer/address/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 修改收货地址
 * @param {type} id 收货地址ID
 * @param {type} receiveAddress 收货地址
 * @param {type} receiveName 收货人姓名
 * @param {type} eceivePhone 收货人电话
 * @param {type}  identificationCode 识别码
 * @param {type} remark 备注
 * @return:
 */
export const updateAddress = ({
    id,
    receiveAddress,
    receiveName,
    receivePhone,
    remark,
    identificationCode
}) => {
    const data = {
        id,
        receiveAddress,
        receiveName,
        receivePhone,
        remark,
        identificationCode
    };
    return axios.request({
        url: 'customer/address/update',
        data,
        method: 'post'
    });
};

/**
 * @description: 客户收货地址列表
 * @param taskInstanceId 任务实例ID
 * @return:
 */
export const getUserAddress = ({ taskInstanceId }) => {
    const data = {
        taskInstanceId
    };
    return axios.request({
        url: 'customer/address/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 删除客户收货地址
 * @param id 收货地址ID
 * @return:
 */
export const delAddress = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'customer/address/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 设置默认收货地址
 * @param id 收货地址ID
 * @return:
 */
export const setDefaultAddress = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'customer/address/default/set',
        data,
        method: 'post'
    });
};

/**
 * @description: 新增客户联系人
 * @param taskInstanceId 任务实例ID
 * @param contactName 联系人
 * @param contactJob 职位
 * @param contactPhone 电话
 * @param contactDepartment 部门
 * @return:
 */
export const addContact = ({
    taskInstanceId,
    contactName,
    contactJob,
    contactPhone,
    contactDepartment
}) => {
    const data = {
        taskInstanceId,
        contactName,
        contactJob,
        contactPhone,
        contactDepartment
    };
    return axios.request({
        url: 'customer/contact/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 客户联系人列表
 * @param {type} taskInstanceId 实例任务ID
 * @return:
 */
export const getContactList = ({ taskInstanceId }) => {
    const data = { taskInstanceId };
    return axios.request({
        url: 'customer/contact/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 修改客户联系人
 * @param {type} id 联系人ID
 * @param {type} contactName 姓名
 * @param {type} contactJob 职务
 * @param {type} contactPhone 电话
 * @param {type} contactDepartment 部门
 * @return:
 */
export const updateContact = ({
    id,
    contactName,
    contactJob,
    contactPhone,
    contactDepartment
}) => {
    const data = {
        id,
        contactName,
        contactJob,
        contactPhone,
        contactDepartment
    };
    return axios.request({
        url: 'customer/contact/update',
        data,
        method: 'post'
    });
};

/**
 * @description: 删除客户联系人
 * @param id 客户联系人id
 * @return:
 */
export const delContact = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'customer/contact/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 提交客管审核
 * @param {type} id 任务实例id
 * @return:
 */
export const submitCustomerManage = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'task/instance/customer/temp/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 提交质管专员审核
 * @param {type} id 任务实例id
 * @return:
 */
export const submitQualitySpecial = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'task/instance/customer/qualification/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 置为无效
 * @param {type} id 任务实例id
 * @return:
 */
export const setInvalid = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'task/instance/customer/disable/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 重新启用
 * @param {type} id 任务实例id
 * @return:
 */
export const reStart = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'task/instance/customer/enable/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 退回
 * @param {type} id 任务实例ID
 * @return:
 */
export const back = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'task/instance/customer/return/submit',
        data,
        method: 'post'
    });
};

/**
 * 获取弹窗客户列表
 * @param customerName
 * @param uniqueCode
 * @param pageNo
 * @param pageSize
 * @param type
 * @returns {*|never}
 */
export const getCustomerSelect = ({ customerName, uniqueCode, pageNo, pageSize },
                                  type
) => {
    const data = { customerName, uniqueCode, pageNo, pageSize };
    return axios.request({
        url: type ? 'customer/select/list' : 'customer/import/select/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 提交质管经理审核
 * @param {type} id 任务实例id
 * @return:
 */
export const submitQualityManage = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'task/instance/customer/manager/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 提交质管终审
 * @param {type} id 任务实例id
 * @return:
 */
export const submitQualityFinal = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'task/instance/customer/final/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 提交集团审核
 * @param {type} id 任务实例id
 * @return:
 */
export const submitGroupAudit = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'task/instance/customer/organization/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 审批通过
 * @param {type} id 任务实例id
 * @return:
 */
export const auditPass = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'task/instance/customer/approve/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 获取证照文件URL
 * @param {type} taskInstanceId 任务实例id
 * @param {type} dataType 物料类型
 * @return:
 */
export const getLicenseUrl = ({ taskInstanceId, dataType }) => {
    const data = {
        taskInstanceId,
        dataType
    };
    return axios.request({
        url: 'customer/license/task/url/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取客管列表
 * @param pageNo
 * @param pageSize
 * @param status
 * @param customerName
 * @returns {*|never}
 */
export const getCustomerManage = ({
    pageNo,
    pageSize,
    status,
    customerName
}) => {
    const data = {
        pageNo,
        pageSize,
        customerName,
        status
    };
    return axios.request({
        url: 'task/instance/customer/save/enterprise/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取质管专员列表
 * @param pageNo
 * @param pageSize
 * @param status
 * @param customerName
 * @returns {*|never}
 */
export const getQualitySpecial = ({
    pageNo,
    pageSize,
    status,
    customerName
}) => {
    const data = {
        pageNo,
        pageSize,
        customerName,
        status
    };
    return axios.request({
        url: 'task/instance/customer/save/enterprise/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取质管经理列表
 * 获取集团审核列表
 * @param pageNo
 * @param pageSize
 * @param status
 * @param customerName
 * @returns {*|never}
 */
export const getQualityManage = ({
    pageNo,
    pageSize,
    status,
    customerName
}) => {
    const data = {
        pageNo,
        pageSize,
        customerName,
        status
    };
    return axios.request({
        url: 'task/instance/customer/save/enterprise/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取质管负责人列表
 * @param pageNo
 * @param pageSize
 * @param status
 * @param customerName
 * @returns {*|never}
 */
export const getQualityHead = ({ pageNo, pageSize, status, customerName }) => {
    const data = {
        pageNo,
        pageSize,
        customerName,
        status
    };
    return axios.request({
        url: 'task/instance/customer/save/enterprise/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取集团审核列表
 * @param pageNo
 * @param pageSize
 * @param status
 * @param customerName
 * @returns {*|never}
 */
export const getFinalList = ({ pageNo, pageSize, status, customerName }) => {
    const data = {
        pageNo,
        pageSize,
        customerName,
        status
    };
    return axios.request({
        url: 'task/instance/customer/save/organization/list',
        params: data,
        method: 'get'
    });
};
