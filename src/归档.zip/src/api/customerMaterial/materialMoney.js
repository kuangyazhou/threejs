/*
 * @Description: 客户物料价格接口
 * @Author: kuangyazhou
 * @Date: 2019-08-01 10:50:58
 * @LastEditTime: 2019-08-15 10:51:36
 * @LastEditors: Please set LastEditors
 */
import axios from '@/libs/api.request';

/**
 * @description: 销售价格列表
 * @param {type} specializedGroupName 专业分组
 * @param {type} commodityName 物料名称
 * @param {type} customerCommodityId 客户物料id
 * @param {type} taskStatus
 * @param {type} customerEnableCode
 * @param {type} pageSize
 * @param {type} pageNo
 * @param {type} initCommodityHandleId
 * @return:
 */
export const salePriceList = ({
    specializedGroupName,
    commodityName,
    taskStatus,
    customerEnableCode,
    customerCommodityId,
    pageSize,
    pageNo,
    initCommodityHandleId
}) => {
    const data = {
        specializedGroupName,
        commodityName,
        taskStatus,
        customerEnableCode,
        customerCommodityId,
        pageSize,
        pageNo,
        initCommodityHandleId
    };
    return axios.request({
        url: 'sale/price/organization/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 获取全量销售单价，慎用
 * @param {type} customerCommodityId 客户物料id
 * @return:
 */
export const getSalePriceUnSafe = ({ customerCommodityId }) => {
    const data = { customerCommodityId };
    return axios.request({
        url: 'sale/price/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 新增
 * @param {type} customerCommodityId 客户物料价格
 * @param {type} unitCode            单位code
 * @param {type} price               价格
 * @param {type} currencyId          币种
 * @param {type} taxRate             税率
 * @param {type} saleOrganizationId  销售组织id
 * @param {type} invoiceName  开票名称
 * @return:
 */
export const salePriceAdd = ({
    customerCommodityId,
    unitCode,
    price,
    currencyId,
    taxRate,
    saleOrganizationId,
    invoiceName
}) => {
    const data = {
        customerCommodityId,
        unitCode,
        price,
        currencyId,
        taxRate,
        saleOrganizationId,
        invoiceName
    };
    return axios.request({
        url: 'sale/price/save',
        data,
        method: 'post'
    });
};

/**
 * @description:销售价格编辑
 * @param {type} id
 * @param {type} customerCommodityId 客户物料价格
 * @param {type} unitCode            单位code
 * @param {type} price               价格
 * @param {type} currencyId          币种
 * @param {type} taxRate             税率
 * @param {type} invoiceName  开票名称
 * @param {type} saleOrganizationId  销售组织
 * @return:
 */
export const salePriceUpdate = ({
    id,
    customerCommodityId,
    unitCode,
    price,
    currencyId,
    taxRate,
    invoiceName,
    saleOrganizationId
}) => {
    const data = {
        id,
        customerCommodityId,
        unitCode,
        price,
        currencyId,
        taxRate,
        invoiceName,
        saleOrganizationId
    };
    return axios.request({
        url: 'sale/price/update',
        data,
        method: 'post'
    });
};

/**
 * @description: 销售价格提交
 * @param {type} id
 * @return:
 */
export const salePriceSubmit = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'sale/price/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 批量提交
 * @param {type} id
 * @return:
 */
export const salePriceSubmitMul = ({ ids }) => {
    const data = { ids };
    return axios.request({
        url: 'sale/price/submitBat',
        data,
        method: 'post'
    });
};

/**
 * @description: 销售价格审批
 * @param {type} id
 * @return:
 */
export const salePriceAudit = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'sale/price/approve',
        data,
        method: 'post'
    });
};

/**
 * @description: 批量审批
 * @param {type} ids
 * @return:
 */
export const salePriceAuditMul = ({ ids }) => {
    const data = { ids };
    return axios.request({
        url: 'sale/price/approveBat',
        data,
        method: 'post'
    });
};

/**
 * @description: 销售价格打回
 * @param {type} id
 * @return:
 */
export const salePriceReturn = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'sale/price/unapprove',
        data,
        method: 'post'
    });
};

/**
 * @description: 批量打回
 * @param {type} id
 * @return:
 */
export const salePriceReturnMul = ({ ids }) => {
    const data = { ids };
    return axios.request({
        url: 'sale/price/unapproveBat',
        data,
        method: 'post'
    });
};
