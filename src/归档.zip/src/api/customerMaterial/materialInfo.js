/*
 * @Description: 销售业务-客户物料信息
 * @Author: your name
 * @Date: 2019-08-01 10:19:07
 * @LastEditTime: 2019-08-15 10:16:42
 * @LastEditors: Please set LastEditors
 */

import axios from '@/libs/api.request';

/**
 * @description: 销售客户物料信息
 * @param {type} commodityName 名称
 * @param {type} specializedGroup  分组
 * @param {type} supplierEnableCode 供应商
 * @param {type} purchaseOrganizationId  组织
 * @return:
 */
export const getMaterialInfo = ({
    commodityName,
    specializedGroup,
    supplierEnableCode,
    purchaseOrganizationId,
    customerEnableCode,
    saleOrganizationId,
    pageNo,
    pageSize
}) => {
    const data = {
        commodityName,
        specializedGroup,
        supplierEnableCode,
        purchaseOrganizationId,
        customerEnableCode,
        saleOrganizationId,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'commodity/enterprise/select/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 物料信息单个新增
 * @param {type} customerEnableCode 客户码
 * @param {type} commodityCode 物料码
 * @param {type} invoiceName 开票
 * @param {type} remark 备注
 * @param {type} saleOrganizationId 销售组织id
 * @param {type} minimumEffectiveDays 最短效期
 * @param {type} winBidCode 中标码
 * @param {type} invoiceUnitCode 开票单位码
 * @return:
 */
export const materialAdd = ({
    customerEnableCode,
    commodityCode,
    invoiceName,
    remark,
    saleOrganizationId,
    minimumEffectiveDays,
    winBidCode,
    invoiceUnitCode
}) => {
    const data = {
        customerEnableCode,
        commodityCode,
        invoiceName,
        remark,
        saleOrganizationId,
        minimumEffectiveDays,
        winBidCode,
        invoiceUnitCode
    };
    return axios.request({
        url: 'customer/commodity/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 物料信息-批量新增
 * @param {type} Array items
 * @param {type} Array customerEnableCode 客户
 * @param {type} Array saleOrganizationId 销售组织
 * @return:
 */
export const materialAddMultiple = ({
    items,
    customerEnableCode,
    saleOrganizationId
}) => {
    const data = { items, customerEnableCode, saleOrganizationId };
    return axios.request({
        url: 'customer/commodity/saveBat',
        data,
        method: 'post'
    });
};

/**
 * @description: 客户申请资料
 * @param {type} salerId 销售员id
 * @param {type} saleOrganizationId 销售组织id
 * @param {type} status 3-有效 4-无效
 * @param {type} customerEnableCode 客户码
 * @param {type} specializedGroupName 专业分组
 * @param {type} commodityName 物料名称
 * @param {type} taskStatus WAIT(0, "保存", "未提交"),//     APPROVE(1, "提交", "审核中"),     APPROVED(2, "审核", "已审核");//
 * @param {type} pageSize
 * @param {type} pageNo
 * @param {type} initCommodityHandleId
 * @param {type} commodityNumber 货号
 * @return:
 */
export const getCustomerInfo = ({
    salerId,
    saleOrganizationId,
    status,
    customerEnableCode,
    specializedGroupName,
    commodityName,
    taskStatus,
    pageSize,
    pageNo,
    initCommodityHandleId,
    commodityNumber
}) => {
    const data = {
        salerId,
        saleOrganizationId,
        status,
        customerEnableCode,
        specializedGroupName,
        commodityName,
        taskStatus,
        pageSize,
        pageNo,
        initCommodityHandleId,
        commodityNumber
    };
    return axios.request({
        url: 'customer/commodity/organization/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 客户物料信息保存
 * @param {type}  id 客户物料id
 * @param {type}  customerEnableCode 客户码
 * @param {type}  commodityCode 物料码
 * @param {type}  invoiceName 开票名
 * @param {type}  remark 备注
 * @param {type}  saleOrganizationId 销售组织
 * @return:
 */
export const customerMaterialUpdate = ({
    id,
    customerEnableCode,
    commodityCode,
    invoiceName,
    remark,
    saleOrganizationId
}) => {
    const data = {
        id,
        customerEnableCode,
        commodityCode,
        invoiceName,
        remark,
        saleOrganizationId
    };
    return axios.request({
        url: 'customer/commodity/update',
        data,
        method: 'post'
    });
};

/**
 * @description: 提交审核
 * @param {type} id
 * @return:
 */
export const customerMaterialSubmit = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'customer/commodity/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 批量提交
 * @param {type} ids
 * @return:
 */
export const customerMaterialSubmitMutl = ({ ids }) => {
    const data = { ids };
    return axios.request({
        url: 'customer/commodity/submitBat',
        data,
        method: 'post'
    });
};

/**
 * @description: 取消审核&&打回
 * @param {type} id
 * @return:
 */
export const customerMaterialBack = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'customer/commodity/unapprove',
        data,
        method: 'post'
    });
};

/**
 * @description: 批量取消审核&&打回
 * @param {type} ids
 * @return:
 */
export const customerMaterialBackMul = ({ ids }) => {
    const data = { ids };
    return axios.request({
        url: 'customer/commodity/unapproveBat',
        data,
        method: 'post'
    });
};

/**
 * @description: 审核通过
 * @param {type} id
 * @return:
 */
export const customerMaterialPass = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'customer/commodity/approve',
        data,
        method: 'post'
    });
};

/**
 * @description: 审核通过 批量
 * @param {type} ids
 * @return:
 */
export const customerMaterialPassMul = ({ ids }) => {
    const data = {
        ids
    };
    return axios.request({
        url: 'customer/commodity/approveBat',
        data,
        method: 'post'
    });
};

/**
 * @description: 添加供应商
 * @param {type} id
 * @param {type} suppliers  Array
 * @return:
 */
export const addSupplier = ({ id, suppliers }) => {
    const data = { id, suppliers };
    return axios.request({
        url: 'customer/commodity/addSuppliers',
        data,
        method: 'post'
    });
};

/**
 * @description: 获取已添加供应商列表
 * @param {type} customerCommodityId 客户物料id
 * @return:
 */
export const getSupplierList = ({ customerCommodityId }) => {
    const data = { customerCommodityId };
    return axios.request({
        url: 'customer/commodity/supplier/list',
        params: data,
        method: 'get'
    });
};
