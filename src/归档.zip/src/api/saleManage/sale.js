import axios from '@/libs/api.request';

/**
 * 查看销售员列表
 * @param realName
 * @param pageNo
 * @param pageSize
 * @returns {*|never}
 */
export const getSalesManList = ({ salerName, pageNo, pageSize }) => {
    const data = {
        salerName,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'sale/saler/enterprise/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取可新增的用户列表
 * @param realName
 * @param departmentName
 * @returns {*|never}
 */
export const getUsersList = ({ realName, departmentName }) => {
    const data = { realName, departmentName };
    return axios.request({
        url: 'sale/saler/user/list',
        params: data,
        method: 'get'
    });
};

/**
 * 批量新增销售员
 * @param userList
 * @returns {*|never}
 */
export const addSalesman = ({ items }) => {
    const data = {
        items
    };
    return axios.request({
        url: 'sale/saler/saveBat',
        data: data,
        method: 'post'
    });
};

/**
 * 设置销售员无效
 * @param id
 * @returns {*|never}
 */
export const salesmanDisable = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/saler/disable',
        data: data,
        method: 'post'
    });
};

/**
 * 设置销售员有效
 * @param id
 * @returns {*|never}
 */
export const salesmanEnable = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/saler/enable',
        data: data,
        method: 'post'
    });
};

/**
 * 关联销售员的客户
 * @param salerId
 * @param customerCodes
 * @returns {*|never}
 */
export const addSalerCustomer = ({ salerId, customerCodes }) => {
    const data = {
        salerId,
        customerCodes
    };
    return axios.request({
        url: 'saler/customer/addCustomers',
        data: data,
        method: 'post'
    });
};

/**
 * 获取已关联的客户
 * @param salerId
 * @returns {*|never}
 */
export const getSaveCustomerList = ({ salerId }) => {
    const data = {
        salerId
    };
    return axios.request({
        url: 'saler/customer/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取本公司所有客户
 * @returns {*|never}
 */
export const getAllCustomerList = () => {
    const data = {};
    return axios.request({
        url: 'customer/enterprise/list',
        params: data,
        method: 'get'
    });
};
