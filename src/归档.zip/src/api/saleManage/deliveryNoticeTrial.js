import axios from '@/libs/api.request';

/**
 * 待发货订单列表
 * @param pageNo
 * @param pageSize
 * @param hasUnShipmentOrder
 * @param customerName
 * @param commodityName
 * @param orderDateStart
 * @param orderDateEnd
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const getDeliveryNoticeTrialList = ({
    pageNo,
    pageSize,
    hasUnShipmentOrder,
    customerName,
    commodityName,
    orderDateStart,
    orderDateEnd
}) => {
    const data = {
        pageNo,
        pageSize,
        hasUnShipmentOrder: hasUnShipmentOrder ? 1 : 0,
        customerName,
        commodityName,
        orderDateStart,
        orderDateEnd
    };
    return axios.request({
        url: 'shipment/notice/sale/order/item/list',
        params: data,
        method: 'get'
    });
};

/**
 * 库存明细列表
 * @param customerEnableCode
 * @param supplierEnableCode
 * @param saleOrderItemId
 * @param commodityCode
 * @param effectiveDate
 * @param effectiveDateStart
 * @param customerCommodityId
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const getInventoryTrialList = ({
    customerEnableCode,
    supplierEnableCode,
    saleOrderItemId,
    commodityCode,
    effectiveDate,
    effectiveDateStart,
    customerCommodityId
}) => {
    const data = {
        customerEnableCode,
        supplierEnableCode,
        saleOrderItemId,
        commodityCode,
        effectiveDate,
        effectiveDateStart,
        customerCommodityId
    };
    return axios.request({
        url: 'shipment/notice/inventory/try/list',
        params: data,
        method: 'get'
    });
};

/**
 * 发货明细列表
 * @param saleOrderItemId
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const getDeliveryTrialList = (saleOrderItemId) => {
    const data = {
        saleOrderItemId
    };
    return axios.request({
        url: 'shipment/notice/itemList',
        params: data,
        method: 'get'
    });
};

/**
 * 库存明细选择，新增发货明细
 * @param saleOrderItemId
 * @param inventoryId
 * @param quantity
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const addDeliveryTrialList = ({
    saleOrderItemId,
    inventoryId,
    quantity
}) => {
    const data = {
        saleOrderItemId,
        inventoryId,
        quantity
    };
    return axios.request({
        url: 'shipment/notice/item/try/save',
        data,
        method: 'post'
    });
};

/**
 * 发货明细移除，退回至库存明细
 * @param ShipmentNoticeItemId
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const delDeliveryTrialList = (ShipmentNoticeItemId) => {
    const data = {
        ShipmentNoticeItemId
    };
    return axios.request({
        url: 'shipment/notice/item/try/remove',
        data,
        method: 'post'
    });
};

// 一键匹配
export const matchAuto = () => {
    return axios.request({
        url: 'shipment/notice/item/try/match/auto',
        method: 'post'
    });
};

// 重置试算
export const matchRemove = () => {
    return axios.request({
        url: 'shipment/notice/item/try/match/remove',
        method: 'post'
    });
};

// 一键匹配
export const matchGenerate = () => {
    return axios.request({
        url: 'shipment/notice/item/try/match/generate',
        method: 'post'
    });
};
