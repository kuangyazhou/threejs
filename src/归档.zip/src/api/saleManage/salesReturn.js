import axios from '@/libs/api.request';

/**
 * 获取销售退货单明细
 * @param pageNo
 * @param pageSize
 * @param inventoryOrganizationId
 * @param warehouseId
 * @param orderStatus
 * @param customerName
 * @returns {*|never}
 */
export const getSalesReturnDetailList = ({ pageNo, pageSize, inventoryOrganizationId, warehouseId, orderStatus, customerName }) => {
    const data = {
        pageNo, pageSize, inventoryOrganizationId, warehouseId, orderStatus, customerName
    };
    return axios.request({
        url: 'sale/return/order/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取可以选择的销售出库单明细
 * @param inventoryOrganizationId
 * @param warehouseId
 * @param inboundOrderCode
 * @param customerName
 * @param beginDate
 * @param endDate
 * @param outboundOrderId
 * @param excludeIds
 * @param pageNo
 * @param pageSize
 * @returns {*|never}
 */
export const getSalesOutboundDetailList = ({ pageNo, pageSize, inventoryOrganizationId, warehouseId, inboundOrderCode, customerName, beginDate, endDate, outboundOrderId, excludeIds }) => {
    const data = {
        pageNo, pageSize, inventoryOrganizationId, warehouseId, inboundOrderCode, customerName, beginDate, outboundOrderId, excludeIds, endDate
    };
    return axios.request({
        url: 'sale/return/order/outboundOrderItems',
        params: data,
        method: 'get'
    });
};

/**
 * 获取某个销售退货单明细
 * @param id
 * @returns {*|never}
 */
export const getSalesRefundDetail = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/return/order/editInfo',
        params: data,
        method: 'get'
    });
};

/**
 * 新增销售退货单
 * @param outboundOrderItemIds
 * @returns {*|never}
 */
export const addSalesRefundOrder = ({
    outboundOrderItemIds
}) => {
    const data = {
        outboundOrderItemIds
    };
    return axios.request({
        url: 'sale/return/order/add',
        data,
        method: 'post'
    });
};

/**
 * 编辑销售退货单明细
 * @param warehouseId
 * @param orderStatus
 * @param remark
 * @param returnTime
 * @param itemQuantity
 * @param id
 * @returns {*|never}
 */
export const editSalesRefundOrder = ({
    warehouseId,
    orderStatus,
    remark,
    returnTime,
    itemQuantity,
    id
}) => {
    const data = {
        warehouseId,
        orderStatus,
        remark,
        returnTime,
        itemQuantity,
        id
    };
    return axios.request({
        url: 'sale/return/order/update',
        data,
        method: 'post'
    });
};

/**
 * 提交
 * @param id
 * @returns {*|never}
 */
export const submitSalesRefundOrder = ({
    id
}) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/return/order/submit',
        data,
        method: 'post'
    });
};

/**
 * 撤回
 * @param id
 * @returns {*|never}
 */
export const cancelSalesRefundOrder = ({
    id
}) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/return/order/revocation',
        data,
        method: 'post'
    });
};

/**
 * 审核
 * @param id
 * @returns {*|never}
 */
export const approveSalesRefundOrder = ({
    id
}) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/return/order/audit',
        data,
        method: 'post'
    });
};

/**
 * 删除销售退货单明细
 * @param id
 * @returns {*|never}
 */
export const delSalesRefundOrderDetail = ({
    id
}) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/return/order/delete',
        data,
        method: 'post'
    });
};
