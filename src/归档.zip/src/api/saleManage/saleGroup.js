import axios from '@/libs/api.request';

/**
 * 获取销售组列表
 * @param saleGroupName
 * @param saleOrganizationId
 * @param pageNo
 * @param pageSize
 * @returns {*|never}
 */
export const getSalesGroupList = ({
    saleGroupName,
    saleOrganizationId,
    pageNo,
    pageSize
}) => {
    const data = {
        saleGroupName,
        saleOrganizationId,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'sale/group/organization/list',
        params: data,
        method: 'get'
    });
};

/**
 * 查找当前公司下的所有销售组织
 * @returns {*|never}
 */
export const getCompanySalesOrganizationList = () => {
    const data = {};
    return axios.request({
        url: 'sale/organization/select/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增销售组
 * @param saleOrganizationId  销售组织id
 * @param saleGroupName  销售组名称
 * @param salerIds
 * @returns {*|never}
 */
export const addSalesGroup = ({
    saleOrganizationId,
    saleGroupName,
    salerIds
}) => {
    const data = {
        saleOrganizationId,
        saleGroupName,
        salerIds
    };
    return axios.request({
        url: 'sale/group/save',
        data: data,
        method: 'post'
    });
};

/**
 * 获取销售组成员list
 * @param saleGroupId
 * @returns {*|never}
 */
export const getSalesGroupDetail = ({ saleGroupId }) => {
    const data = {
        saleGroupId
    };
    return axios.request({
        url: 'sale/group/saler/list',
        params: data,
        method: 'get'
    });
};

/**
 *  编辑销售组
 * @param saleOrganizationId
 * @param saleGroupName
 * @param id
 * @returns {*|never}
 */
export const editSalesGroup = ({ saleOrganizationId, saleGroupName, id }) => {
    const data = {
        saleOrganizationId,
        saleGroupName,
        id
    };
    return axios.request({
        url: 'sale/group/update',
        data: data,
        method: 'post'
    });
};

/**
 * 查询本公司所有销售员
 * @param salerName
 * @param departmentName
 * @param notSaleGroupId
 * @returns {*|never}
 */
export const getCompanySalesmanList = ({
    salerName,
    departmentName,
    notSaleGroupId
}) => {
    const data = {
        salerName,
        departmentName,
        notSaleGroupId
    };
    return axios.request({
        url: 'sale/saler/enterprise/list',
        params: data,
        method: 'get'
    });
};

/**
 * 销售组新增销售员
 * @param id
 * @param salerIds
 * @returns {*|never}
 */
export const salesGroupAddBuyer = ({ saleGroupId, salerIds }) => {
    const data = {
        saleGroupId,
        salerIds
    };
    return axios.request({
        url: 'sale/group/saler/save',
        data: data,
        method: 'post'
    });
};

/**
 * 销售组删除销售员
 * @param id
 * @returns {*|never}
 */
export const salesGroupDeleteBuyer = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/group/saler/delete',
        data: data,
        method: 'post'
    });
};

/**
 * 删除销售组
 * @param id
 * @returns {*|never}
 */
export const delSalesGroup = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/group/delete',
        data: data,
        method: 'post'
    });
};
