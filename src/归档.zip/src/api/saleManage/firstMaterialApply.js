import axios from '@/libs/api.request';

/**
 * 查看销售员列表
 * @param realName
 * @param pageNo
 * @param pageSize
 * @returns {*|never}
 */
export const getCommodityTaskList = ({
    pageNo,
    pageSize,
    inquiryTaskStatus,
    customerName,
    organizationId,
    saleOrganizationId,
    salerId
}) => {
    const data = {
        pageNo,
        pageSize,
        inquiryTaskStatus,
        customerName,
        organizationId,
        saleOrganizationId,
        salerId
    };
    return axios.request({
        url: 'init/commodity/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增首营物料申请
 * @param customerName
 * @param commodityName
 * @param commodityBrand
 * @param commoditySpecializedGroupId
 * @param instrumentName
 * @param manufacturer
 * @param outboundMethodId
 * @param deliveryMethodId
 * @param commoditySpec
 * @param commodityNumber
 * @param commodityUnitName
 * @param price
 * @param yearOrderNumber
 * @param yearTestNumber
 * @param metaSupplier
 * @param purchaseOrganizationId
 * @param writeDescription
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const addCommodityTask = ({
    customerName,
    commodityName,
    commodityBrand,
    commoditySpecializedGroupId,
    instrumentName,
    manufacturer,
    outboundMethodId,
    deliveryMethodId,
    commoditySpec,
    commodityNumber,
    commodityUnitName,
    price,
    yearOrderNumber,
    yearTestNumber,
    metaSupplier,
    purchaseOrganizationId,
    writeDescription
}) => {
    const data = {
        customerName,
        commodityName,
        commodityBrand,
        commoditySpecializedGroupId,
        instrumentName,
        manufacturer,
        outboundMethodId,
        deliveryMethodId,
        commoditySpec,
        commodityNumber,
        commodityUnitName,
        price,
        yearOrderNumber,
        yearTestNumber,
        metaSupplier,
        purchaseOrganizationId,
        writeDescription
    };
    return axios.request({
        url: 'init/commodity/save',
        data,
        method: 'post'
    });
};

/**
 * 编辑
 * @param id
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const updateCommodityTask = ({
    id,
    customerName,
    commodityName,
    commodityBrand,
    commoditySpecializedGroupId,
    instrumentName,
    manufacturer,
    outboundMethodId,
    deliveryMethodId,
    commoditySpec,
    commodityNumber,
    commodityUnitName,
    price,
    yearOrderNumber,
    yearTestNumber,
    metaSupplier,
    purchaseOrganizationId,
    writeDescription
}) => {
    const data = {
        id,
        customerName,
        commodityName,
        commodityBrand,
        commoditySpecializedGroupId,
        instrumentName,
        manufacturer,
        outboundMethodId,
        deliveryMethodId,
        commoditySpec,
        commodityNumber,
        commodityUnitName,
        price,
        yearOrderNumber,
        yearTestNumber,
        metaSupplier,
        purchaseOrganizationId,
        writeDescription
    };
    return axios.request({
        url: 'init/commodity/update',
        data,
        method: 'post'
    });
};
/**
 * 删除
 * @param id
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const deleteCommodityTask = id => {
    const data = {
        id
    };
    return axios.request({
        url: 'init/commodity/delete',
        data,
        method: 'post'
    });
};

/**
 * 首营申请
 * @param id
 * @param customerEnableCode
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const submitCommodityTask = (id, customerEnableCode) => {
    const data = {
        id,
        customerEnableCode
    };
    return axios.request({
        url: 'init/commodity/task/submit',
        data,
        method: 'post'
    });
};

/**
 * 询价
 * @param id
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const startInquiry = id => {
    const data = {
        id
    };
    return axios.request({
        url: 'init/commodity/start/inquiry',
        data,
        method: 'post'
    });
};

/**
 * 批量询价
 * @param items
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const startInquiryBat = items => {
    const data = {
        items
    };
    return axios.request({
        url: 'init/commodity/start/inquiryBat',
        data,
        method: 'post'
    });
};

/**
 * 获取询价结果
 * @param id
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const getInquiryResult = id => {
    const data = {
        id
    };
    return axios.request({
        url: 'inquiry/result/get',
        params: data,
        method: 'get'
    });
};

/**
 * 获取反馈信息
 * @param id
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const getInquiryInfo = id => {
    const data = {
        id
    };
    return axios.request({
        url: 'inquiry/info/get',
        params: data,
        method: 'get'
    });
};

/**
 * 询价结果供应商勾选
 * @param inquiryId
 * @param ids
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const supplierChecked = (inquiryId, ids) => {
    const data = {
        inquiryId, ids
    };
    return axios.request({
        url: 'inquiry/supplier/commodity/checked',
        data,
        method: 'post'
    });
};
