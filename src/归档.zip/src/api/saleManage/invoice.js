import axios from '@/libs/api.request';

/**
 * 查看销售开票列表
 * @param pageNo
 * @param pageSize
 * @param customerId
 * @param invoiceNo
 * @param outboundOrderNo
 * @param beginDate
 * @param endDate
 * @returns {ClientHttp2Stream | * | void | AxiosPromise<any> | http.ClientRequest}
 */
export const getSaleInvoiceList = ({
    pageNo,
    pageSize,
    customerId,
    invoiceNo,
    outboundOrderNo,
    beginDate,
    endDate
}) => {
    const data = {
        pageNo,
        pageSize,
        customerId,
        invoiceNo,
        outboundOrderNo,
        beginDate,
        endDate
    };
    return axios.request({
        url: 'sale/invoice/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增开票
 * @param invoiceDate
 * @param customerId
 * @param invoiceNo
 * @param invoiceAbstract
 * @param internalAbstract
 * @param outboundOrderItemIdList
 * @param invoiceStatus
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const addSaleInvoice = ({
    invoiceDate,
    customerId,
    invoiceNo,
    invoiceAbstract,
    internalAbstract,
    outboundOrderItemIdList,
    invoiceStatus
}) => {
    const data = {
        invoiceDate,
        customerId,
        invoiceNo,
        invoiceAbstract,
        internalAbstract,
        outboundOrderItemIdList,
        invoiceStatus
    };
    return axios.request({
        url: 'sale/invoice/add',
        data,
        method: 'post'
    });
};

/**
 * 进入编辑销售开票
 * @param id
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const getDetailSaleInvoice = (id) => {
    const data = { id };
    return axios.request({
        url: 'sale/invoice/edit',
        params: data,
        method: 'get'
    });
};

/**
 * 编辑销售开票
 * @param id
 * @param invoiceDate
 * @param customerId
 * @param invoiceNo
 * @param invoiceAbstract
 * @param internalAbstract
 * @param outboundOrderItemIdList
 * @param invoiceStatus
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const editSaleInvoice = ({
    id,
    invoiceDate,
    customerId,
    invoiceNo,
    invoiceAbstract,
    internalAbstract,
    outboundOrderItemIdList,
    invoiceStatus
}) => {
    const data = {
        id,
        invoiceDate,
        customerId,
        invoiceNo,
        invoiceAbstract,
        internalAbstract,
        outboundOrderItemIdList,
        invoiceStatus
    };
    return axios.request({
        url: 'sale/invoice/update',
        data,
        method: 'post'
    });
};

/**
 * 提交销售开票
 * @param ids
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const submitSaleInvoice = (ids) => {
    const data = {
        ids
    };
    return axios.request({
        url: 'sale/invoice/submit',
        data,
        method: 'post'
    });
};

/**
 * 撤回销售开票
 * @param ids
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const revocationSaleInvoice = (ids) => {
    const data = {
        ids
    };
    return axios.request({
        url: 'sale/invoice/revocation',
        data,
        method: 'post'
    });
};

/**
 * 审核销售开票
 * @param ids
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const auditSaleInvoice = (ids) => {
    const data = {
        ids
    };
    return axios.request({
        url: 'sale/invoice/audit',
        data,
        method: 'post'
    });
};

/**
 * 根据单据条码查询
 * @param outboundOrderNo
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const itemDetailSaleInvoice = (outboundOrderNo) => {
    const data = {
        outboundOrderNo
    };
    return axios.request({
        url: 'sale/invoice/itemDetail',
        params: data,
        method: 'get'
    });
};
