/*
 * @Description: 销售业务-销售订单接口
 * @Author: kuangyazhou
 * @Date: 2019-08-07 11:44:47
 * @LastEditTime: 2019-08-15 17:56:47
 * @LastEditors: Please set LastEditors
 */

import axios from '@/libs/api.request';

/**
 * @description: 获取订单分页数据
 * @param {type} startDate 格式化时间 起点
 * @param {type} endDate 格式化时间 终点
 * @param {type} orderStatus 订单状态 0 未提交 1 审核中 2 已审核
 * @return:
 */
export const getOrderList = ({ customerId, startDate, endDate, orderStatus, pageSize, pageNo }) => {
    const data = {
        customerId,
        startDate,
        endDate,
        orderStatus,
        pageSize,
        pageNo
    };
    return axios.request({
        url: 'sale/order/organization/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 获取订单明细list
 * @param {type} saleOrderId 销售订单id
 * @param {type} customerId 客户id
 * @param {type} isRed 是否查询所有已通过订单明细 0为正常查询 1为红字查询
 * @param {type} operatorId 操作员id
 * @param {type} startDate
 * @param {type} endDate
 * @param {type} pageNo
 * @param {type} pageSize
 * @return:
 */
export const getOrderDetail = ({ startDate, endDate, customerEnableCode, operatorId, customerId, saleOrderId, isRed, pageNo, pageSize }) => {
    const data = { startDate, endDate, customerEnableCode, operatorId, customerId, saleOrderId, isRed, pageNo, pageSize };
    return axios.request({
        url: 'sale/order/item/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 销售订单新增、更新
 * @param {type} id 订单id （编辑时才传)
 * @param {type} orderType 订单类型
 * @param {type} customerId 客户id
 * @param {type} customerEnableCode 客户码
 * @param {type} saleDepartment 销售部门 -字典
 * @param {type} invoiceType 开票方式-字典
 * @param {type} outboundType 出库类型，根据订单类型联动 系统字典
 * @param {type} accountingDate 核算年月
 * @param {type} orderRemark 订单备注
 * @param {type} salerId 业务员id
 * @param {type} items 明细项
 * item 子参数
 * @param {type} customerCommodityId 客户物料id
 * @param {type} customerId 客户id
 * @param {type} commodityId 物料id
 * @param {type} quantity 数量
 * @param {type} planLeftQuantity 计划剩余数
 * @param {type} isPlaned 是否计划内 1：是，2：否
 * @param {type} salePrice 销售价格
 * @param {type} currency 币种Id
 * @param {type} taxRate 税率
 * @param {type} amount 金额
 * @param {type} effectiveDate 要求效期
 * @param {type} arriveDate 要求到货期
 * @param {type} packageId 包装单位id
 * @param {type} unitId 包装单位字典id
 * @param {type} unitName 包装名
 * @param {type} brandName 品牌名
 * @param {type} commoditySpec 物料规格
 * @param {type} registerName 注册名
 * @param {type} registerNumber 注册证号
 * @param {type} commodityCode 物料码
 * @param {type} commodityName 物料名
 * @param {type} customerName 客户名
 * @param {type} customerAddress 客户地址
 * @return:
 */
export const saleOrderSave = ({ id, orderType, customerId, customerEnableCode, saleDepartment, invoiceType, outboundType, accountingDate, orderRemark, salerId, items }) => {
    const data = { id, orderType, customerId, customerEnableCode, saleDepartment, invoiceType, outboundType, accountingDate, orderRemark, salerId, items };
    return axios.request({
        url: 'sale/order/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 销售订单提交
 * @param {type} id 订单id
 * @return:
 */
export const saleOrderSubmit = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/order/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 批量提交
 * @param {type} id 订单id
 * @return:
 */
export const saleOrderSubmitMul = ({ ids }) => {
    const data = {
        ids
    };
    return axios.request({
        url: 'sale/order/submitBat',
        data,
        method: 'post'
    });
};

/**
 * @description: 销售订单撤回
 * @param {type} id 订单id
 * @return:
 */
export const saleOrderRevert = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/order/return',
        data,
        method: 'post'
    });
};

/**
 * @description: 批量撤回
 * @param {type} id 订单id
 * @return:
 */
export const saleOrderRevertMul = ({ ids }) => {
    const data = {
        ids
    };
    return axios.request({
        url: 'sale/order/returnBat',
        data,
        method: 'post'
    });
};

/**
 * @description: 销售订单通过
 * @param {type} id 订单id
 * @return:
 */
export const saleOrderPass = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/order/approve',
        data,
        method: 'post'
    });
};

/**
 * @description: 批量通过
 * @param {type} id 订单id
 * @return:
 */
export const saleOrderPassMul = ({ ids }) => {
    const data = {
        ids
    };
    return axios.request({
        url: 'sale/order/approveBat',
        data,
        method: 'post'
    });
};

/**
 * @description: 新增红字保存-更新
 * @param {type} id 订单id （编辑时才传)
 * @param {type} orderType 订单类型
 * @param {type} customerId 客户id
 * @param {type} customerEnableCode 客户码
 * @param {type} saleDepartment 销售部门 -字典
 * @param {type} invoiceType 开票方式-字典
 * @param {type} outboundType 出库类型，根据订单类型联动 系统字典
 * @param {type} accountingDate 核算年月
 * @param {type} orderRemark 订单备注
 * @param {type} salerId 业务员id
 * @param {type} items 明细项
 * item 子参数
 * @param {type} customerCommodityId 客户物料id
 * @param {type} customerId 客户id
 * @param {type} commodityId 物料id
 * @param {type} quantity 数量
 * @param {type} planLeftQuantity 计划剩余数
 * @param {type} isPlaned 是否计划内 1：是，2：否
 * @param {type} salePrice 销售价格
 * @param {type} currency 币种Id
 * @param {type} taxRate 税率
 * @param {type} amount 金额
 * @param {type} effectiveDate 要求效期
 * @param {type} arriveDate 要求到货期
 * @param {type} packageId 包装单位id
 * @param {type} unitId 包装单位字典id
 * @param {type} unitName 包装名
 * @param {type} brandName 品牌名
 * @param {type} commoditySpec 物料规格
 * @param {type} registerName 注册名
 * @param {type} registerNumber 注册证号
 * @param {type} commodityCode 物料码
 * @param {type} commodityName 物料名
 * @param {type} customerName 客户名
 * @param {type} customerAddress 客户地址
 * @param {type} redOrderId 原订单id
 * @return:
 */
export const redOrderSave = ({ redOrderId, id, orderType, customerId, customerEnableCode, saleDepartment, invoiceType, outboundType, accountingDate, orderRemark, salerId, items }) => {
    const data = { redOrderId, id, orderType, customerId, customerEnableCode, saleDepartment, invoiceType, outboundType, accountingDate, orderRemark, salerId, items };
    return axios.request({
        url: 'sale/order/red/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 销售订单删除
 * @param {type} id 订单id
 * @return:
 */
export const saleOrderDel = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'sale/order/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 批量删除
 * @param {type} id 订单id
 * @return:
 */
export const saleOrderDelMul = ({ ids }) => {
    const data = {
        ids
    };
    return axios.request({
        url: 'sale/order/deleteBat',
        data,
        method: 'post'
    });
};

/**
 * @description: 订单凭证列表
 * @param {type} saleOrderId 订单id
 * @param {type} pageNo
 * @param {type} pageSize
 * @return:
 */
export const saleOrderLicense = ({ saleOrderId }) => {
    const data = {
        saleOrderId
    };
    return axios.request({
        url: 'sale/order/attach/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 销售订单凭证新增
 * @param {type} remark 备注
 * @param {type} saleOrderAttachType 订单类型
 * @param {type} saleOrderId 订单id
 * @param {type} records 文件列表
 * @return:
 */
export const licenseAdd = ({ remark, saleOrderAttachType, saleOrderId, records }) => {
    const data = { remark, saleOrderAttachType, saleOrderId, records };
    return axios.request({
        url: 'sale/order/attach/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 销售订单凭证更新
 * @param {type} remark 备注
 * @param {type} saleOrderAttachType 订单类型
 * @param {type} saleOrderId 订单id
 * @param {type} records 文件列表
 * @return:
 */
export const licenseUpdate = ({ id, remark, saleOrderAttachType, saleOrderId, records }) => {
    const data = { id, remark, saleOrderAttachType, saleOrderId, records };
    return axios.request({
        url: 'sale/order/attach/update',
        data,
        method: 'post'
    });
};

/**
 * @description: 订单凭证删除
 * @param {type} id 订单id
 * @return:
 */
export const licenseDel = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: '/sale/order/attach/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 获取客户物料计划剩余数
 * @param {type} customerCommodityId 物料id
 * @param {type} salerId 销售员ID
 * @param {type} accountingDate 核算年月时间戳
 * @return:
 */
export const getRemain = ({ customerCommodityId, salerId, accountingDate }) => {
    const data = { customerCommodityId, salerId, accountingDate };
    return axios.request({
        url: 'sale/order/item/get/plan/left',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 获取单个订单头信息
 * @param {type} id 订单id
 * @return:
 */
export const getOrderHead = ({ id }) => {
    const data = { id: id };
    return axios.request({
        url: 'sale/order/getOne',
        params: data,
        method: 'get'
    });
};
