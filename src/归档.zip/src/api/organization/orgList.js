/*
 * @Description: 运营后台-组织管理接口
 * @Author: kuangyazhou
 * @Date: 2019-06-26 15:08:38
 * @LastEditTime: 2019-07-04 14:17:05
 * @LastEditors: Please set LastEditors
 */
import axios from '@/libs/api.request';

/**
 * @description: 获取组织列表数据
 * @param organizationName 组织名称
 * @param organizationCode 组织编号
 * @param status 组织状态：0-无效、1-有效
 * @param locked 锁定状态：1-正常、0-已锁定
 * @return: Promise
 */
export const getOrganizationList = ({
    organizationName,
    organizationCode,
    status,
    locked,
    pageNo,
    pageSize
}) => {
    const params = {
        organizationName,
        organizationCode,
        status,
        locked,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'organization/list',
        params,
        method: 'get'
    });
};

/**
 * @description: 修改组织信息
 * @param organizationName 组织名称:不能为空且不能大于50长度
 * @param organizationCode 组织编码 统一社会信用代码应小于50字符号应小于20字符
 * @param parentOrganizationId 上级组织id
 * @param socialCreditCode 机构代码
 * @param status 组织状态：0-无效、1-有效
 * @param locked 组织锁定状态：1-正常、0-已锁定
 * @return:
 */
export const updateOrganization = ({
    id,
    organizationName,
    organizationCode,
    parentOrganizationId,
    socialCreditCode,
    status,
    locked
}) => {
    const data = {
        id,
        organizationName,
        organizationCode,
        parentOrganizationId,
        socialCreditCode,
        status,
        locked
    };
    return axios.request({
        url: 'organization/update',
        data,
        method: 'post'
    });
};

/**
 * @description: 添加组织
 * @param organizationName 组织名称：组织名称不能为空且不能小于50长度
 * @param organizationCode 组织编号应小于20字符
 * @param socialCreditCode 统一社会信用代码应小于50字符
 * @param parentOrganizationId 上级组织id
 * @return:
 */
export const addOrganization = ({
    organizationName,
    organizationCode,
    socialCreditCode,
    parentOrganizationId
}) => {
    const data = {
        organizationName,
        organizationCode,
        socialCreditCode,
        parentOrganizationId
    };
    return axios.request({
        url: 'organization/create',
        data,
        method: 'post'
    });
};

export const getUserOrg = ({ userId }) => {
    const params = {
        userId
    };
    return axios.request({
        url: 'organization/getUserOrganization',
        params,
        method: 'get'
    });
};
