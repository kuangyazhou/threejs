/*
 * @Description: 运营后台-组织用户接口
 * @Author: kuangyazhou
 * @Date: 2019-06-27 11:37:48
 * @LastEditTime: 2019-06-28 17:35:41
 * @LastEditors: Please set LastEditors
 */

import axios from '@/libs/api.request';

/**
 * @description: 获取用户列表
 * @param organizationId 所属组织
 * @param realName 用户姓名
 * @param mobile 手机号
 * @param status 用户状态：0-无效、1-有效
 * @param locked 锁定状态：1-正常、0-已锁定
 * @return:
 */
export const getUserList = ({
    id,
    organizationId,
    realName,
    mobile,
    status,
    locked,
    pageNo,
    pageSize
}) => {
    const params = {
        id,
        organizationId,
        realName,
        mobile,
        status,
        locked,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'platform/user/list',
        params,
        method: 'get'
    });
};

/**
 * @description: 创建组织用户
 * @param userName 登录名不能为空且不能超过20字符
 * @param realName 用户姓名不能为空且不能超过20字符
 * @param mobile 手机号不能为空且不能超过规定长度
 * @param email 邮箱
 * @param sex 0-男，1-女
 * @param idNumber 身份证号
 * @param organizationId 所属组织不能为空
 * @return:
 */
export const createUser = ({
    userName,
    realName,
    mobile,
    email,
    sex,
    idNumber,
    organizationId
}) => {
    const data = {
        userName,
        realName,
        mobile,
        email,
        sex,
        idNumber,
        organizationId
    };
    return axios.request({
        url: 'platform/user/create',
        data,
        method: 'post'
    });
};

/**
 * @description: 修改组织用户信息
 * @param id
 * @param userName
 * @param realName
 * @param mobile
 * @param email
 * @param sex
 * @param idNumber
 * @param organizationId
 * @param status
 * @param locked
 * @return:
 */
export const updateUser = ({
    id,
    userName,
    realName,
    mobile,
    email,
    sex,
    idNumber,
    organizationId,
    status,
    locked
}) => {
    const data = {
        id,
        userName,
        realName,
        mobile,
        email,
        sex,
        idNumber,
        organizationId,
        status,
        locked
    };
    return axios.request({
        url: 'platform/user/update',
        data,
        method: 'post'
    });
};

/**
 * @description: 重置用户密码
 * @param userId 被重置的用户id
 * @return:
 */

export const resetPwd = ({ userId }) => {
    const data = { userId };
    return axios.request({
        url: 'platform/user/password/reset',
        data,
        method: 'post'
    });
};

export const updateOrg = ({ userId, organizationIds }) => {
    const data = {
        userId,
        organizationIds
    };
    return axios.request({
        url: 'platform/user/updateUserOrganization',
        data,
        method: 'post'
    });
};
