/*
 * @Description: 基础数据设置-器械分类-集团
 * @Author: kuangyazhou
 * @Date: 2019-07-03 15:15:13
 * @LastEditTime: 2019-07-04 11:27:36
 * @LastEditors: Please set LastEditors
 */
import axios from '@/libs/api.request';

/**
 * @description: 查找器械分类
 * @param organizationId 组织id
 * @param deviceClassifyType 器械类别id
 * @param deviceClassifyCode 器械分类
 * @param deviceClassifyName 分类名称
 * @return:
 */
export const getMachineList = ({
    organizationId,
    deviceClassifyCode,
    deviceClassifyType,
    deviceClassifyName,
    status,
    pageNo,
    pageSize
}) => {
    const params = {
        organizationId,
        deviceClassifyCode,
        deviceClassifyType,
        deviceClassifyName,
        status,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'device/classify/list',
        params,
        method: 'get'
    });
};

/**
 * @description: 增加器械分类
 * @param organizationId 组织id
 * @param deviceClassifyType 器械类别id
 * @param deviceClassifyCode 器械分类
 * @param deviceClassifyName 分类名称
 * @return:
 */
export const addDeviceType = ({
    organizationId,
    deviceClassifyType,
    deviceClassifyCode,
    deviceClassifyName,
    status
}) => {
    const data = {
        organizationId,
        deviceClassifyType,
        deviceClassifyCode,
        deviceClassifyName,
        status
    };
    return axios.request({
        url: 'device/classify/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 修改器械分类
 * @param organizationId 组织id
 * @param deviceClassifyType 器械类别id
 * @param deviceClassifyCode 器械分类
 * @param deviceClassifyName 分类名称
 * @return:
 */
export const updateDevice = ({
    id,
    deviceClassifyType,
    deviceClassifyCode,
    deviceClassifyName,
    status
}) => {
    const data = {
        id,
        deviceClassifyType,
        deviceClassifyCode,
        deviceClassifyName,
        status
    };
    return axios.request({
        url: 'device/classify/update',
        data,
        method: 'post'
    });
};

/**
 * @description: 获取器械类别
 * @param level 传1 代表组织
 * @param levelId 条件必填，当level不为0时必填：组织ID或公司ID（根据level选择）
 * @param fieldCode 传device_classify_type
 * @param fieldCodes 以,分隔传多个参数，精准查询
 * @return:
 */
export const getMachineType = ({ level, levelId, fieldCode }) => {
    const params = {
        level,
        levelId,
        fieldCode
    };
    return axios.request({
        url: 'system/field/query/list',
        params,
        method: 'get'
    });
};
