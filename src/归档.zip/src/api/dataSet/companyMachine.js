/*
 * @Description: 基础数据设置-器械分类-公司
 * @Author: your name
 * @Date: 2019-07-03 15:15:21
 * @LastEditTime: 2019-07-24 17:30:16
 * @LastEditors: Please set LastEditors
 */

import axios from '@/libs/api.request';

/**
 * @description: 查询公司器械分类
 * @param enterpriseId 公司id
 * @param deviceClassifyName 分类名称
 * @param deviceClassifyType 器械分类
 * @param deviceClassifyCode 器械类别id
 * @return:
 */
export const getMachineList = ({
    enterpriseId,
    deviceClassifyCode,
    deviceClassifyType,
    deviceClassifyName,
    pageNo,
    pageSize
}) => {
    const params = {
        enterpriseId,
        deviceClassifyCode,
        deviceClassifyType,
        deviceClassifyName,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'enterprise/device/classify/list',
        params,
        method: 'get'
    });
};

/**
 * @description: 查询未引入的器械分类
 * @param enterpriseId 公司id
 * @param organizationId 组织id
 * @return:
 */

export const getUnsedList = ({ enterpriseId, organizationId }) => {
    const params = {
        enterpriseId,
        organizationId
    };
    return axios.request({
        url: 'device/classify/listUnused',
        params,
        method: 'get'
    });
};

/**
 * @description: 引入器械分类
 * @param enterpriseId number 公司id
 * @param deviceClassifyIds Array 组织分类id
 * @return:
 */
export const importDevice = ({ enterpriseId, deviceClassifyIds }) => {
    const data = {
        enterpriseId,
        deviceClassifyIds
    };
    return axios.request({
        url: 'enterprise/device/classify/import',
        data,
        method: 'post'
    });
};

/**
 * @description: 删除器械分类
 * @param enterpriseId number 公司id
 * @param deviceClassifyIds Array 组织分类id
 * @return:
 */
export const delDevice = ({ enterpriseId, deviceClassifyIds }) => {
    const data = {
        enterpriseId,
        deviceClassifyIds
    };
    return axios.request({
        url: 'enterprise/device/classify/delete',
        data,
        method: 'post'
    });
};
