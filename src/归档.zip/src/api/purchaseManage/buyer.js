import axios from '@/libs/api.request';

/**
 * 查看采购员列表
 * @param realName
 * @param pageNo
 * @param pageSize
 * @returns {*|never}
 */
export const getBuyerList = ({ realName, pageNo, pageSize }) => {
    const data = {
        realName,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'purchase/purchaser/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取可新增的用户列表
 * @param realName
 * @param departmentName
 * @returns {*|never}
 */
export const getUsersList = ({ realName, departmentName }) => {
    const data = {
        realName,
        departmentName
    };
    return axios.request({
        url: 'purchase/purchaser/user/list',
        params: data,
        method: 'get'
    });
};

/**
 * 批量新增采购员
 * @param userList
 * @returns {*|never}
 */
export const addBuyer = ({ userList }) => {
    const data = {
        userList
    };
    return axios.request({
        url: 'purchase/purchaser/save',
        data: data,
        method: 'post'
    });
};

/**
 * 设置采购员无效
 * @param id
 * @returns {*|never}
 */
export const purchaserDisable = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'purchase/purchaser/disable',
        data: data,
        method: 'post'
    });
};

/**
 * 设置采购员有效
 * @param id
 * @returns {*|never}
 */
export const purchaserEnable = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'purchase/purchaser/enable',
        data: data,
        method: 'post'
    });
};

/**
 * 关联采购员的专业分组
 * @param purchaserId
 * @param professionalGroupIds
 * @returns {*|never}
 */
export const addSpecialtyGroup = ({ purchaserId, professionalGroupIds }) => {
    const data = {
        purchaserId,
        professionalGroupIds
    };
    return axios.request({
        url: 'purchaser/professional/addProfessionalGroups',
        data: data,
        method: 'post'
    });
};

/**
 * 获取已关联的专业分组
 * @param purchaserId
 * @returns {*|never}
 */
export const getProfessionalList = ({ purchaserId }) => {
    const data = {
        purchaserId
    };
    return axios.request({
        url: 'purchaser/professional/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取本公司所有供应商
 * @returns {*|never}
 */
export const getAllSupplierList = () => {
    const data = {};
    return axios.request({
        url: 'purchaser/supplier/enterpriseSupplierList',
        params: data,
        method: 'get'
    });
};

/**
 * 获取已关联的供应商列表
 * @param purchaserId
 * @returns {*|never}
 */
export const getSaveSupplierList = ({ purchaserId, supplierName, supplierEnableCode, pageNo, pageSize }) => {
    const data = {
        purchaserId,
        supplierName,
        supplierEnableCode,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'purchaser/supplier/list',
        params: data,
        method: 'get'
    });
};

/**
 * 批量添加采购员关联的供应商
 * @param purchaserId
 * @param supplierEnableCodes
 * @returns {*|never}
 */
export const addSupplier = ({ purchaserId, supplierEnableCodes }) => {
    const data = {
        purchaserId,
        supplierEnableCodes
    };
    return axios.request({
        url: 'purchaser/supplier/addSuppliers',
        data: data,
        method: 'post'
    });
};
