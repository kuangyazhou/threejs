import axios from '@/libs/api.request';

/**
 * 获取采购组列表
 * @param purchaseGroupName
 * @param purchaseOrganizationId
 * @param pageNo
 * @param pageSize
 * @returns {*|never}
 */
export const getPurchaseGroupList = ({
    purchaseGroupName,
    purchaseOrganizationId,
    pageNo,
    pageSize
}) => {
    const data = {
        purchaseGroupName,
        purchaseOrganizationId,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'purchase/group/pageList',
        params: data,
        method: 'get'
    });
};

/**
 * 查找当前公司下的所有采购组织
 * @returns {*|never}
 */
export const getCompanyPurchaseOrganizationList = () => {
    const data = {};
    return axios.request({
        url: 'purchase/organization/select/list',
        params: data,
        method: 'get'
    });
};

/**
 * 查找所有采购组织
 * @returns {*|never}
 */
export const getPurchaseOrganizationList = () => {
    const data = {};
    return axios.request({
        url: 'purchase/organization/select/alllist',
        params: data,
        method: 'get'
    });
};

/**
 * 新增采购组
 * @param purchaseOrganizationId  采购组织id
 * @param purchaseGroupName  采购组名称
 * @param organizationId
 * @param purchaserIds
 * @returns {*|never}
 */
export const addPurchaseGroup = ({
    purchaseOrganizationId,
    purchaseGroupName,
    organizationId,
    purchaserIds
}) => {
    const data = {
        purchaseOrganizationId,
        purchaseGroupName,
        organizationId,
        purchaserIds
    };
    return axios.request({
        url: 'purchase/group/save',
        data: data,
        method: 'post'
    });
};

/**
 * 获取单个采购组明细
 * @param id
 * @returns {*|never}
 */
export const getPurchaseGroupDetail = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'purchase/group/queryOne',
        params: data,
        method: 'get'
    });
};

/**
 *  编辑采购组
 * @param purchaseOrganizationId
 * @param purchaseGroupName
 * @param id
 * @returns {*|never}
 */
export const editPurchaseGroup = ({
    purchaseOrganizationId,
    purchaseGroupName,
    id
}) => {
    const data = {
        purchaseOrganizationId,
        purchaseGroupName,
        id
    };
    return axios.request({
        url: 'purchase/group/update',
        data: data,
        method: 'post'
    });
};

/**
 * 查询本公司所有采购员
 * @param realName
 * @param departmentName
 * @param purchaseGroupId
 * @returns {*|never}
 */
export const getCompanyBuyerList = ({ realName, departmentName, purchaseGroupId }) => {
    const data = {
        realName,
        departmentName,
        purchaseGroupId
    };
    return axios.request({
        url: 'purchase/purchaser/purchasePurchaserList',
        params: data,
        method: 'get'
    });
};

/**
 * 采购组新增采购员
 * @param purchaseGroupId
 * @param purchaserId
 * @returns {*|never}
 */
export const purchaseGroupAddBuyer = ({ purchaseGroupId, purchaserIds }) => {
    const data = {
        purchaseGroupId,
        purchaserIds
    };
    return axios.request({
        url: 'purchase/group/addMember',
        data: data,
        method: 'post'
    });
};

/**
 * 采购组删除采购员
 * @param purchaseGroupPurchaseId
 * @returns {*|never}
 */
export const purchaseGroupDeleteBuyer = ({ purchaseGroupPurchaseId }) => {
    const data = {
        purchaseGroupPurchaseId
    };
    return axios.request({
        url: 'purchase/group/deleteMember',
        data: data,
        method: 'post'
    });
};

/**
 * 删除采购组
 * @param id
 * @returns {*|never}
 */
export const delPurchaseGroup = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'purchase/group/delete',
        data: data,
        method: 'post'
    });
};
