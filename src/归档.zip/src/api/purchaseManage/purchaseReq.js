/*
 * @Description: 采购需求接口
 * @Author: kuangyazhou
 * @Date: 2019-08-12 19:21:22
 * @LastEditTime: 2019-08-12 20:03:30
 * @LastEditors: Please set LastEditors
 */
import axios from '@/libs/api.request';

/**
 * @description: 获取采购需求列表
 * @param {type} processed 0-等处理，1-已处理
 * @param {type} bizType 来源类型，字符窜
 * @param {type} specializedGroupId 专业分组id
 * @param {type} commodityName 物料名称
 * @param {type} pageNo
 * @param {type} pageSize
 * @return:
 */
export const reqList = ({ processed, bizType, specializedGroupId, commodityName, pageNo, pageSize }) => {
    const data = { processed, bizType, specializedGroupId, commodityName, pageNo, pageSize };
    return axios.request({
        url: 'purchase/requirement/process/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 查看库存明细
 * @param {type} id
 * @return:
 */
export const viewDetail = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'purchase/requirement/inventory/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 匹配库存
 * @return:
 */
export const matchInve = () => {
    return axios.request({
        url: 'purchase/requirement/match/inventory',
        method: 'post'
    });
};

/**
 * @description: 生成采购单
 * @return:
 */
export const createPurchase = () => {
    return axios.request({
        url: 'purchase/requirement/generate/purchase/order',
        method: 'post'
    });
};
