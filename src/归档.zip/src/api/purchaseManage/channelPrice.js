/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-14 11:48:35
 * @LastEditTime: 2019-08-14 11:48:35
 * @LastEditors: your name
 */
import axios from '@/libs/api.request';

/**
 * 获取渠道价格列表
 * @param supplierEnableCode
 * @param commodityName
 * @param commodityCode
 * @param specializedGroupName
 * @param status
 * @param pageNo
 * @param pageSize
 * @param initCommodityHandleId 首营处理单ID
 * @returns {*|never}
 */
export const getChannelPriceList = ({
    supplierEnableCode,
    commodityName,
    specializedGroupName,
    status,
    pageNo,
    pageSize,
    initCommodityHandleId,
    commodityCode
}) => {
    const data = {
        commodityName,
        specializedGroupName,
        status,
        pageNo,
        pageSize,
        initCommodityHandleId,
        commodityCode,
        supplierEnableCode
    };
    return axios.request({
        url: 'purchase/price/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取公司物料列表
 * @param pageNo
 * @param pageSize
 * @param commodityName
 * @param specializedGroup
 * @returns {*|never}
 */
export const getCompanyMaterialList = ({
    pageNo,
    pageSize,
    commodityName,
    specializedGroup
}) => {
    const data = {
        pageNo,
        pageSize,
        commodityName,
        specializedGroup
    };
    return axios.request({
        url: 'commodity/enterprise/select/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增渠道价格
 * @param commodityCode
 * @param supplierEnableCode
 * @param selectPurchaseOrganizationId
 * @param purchasePrice
 * @param unitCode
 * @param currencyId
 * @param marketPrice
 * @param inquiryTime
 * @param taxRate
 * @param purchaseCycle
 * @returns {*|never}
 */
export const addChannelPrice = ({
    commodityCode,
    supplierEnableCode,
    selectPurchaseOrganizationId,
    purchasePrice,
    unitCode,
    currencyId,
    marketPrice,
    inquiryTime,
    taxRate,
    purchaseCycle
}) => {
    const data = {
        commodityCode,
        supplierEnableCode,
        selectPurchaseOrganizationId,
        purchasePrice,
        unitCode,
        currencyId,
        marketPrice,
        inquiryTime,
        taxRate,
        purchaseCycle
    };
    return axios.request({
        url: 'purchase/price/save',
        data: data,
        method: 'post'
    });
};

/**
 * 编辑渠道价格
 * @param commodityCode
 * @param supplierEnableCode
 * @param selectPurchaseOrganizationId
 * @param purchasePrice
 * @param unitCode
 * @param currencyId
 * @param marketPrice
 * @param inquiryTime
 * @param taxRate
 * @param id
 * @param purchaseCycle
 * @returns {*|never}
 */
export const editChannelPrice = ({
    commodityCode,
    supplierEnableCode,
    selectPurchaseOrganizationId,
    purchasePrice,
    unitCode,
    currencyId,
    marketPrice,
    inquiryTime,
    taxRate,
    purchaseCycle,
    id
}) => {
    const data = {
        commodityCode,
        supplierEnableCode,
        selectPurchaseOrganizationId,
        purchasePrice,
        unitCode,
        currencyId,
        marketPrice,
        inquiryTime,
        taxRate,
        purchaseCycle,
        id
    };
    return axios.request({
        url: 'purchase/price/update',
        data: data,
        method: 'post'
    });
};

/**
 * 获取物料包装单位
 * @param commodityCode
 * @param {type} status 状态
 * @param {type} isDeleted 是否删除
 * @param {type} isDefault 是否默认
 * @returns {*|never}
 */
export const getMaterialUnitList = ({ commodityCode, commodityId, status, isDeleted, isDefault }) => {
    const data = {
        commodityCode,
        commodityId,
        status: 3,
        isDeleted: 1,
        isDefault: 1
    };
    return axios.request({
        url: 'commodity/package/organization/list',
        params: data,
        method: 'get'
    });
};

/**
 * 提交
 * @param ids
 * @returns {*|never}
 */
export const submitChannelPrice = ({ ids }) => {
    const data = {
        ids
    };
    return axios.request({
        url: 'purchase/price/submit',
        data: data,
        method: 'post'
    });
};

/**
 * 审核
 * @param ids
 * @returns {*|never}
 */
export const approveChannelPrice = ({ ids }) => {
    const data = {
        ids
    };
    return axios.request({
        url: 'purchase/price/approve',
        data: data,
        method: 'post'
    });
};

/**
 * 反审核
 * @param ids
 * @returns {*|never}
 */
export const unapproveChannelPrice = ({ ids }) => {
    const data = {
        ids
    };
    return axios.request({
        url: 'purchase/price/unapprove',
        data: data,
        method: 'post'
    });
};
