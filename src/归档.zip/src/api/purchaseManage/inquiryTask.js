import axios from '@/libs/api.request';

/**
 * 获取询价任务列表
 * @param receiveStatus
 * @param specializedGroupName
 * @param purchaserName
 * @param startDate
 * @param endDate
 * @param pageNo
 * @param pageSize
 * @param customerName
 * @param createName
 * @param status
 * @param commodityName
 * @returns {*|never}
 */
export const getInquiryTaskList = ({
    receiveStatus,
    specializedGroupName,
    purchaserName,
    startDate,
    endDate,
    customerName,
    createName,
    pageNo,
    pageSize,
    status,
    commodityName
}) => {
    const data = {
        receiveStatus,
        specializedGroupName,
        purchaserName,
        startDate,
        endDate,
        customerName,
        createName,
        pageNo,
        pageSize,
        status,
        commodityName
    };
    return axios.request({
        url: 'inquiry/list',
        params: data,
        method: 'get'
    });
};

/**
 * 分配询价任务
 * @param purchaserId  分配才传，领取时不传
 * @param inquiryIds
 * @returns {*|never}
 */
export const distributionInquiryTask = ({ purchaserId, inquiryIds }) => {
    const data = {
        purchaserId,
        inquiryIds
    };
    return axios.request({
        url: 'inquiry/receive',
        data: data,
        method: 'post'
    });
};

/**
 * 转交
 * @param purchaserId
 * @param id
 * @returns {*|never}
 */
export const transferInquiryTask = ({ purchaserId, id }) => {
    const data = {
        purchaserId,
        id
    };
    return axios.request({
        url: 'inquiry/change',
        data: data,
        method: 'post'
    });
};

/**
 * 退回询价任务
 * @param id
 * @returns {*|never}
 */
export const returnInquiryTask = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'inquiry/return',
        data: data,
        method: 'post'
    });
};

/**
 *  驳回询价任务
 * @param id
 * @param rejectDescription
 * @returns {*|never}
 */
export const rejectInquiryTask = ({ id, rejectDescription }) => {
    const data = {
        id, rejectDescription
    };
    return axios.request({
        url: 'inquiry/reject',
        data: data,
        method: 'post'
    });
};

/**
 * 关联物料
 * @param commodityCode
 * @param id
 * @returns {*|never}
 */
export const inquiryTaskRelationMaterial = ({ commodityCode, id }) => {
    const data = {
        commodityCode,
        id
    };
    return axios.request({
        url: 'inquiry/relation/commodity',
        data: data,
        method: 'post'
    });
};

/**
 *  关联询价
 * @param relationInquiryId
 * @param id
 * @returns {*|never}
 */
export const inquiryTaskRelationInquiry = ({ relationInquiryId, id }) => {
    const data = {
        relationInquiryId,
        id
    };
    return axios.request({
        url: 'inquiry/relation/inquiry',
        data: data,
        method: 'post'
    });
};

/**
 * 获取询价任务首营信息
 * @param id
 * @returns {*|never}
 */
export const getInquiryTaskFirstInfo = ({
    id
}) => {
    const data = {
        id
    };
    return axios.request({
        url: 'inquiry/init/commodity/get',
        params: data,
        method: 'get'
    });
};

/**
 * 获取自己领取的询价任务列表
 * @param specializedGroupName
 * @param commodityBrand
 * @param customerName
 * @param pageNo
 * @param pageSize
 * @param status
 * @returns {*|never}
 */
export const getReceiveInquiryTaskList = ({
    specializedGroupName,
    commodityBrand,
    customerName,
    pageNo,
    pageSize,
    status
}) => {
    const data = {
        specializedGroupName,
        commodityBrand,
        customerName,
        pageNo,
        pageSize,
        status
    };
    return axios.request({
        url: 'inquiry/receive/list',
        params: data,
        method: 'get'
    });
};

/**
 *  获取询价单列表
 * @param inquiryId
 * @param pageNo
 * @param pageSize
 * @returns {*|never}
 */
export const getInquiryOrderList = ({ inquiryId, pageNo, pageSize }) => {
    const data = {
        inquiryId,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'inquiry/order/list',
        params: data,
        method: 'get'
    });
};

/**
 *  获取可引入的物料
 * @returns {*|never}
 */
export const getImportInquiryTaskMaterial = () => {
    const data = {};
    return axios.request({
        url: 'inquiry/receive/import/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取询价单明细
 * @param inquiryOrderId
 * @returns {*|never}
 */
export const getInquiryOrderDetail = ({ inquiryOrderId }) => {
    const data = { inquiryOrderId };
    return axios.request({
        url: 'inquiry/inquiry/order/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增询价单
 * @param customerName
 * @param supplierName
 * @param negotiatingMatter
 * @param items
 * @returns {*|never}
 */
export const addInquiryOrder = ({
    customerName,
    supplierName,
    negotiatingMatter,
    items
}) => {
    const data = {
        customerName,
        supplierName,
        negotiatingMatter,
        items
    };
    return axios.request({
        url: 'inquiry/order/save',
        data: data,
        method: 'post'
    });
};

/**
 * 编辑询价单
 * @param customerName
 * @param supplierName
 * @param negotiatingMatter
 * @param items
 * @param id
 * @returns {*|never}
 */
export const editInquiryOrder = ({
    customerName,
    supplierName,
    negotiatingMatter,
    items,
    id
}) => {
    const data = {
        customerName,
        supplierName,
        negotiatingMatter,
        items,
        id
    };
    return axios.request({
        url: 'inquiry/order/update',
        data: data,
        method: 'post'
    });
};

/**
 * 删除询价单
 * @param id
 * @returns {*|never}
 */
export const delInquiryOrder = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'inquiry/order/delete',
        data: data,
        method: 'post'
    });
};

/**
 * 提交询价单
 * @param id
 * @returns {*|never}
 */
export const submitInquiryOrder = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'inquiry/order/submit',
        data: data,
        method: 'post'
    });
};

/**
 * 撤回询价单
 * @param id
 * @returns {*|never}
 */
export const cancelInquiryOrder = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'inquiry/order/cancel',
        data: data,
        method: 'post'
    });
};

/**
 * 获取谈判记录列表
 * @param inquiryOrderId
 * @returns {*|never}
 */
export const getNegotiationRecord = ({ inquiryOrderId }) => {
    const data = { inquiryOrderId };
    return axios.request({
        url: 'purchase/negotiation/record/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增谈判记录
 * @param recordMsg
 * @param inquiryOrderId
 * @returns {*|never}
 */
export const addNegotiationRecord = ({ recordMsg, inquiryOrderId }) => {
    const data = {
        recordMsg, inquiryOrderId
    };
    return axios.request({
        url: 'purchase/negotiation/record/save',
        data: data,
        method: 'post'
    });
};

/**
 * 删除谈判记录
 * @param id
 * @returns {*|never}
 */
export const delNegotiationRecord = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'purchase/negotiation/record/delete',
        data: data,
        method: 'post'
    });
};

/**
 * 编辑询价任务首营物料信息
 * @param purchaseOrganizationId
 * @param customerName
 * @param commodityName
 * @param commodityBrand
 * @param commoditySpecializedGroupId
 * @param instrumentName
 * @param manufacturer
 * @param outboundMethodId
 * @param deliveryMethodId
 * @param commoditySpec
 * @param commodityNumber
 * @param commodityUnitName
 * @param price
 * @param metaSupplier
 * @param writeDescription
 * @param yearOrderNumber
 * @param yearTestNumber
 * @param id
 * @returns {*|never}
 */
export const editInquiryTaskInfo = ({
    purchaseOrganizationId,
    customerName,
    commodityName,
    commodityBrand,
    commoditySpecializedGroupId,
    instrumentName,
    manufacturer,
    outboundMethodId,
    deliveryMethodId,
    commoditySpec,
    commodityNumber,
    commodityUnitName,
    price,
    metaSupplier,
    writeDescription,
    yearOrderNumber,
    yearTestNumber,
    id
}) => {
    const data = {
        purchaseOrganizationId,
        customerName,
        commodityName,
        commodityBrand,
        commoditySpecializedGroupId,
        instrumentName,
        manufacturer,
        outboundMethodId,
        deliveryMethodId,
        commoditySpec,
        commodityNumber,
        commodityUnitName,
        price,
        metaSupplier,
        writeDescription,
        yearOrderNumber,
        yearTestNumber,
        id
    };
    return axios.request({
        url: 'inquiry/commodity/update',
        data: data,
        method: 'post'
    });
};

/**
 * 完成询价任务
 * @param id
 * @returns {*|never}
 */
export const completeInquiryTask = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'inquiry/complete',
        data: data,
        method: 'post'
    });
};

/**
 * 获取首营处理订单列表
 * @param customerName
 * @param createName
 * @param startDate
 * @param endDate
 * @param handleStatus
 * @returns {*|never}
 */
export const getFirstCampHandleList = ({ customerName, createName, startDate, endDate, handleStatus }) => {
    const data = { customerName, createName, startDate, endDate, handleStatus };
    return axios.request({
        url: 'init/commodity/handle/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取首营准备信息
 * @param id
 * @returns {*|never}
 */
export const getFirstCampInfo = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'init/commodity/handle/get',
        params: data,
        method: 'get'
    });
};

/**
 * 首营关联客户
 * @param id
 * @param customerId
 * @returns {*|never}
 * @constructor
 */
export const firstCampRelationCustomer = ({ id, customerId }) => {
    const data = {
        id, customerId
    };
    return axios.request({
        url: 'init/commodity/handle/relation/customer',
        data: data,
        method: 'post'
    });
};

/**
 * 首营关联物料
 * @param id
 * @param commodityId
 * @returns {*|never}
 * @constructor
 */
export const firstCampRelationCommodity = ({ id, commodityId }) => {
    const data = {
        id, commodityId
    };
    return axios.request({
        url: 'init/commodity/handle/relation/commodity',
        data: data,
        method: 'post'
    });
};

/**
 * 首营关联供应商
 * @param initCommodityHandleSupplierId
 * @param supplierId
 * @returns {*|never}
 */
export const firstCampRelationSupplier = ({ initCommodityHandleSupplierId, supplierId }) => {
    const data = {
        initCommodityHandleSupplierId, supplierId
    };
    return axios.request({
        url: 'init/commodity/handle/relation/supplier',
        data: data,
        method: 'post'
    });
};

/**
 * 首营处理
 * @param id
 * @returns {*|never}
 */
export const firstCampHandle = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'init/commodity/handle/complete',
        data: data,
        method: 'post'
    });
};

/**
 * 获取公司供应商列表
 * @param pageSize
 * @param pageNo
 * @returns {*|never}
 */
export const getAllSupplierList = ({ pageSize, pageNo, supplierName }) => {
    const data = { pageSize, pageNo, supplierName };
    return axios.request({
        url: 'purchaser/supplier/enterpriseSupplierList',
        params: data,
        method: 'get'
    });
};
