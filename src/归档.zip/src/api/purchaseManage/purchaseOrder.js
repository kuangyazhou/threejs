/*
 * @Description: 采购订单接口
 * @Author: kuangyazhou
 * @Date: 2019-08-12 19:21:22
 * @LastEditTime: 2019-08-12 20:03:30
 * @LastEditors: Please set LastEditors
 */
import axios from '@/libs/api.request';

/**
 * @description: 采购订单列表
 * @param {type} supplierEnableCode 供应商生效对象编码
 * @param {type} orderNo 采购单号
 * @param {type} commodityName 物料名称
 * @param {type} startDate 起时间 时间字符串
 * @param {type} endDate 结束时间 时间字符串
 * @param {type} pageNo
 * @param {type} pageSize
 * @return:
 */
export const purchaseOrderList = ({ supplierEnableCode, orderNo, commodityName, startDate, endDate, pageNo, pageSize }) => {
    const data = { supplierEnableCode, orderNo, commodityName, startDate, endDate, pageNo, pageSize };
    return axios.request({
        url: 'purchase/order/organization/task/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 查询订单明细
 * @param {type} purchaseOrderId 采购订单id
 * @param {type} isRed 传1 表示只选择可做红单的明细列表
 * @param {type} startDate 起时间 时间字符串
 * @param {type} endDate 结束时间 时间字符串
 * @param {type} supplierEnableCode 供应商code
 * @param {type} pageNo
 * @param {type} pageSize
 * @return:
 */
export const getOrderDetail = ({ supplierEnableCode, commodityName, orderItemStatus, purchaseId, purchaseOrderId, isRed, startDate, endDate, pageNo, pageSize }) => {
    const data = { supplierEnableCode, commodityName, orderItemStatus, purchaseId, purchaseOrderId, isRed, startDate, endDate, pageNo, pageSize };
    return axios.request({
        url: 'purchase/order/item/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 采购订单新增、保存、编辑
 * @param {type} orderType 订单类型
 * @param {type} supplierEnableCode 供应商码
 * @param {type} supplierId 供应商id
 * @param {type} currencyId 币种id
 * @param {type} currencyRate 汇率
 * @param {type} orderRemark 采购摘要
 * @param {type} inventoryOrganizationId 库存组织id
 * @param {type} inventoryOrganizationCode 库存组织code
 * @param {type} purchaseId
 * @param {type} warehouseId 仓库id
 * @param {type} warehouseCode 仓库code
 * @param {type} items
 * @return:
 */
export const purchaseOrderSave = ({ id, orderType, supplierEnableCode, supplierId, currencyId, currencyRate, orderRemark, inventoryOrganizationId, inventoryOrganizationCode, purchaseId, warehouseId, warehouseCode, items }) => {
    const data = { id, orderType, supplierEnableCode, supplierId, currencyId, currencyRate, orderRemark, inventoryOrganizationId, inventoryOrganizationCode, purchaseId, warehouseId, warehouseCode, items };
    return axios.request({
        url: 'purchase/order/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 采购订单提交
 * @param {type} id
 * @return:
 */
export const purchaseSubmit = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'purchase/order/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 采购订单撤回
 * @param {type} id
 * @return:
 */
export const purchaseReturn = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'purchase/order/return',
        data,
        method: 'post'
    });
};

/**
 * @description: 采购订单通过
 * @param {type} id
 * @return:
 */
export const purchasePass = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'purchase/order/approve',
        data,
        method: 'post'
    });
};

/**
 * @description: 采购订单删除
 * @param {type} id
 * @return:
 */
export const purchaseDel = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'purchase/order/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 红字订单新增、保存、编辑
 * @param {type} redOrderId 原订单id
 * @param {type} redOrderItemId 原订单明细id
 * @param {type} orderType 订单类型
 * @param {type} supplierEnableCode 供应商码
 * @param {type} supplierId 供应商id
 * @param {type} currencyId 币种id
 * @param {type} currencyRate 汇率
 * @param {type} orderRemark 采购摘要
 * @param {type} inventoryOrganizationId 库存组织id
 * @param {type} inventoryOrganizationCode 库存组织code
 * @param {type} purchaseId
 * @param {type} warehouseId 仓库id
 * @param {type} warehouseCode 仓库code
 * @param {type} items
 * @return:
 */
export const redSave = ({ redOrderId, redOrderItemId, orderType, supplierEnableCode, supplierId, currencyId, currencyRate, orderRemark, inventoryOrganizationId, inventoryOrganizationCode, purchaseId, warehouseId, warehouseCode, items }) => {
    const data = { redOrderId, redOrderItemId, orderType, supplierEnableCode, supplierId, currencyId, currencyRate, orderRemark, inventoryOrganizationId, inventoryOrganizationCode, purchaseId, warehouseId, warehouseCode, items };
    return axios.request({
        url: 'purchase/order/red/save',
        data,
        method: 'post'
    });
};
