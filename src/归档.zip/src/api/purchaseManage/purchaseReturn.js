import axios from '@/libs/api.request';

/**
 * 获取采购退货单明细
 * @param pageNo
 * @param pageSize
 * @param inventoryOrganizationId
 * @param warehouseId
 * @param status
 * @param supplierName
 * @param purchaseRefundOrderCode
 * @returns {*|never}
 */
export const getPurchaseReturnDetailList = ({ pageNo, pageSize, inventoryOrganizationId, warehouseId, status, supplierName, purchaseRefundOrderCode }) => {
    const data = {
        pageNo, pageSize, inventoryOrganizationId, warehouseId, status, supplierName, purchaseRefundOrderCode
    };
    return axios.request({
        url: 'purchase/refund/order/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取可以退货的采购入库单
 * @param inventoryOrganizationId
 * @param warehouseId
 * @param inboundOrderCode
 * @param supplierName
 * @param createDate
 * @param pageNo
 * @param pageSize
 * @returns {*|never}
 */
export const getPurchaseInboundList = ({ pageNo, pageSize, inventoryOrganizationId, warehouseId, inboundOrderCode, supplierName, createDate }) => {
    const data = {
        pageNo, pageSize, inventoryOrganizationId, warehouseId, inboundOrderCode, supplierName, createDate
    };
    return axios.request({
        url: 'purchase/refund/order/select',
        params: data,
        method: 'get'
    });
};

/**
 * 新增采购退货单
 * @param inventoryOrganizationId
 * @param warehouseId
 * @param supplierId
 * @param receiveAddress
 * @param refundDate
 * @param refundTime
 * @param items
 * @returns {*|never}
 */
export const addPurchaseRefundOrder = ({
    inventoryOrganizationId,
    warehouseId,
    supplierId,
    receiveAddress,
    refundDate,
    refundTime,
    items
}) => {
    const data = {
        inventoryOrganizationId,
        warehouseId,
        supplierId,
        receiveAddress,
        refundDate,
        refundTime,
        items
    };
    return axios.request({
        url: 'purchase/refund/order/save',
        data,
        method: 'post'
    });
};

/**
 * 编辑采购退货单
 * @param inventoryOrganizationId
 * @param warehouseId
 * @param supplierId
 * @param receiveAddress
 * @param refundDate
 * @param refundTime
 * @param items
 * @param id
 * @returns {*|never}
 */
export const editPurchaseRefundOrder = ({
    inventoryOrganizationId,
    warehouseId,
    supplierId,
    receiveAddress,
    refundDate,
    refundTime,
    items,
    id
}) => {
    const data = {
        inventoryOrganizationId,
        warehouseId,
        supplierId,
        receiveAddress,
        refundDate,
        refundTime,
        items,
        id
    };
    return axios.request({
        url: 'purchase/refund/order/update',
        data,
        method: 'post'
    });
};

/**
 * 提交
 * @param ids
 * @returns {*|never}
 */
export const submitPurchaseRefundOrder = ({
    ids
}) => {
    const data = {
        ids
    };
    return axios.request({
        url: 'purchase/refund/order/submit',
        data,
        method: 'post'
    });
};

/**
 * 撤回
 * @param id
 * @returns {*|never}
 */
export const cancelPurchaseRefundOrder = ({
    ids
}) => {
    const data = {
        ids
    };
    return axios.request({
        url: 'purchase/refund/order/cancel',
        data,
        method: 'post'
    });
};

/**
 * 审核
 * @param id
 * @returns {*|never}
 */
export const approvePurchaseRefundOrder = ({
    ids
}) => {
    const data = {
        ids
    };
    return axios.request({
        url: 'purchase/refund/order/approve',
        data,
        method: 'post'
    });
};
