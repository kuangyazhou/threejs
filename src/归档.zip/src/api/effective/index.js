import axios from '@/libs/api.request';

/**
 * 查询采购需求列表
 * @param pageNo
 * @param pageSize
 * @param bizType
 * @param supplierEnableCode
 * @param commodityName
 * @param confirmStatus
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const getRequirementList = ({ pageNo, pageSize, bizType, supplierEnableCode, commodityName, confirmStatus, customerEnableCode }) => {
    const data = {
        pageNo,
        pageSize,
        bizType,
        supplierEnableCode,
        commodityName,
        confirmStatus,
        customerEnableCode
    };
    return axios.request({
        url: 'purchase/requirement/list',
        params: data,
        method: 'get'
    });
};

/**
 * 反馈页面供应商下拉列表
 * @param id
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const getModalSupplierList = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'purchase/requirement/supplier/info',
        params: data,
        method: 'get'
    });
};

/**
 * 效期接受
 * @param id
 * @param supplierEnableCode
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const acceptRequirement = ({ id, supplierEnableCode }) => {
    const data = {
        id,
        supplierEnableCode
    };
    return axios.request({
        url: 'purchase/requirement/accept',
        data,
        method: 'post'
    });
};

/**
 * 效期反馈
 * @param id
 * @param supplierEnableCode
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const feedbackRequirement = ({ id, feedBackEffectiveDate, recommandEffectiveDateType, supplierEnableCode, recommandEffectiveDate }) => {
    const data = {
        id,
        feedBackEffectiveDate,
        recommandEffectiveDateType,
        supplierEnableCode,
        recommandEffectiveDate
    };
    return axios.request({
        url: 'purchase/requirement/feedback',
        data,
        method: 'post'
    });
};

/**
 * 效期反馈
 * @param id
 * @param isAgree
 * @param confirmQuantity
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const feedbackConfirm = ({ id, isAgree, confirmQuantity }) => {
    const data = {
        id,
        isAgree,
        confirmQuantity
    };
    return axios.request({
        url: 'purchase/requirement/confirm',
        data,
        method: 'post'
    });
};
