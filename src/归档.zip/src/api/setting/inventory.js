import axios from '@/libs/api.request';

/**
 * 获取当前库存组织树
 * @returns {*|never}
 */
export const getSalesTree = () => {
    const data = {};
    return axios.request({
        url: 'inventory/organization/tree',
        params: data,
        method: 'get'
    });
};

/**
 * 新增库存组织
 * @param inventoryOrganizationCode
 * @param inventoryOrganizationName
 * @param parentId
 * @param status
 * @param nodeId 行政组织树id
 * @returns {*|never}
 */
export const addSalesNode = ({
    inventoryOrganizationCode,
    inventoryOrganizationName,
    parentId,
    status,
    nodeId
}) => {
    const data = {
        inventoryOrganizationCode,
        inventoryOrganizationName,
        parentId,
        status,
        nodeId
    };
    return axios.request({
        url: 'inventory/organization/save',
        data,
        method: 'post'
    });
};

/**
 * 编辑库存树
 * @param inventoryOrganizationCode
 * @param inventoryOrganizationName
 * @param parentId
 * @param status
 * @param nodeId 行政组织树id
 * @param id
 * @param isDeleted
 * @returns {*|never}
 */
export const editSalesNode = ({
    id,
    inventoryOrganizationCode,
    inventoryOrganizationName,
    parentId,
    status,
    nodeId,
    isDeleted
}) => {
    const data = {
        inventoryOrganizationCode,
        inventoryOrganizationName,
        parentId,
        status,
        nodeId,
        id,
        isDeleted
    };
    return axios.request({
        url: 'inventory/organization/update',
        data,
        method: 'post'
    });
};

/**
 * 查询可关联的公司
 * @returns {*|never}
 */
export const getCompanyList = () => {
    const data = {};
    return axios.request({
        url: 'inventory/organization/list/unattached/enterprise',
        params: data,
        method: 'get'
    });
};
