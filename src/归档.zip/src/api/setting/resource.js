import axios from '@/libs/api.request';

/**
 * 获取资源管理列表
 * @returns {ClientHttp2Stream | ClientRequest | * | void | AxiosPromise<any>}
 */
export const getResourceList = () => {
    return axios.request({
        url: 'resource/list',
        method: 'get'
    });
};

/**
 * 新增资源
 * @param parentId
 * @param resourceName
 * @param url
 * @param type
 * @param icon
 * @param sort
 * @param level
 * @param authorityScope 0-platform与oganization共有，1-platform,2-organization
 * @returns {ClientHttp2Stream | ClientRequest | * | void | AxiosPromise<any>}
 */
export const addResource = ({
    parentId,
    resourceName,
    url,
    type,
    icon,
    sort,
    level,
    authorityScope
}) => {
    const data = {
        parentId,
        resourceName,
        url,
        type,
        icon,
        sort,
        level,
        authorityScope
    };
    return axios.request({
        url: 'resource/create',
        data,
        method: 'post'
    });
};

/**
 * 修改资源
 * @param parentId
 * @param resourceName
 * @param url
 * @param type
 * @param icon
 * @param sort
 * @param id
 * @returns {ClientHttp2Stream | ClientRequest | * | void | AxiosPromise<any>}
 */
export const editResource = ({
    parentId,
    resourceName,
    url,
    type,
    icon,
    sort,
    id,
    level
}) => {
    const data = {
        parentId,
        resourceName,
        url,
        type,
        icon,
        sort,
        id,
        level
    };
    return axios.request({
        url: 'resource/update',
        data,
        method: 'post'
    });
};

/**
 * 删除资源
 * @param ids
 * @returns {ClientHttp2Stream | ClientRequest | * | void | AxiosPromise<any>}
 */
export const deleteResource = ids => {
    const data = {
        ids
    };
    return axios.request({
        url: 'resource/delete',
        data,
        method: 'post'
    });
};
