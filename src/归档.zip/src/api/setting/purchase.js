import axios from '@/libs/api.request';

/**
 * 获取当前采购组织树
 * @returns {*|never}
 */
export const getSalesTree = () => {
    const data = {};
    return axios.request({
        url: 'purchase/organization/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增采购组织
 * @param purchaseOrganizationCode
 * @param purchaseOrganizationName
 * @param parentId
 * @param status
 * @param nodeId 行政组织树id
 * @returns {*|never}
 */
export const addSalesNode = ({
    purchaseOrganizationCode,
    purchaseOrganizationName,
    parentId,
    status,
    nodeId
}) => {
    const data = {
        purchaseOrganizationCode,
        purchaseOrganizationName,
        parentId,
        status,
        nodeId
    };
    return axios.request({
        url: 'purchase/organization/save',
        data,
        method: 'post'
    });
};

/**
 * 编辑采购树
 * @param purchaseOrganizationCode
 * @param purchaseOrganizationName
 * @param parentId
 * @param status
 * @param nodeId 行政组织树id
 * @param id
 * @param isDeleted
 * @returns {*|never}
 */
export const editSalesNode = ({
    id,
    purchaseOrganizationCode,
    purchaseOrganizationName,
    parentId,
    status,
    nodeId,
    isDeleted
}) => {
    const data = {
        purchaseOrganizationCode,
        purchaseOrganizationName,
        parentId,
        status,
        nodeId,
        id,
        isDeleted
    };
    return axios.request({
        url: 'purchase/organization/update',
        data,
        method: 'post'
    });
};

/**
 * 查询可关联的公司
 * @returns {*|never}
 */
export const getCompanyList = () => {
    const data = {};
    return axios.request({
        url: 'purchase/organization/list/unattached/enterprise',
        params: data,
        method: 'get'
    });
};
