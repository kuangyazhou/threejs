import axios from '@/libs/api.request';

/**
 * 获取角色管理列表
 * @param pageNo
 * @param pageSize
 * @param roleName
 * @param roleCode
 * @returns {*|never}
 */
export const getRoleList = ({ pageNo, pageSize, roleName, roleCode }) => {
    const data = {
        pageNo,
        pageSize,
        roleName,
        roleCode
    };
    return axios.request({
        url: 'role/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增角色
 * @param roleName
 * @param roleCode
 * @param status
 * @returns {ClientHttp2Stream | ClientRequest | * | void | AxiosPromise<any>}
 */
export const addRole = ({ roleName, roleCode, status }) => {
    const data = {
        roleName,
        roleCode,
        status
    };
    return axios.request({
        url: 'role/create',
        data,
        method: 'post'
    });
};

/**
 * 修改角色
 * @param roleName
 * @param roleCode
 * @param status
 * @param id
 * @returns {ClientHttp2Stream | ClientRequest | * | void | AxiosPromise<any>}
 */
export const editRole = ({ roleName, roleCode, status, id }) => {
    const data = {
        roleName,
        roleCode,
        status,
        id
    };
    return axios.request({
        url: 'role/update',
        data,
        method: 'post'
    });
};

/**
 * 删除角色
 * @param ids
 * @returns {ClientHttp2Stream | ClientRequest | * | void | AxiosPromise<any>}
 */
export const deleteRole = ids => {
    const data = {
        ids
    };
    return axios.request({
        url: 'role/delete',
        data,
        method: 'post'
    });
};

/**
 * 根据角色id查询所拥有的权限资源
 * @param roleId
 * @returns {*|never}
 */
export const getResourceIds = ({ roleId }) => {
    const data = {
        roleId
    };
    return axios.request({
        url: 'resource/grant/list',
        params: data,
        method: 'get'
    });
};

/**
 * 角色关联权限
 * @param id
 * @param resourceIds
 * @returns {*|never}
 */
export const rolesConnectRosource = ({ id, resourceIds }) => {
    const data = {
        id,
        resourceIds
    };
    return axios.request({
        url: 'role/grant',
        data,
        method: 'post'
    });
};
