import axios from '@/libs/api.request';

/**
 * 获取当前销售组织树
 * @returns {*|never}
 */
export const getSalesTree = () => {
    const data = {};
    return axios.request({
        url: 'sale/organization/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增销售组织
 * @param saleOrganizationCode
 * @param saleOrganizationName
 * @param parentId
 * @param status
 * @param nodeId 行政组织树id
 * @returns {*|never}
 */
export const addSalesNode = ({
    saleOrganizationCode,
    saleOrganizationName,
    parentId,
    status,
    nodeId
}) => {
    const data = {
        saleOrganizationCode,
        saleOrganizationName,
        parentId,
        status,
        nodeId
    };
    return axios.request({
        url: 'sale/organization/save',
        data,
        method: 'post'
    });
};

/**
 * 编辑销售树
 * @param saleOrganizationCode
 * @param saleOrganizationName
 * @param parentId
 * @param status
 * @param nodeId 行政组织树id
 * @param id
 * @param isDeleted
 * @returns {*|never}
 */
export const editSalesNode = ({
    id,
    saleOrganizationCode,
    saleOrganizationName,
    parentId,
    status,
    nodeId,
    isDeleted
}) => {
    const data = {
        saleOrganizationCode,
        saleOrganizationName,
        parentId,
        status,
        nodeId,
        id,
        isDeleted
    };
    return axios.request({
        url: 'sale/organization/update',
        data,
        method: 'post'
    });
};

/**
 * 查询可关联的公司
 * @returns {*|never}
 */
export const getCompanyList = () => {
    const data = {};
    return axios.request({
        url: 'sale/organization/list/unattached/enterprise',
        params: data,
        method: 'get'
    });
};
