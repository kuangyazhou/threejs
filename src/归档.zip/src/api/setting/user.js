import axios from '@/libs/api.request';

/**
 * 用户分页
 * @param pageNo
 * @param pageSize
 * @param realName
 * @param mobile
 * @param status
 * @param locked
 * @param id
 * @returns {*|never}
 */
export const getUserList = ({
    pageNo,
    pageSize,
    realName,
    mobile,
    status,
    locked,
    id
}) => {
    const data = {
        pageNo,
        pageSize,
        realName,
        mobile,
        status,
        locked,
        id
    };
    return axios.request({
        url: 'organization/user/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增员工
 * @param userName
 * @param realName
 * @param mobile
 * @param email
 * @param sex
 * @param organizationId
 * @param departmentId
 * @param type
 * @param roleIds
 * @returns {*|never}
 */
export const addUser = ({
    userName,
    realName,
    mobile,
    email,
    sex,
    organizationId,
    departmentId,
    type,
    roleIds,
    idNumber
}) => {
    const data = {
        userName,
        realName,
        mobile,
        email,
        sex,
        organizationId,
        departmentId,
        type,
        roleIds,
        idNumber
    };
    return axios.request({
        url: 'organization/user/create',
        data,
        method: 'post'
    });
};

/**
 * 修改角色
 * @param userName
 * @param realName
 * @param mobile
 * @param email
 * @param sex
 * @param organizationId
 * @param departmentId
 * @param type
 * @param roleIds
 * @param id
 * @param status
 * @param locked
 * @returns {*|never}
 */
export const editUser = ({
    userName,
    realName,
    mobile,
    email,
    sex,
    organizationId,
    departmentId,
    type,
    roleIds,
    id,
    status,
    locked,
    idNumber
}) => {
    const data = {
        userName,
        realName,
        mobile,
        email,
        sex,
        organizationId,
        departmentId,
        type,
        roleIds,
        id,
        status,
        locked,
        idNumber
    };
    return axios.request({
        url: 'organization/user/update',
        data,
        method: 'post'
    });
};

/**
 * 重置密码
 * @param userId
 * @returns {*|never}
 */
export const resetUserPassword = ({ userId }) => {
    const data = {
        userId
    };
    return axios.request({
        url: 'organization/user/password/reset',
        data,
        method: 'post'
    });
};
