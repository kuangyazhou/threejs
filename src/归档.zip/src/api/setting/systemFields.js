import axios from '@/libs/api.request';

/**
 * 获取系统字段列表
 * @param id
 * @param fieldCode
 * @returns {*|never}
 */
export const getFieldList = ({ id, fieldCode }) => {
    const data = {
        id,
        fieldCode
    };
    return axios.request({
        url: 'system/field/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取系统字段资料
 * @param pageNo
 * @param pageSize
 * @param systemFieldId  系统字段id
 * @param levelId
 * @returns {*|never}
 */
export const getFieldValuesList = ({
    pageNo,
    pageSize,
    systemFieldId,
    levelId
}) => {
    const data = {
        pageNo,
        pageSize,
        systemFieldId,
        levelId
    };
    return axios.request({
        url: 'system/field/value/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增系统字典的值
 * @param systemFieldId
 * @param fieldValue
 * @param levelId
 * @param valueCode
 * @returns {*|never}
 */
export const addFieldValues = ({
    systemFieldId,
    fieldValue,
    levelId,
    valueCode
}) => {
    const data = {
        systemFieldId,
        fieldValue,
        levelId,
        valueCode
    };
    return axios.request({
        url: 'system/field/value/save',
        data,
        method: 'post'
    });
};

/**
 * 修改系统字段资料
 * @param systemFieldId  字段id
 * @param fieldValue  显示值
 * @param levelId  组织id或者公司id
 * @param id
 * @param status
 * @param valueCode
 * @returns {*|never}
 */
export const editFieldValues = ({
    systemFieldId,
    fieldValue,
    levelId,
    id,
    status,
    valueCode
}) => {
    const data = {
        systemFieldId,
        fieldValue,
        id,
        levelId,
        status,
        valueCode
    };
    return axios.request({
        url: 'system/field/value/update',
        data,
        method: 'post'
    });
};

/**
 * 删除系统字段资料
 * @param ids
 * @returns {ClientHttp2Stream | ClientRequest | * | void | AxiosPromise<any>}
 */
export const deleteFieldValues = ids => {
    const data = {
        ids
    };
    return axios.request({
        url: 'system/field/value/delete',
        data,
        method: 'post'
    });
};
