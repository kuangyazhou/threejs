import axios from '@/libs/api.request';

/**
 * 获取当前组织树
 * @param organizationId
 * @param status 1-只显示有效
 * @returns {*|never}
 */
export const getDepartTree = ({ organizationId, status }) => {
    const data = { organizationId, status };
    return axios.request({
        url: 'department/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增部门
 * @param departmentCode
 * @param departmentName
 * @param departmentType 1-公司部门 2-子公司
 * @param organizationId
 * @param parentId
 * @param parentType 1-公司部门 2-子公司 0-属于根级部门
 * @param status
 * @param parentNodeId 父树节点id
 * @returns {*|never}
 */
export const addDepartNode = ({
    departmentCode,
    departmentName,
    departmentType,
    organizationId,
    parentId,
    parentType,
    status,
    parentNodeId
}) => {
    const data = {
        departmentCode,
        departmentName,
        departmentType,
        organizationId,
        parentId,
        parentType,
        status,
        parentNodeId
    };
    return axios.request({
        url: 'department/add',
        data,
        method: 'post'
    });
};

/**
 * 编辑部门
 * @param departmentCode
 * @param departmentName
 * @param departmentType
 * @param organizationId
 * @param parentId
 * @param parentType
 * @param id 部门id
 * @param nodeId 树节点id
 * @param status
 * @param parentNodeId 父树节点id
 * @returns {*|never}
 */
export const editDepartNode = ({
    departmentCode,
    departmentName,
    departmentType,
    organizationId,
    parentId,
    parentType,
    id,
    nodeId,
    status,
    parentNodeId
}) => {
    const data = {
        departmentCode,
        departmentName,
        departmentType,
        organizationId,
        parentId,
        parentType,
        id,
        nodeId,
        status,
        parentNodeId
    };
    return axios.request({
        url: 'department/update',
        data,
        method: 'post'
    });
};

/**
 * 获取部门详细信息
 * @param id
 * @returns {*|never}
 */
export const getDepartInfo = ({ id, type }) => {
    const data = { id, type };
    return axios.request({
        url: 'department/getOne',
        params: data,
        method: 'get'
    });
};

/**
 * 删除部门
 * @param id
 * @returns {*|never}
 */
export const deleteDepartment = ({ id, type }) => {
    const data = {
        id,
        type
    };
    return axios.request({
        url: 'department/deleteOne',
        data,
        method: 'post'
    });
};
