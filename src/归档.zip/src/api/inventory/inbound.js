import axios from '@/libs/api.request';

/**
 * 获取采购入库单明细列表
 * @param pageNo
 * @param pageSize
 * @param inventoryOrganizationId
 * @param warehouseId
 * @param inboundOrderCode
 * @param supplierName
 * @param createDate
 * @returns {*|never}
 */
export const getPurchaseInboundList = ({ pageNo, pageSize, inventoryOrganizationId, warehouseId, inboundOrderCode, supplierName, createDate }) => {
    const data = {
        pageNo, pageSize, inventoryOrganizationId, warehouseId, inboundOrderCode, supplierName, createDate
    };
    return axios.request({
        url: 'inbound/order/list',
        params: data,
        method: 'get'
    });
};
