import axios from '@/libs/api.request';

/**
 * 获取销售出库单明细
 * @param pageNo
 * @param pageSize
 * @param inventoryOrganizationId
 * @param warehouseId
 * @param orderType
 * @returns {*|never}
 */
export const getSalesOutboundOrderDetailList = ({ pageNo, pageSize, inventoryOrganizationId, warehouseId, orderType }) => {
    const data = {
        pageNo, pageSize, inventoryOrganizationId, warehouseId, orderType
    };
    return axios.request({
        url: 'outbound/order/itemList',
        params: data,
        method: 'get'
    });
};

/**
 * 获取其他出库订单明细列表
 * @param pageNo
 * @param pageSize
 * @param orderType
 * @param warehouseId
 * @returns {*|never}
 */
export const getOtherOutboundOrderDetailList = ({ pageNo, pageSize, orderType, warehouseId }) => {
    const data = {
        pageNo, pageSize, orderType, warehouseId
    };
    return axios.request({
        url: 'outbound/loss/order/organization/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增销售出库单
 * @param orderType 出库单类型，1：销售出库单，2：其他出库单
 * @param sourceType 出库单来源1：发货通知单2：销售出库单3：转库单
 * @param orderSourceItem
 * @returns {*|never}
 */
export const addSaleOutboundOrder = ({
    orderType,
    sourceType,
    orderSourceItem
}) => {
    const data = {
        orderType,
        sourceType,
        orderSourceItem
    };
    return axios.request({
        url: 'outbound/order/add',
        data,
        method: 'post'
    });
};

/**
 * 新增红字销售出库单
 * @param items
 * @returns {*|never}
 */
export const adRedSaleOutboundOrder = ({
    items
}) => {
    const data = {
        items
    };
    return axios.request({
        url: 'outbound/order/addRed',
        data,
        method: 'post'
    });
};

/**
 * 获取出库单详细信息
 * @param id
 * @returns {*|never}
 */
export const getSalesOutboundOrderDetail = ({ id }) => {
    const data = {
        id
    };
    return axios.request({
        url: 'outbound/order/orderDetail',
        params: data,
        method: 'get'
    });
};

/**
 * 查看已审核的发货通知明细
 * @param inventoryOrganizationId  库存组织id
 * @param warehouseId
 * @param shipmentDate  发货日期，yyyy-MM-dd
 * @param shipmentTime 发货时间,1:全天，2：上午，3：下午
 * @param customerAddressId
 * @returns {*|never}
 */
export const getOutboundNoticeOrderDetail = ({ inventoryOrganizationId, warehouseId, shipmentDate, shipmentTime, customerAddressId }) => {
    const data = {
        inventoryOrganizationId, warehouseId, shipmentDate, shipmentTime, customerAddressId
    };
    return axios.request({
        url: 'outbound/order/notice/item/list',
        params: data,
        method: 'get'
    });
};

/**
 * 编辑出库单
 * @param orderId
 * @param addItems
 * @param deleteItems
 * @param updateItems
 * @returns {*|never}
 */
export const editSaleOutboundOrder = ({
    orderId,
    addItems,
    deleteItems,
    updateItems
}) => {
    const data = {
        orderId,
        addItems,
        deleteItems,
        updateItems
    };
    return axios.request({
        url: 'outbound/order/save',
        data,
        method: 'post'
    });
};

/**
 * 提交
 * @param id
 * @returns {*|never}
 */
export const submitSaleOutboundOrder = ({
    id
}) => {
    const data = {
        id
    };
    return axios.request({
        url: 'outbound/order/submit',
        data,
        method: 'post'
    });
};

/**
 * 撤回
 * @param id
 * @returns {*|never}
 */
export const revocationSaleOutboundOrder = ({
    id
}) => {
    const data = {
        id
    };
    return axios.request({
        url: 'outbound/order/revocation',
        data,
        method: 'post'
    });
};

/**
 * 审核
 * @param id
 * @returns {*|never}
 */
export const auditSaleOutboundOrder = ({
    id
}) => {
    const data = {
        id
    };
    return axios.request({
        url: 'outbound/order/audit',
        data,
        method: 'post'
    });
};
