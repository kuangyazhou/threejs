import axios from '@/libs/api.request';

/**
 * 库存初始化列表
 * @param pageNo
 * @param pageSize
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const getInventoryInitList = ({ inventoryOrganizationId, warehouseId }) => {
    const data = {
        inventoryOrganizationId, warehouseId
    };
    return axios.request({
        url: 'inventory/init/record/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取库存组织下拉列表
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const getOrganizationDropList = () => {
    return axios.request({
        url: 'inventory/organization/children',
        method: 'get'
    });
};

/**
 * 获取仓库下拉列表
 * @param inventoryOrganizationId
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const getWarehouseDropList = ({ inventoryOrganizationId }) => {
    const data = {
        inventoryOrganizationId
    };
    return axios.request({
        url: 'warehouse/select',
        params: data,
        method: 'get'
    });
};
/**
 * 获取对应物料的包装单位下拉列表
 * @param commodityId
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const getPackageDropList = ({ commodityId }) => {
    const data = {
        commodityId
    };
    return axios.request({
        url: 'commodity/package/organization/list',
        params: data,
        method: 'get'
    });
};

/**
 * 保存库存初始化
 * @param warehouseId
 * @param inventoryOrganizationId
 * @param items
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const saveInventoryInit = ({ warehouseId, inventoryOrganizationId, items }) => {
    const data = {
        warehouseId, inventoryOrganizationId, items
    };
    return axios.request({
        url: 'inventory/init/record/save',
        data,
        method: 'post'
    });
};

/**
 * 提交库存初始化
 * @param warehouseId
 * @param inventoryOrganizationId
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const submitInventoryInit = ({ warehouseId, inventoryOrganizationId }) => {
    const data = {
        warehouseId, inventoryOrganizationId
    };
    return axios.request({
        url: 'inventory/init/record/submit',
        data,
        method: 'post'
    });
};

/**
 * 库存初始化完成
 * @param warehouseId
 * @param inventoryOrganizationId
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const completeInventoryInit = ({ warehouseId, inventoryOrganizationId }) => {
    const data = {
        warehouseId, inventoryOrganizationId
    };
    return axios.request({
        url: 'inventory/init/record/complete',
        data,
        method: 'post'
    });
};
