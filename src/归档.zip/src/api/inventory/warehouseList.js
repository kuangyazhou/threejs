import axios from '@/libs/api.request';

/**
 * 获取仓库列表
 * @param pageNo
 * @param pageSize
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const getWarehouseList = ({ pageNo, pageSize }) => {
    const data = {
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'warehouse/list',
        params: data,
        method: 'get'
    });
};

/**
 * 新增仓库
 * @param isStopUse
 * @param warehouseType
 * @param warehouseCode
 * @param warehouseName
 * @param remark
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const addWarehouse = ({ isStopUse, warehouseType, warehouseCode, warehouseName, remark, warehouseAddress }) => {
    const data = {
        isStopUse, warehouseType, warehouseCode, warehouseName, remark, warehouseAddress
    };
    return axios.request({
        url: 'warehouse/save',
        data,
        method: 'post'
    });
};

/**
 * 新增仓库
 * @param isStopUse
 * @param warehouseType
 * @param warehouseCode
 * @param warehouseName
 * @param remark
 * @param id
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const updateWarehouse = ({ isStopUse, warehouseType, warehouseCode, warehouseName, remark, warehouseAddress, id }) => {
    const data = {
        isStopUse, warehouseType, warehouseCode, warehouseName, remark, warehouseAddress, id
    };
    return axios.request({
        url: 'warehouse/update',
        data,
        method: 'post'
    });
};
