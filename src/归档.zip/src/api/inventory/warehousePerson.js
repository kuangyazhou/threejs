import axios from '@/libs/api.request';

/**
 * 获取仓储人员列表
 * @param pageNo
 * @param pageSize
 * @param erpOwnerCode 库存组织编号
 * @param warehouseCode
 * @param employeeName
 * @returns {*|never}
 */
export const getWarehousePersonList = ({ pageNo, pageSize, erpOwnerCode, warehouseCode, employeeName }) => {
    const data = {
        pageNo, pageSize, erpOwnerCode, warehouseCode, employeeName
    };
    return axios.request({
        url: 'employee/list',
        params: data,
        method: 'get'
    });
};

/**
 * 单个新增仓储人员
 * @param employeeName
 * @param userName
 * @param remark
 * @param memoryCode
 * @param status
 * @param pdaWarehouseCode
 * @param erpOwnerCode
 * @param ownerCodes
 * @param warehouseCodes
 * @param roleIds
 * @returns {*|never}
 */
export const addWarehousePerson = ({ employeeName, userName, remark, memoryCode, status, pdaWarehouseCode, erpOwnerCode, ownerCodes, warehouseCodes, roleIds }) => {
    const data = {
        employeeName, userName, remark, memoryCode, status, pdaWarehouseCode, erpOwnerCode, ownerCodes, warehouseCodes, roleIds
    };
    return axios.request({
        url: 'employee/save',
        data,
        method: 'post'
    });
};

/**
 * 编辑仓储人员
 * @param id
 * @param employeeName
 * @param userName
 * @param remark
 * @param memoryCode
 * @param status
 * @param pdaWarehouseCode
 * @param erpOwnerCode
 * @param ownerCodes
 * @param warehouseCodes
 * @param roleIds
 * @returns {*|never}
 */
export const editWarehousePerson = ({ id, employeeName, userName, remark, memoryCode, status, pdaWarehouseCode, erpOwnerCode, ownerCodes, warehouseCodes, roleIds }) => {
    const data = {
        id, employeeName, userName, remark, memoryCode, status, pdaWarehouseCode, erpOwnerCode, ownerCodes, warehouseCodes, roleIds
    };
    return axios.request({
        url: 'employee/update',
        data,
        method: 'post'
    });
};

/**
 * 获取用户列表
 * @param pageNo
 * @param pageSize
 * @param erpOwnerCode
 * @param departmentName
 * @param realName
 * @returns {*|never}
 */
export const getUsersList = ({ pageNo, pageSize, erpOwnerCode, departmentName, realName }) => {
    const data = {
        pageNo, pageSize, erpOwnerCode, departmentName, realName
    };
    return axios.request({
        url: 'employee/user/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取库存组织下的仓库
 * @param inventoryOrganizationCode
 * @returns {*|never}
 */
export const getWarehouseDropList = ({ inventoryOrganizationCode }) => {
    const data = { inventoryOrganizationCode };
    return axios.request({
        url: 'warehouse/list',
        params: data,
        method: 'get'
    });
};

/**
 * 获取仓库的角色列表
 * @param warehouseCodes  仓库编号逗号分割
 * @returns {*|never}
 */
export const getRoleList = ({ warehouseCodes }) => {
    const data = { warehouseCodes };
    return axios.request({
        url: 'employee/role/list',
        params: data,
        method: 'get'
    });
};

/**
 * 批量新增
 * @param params
 * @returns {*|never}
 */
export const batchAddWarehousePerson = ({ params }) => {
    const data = {
        params
    };
    return axios.request({
        url: 'employee/batch/save',
        data,
        method: 'post'
    });
};
