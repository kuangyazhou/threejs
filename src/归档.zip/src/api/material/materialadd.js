/*
 * @Description: 物料新增接口
 * @Author: kuangyazhou
 * @Date: 2019-07-24 10:27:34
 * @LastEditTime: 2019-08-15 11:15:00
 * @LastEditors: Please set LastEditors
 */
import axios from '@/libs/api.request';

/**
 * @description: 采购新建的物料申请列表
 * @param {type} statusList 0, "新增物料-采购", "采购发起" 1, "新增物料-质管", "质管录入" 2, "提交集团审核", "审批中" 3, "审核通过", "审批通过" 4, "置为无效", "打回"
 * @param {type} organizationId 组织id
 * @param {type} createUser 组织id 创建人id
 * @param {type} brandName 品牌名 -支持模糊
 * @param {type} commodityName 物料名- 支持模糊
 */
export const materialList = ({
    statusList,
    organizationId,
    createUser,
    brandName,
    commodityName,
    pageNo,
    pageSize
}) => {
    const data = {
        statusList,
        organizationId,
        createUser,
        brandName,
        commodityName,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'commodity/task/save/create/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 物料新建&编辑
 * @param {type} organizationId 组织id
 * @param {type} registerName 注册证名称
 * @param {type} registerNumber 注册证号
 * @param {type} isImport 是否是【引入】 0-否 1-是
 * @param {type} id  编辑时必须传入申请单id
 * @param {type} brandId 品牌id (系统字典id) commodity_band
 * @param {type} commoditySpec 物料规格
 * @param {type} commodityType 药品剂型 (系统字典id)commodity_medicinal_type)
 * @param {type} deviceClassifyType 器械类别（系统字典值ID）device_classify_type）
 * @param {type} deviceClassifyCode 器械分类（编号)
 * @param {type} effectiveDays 有效期天数
 * @param {type} manufacturerId 生产厂家id
 * @param {type} productionLicense 生产许可证
 * @param {type} accountingId 核算名称id
 * @param {type} commodityNumber 物料货号
 * @param {type} commodityName 物料常用名称
 * @param {type} isSimplelevy 简易征收 1-是 0-否
 * @param {type} hasSet 有无配套 0-没有 1-有
 * @param {type} coldChainMarkId 冷链标识（系统字典值id commodity_cold_chain_mark）
 * @param {type} storageCondition 存储条件
 * @param {type} specializedGroupId 专业分组(系统字典取值 commodity_specialized_group)
 * @param {type} accountingOne 核算人份
 * @param {type} accountingMl 核算毫升
 * @param {type} classifyIdLevel1 分类一级id 字典 commodity_classify_level1)
 * @param {type} classifyIdLevel2 分类二级id 字典 commodity_classify_level2)
 * @param {type} remark 备注
 * @param {type} isImported 是否进口 1-是 0-否
 * @param {type} commodityId 引入的物料ID
 * @return:
 */
export const materialSave = ({
    organizationId,
    registerName,
    registerNumber,
    isImport,
    id,
    brandId,
    commoditySpec,
    commodityType,
    deviceClassifyType,
    deviceClassifyCode,
    effectiveDays,
    effectiveDaysShow,
    manufacturerId,
    manufacturerName,
    productionLicense,
    accountingId,
    commodityNumber,
    commodityName,
    isSimplelevy,
    hasSet,
    coldChainMarkId,
    storageCondition,
    specializedGroupId,
    accountingOne,
    accountingMl,
    classifyIdLevel1,
    classifyIdLevel2,
    remark,
    isImported,
    commodityId
}) => {
    const data = {
        organizationId,
        registerName,
        registerNumber,
        isImport,
        id,
        brandId,
        commoditySpec,
        commodityType,
        deviceClassifyType,
        deviceClassifyCode,
        effectiveDays,
        effectiveDaysShow,
        manufacturerId,
        manufacturerName,
        productionLicense,
        accountingId,
        commodityNumber,
        commodityName,
        isSimplelevy,
        hasSet,
        coldChainMarkId,
        storageCondition,
        specializedGroupId,
        accountingOne,
        accountingMl,
        classifyIdLevel1,
        classifyIdLevel2,
        remark,
        isImported,
        commodityId
    };
    return axios.request({
        url: 'commodity/task/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 物料删除
 * @param {type} id
 * @return:
 */
export const materialDel = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'commodity/task/save/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 下一步
 * @param {type} id
 * @return:
 */
export const materialSubmit = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'commodity/task/save/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 物料引入列表
 * @param {type} organizationId 组织id
 * @param {type} registerName 注册证名称
 * @param {type} registerNumber 注册证号
 * @param {type} notEnterpriseId 当前公司ID
 * @param {type} pageNo
 * @param {type} pageSize
 * @return:
 */
export const materialImport = ({
    organizationId,
    registerName,
    registerNumber,
    notEnterpriseId,
    inEnterpriseId,
    pageNo,
    pageSize
}) => {
    const data = {
        organizationId,
        registerName,
        registerNumber,
        notEnterpriseId,
        inEnterpriseId,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'commodity/organization/select/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 包装单位列表
 * @param {type} commodityId 物料ID
 * @param {type} commodityCode 物料codde
 * @param {type} status 状态
 * @param {type} isDeleted 是否删除
 * @param {type} isDefault 是否默认
 * @return:
 */
export const packageList = ({ commodityId, commodityCode, status, isDeleted, isDefault }) => {
    const data = { commodityId, commodityCode, status, isDeleted, isDefault };
    return axios.request({
        url: 'commodity/package/organization/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 包装单位新增
 * @param {type} organizationId 组织id
 * @param {type} commodityId 物料id
 * @param {type} unitId 单位名
 * @param {type} quotiety 转换系数
 * @param {type} status 状态值 3-有效 4 无效
 * @return:
 */
export const packageAdd = ({
    organizationId,
    commodityId,
    unitId,
    quotiety,
    status
}) => {
    const data = { organizationId, commodityId, unitId, quotiety, status };
    return axios.request({
        url: 'commodity/package/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 包装单位修改
 * @param {type} id
 * @param {type} unitId 单位名
 * @param {type} quotiety 转换系数
 * @param {type} status 状态值 3-有效 4 无效
 * @return:
 */
export const packageUpdate = ({ unitId, quotiety, status, id }) => {
    const data = { unitId, quotiety, status, id };
    return axios.request({
        url: 'commodity/package/update',
        data,
        method: 'post'
    });
};

/**
 * @description: 包装单位-删除
 * @param {type} id
 * @param {type} isChange 区分假删除和真删除
 * @return:
 */
export const packageDel = ({ id, isChange }) => {
    const data = { id };
    return axios.request({
        url: isChange ? 'commodity/package/softdelete' : 'commodity/package/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 包装单位-设为默认
 * @param {type} id 包装单位id
 * @return:
 */
export const packageDefault = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'commodity/package/default/set',
        data,
        method: 'post'
    });
};

/**
 * @description: 包装单位-设为标准
 * @param {type} id 包装单位id
 * @return:
 */
export const packageStandard = ({ id, existUnits }) => {
    const data = { id, existUnits };
    return axios.request({
        url: 'commodity/package/standard/set',
        data,
        method: 'post'
    });
};

/**
 * @description:物料新增-质管发起审批
 * @param {type} id
 * @return:
 */
export const materialAudit = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'commodity/task/save/qualification/sumbit',
        data,
        method: 'post'
    });
};

/**
 * @description: 物料新增-质管 打回
 * @param {type} id
 * @return:
 */
export const materialBackUp = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'commodity/task/save/return/sumbit',
        data,
        method: 'post'
    });
};

/**
 * @description: 物料新增-质管 审核通过
 * @param {type} id
 * @return:
 */
export const materialPass = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'commodity/task/save/approve/sumbit',
        data,
        method: 'post'
    });
};

/**
 * @description: 物料资料上传信息
 * @param {type} commodityId 物料ID
 * @param {type} dataType 文档类型ID
 * @return:
 */
export const materialUpload = ({ commodityId, dataType, pageNo, pageSize }) => {
    const data = { commodityId, dataType, pageNo, pageSize };
    return axios.request({
        url: 'commodity/license/organization/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 物料质管保存 参数同专员新增
 * @param {type}
 * @return:
 */
export const qualitySave = ({
    organizationId,
    registerName,
    registerNumber,
    isImport,
    id,
    brandId,
    commoditySpec,
    commodityType,
    deviceClassifyType,
    deviceClassifyCode,
    effectiveDays,
    effectiveDaysShow,
    manufacturerId,
    manufacturerName,
    productionLicense,
    accountingId,
    commodityNumber,
    commodityName,
    isSimplelevy,
    hasSet,
    coldChainMarkId,
    storageCondition,
    specializedGroupId,
    accountingOne,
    accountingMl,
    classifyIdLevel1,
    classifyIdLevel2,
    remark,
    isImported,
    commodityId,
    deviceClassifyId
}) => {
    const data = {
        organizationId,
        registerName,
        registerNumber,
        isImport,
        id,
        brandId,
        commoditySpec,
        commodityType,
        deviceClassifyType,
        deviceClassifyCode,
        effectiveDays,
        effectiveDaysShow,
        manufacturerId,
        manufacturerName,
        productionLicense,
        accountingId,
        commodityNumber,
        commodityName,
        isSimplelevy,
        hasSet,
        coldChainMarkId,
        storageCondition,
        specializedGroupId,
        accountingOne,
        accountingMl,
        classifyIdLevel1,
        classifyIdLevel2,
        remark,
        isImported,
        commodityId,
        deviceClassifyId
    };
    return axios.request({
        url: 'commodity/task/save/qualification',
        data,
        method: 'post'
    });
};

/**
 * @description: 物料新增-资料上传单选框数据
 * @param {type}
 * @return:
 */
export const getRadioData = () => {
    return axios.request({
        url: 'commodity/license/type/organization/list',
        method: 'get'
    });
};

/**
 * @description: 物料资料-新增
 * @param {type} dataType 文件类型
 * @param {type} commodityId 物料id
 * @param {type} licenseCode 证件编号
 * @param {type} expiryDate 有效期-时间戳
 * @param {type} records 文件id
 * @return:
 */
export const materialUploadAdd = ({
    dataType,
    commodityId,
    licenseCode,
    expiryDate,
    records
}) => {
    const data = {
        dataType,
        commodityId,
        licenseCode,
        expiryDate,
        records
    };
    return axios.request({
        url: 'commodity/license/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 物料资料-更新
 * @param {type} dataType 文件类型
 * @param {type} commodityId 物料id
 * @param {type} licenseCode 证件编号
 * @param {type} expiryDate 有效期-时间戳
 * @param {type} records 文件id
 * @param {type} isDeleted 假删除恢复使用
 * @return:
 */
export const materialUploadUpdate = ({
    id,
    dataType,
    commodityId,
    licenseCode,
    expiryDate,
    records,
    isDeleted
}) => {
    const data = {
        id,
        dataType,
        commodityId,
        licenseCode,
        expiryDate,
        records,
        isDeleted
    };
    return axios.request({
        url: 'commodity/license/update',
        data,
        method: 'post'
    });
};

/**
 * @description: 物料资料删除
 * @param {type} id
 * @param {type} isChange 区分假删除和真删除
 * @return:
 */
export const materialUploadDel = ({ id, isChange }) => {
    const data = { id };
    return axios.request({
        url: isChange ? 'commodity/license/softdelete' : 'commodity/license/delete',
        data,
        method: 'post'
    });
};
