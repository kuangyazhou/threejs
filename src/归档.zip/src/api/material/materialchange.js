/*
 * @Description: 物料申请变更接口
 * @Author: kuangyazhou
 * @Date: 2019-07-26 19:51:52
 * @LastEditTime: 2019-08-01 21:34:11
 * @LastEditors: Please set LastEditors
 */

import axios from '@/libs/api.request';

/**
 * @description: 采购新建的物料申请列表
 * @param {type} statusList 0, "新增物料-采购", "采购发起" 1, "新增物料-质管", "质管录入" 2, "提交集团审核", "审批中" 3, "审核通过", "审批通过" 4, "置为无效", "打回"
 * @param {type} organizationId 组织id
 * @param {type} createUser 组织id 创建人id
 * @param {type} brandName 品牌名 -支持模糊
 * @param {type} commodityName 物料名- 支持模糊
 */
export const materialChangeList = ({
    statusList,
    organizationId,
    createUser,
    brandName,
    commodityName,
    pageNo,
    pageSize
}) => {
    const data = {
        statusList,
        organizationId,
        createUser,
        brandName,
        commodityName,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'commodity/task/change/create/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 变更前物料文件资料类别获取
 * @param {type} taskInstanceId 申请单ID
 * @return:
 */
export const getBeforeFile = ({ taskInstanceId, pageSize, pageNo }) => {
    const data = { taskInstanceId, pageSize, pageNo };
    return axios.request({
        url: 'commodity/license/before/organization/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 变更前包装单位列表
 * @param {type} taskInstanceId 申请单ID
 * @return:
 */
export const getBeforePackage = ({ taskInstanceId, pageSize, pageNo }) => {
    const data = { taskInstanceId, pageSize, pageNo };
    return axios.request({
        url: 'commodity/package/before/organization/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 获取企业下的物料基础信息
 * @param {type} id 物料id
 * @return:
 */
export const getBaseInfo = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'commodity/enterprise/select/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 获取变更前基础信息
 * @param {type} id 申请单ID
 * @param {type} taskInstanceId 任务id *
 * @return:
 */
export const getBeforeBaseInfo = ({ id, taskInstanceId }) => {
    const data = { id, taskInstanceId };
    return axios.request({
        url: 'commodity/before/get',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 物料变更新增&&编辑
 * @param {type} organizationId 组织id
 * @param {type} commodityId 需要变更的物料id
 * @param {type} id 申请单id 编辑时必传
 * @return:
 */
export const materialChangeSave = ({
    organizationId,
    commodityId,
    id,
    registerName,
    registerNumber,
    brandId,
    commoditySpec,
    commodityType,
    deviceClassifyType,
    deviceClassifyCode,
    effectiveDays,
    manufacturerId,
    manufacturerName,
    productionLicense,
    accountingId,
    commodityNumber,
    commodityName,
    isSimplelevy,
    hasSet,
    coldChainMarkId,
    storageCondition,
    specializedGroupId,
    accountingOne,
    accountingMl,
    classifyIdLevel1,
    classifyIdLevel2,
    remark,
    isImported,
    deviceClassifyId
}) => {
    const data = {
        organizationId,
        commodityId,
        id,
        registerName,
        registerNumber,
        brandId,
        commoditySpec,
        commodityType,
        deviceClassifyType,
        deviceClassifyCode,
        effectiveDays,
        manufacturerId,
        manufacturerName,
        productionLicense,
        accountingId,
        commodityNumber,
        commodityName,
        isSimplelevy,
        hasSet,
        coldChainMarkId,
        storageCondition,
        specializedGroupId,
        accountingOne,
        accountingMl,
        classifyIdLevel1,
        classifyIdLevel2,
        remark,
        isImported,
        deviceClassifyId
    };
    return axios.request({
        url: 'commodity/task/change/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 变更单删除
 * @param {type} id 单据申请ID
 * @return:
 */
export const materialChangeDel = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'commodity/task/change/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 变更单发起审核
 * @param {type} id 单据申请ID
 * @return:
 */
export const materialChangeSubmit = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'commodity/task/change/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 变更单审核通过
 * @param {type} id 单据申请ID
 * @return:
 */
export const materialChangePass = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'commodity/task/change/approve/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 变更单审核打回
 * @param {type} id 单据申请ID
 * @return:
 */
export const materialChangeBack = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'commodity/task/change/return/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 证照假删除恢复
 * @param {type} id
 * @return:
 */
export const licenseRevert = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'commodity/license/softdelete/restore',
        data,
        method: 'post'
    });
};

/**
 * @description: 包装单位假删除恢复
 * @param {type} id
 * @return:
 */
export const packageRevert = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'commodity/package/softdelete/restore',
        data,
        method: 'post'
    });
};
