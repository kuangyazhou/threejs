/*
 * @Description: 发货通知单接口
 * @Author: kuangyazhou
 * @Date: 2019-08-14 15:00:47
 * @LastEditTime: 2019-08-16 10:45:31
 * @LastEditors: Please set LastEditors
 */
import axios from '@/libs/api.request';

/**
 * @description: 查询发货通知单接口
 * @param {type} inventoryOrganizationId 销售组织
 * @param {type} customerId 客户
 * @param {type} shipmentDate 发货日期
 * @param {type} shipmentTime 1全天 2上午 3下午
 * @param {type} orderNo 来源订单号
 * @param {type} orderType 订单类型:1销售订单2定向订单3测试订单4借贷订单5赠送订单6投放订单7领用订单

 * @param {type} shipmentNoticeStatus 发货通知单状态 1：未提交，2：已提交，3：已审核
 * @param {type} warehouseCode 仓库编码
 * @return:
 */
export const adviceList = ({ customerId, customerName, inventoryOrganizationId, shipmentDate, shipmentTime, orderNo, orderType, shipmentNoticeStatus, warehouseCode, isRedNotice }) => {
    const data = {
        customerId,
        customerName,
        inventoryOrganizationId,
        shipmentDate,
        shipmentTime,
        orderNo,
        orderType,
        shipmentNoticeStatus,
        warehouseCode,
        isRedNotice
    };
    return axios.request({
        url: 'shipment/notice/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 查询已审核的销售订单详情列表
 * @param {type} customerId 客户id
 * @param {type} inputTimeStart 录入时间——开始
 * @param {type} inputTimeEnd 录入时间——结束
 * @return:
 */
export const getOrderDetail = ({ customerEnableCode, customerId, orderDateStart, orderDateEnd }) => {
    const data = { customerEnableCode, customerId, orderDateStart, orderDateEnd };
    return axios.request({
        url: 'shipment/notice/sale/order/item/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 查询库存列表
 * @param {type} commodityCode 物料编码
 * @param {type} customerCommodityId 客户物料id
 * @param {type} effectiveTime 要求效期
 * @param {type} warehouseId 仓库id
 * @param {type} effectiveDateStart 有效期结束时间
 * @param {type} effectiveDateEnd 有效期结束时间
 * @return:
 */
export const getInve = ({ commodityCode, customerCommodityId, effectiveDate, warehouseId, effectiveDateStart, effectiveDateEnd }) => {
    const data = {
        commodityCode,
        customerCommodityId,
        effectiveDate,
        warehouseId,
        effectiveDateStart,
        effectiveDateEnd
    };
    return axios.request({
        url: 'shipment/notice/inventory/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 删除发货通知单
 * @param {type} id
 * @return:
 */
export const adviceDel = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'shipment/notice/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 获取发货通知单详情
 * @param {type} id
 * @return:
 */
export const adviceDetail = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'shipment/notice/get',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 修改发货通知单
 * @param {type} id
 * @param {type} customerId
 * @param {type} customerName
 * @param {type} customerAddress
 * @param {type} customerAddressId
 * @param {type} identificationCode
 * @param {type} shipmentDate
 * @param {type} shipmentTime
 * @param {type} itemList
 * @return:
 */
export const adviceUpdate = ({ id, customerId, customerName, customerAddress, customerAddressId, identificationCode, shipmentDate, shipmentTime, itemList, isRedNotice, warehouseCode }) => {
    const data = {
        id,
        customerId,
        customerName,
        customerAddress,
        customerAddressId,
        identificationCode,
        shipmentDate,
        shipmentTime,
        itemList,
        isRedNotice,
        warehouseCode
    };
    return axios.request({
        url: 'shipment/notice/update',
        data,
        method: 'post'
    });
};

/**
 * @description: 发货通知单提交/撤销
 * @param {type} id
 * @param {type} operationType 操作类型 1 提交 2 撤销
 * @return:
 */
export const adviceSubmit = ({ id, operationType }) => {
    const data = { id, operationType };
    return axios.request({
        url: 'shipment/notice/submit',
        data,
        method: 'post'
    });
};

/**
 * @description: 发货通知单审批
 * @param {type} id
 * @return:
 */
export const adviceAudit = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'shipment/notice/audit',
        data,
        method: 'post'
    });
};

/**
 * @description: 发货通知单保存
 * @param {type} inventoryOrganizationId 库存组织id
 * @param {type} customerId 客户id
 * @param {type} customerName 客户名称
 * @param {type} customerAddress 客户注册地址
 * @param {type} customerAddressId 客户真实发货地址id
 * @param {type} identificationCode 识别码
 * @param {type} shipmentDate 发货时段，1：全天，2：上午，3：下午
 * @param {type} shipmentTime 发货日期
 * @param {type} shipmentNoticeStatus 通知单状态（1：未提交，2：已提交，3：已审核）
 * @param {type} isRedNotice 是否红字通知单 0：不是 1：是
 * @param {type} shipmentNoticeItemId 订单明细id数组
 * @param {type} itemList
 * @return:
 */
export const adviceSave = ({ inventoryOrganizationId, customerId, customerName, customerAddress, customerAddressId, identificationCode, shipmentDate, shipmentTime, shipmentNoticeStatus, isRedNotice, itemList, shipmentNoticeItemId }) => {
    const data = {
        inventoryOrganizationId,
        customerId,
        customerName,
        customerAddress,
        customerAddressId,
        identificationCode,
        shipmentDate,
        shipmentTime,
        shipmentNoticeStatus,
        isRedNotice,
        itemList,
        shipmentNoticeItemId
    };
    return axios.request({
        url: 'shipment/notice/save',
        data,
        method: 'post'
    });
};

/**
 * @description:  获取收货地址
 * @param {type}
 * @return:
 */
export const getUserAddress = ({ isNew = 1, customerId, status = 3 }) => {
    const data = { isNew, customerId, status };
    return axios.request({
        url: 'customer/address/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 获取仓库列表
 * @param {type} inventoryOrganizationId 组织id
 * @param {type} isStopUse 0
 * @return:
 */
export const getWarhouse = ({ inventoryOrganizationId, isStopUse = 0 }) => {
    const data = { inventoryOrganizationId, isStopUse };
    return axios.request({
        url: 'warehouse/list',
        params: data,
        method: 'get'
    });
};

/**
 * 发货通知单打印
 * @param id
 * @returns {ClientHttp2Stream | * | AxiosPromise<any> | void | http.ClientRequest}
 */
export const getPrintInfo = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'shipment/notice/printInfo',
        params: data,
        method: 'get'
    });
};
