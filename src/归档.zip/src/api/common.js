/*
 * @Description: 公用接口
 * @Author: kuangyazhou
 * @Date: 2019-07-08 13:48:18
 * @LastEditTime: 2019-07-08 13:51:16
 * @LastEditors: Please set LastEditors
 */
import axios from '@/libs/api.request';

/**
 * @description: 获取系统字段的值
 * @param fieldCode
 * @return:
 */
export const getFieldValues = ({ fieldCode }) => {
    const params = {
        fieldCode
    };
    return axios.request({
        url: 'system/field/value/select',
        params,
        method: 'get'
    });
};

/**
 * @description: 获取器械类别
 * @param level 传1 代表组织
 * @param levelId 条件必填，当level不为0时必填：组织ID或公司ID（根据level选择）
 * @param fieldCode 传device_classify_type
 * @param fieldCodes 以,分隔传多个参数，精准查询
 * @return:
 */
export const getMachineType = ({ level, levelId, fieldCode }) => {
    const params = {
        level,
        levelId,
        fieldCode
    };
    return axios.request({
        url: 'system/field/query/list',
        params,
        method: 'get'
    });
};
