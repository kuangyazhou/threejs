/*
 * @Description: 物料管理-物料分类维护接口
 * @Author: kuangyazhou
 * @Date: 2019-07-22 10:40:51
 * @LastEditTime: 2019-07-22 18:12:04
 * @LastEditors: Please set LastEditors
 */
import axios from '@/libs/api.request';

/**
 * @description: 获取物料分类树
 * @param {type}
 * @return:
 */
export const getMaterialTree = () => {
    return axios.request({
        url: 'commodity/classify/tree',
        method: 'get'
    });
};

/**
 * @description: 新增物料分类
 * @param {type} commodityClassifyCode 分类编号
 * @param {type} parentId 父级ID（顶级传1)
 * @param {type} commodityClassifyName 分类名称
 * @param {type} status 状态（3有效，4无效)
 * @return:
 */
export const addMaterial = ({
    commodityClassifyCode,
    parentId,
    commodityClassifyName,
    status
}) => {
    const data = {
        commodityClassifyCode,
        parentId,
        commodityClassifyName,
        status
    };
    return axios.request({
        url: 'commodity/classify/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 修改物料分类
 * @param {type} commodityClassifyCode 分类编号
 * @param {type} parentId 父级ID（顶级传1)
 * @param {type} commodityClassifyName 分类名称
 * @param {type} status 状态（3有效，4无效)
 * @param {type} id
 * @return:
 */
export const updateMaterial = ({
    commodityClassifyCode,
    parentId,
    commodityClassifyName,
    status,
    id
}) => {
    const data = {
        commodityClassifyCode,
        parentId,
        commodityClassifyName,
        status,
        id
    };
    return axios.request({
        url: 'commodity/classify/update',
        data,
        method: 'post'
    });
};
