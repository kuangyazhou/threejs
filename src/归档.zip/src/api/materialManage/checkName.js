/*
 * @Description: 物料管理-核算名称设置
 * @Author: kuangyazhou
 * @Date: 2019-07-22 19:24:25
 * @LastEditTime: 2019-08-05 16:56:42
 * @LastEditors: Please set LastEditors
 */
import axios from '@/libs/api.request';

/**
 * @description: 核算名称分页列表
 * @param {type} accountingName 核算名称
 * @param {type} status 0, "新增核算名称", "待审核" 1, "审核", "已审核"
 * @param {type} threeLevelEnter 三级分录
 * @return:
 */
export const getCheckName = ({ accountingName, status, threeLevelEnter, pageNo, pageSize }) => {
    const data = {
        accountingName,
        status,
        threeLevelEnter,
        pageNo,
        pageSize
    };
    return axios.request({
        url: 'accounting/name/list',
        params: data,
        method: 'get'
    });
};

/**
 * @description: 新增核算名称
 * @param {type} accountingName 核算名称
 * @param {type} threeLevelEnter 三级分录
 * @return:
 */
export const addCheckName = ({ accountingName, threeLevelEnter }) => {
    const data = {
        accountingName,
        threeLevelEnter
    };
    return axios.request({
        url: 'accounting/name/save',
        data,
        method: 'post'
    });
};

/**
 * @description: 核算名称审核
 * @param {type} id
 * @return:
 */
export const checkNameAudit = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'accounting/name/approve',
        data,
        method: 'post'
    });
};

/**
 * @description: 取消审核
 * @param {type} id
 * @return:
 */
export const cancelAudit = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'accounting/name/unapprove',
        data,
        method: 'post'
    });
};

/**
 * @description: 核算名称删除
 * @param {type} id
 * @return:
 */
export const checkNameDel = ({ id }) => {
    const data = { id };
    return axios.request({
        url: 'accounting/name/delete',
        data,
        method: 'post'
    });
};

/**
 * @description: 修改名称
 * @param {type} threeLevelEnter 三级分录
 * @param {type} accountingName 核算名称
 * @param {type} id
 * @return:
 */
export const checkNameUpdate = ({ id, threeLevelEnter, accountingName }) => {
    const data = { id, threeLevelEnter, accountingName };
    return axios.request({
        url: 'accounting/name/update',
        data,
        method: 'post'
    });
};
