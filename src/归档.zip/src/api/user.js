import axios from '@/libs/api.request';

/**
 * 登录
 * @param userName
 * @param password
 * @returns {*|never}
 */
export const login = ({ userName, password }) => {
    const data = {
        userName,
        userPwd: password
    };
    return axios.request({
        url: 'user/signin',
        data,
        method: 'post'
    });
};

/**
 * 获取个人信息
 * @param token
 * @returns {*|never}
 */
export const getUserInfo = token => {
    return axios.request({
        url: '/user/info',
        params: {
            token
        },
        method: 'get'
    });
};

/**
 * 登出
 * @returns {*|never}
 */
export const logout = () => {
    return axios.request({
        url: 'user/signout',
        method: 'post'
    });
};

/**
 * 重置密码
 * @param userPwd
 * @param reUserPwd
 * @returns {*|never}
 */
export const editInitPassword = ({ userPwd, reUserPwd }) => {
    const data = {
        userPwd,
        reUserPwd
    };
    return axios.request({
        url: 'user/password/reset',
        data,
        method: 'post'
    });
};

/**
 * 获取菜单列表
 * @returns {*|never}
 */
export const listUserMenus = () => {
    return axios.request({
        url: 'resource/menu/list',
        method: 'get'
    });
};

/**
 * 切换当前组织
 * @param organizationId
 * @returns {*|never}
 */
export const switchOrganization = ({ organizationId }) => {
    const data = {
        organizationId
    };
    return axios.request({
        url: 'user/switchOrganization',
        params: data,
        method: 'get'
    });
};

/**
 * 刷新用户token信息
 * @returns {*|never}
 */
export const refreshToken = () => {
    const data = {};
    return axios.request({
        url: 'user/token/refresh',
        params: data,
        method: 'get'
    });
};

/**
 * 修改登录密码
 * @param newPwd 新密码
 * @param originalPwd 旧密码
 * @returns {*|never}
 */
export const editPassword = ({ originalPwd, newPwd }) => {
    const data = {
        originalPwd,
        newPwd
    };
    return axios.request({
        url: 'user/pwd/modify',
        data,
        method: 'post'
    });
};
