// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue';
import App from './App';
import router from './router';
import store from './store';
import iView from 'iview';
import config from '@/config';
import './style/index.less';
import '@/assets/icons/iconfont.css';
import { getDate, environmentConfig } from '@/libs/tools';

import cloneDeep from 'lodash/cloneDeep';

Vue.use(iView);
/**
 * @description 生产环境关掉提示
 */
Vue.config.productionTip = false;
/**
 * @description 全局注册应用配置
 */
Vue.prototype.$config = config;
Vue.prototype.fileUrl = environmentConfig('fileUrl');

// 引入lodash
Vue.prototype.cloneDeep = cloneDeep;

// 全局日期方法
Vue.prototype.getDate = (arg, type) => {
    return getDate(arg, type);
};

// 自定义权限按钮命令
Vue.directive('has', {
    inserted: function (el, binding) {
        if (!permissionJudge(binding.value)) {
            el.parentNode.removeChild(el);
        }

        function permissionJudge (value) {
            // 此处store.getters.getAccess代表vuex中储存的按钮菜单数据
            let list = store.getters.getAccess;
            // console.log(list);
            return list.includes(value);
        }
    }
});

// 全局提示统一3秒
Vue.prototype.$Message.config({
    duration: 3
});

/* eslint-disable no-new */
new Vue({
    el: '#app',
    router,
    store,
    render: h => h(App)
});
