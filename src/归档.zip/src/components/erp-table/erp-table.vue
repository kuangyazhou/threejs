<template>
    <div class="erp-table">
        <Table
            ref="erpTable"
            @on-selection-change="selectionChange"
            @on-row-click="currentChange"
            :loading="tableLoading"
            border
            :highlight-row="highlight"
            :columns="erpTableTitle"
            :data="erpTableData"
        ></Table>
        <div class="wrapper-page" v-if="hasPage">
            <Page
                :current="current"
                @on-change="changePage"
                @on-page-size-change="changePageSize"
                :total="total"
                :show-elevator="showElevator"
                :show-sizer="showSizer"
            />
        </div>
    </div>
</template>
<script>
    export default {
        name: 'ErpTable',
        props: {
            // 表格顶部标题
            erpTableTitle: {
                type: Array,
                default: () => {
                    return [];
                }
            },
            // 表格数据
            erpTableData: {
                type: Array,
                default: () => {
                    return [];
                }
            },
            // 表格宽度
            tableWidth: {
                type: Number,
                default: 0
            },
            // 分页总条数
            total: {
                type: Number,
                default: 0
            },
            // 表格是否加载中
            tableLoading: {
                type: Boolean,
                default: false
            },
            // 当前页码
            current: {
                type: Number,
                default: 1
            },
            // 是否高亮
            highlight: {
                type: Boolean,
                default: false
            },
            // 是否分页
            hasPage: {
                type: Boolean,
                default: true
            },
            // 改变每页页数
            showSizer: {
                type: Boolean,
                default: true
            },
            // 显示电梯
            showElevator: {
                type: Boolean,
                default: true
            }
        },
        data () {
            return {};
        },
        methods: {
            /**
             * 在多选模式下有效，只要选中项发生变化时就会触发
             * @param value
             */
            selectionChange (value) {
                this.$emit('on-selection-change', value);
            },
            // 高亮模式下生效，点击单行触发
            currentChange (value) {
                if (value) this.$emit('on-current-change', value);
            },
            /**
             * 改变页码
             * @param value 页码
             */
            changePage (value) {
                this.$emit('on-page-no-change', value);
            },
            /**
             * 切换每页条数时的回调
             * @param value 每页条数
             */
            changePageSize (value) {
                this.$emit('on-page-size-change', value);
            },
            // 取消单行高亮
            clearCurrentTableRow () {
                this.$refs.erpTable.clearCurrentRow();
            },
            // 导出excel
            exportCsv (config) {
                this.$refs.erpTable.exportCsv(Object.prototype.toString.call(config) === '[object Object]' ? config : {});
            }
        }
    };
</script>
<style scoped lang="less">
    .wrapper-page {
        margin-top: 20px;
        float: right;
    }
</style>
