import ErpTable from './erp-table.vue';

export default ErpTable;
