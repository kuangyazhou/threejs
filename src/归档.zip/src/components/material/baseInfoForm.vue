<!--
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-15 11:10:19
 * @LastEditTime: 2019-08-15 14:06:32
 * @LastEditors: Please set LastEditors
 -->
<template>
    <div class="base-info-form">
        <Card dis-hover>
            <Form :model="formAttr" ref="formValidate" :label-width="120">
                <Row>
                    <Col span="8">
                        <FormItem label="物料代码">
                            <Input v-model="formAttr.commodityCode" placeholder="物料代码" disabled></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="物料货号" prop="commodityNumber" class="is-required">
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.commodityNumber">物料货号</Tooltip>
                            </template>
                            <Input
                                v-model="formAttr.commodityNumber"
                                :disabled="
                                    qualityReadonly || projectChangeReadonly||readonly
                                "
                                placeholder="物料货号"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="分类一级" prop="classifyIdLevel1" class="is-required">
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.classifyNameLevel1">分类一级</Tooltip>
                            </template>
                            <Select
                                v-model="formAttr.classifyIdLevel1"
                                :disabled="
                                    purchaseReadOnly || projectChangeReadonly||readonly
                                "
                            >
                                <Option
                                    v-for="(item, index) in LevelOneArr"
                                    :value="item.id"
                                    :label="item.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="16">
                        <FormItem label="常用名称" prop="commodityName" class="is-required">
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.commodityName">常用名称</Tooltip>
                            </template>
                            <Input
                                v-model="formAttr.commodityName"
                                :disabled="
                                    qualityReadonly ||
                                        qualityChangeReadonly ||
                                        projectChangeReadonly||readonly
                                "
                                placeholder="常用名称"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="物料品牌" prop="brandId" class="is-required">
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.brandName">物料品牌</Tooltip>
                            </template>
                            <Select
                                v-model="formAttr.brandId"
                                :disabled="
                                    qualityReadonly ||
                                        qualityChangeReadonly ||
                                        projectChangeReadonly ||
                                        isImport||readonly
                                "
                            >
                                <Option
                                    v-for="(item, index) in brandNameArr"
                                    :value="item.id"
                                    :label="item.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="8">
                        <FormItem label="物料规格" prop="commoditySpec" class="is-required">
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.commoditySpec">物料规格</Tooltip>
                            </template>
                            <Input
                                v-model="formAttr.commoditySpec"
                                :disabled="
                                    qualityReadonly ||
                                        projectChangeReadonly ||
                                        isImport||readonly
                                "
                                placeholder="物料规格"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="药品剂型" prop="commodityType" class="is-required">
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.commodityTypeName">药品剂型</Tooltip>
                            </template>
                            <Select
                                v-model="formAttr.commodityType"
                                :disabled="
                                    isChange ||
                                        purchaseReadOnly ||
                                        qualityReadonly ||
                                        projectChangeReadonly||readonly
                                "
                            >
                                <Option
                                    v-for="(item,
                                    index) in commodityTypeNameArr"
                                    :value="item.id"
                                    :label="item.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="简易征收" prop="isSimplelevy" class="is-required">
                            <RadioGroup v-model="formAttr.isSimplelevy">
                                <Radio
                                    :disabled="
                                        qualityReadonly || projectChangeReadonly||readonly
                                    "
                                    :label="1"
                                >是</Radio>
                                <Radio
                                    :disabled="
                                        qualityReadonly || projectChangeReadonly||readonly
                                    "
                                    :label="0"
                                >否</Radio>
                            </RadioGroup>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="16">
                        <FormItem label="注册证名称" prop="registerName" class="is-required">
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.registerName">注册证名称</Tooltip>
                            </template>
                            <Input
                                v-model="formAttr.registerName"
                                :disabled="
                                    purchaseReadOnly || projectChangeReadonly||readonly
                                "
                                placeholder="注册证名称"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="注册证号" prop="registerNumber" class="is-required">
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.registerNumber">注册证号</Tooltip>
                            </template>
                            <Input
                                v-model="formAttr.registerNumber"
                                :disabled="purchaseReadOnly||readonly"
                                placeholder="注册证号"
                            ></Input>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="8">
                        <FormItem label="有无配套" prop="hasSet" class="is-required">
                            <RadioGroup v-model="formAttr.hasSet">
                                <Radio
                                    :disabled="
                                        qualityReadonly || projectChangeReadonly||readonly
                                    "
                                    :label="1"
                                >有</Radio>
                                <Radio
                                    :disabled="
                                        qualityReadonly || projectChangeReadonly||readonly
                                    "
                                    :label="0"
                                >无</Radio>
                            </RadioGroup>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="储存条件" prop="storageCondition" class="is-required">
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.storageCondition">储存条件</Tooltip>
                            </template>
                            <Input
                                v-model="formAttr.storageCondition"
                                :disabled="
                                    purchaseReadOnly || projectChangeReadonly||readonly
                                "
                                placeholder="存储条件"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="冷链标识" prop="coldChainMarkId" class="is-required">
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.coldChainMarkName">冷链标识</Tooltip>
                            </template>
                            <Select
                                v-model="formAttr.coldChainMarkId"
                                :disabled="
                                    purchaseReadOnly || projectChangeReadonly||readonly
                                "
                            >
                                <Option
                                    v-for="(item, index) in coldChainMarkIdArr"
                                    :value="item.id"
                                    :label="item.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="8">
                        <FormItem label="器械类别" prop="deviceClassifyType" class="is-required">
                            <template slot="label" v-if="isChange">
                                <Tooltip
                                    :content="
                                        oldBaseInfo.deviceClassifyTypeName
                                    "
                                >器械类别</Tooltip>
                            </template>
                            <Select
                                v-model="formAttr.deviceClassifyType"
                                @on-change="typeChange"
                                :disabled="
                                    purchaseReadOnly || projectChangeReadonly||readonly
                                "
                            >
                                <Option
                                    v-for="(item,
                                    index) in deviceClassifyTypeArr"
                                    :value="item.id"
                                    :label="item.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="器械分类" prop="deviceClassifyId" class="is-required">
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.deviceClassifyCode">器械分类</Tooltip>
                            </template>
                            <Select
                                v-model="formAttr.deviceClassifyId"
                                :disabled="
                                    purchaseReadOnly || projectChangeReadonly||readonly
                                "
                            >
                                <!--  -->
                                <Option
                                    v-for="(item,
                                    index) in deviceClassifyCodeArr"
                                    :label="item.deviceClassifyCode+','+item.deviceClassifyName"
                                    :value="item.id"
                                    :key="index"
                                ></Option>
                                <!-- {{item.deviceClassifyCode+''+item.deviceClassifyName}} -->
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="质保效期" prop="effectiveDays" class="is-required">
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.effectiveDays">质保效期</Tooltip>
                            </template>
                            <Input
                                v-model="formAttr.effectiveDays"
                                :disabled="
                                    purchaseReadOnly || projectChangeReadonly||readonly
                                "
                                placeholder="质保效期"
                                type="number"
                                class="z10"
                            >
                                <Button slot="append" @click="setDateType">{{isDay?'天':'月'}}</Button>
                            </Input>
                            <Row></Row>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="8">
                        <FormItem label="生产厂家" prop="manufacturerName" class="is-required">
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.manufacturerName">生产厂家</Tooltip>
                            </template>
                            <Input
                                v-model="formAttr.manufacturerName"
                                :disabled="
                                    purchaseReadOnly || projectChangeReadonly||readonly
                                "
                                placeholder="生产厂家"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="生产许可">
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.productionLicense">生产许可</Tooltip>
                            </template>
                            <Input
                                v-model="formAttr.productionLicense"
                                :disabled="
                                    purchaseReadOnly || projectChangeReadonly||readonly
                                "
                                placeholder="生产许可"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="分类二级" prop="classifyIdLevel2" class="is-required">
                            <template slot="label">
                                <Tooltip
                                    :content="oldBaseInfo.classifyNameLevel2"
                                    v-if="isChange"
                                >分类二级</Tooltip>
                            </template>
                            <Select
                                v-model="formAttr.classifyIdLevel2"
                                :disabled="
                                    purchaseReadOnly ||
                                        purchaseChangeReadonly ||
                                        qualityChangeReadonly||readonly
                                "
                            >
                                <Option
                                    v-for="(item, index) in LevelTwoArr"
                                    :value="item.id"
                                    :label="item.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="8">
                        <FormItem label="专业分组" prop="specializedGroupId" class="is-required">
                            <template slot="label">
                                <Tooltip
                                    :content="oldBaseInfo.specializedGroupName"
                                    v-if="isChange"
                                >专业分组</Tooltip>
                            </template>
                            <!-- <Input
                                v-model="formAttr.specializedGroupId"
                                :disabled="
                                    qualityReadonly || qualityChangeReadonly
                                "
                                type="number"
                                placeholder="专业分组"
                            ></Input>-->
                            <Select
                                v-model="formAttr.specializedGroupId"
                                :disabled="
                                    qualityReadonly || qualityChangeReadonly||readonly
                                "
                                placeholder="专业分组"
                            >
                                <Option
                                    v-for="item in specialGroupArr"
                                    :key="item.index"
                                    :label="item.fieldValue"
                                    :value="item.id"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="核算人份" prop="accountingOne" class="is-required">
                            <template slot="label">
                                <Tooltip :content="oldBaseInfo.accountingOne" v-if="isChange">核算人份</Tooltip>
                            </template>
                            <Input
                                v-model="formAttr.accountingOne"
                                :disabled="
                                    purchaseReadOnly ||
                                        purchaseChangeReadonly ||
                                        qualityChangeReadonly||readonly
                                "
                                placeholder="核算人份"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="核算毫升" prop="accountingMl" class="is-required">
                            <template slot="label">
                                <Tooltip :content="oldBaseInfo.accountingMl" v-if="isChange">核算毫升</Tooltip>
                            </template>
                            <Input
                                v-model="formAttr.accountingMl"
                                :disabled="
                                    purchaseReadOnly ||
                                        purchaseChangeReadonly ||
                                        qualityChangeReadonly||readonly
                                "
                                placeholder="核算毫升"
                            ></Input>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="8">
                        <FormItem label="核算名称" prop="accountingId" class="is-required">
                            <template slot="label">
                                <Tooltip :content="oldBaseInfo.accountingId" v-if="isChange">核算名称</Tooltip>
                            </template>
                            <Select
                                v-model="formAttr.accountingId"
                                :disabled="
                                    purchaseReadOnly ||
                                        purchaseChangeReadonly ||
                                        qualityChangeReadonly||readonly
                                "
                                placeholder="核算名称"
                            >
                                <Option
                                    v-for="item in accountArr"
                                    :label="item.accountingName"
                                    :key="item.index"
                                    :value="item.id"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem label="产地属性" prop="isImported" class="is-required">
                            <template slot="label">
                                <Tooltip :content="oldBaseInfo.isImported" v-if="isChange">产地属性</Tooltip>
                            </template>
                            <RadioGroup v-model="formAttr.isImported">
                                <Radio
                                    :disabled="
                                        purchaseReadOnly ||
                                            projectChangeReadonly||readonly
                                    "
                                    :label="0"
                                >国产</Radio>
                                <Radio
                                    :disabled="
                                        purchaseReadOnly ||
                                            projectChangeReadonly||readonly
                                    "
                                    :label="1"
                                >进口</Radio>
                            </RadioGroup>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <FormItem label="备注">
                        <template slot="label">
                            <Tooltip :content="oldBaseInfo.remark" v-if="isChange">备注</Tooltip>
                        </template>
                        <Input
                            v-model="formAttr.remark"
                            :disabled="
                                purchaseReadOnly || projectChangeReadonly||readonly
                            "
                            type="textarea"
                        ></Input>
                    </FormItem>
                </Row>
            </Form>
        </Card>
    </div>
</template>

<script>
import { materialSave, qualitySave } from '@/api/material/materialadd';
import { materialChangeSave } from '@/api/material/materialchange';
import { getMachineList } from '@/api/dataSet/groupMachine';
export default {
    props: {
        oldFormAttr: {
            type: Object,
            default: () => {
                return {};
            }
        },
        // 分类一级下拉框数据
        LevelOneArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 物料品牌下拉框数据
        brandNameArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 药品剂型下拉框数据
        commodityTypeNameArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 冷链标识下拉框数据
        coldChainMarkIdArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 器械类别下拉框数据
        deviceClassifyTypeArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 核算名称数据
        accountArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 专业分组数据源
        specialGroupArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 器械分类下拉框数据
        // deviceClassifyCodeArr: {
        //     type: Array,
        //     default: () => {
        //         return [];
        //     }
        // },
        // 分类二级下拉框数据
        LevelTwoArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        currentId: '',
        isImport: {
            type: Boolean,
            default: () => {
                return false;
            }
        },
        organizationId: {
            id: null
        },
        // 采购只读
        purchaseReadOnly: {
            type: Boolean,
            default: false
        },
        // 质管只读
        qualityReadonly: {
            type: Boolean,
            default: false
        },
        // 采购变更只读
        purchaseChangeReadonly: {
            type: Boolean,
            default: false
        },
        // 项目部变更只读
        projectChangeReadonly: {
            type: Boolean,
            default: false
        },
        // 质管变更只读
        qualityChangeReadonly: {
            type: Boolean,
            default: false
        },
        //是否变更
        isChange: {
            type: Boolean,
            default: false
        },
        readonly:{
            type:Boolean,
            default:false
        },
        commodityId: '',
        oldBaseInfo: {
            type: Object,
            default: () => {
                return {
                    commodityCode: '',
                    commodityNumber: '',
                    classifyIdLevel1: '',
                    commodityName: '',
                    brandId: '',
                    commoditySpec: '',
                    commodityType: '',
                    isSimplelevy: '',
                    registerName: '',
                    registerNumber: '',
                    hasSet: '',
                    storageCondition: '',
                    coldChainMarkId: '',
                    deviceClassifyType: '',
                    deviceClassifyCode: '',
                    effectiveDays: '',
                    manufacturerId: '',
                    manufacturerName: '',
                    productionLicense: '',
                    classifyIdLevel2: '',
                    specializedGroupId: '',
                    accountingOne: '',
                    accountingMl: '',
                    accountingId: '',
                    isImported: '',
                    remark: '',
                    id: '',
                    status: '',
                    deviceClassifyId: ''
                };
            }
        }
    },
    data() {
        return {
            isDay: true,
            code: 10000,
            deviceClassifyCodeArr: [],
            formAttr: {
                commodityCode: '',
                commodityNumber: '',
                classifyIdLevel1: '',
                commodityName: '',
                brandId: '',
                commoditySpec: '',
                commodityType: '',
                isSimplelevy: '',
                registerName: '',
                registerNumber: '',
                hasSet: '',
                storageCondition: '',
                coldChainMarkId: '',
                deviceClassifyType: '',
                deviceClassifyCode: '',
                effectiveDays: '',
                effectiveDaysShow: '',
                manufacturerId: '',
                manufacturerName: '',
                productionLicense: '',
                classifyIdLevel2: '',
                specializedGroupId: '',
                accountingOne: '',
                accountingMl: '',
                accountingId: '',
                isImported: '',
                remark: '',
                id: '',
                status: '',
                deviceClassifyId: ''
            },
            ruleValidate: {
                commodityNumber: [
                    { required: true, message: '物料货号不可为空' }
                ],
                classifyIdLevel1: [
                    { required: true, message: '分类一级不可为空' }
                ],
                commodityName: [
                    { required: true, message: '常用名称不可为空' }
                ],
                brandId: [{ required: true, message: '物料品牌不可为空' }],
                commoditySpec: [
                    { required: true, message: '物料规格不可为空' }
                ],
                commodityType: [
                    { required: true, message: '药品剂型不可为空' }
                ],
                isSimplelevy: [{ required: true, message: '简易征收不可为空' }],
                registerName: [
                    { required: true, message: '注册证名称不可为空' }
                ],
                registerNumber: [
                    { required: true, message: '注册证号不可为空' }
                ],
                hasSet: [{ required: true, message: '有无配套不可为空' }],
                storageCondition: [
                    { required: true, message: '存储条件不可为空' }
                ],
                coldChainMarkId: [
                    { required: true, message: '冷链标识不可为空' }
                ],
                deviceClassifyType: [
                    { required: true, message: '器械类别不可为空' }
                ],
                deviceClassifyId: [
                    { required: true, message: '器械分类不可为空' }
                ],
                effectiveDays: [
                    { required: true, message: '质保效期不可为空' }
                ],
                manufacturerName: [
                    { required: true, message: '生产厂家不可为空' }
                ],
                classifyIdLevel2: [
                    { required: true, message: '分类二级不可为空' }
                ],
                specializedGroupId: [
                    { required: true, message: '专业分组不可为空' }
                ],
                accountingOne: [
                    { required: true, message: '核算人份不可为空' }
                ],
                accountingMl: [{ required: true, message: '核算毫升不可为空' }],
                accountingId: [{ required: true, message: '核算名称不可为空' }],
                isImported: [{ required: true, message: '产地属性不可为空' }]
            }
        };
    },
    watch: {
        oldFormAttr: {
            handler(val) {
                for (let key in val) {
                    this.formAttr[key] = val[key];
                }
            },
            deep: true
        },
        'formAttr.deviceClassifyType': function(val) {
            if (val) {
                this.typeChange(val);
                this.formAttr.deviceClassifyCode = Number(
                    this.formAttr.deviceClassifyCode
                );
            }
        },
        // 'formAttr.deviceClassifyId': function(val) {
        //     if (val) {
        //         this.typeChange(val);
        //         this.formAttr.deviceClassifyCode = Number(
        //             this.formAttr.deviceClassifyCode
        //         );
        //     }
        // },

        'formAttr.effectiveDaysShow': function(val) {
            if (val) {
                if (Number(val.split('_')[0])) {
                    this.isDay = false;
                } else {
                    this.isDay = true;
                }
            }
        }
    },
    methods: {
        save() {
            this.$refs['formValidate'].validate(async valid => {
                if (!valid) {
                    return this.$emit('changeLoading');
                }

                // 判断质保效期为月或者天
                if (this.isDay) {
                    this.formAttr.effectiveDaysShow =
                        '0_' + this.formAttr.effectiveDays;
                } else {
                    this.formAttr.effectiveDaysShow =
                        this.formAttr.effectiveDays + '_0';
                }
                if (!this.formAttr.status || this.formAttr.status === 3) {
                    let id = null;
                    if (this.isImport) {
                        id = this.formAttr.id;
                    } else {
                        id = null;
                    }
                    if (this.currentId) {
                        id = this.currentId;
                    } else {
                        id = null;
                    }
                    const params = Object.assign(this.formAttr, {
                        isImport: this.isImport ? 1 : 0,
                        id: id,
                        commodityType: this.commodityTypeNameArr.length&&this.commodityTypeNameArr.slice(-1)[0].id //药品剂型暂设为*
                    });
                    const res = await materialSave(params);
                    if (res.status === this.code) {
                        this.$Message.success(res.msg);
                        this.$emit('changeCurrentId', res.content);
                        this.$emit('changeLoading');
                        this.$emit('getTableList');
                    } else {
                        this.$emit('changeLoading');
                    }
                }
                if (this.formAttr.status === 1) {
                    const params = Object.assign({}, this.formAttr);
                    const res = await qualitySave(params);
                    if (res.status === this.code) {
                        this.$Message.success(res.msg);
                        this.$emit('changeLoading');
                        this.$emit('getTableList');
                    } else {
                        this.$emit('changeLoading');
                    }
                }
            });
        },

        // 变更保存
        changeSave() {
            this.$refs['formValidate'].validate(async valid => {
                if (!valid) {
                    return this.$emit('changeLoading');
                }
                const params = Object.assign({}, this.formAttr, {
                    organizationId: this.organizationId.id,
                    commodityId: this.commodityId
                });
                const res = await materialChangeSave(params);
                if (res.status === this.code) {
                    this.formAttr.id = res.content.id;
                    this.$emit('isSave', true);
                    this.$emit('changeCurrentId', res.content);
                    this.$emit('changeLoading');
                    this.$Message.success(res.msg);
                    this.$emit('getTableList');
                }
            });
        },

        // 设置质保效期是月还是天
        setDateType() {
            this.isDay = !this.isDay;
            if (this.isDay) {
                this.formAttr.effectiveDaysShow =
                    '0_' + this.formAttr.effectiveDays;
            } else {
                this.formAttr.effectiveDaysShow =
                    this.formAttr.effectiveDays + '_0';
            }
        },

        // 通过器械类别去查找集团器分类
        async typeChange(e) {
            const params = {
                organizationId: this.organizationId.id,
                deviceClassifyType: e
            };
            const res = await getMachineList(params);
            if (res.status === this.code) {
                this.deviceClassifyCodeArr = res.content;

                // 必须要等下拉框数据请求结束以后再更新器械分类值
                this.$set(
                    this.formAttr,
                    'deviceClassifyCode',
                    Number(this.formAttr.deviceClassifyCode)
                );
            }
        }
    }
};
</script>

<style scoped lang="less">
.is-required {
    /deep/ .ivu-form-item-label {
        &::before {
            content: '*';
            display: inline-block;
            margin-right: 4px;
            line-height: 1;
            font-family: SimSun;
            font-size: 12px;
            color: #ed4014;
        }
    }
}
</style>
