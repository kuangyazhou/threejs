<template>
    <div class="upload">
        <!-- <h1>资料上传</h1> -->
        <Card dis-hover class="mb20">
            <div slot="extra" v-if="!projectChangeReadonly">
                <ButtonGroup class="z10">
                    <Button icon="md-add" @click="add" v-if="!readonly">新增</Button>
                </ButtonGroup>
            </div>
            <Row>
                <Col span="2">资料类型</Col>
                <Col span="12">
                    <RadioGroup v-model="typeRadio" @on-change="radioChange">
                        <span class="check-container f16">
                            <Radio :label="Null">全部</Radio>
                        </span>
                        <span
                            class="check-container f16"
                            v-for="item in radioData"
                            :key="item.index"
                            :class="{ 'is-required': item.isMust }"
                        >
                            <Radio :label="item.dataType" :disabled="readonly">
                                {{
                                item.dataName
                                }}
                            </Radio>
                        </span>
                    </RadioGroup>
                </Col>
            </Row>
        </Card>
        <Table :border="true" :columns="uploadTitle" :data="uploadTable">
            <!-- 资料类型 -->
            <template slot-scope="{ row }" slot="dataTypeName">
                <span
                    :class="{
                        update:
                            isChange &&
                            findUpdate(oldUploadArr, row, 'dataName'),
                        add: isChange && !row.metaId,
                        deleted: isChange && row.isDeleted == 2
                    }"
                >{{ row.dataName }}</span>
            </template>
            <!-- 证号编号 -->
            <template slot-scope="{ row }" slot="licenseCode">
                <span
                    :class="{
                        update:
                            isChange &&
                            findUpdate(oldUploadArr, row, 'licenseCode'),
                        add: isChange && !row.metaId,
                        deleted: isChange && row.isDeleted == 2
                    }"
                >{{ row.licenseCode }}</span>
            </template>
            <!-- 有效日期 -->
            <template slot-scope="{ row }" slot="expiryDate">
                <span
                    :class="{
                        update:
                            isChange &&
                            findUpdate(oldUploadArr, row, 'expiryDate'),
                        add: isChange && !row.metaId,
                        deleted: isChange && row.isDeleted == 2
                    }"
                >{{ getDatePrive(row.expiryDate, 'long') }}</span>
            </template>
            <!-- 状态 -->
            <template slot-scope="{ row }" slot="statusName">
                <span
                    :class="{
                        update:
                            isChange &&
                            findUpdate(oldUploadArr, row, 'statusName'),
                        add: isChange && !row.metaId,
                        deleted: isChange && row.isDeleted == 2
                    }"
                ><Tag :color="row.status===3?'success':'defaut'">{{ row.status===3?'有效':'无效' }}</Tag></span>
            </template>
            <!-- 上传日期 -->
            <template slot-scope="{ row }" slot="updateTime">
                <span
                    :class="{
                        update:
                            isChange &&
                            findUpdate(oldUploadArr, row, 'updateTime'),
                        add: isChange && !row.metaId,
                        deleted: isChange && row.isDeleted == 2
                    }"
                >{{ getDatePrive(row.updateTime, 'long') }}</span>
            </template>
            <!-- 上传人员 -->
            <template slot-scope="{ row }" slot="updateName">
                <span
                    :class="{
                        update:
                            isChange &&
                            findUpdate(oldUploadArr, row, 'updateName'),
                        add: isChange && !row.metaId,
                        deleted: isChange && row.isDeleted == 2
                    }"
                >{{ row.updateName }}</span>
            </template>
            <template slot-scope="{ row }" slot="operate">
                <Button @click="edit(row)" class="mr6" type="primary" size="small">编辑</Button>
                <Button @click="delInfo(row)" v-if="row.isDeleted===1" type="error" size="small">删除</Button>
                <Button
                    size="small"
                    type="success"
                    @click="resvert(row)"
                    v-if="row.isDeleted == 2"
                    >恢复</Button
                >
            </template>
        </Table>
        <Modal
            v-model="modalShowFlag"
            width="650"
            height="800"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalClose"
        >
            <div class="erp-modal-content">
                <Form :model="formAttr" :rules="ruleValidate" ref="form" :label-width="120">
                    <FormItem label="资料类型" prop="dataType">
                        <Select v-model="formAttr.dataType" placeholder="请选择">
                            <Option
                                v-for="item in radioData"
                                :value="item.dataType"
                                :key="item.index"
                            >{{ item.dataName }}</Option>
                        </Select>
                    </FormItem>
                    <FormItem label="证书编号" prop="licenseCode">
                        <Input v-model="formAttr.licenseCode" placeholder="证书编号"></Input>
                    </FormItem>
                    <FormItem label="有效日期" prop="expiryDate">
                        <DatePicker
                            :editable="false"
                            v-model="formAttr.expiryDate"
                            format="yyyy-MM-dd"
                            type="date"
                            placeholder="年/月/日"
                            @on-change="dateChange"
                        ></DatePicker>
                    </FormItem>
                    <FormItem label="附件" class="mb20">
                        <Upload
                            type="select"
                            accept="image/*, .pdf"
                            multiple
                            action="''"
                            :before-upload="handleBeforeUpload"
                        >
                            <Button icon="ios-cloud-upload-outline">选择</Button>
                        </Upload>
                    </FormItem>
                </Form>
                <Table border :columns="fileTitle" :data="fileData">
                    <template slot-scope="{ row }" slot="index">
                        <span
                            :class="{
                                deleted: isChange && row.isDeleted == 2
                            }"
                        >{{ row.index }}</span>
                    </template>
                    <template slot-scope="{ row }" slot="documentName">
                        <span
                            :class="{
                                deleted: isChange && row.isDeleted == 2
                            }"
                        >{{ row.documentName }}</span>
                    </template>
                    <template slot-scope="{ row }" slot="status">
                        <span v-if="row.documentUrl">已上传</span>
                        <Spin v-else>
                            <Icon type="ios-loading" size="22" style="color: #3399ff"></Icon>
                        </Spin>
                    </template>
                    <template slot-scope="{ row }" slot="operate">
                        <ButtonGroup>
                            <Button
                                v-if="row.isDeleted == 1"
                                @click="delFile(row)"
                                type="error"
                                size="small"
                            >删除</Button>
                            <Button
                                v-if="row.isDeleted == 2"
                                @click="fileRevert(row)"
                                type="success"
                                size="small"
                            >恢复</Button>
                        </ButtonGroup>
                    </template>
                </Table>
            </div>
        </Modal>
    </div>
</template>

<script>
import modalMixin from '@/mixins/modalMixin';
import { uploadFile } from '@/api/upload';
import {
    materialUploadAdd,
    materialUploadDel,
    materialUploadUpdate
} from '@/api/material/materialadd';
import { getRecordList, delRecord } from '@/api/masterData/customer';
import {licenseRevert} from '@/api/material/materialchange.js';
import { changeFileRevert } from '@/api/masterData/userchange';
import { getDate } from '@/libs/tools';

export default {
    props: {
        radioData: {
            type: Array,
            default: () => {
                return [];
            }
        },
        uploadTable: {
            type: Array,
            default: () => {
                return [];
            }
        },
        projectChangeReadonly: {
            type: Boolean,
            default: false
        },
        isChange: {
            type: Boolean,
            default: false
        },
        oldUploadArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        readonly: {
            type: Boolean,
            default: false
        },
        commodityId: ''
    },
    mixins: [modalMixin],
    data() {
        return {
            Null: '',
            typeRadio: '',
            fileData: [],
            records: [],
            formAttr: {
                licenseCode: '',
                expiryDate: '',
                dataType: ''
            },
            documentId: '',
            ruleValidate: {
                licenseCode: [{ required: true, message: '证书编号为必填项' }],
                dataType: [{ required: true, message: '资料类型为必填项' }],
                expiryDate: [{ required: true, message: '有效日期为必填项' }]
            },
            fileTitle: [
                { type: 'index', title: '序号', align: 'center' },
                { title: '文件名', key: 'documentName', align: 'center' },
                { title: '状态', align: 'center', slot: 'status' },
                {
                    title: '操作',
                    align: 'center',
                    render: (h, params) => {
                        return h(
                            'Button',
                            {
                                props: {
                                    type: 'error',
                                    size: 'small'
                                },
                                on: {
                                    click: () => {
                                        this.delFile(params.row);
                                    }
                                }
                            },
                            '删除'
                        );
                    }
                }
            ],
            uploadTitle: [
                {
                    title: '资料类型',
                    align: 'center',
                    minWidth: 100,
                    slot: 'dataTypeName'
                },
                {
                    title: '证书编号',
                    align: 'center',
                    minWidth: 100,
                    slot: 'licenseCode'
                },
                {
                    title: '有效日期',
                    align: 'center',
                    minWidth: 150,
                    slot: 'expiryDate',
                    // render: (h, params) => {
                    //     return h(
                    //         'span',
                    //         {},
                    //         getDate(params.row.expiryDate, 'long')
                    //     );
                    // }
                },
                {
                    title: '状态',
                    align: 'center',
                    minWidth: 100,
                    slot: 'statusName'
                    // render: (h, params) => {
                    //     const status = params.row.status === 3;
                    //     return h(
                    //         'Tag',
                    //         {
                    //             props: {
                    //                 color: status ? 'success' : 'default'
                    //             }
                    //         },
                    //         status ? '有效' : '无效'
                    //     );
                    // }
                },
                {
                    title: '上传日期',
                    align: 'center',
                    minWidth: 150,
                    slot: 'updateTime'
                    // render: (h, params) => {
                    //     return h(
                    //         'span',
                    //         {},
                    //         getDate(params.row.updateTime, 'long')
                    //     );
                    // }
                },
                {
                    title: '上传人员',
                    align: 'center',
                    minWidth: 100,
                    slot: 'updateName'
                    // key: 'updateName'
                },
                {
                    title: '操作',
                    align: 'center',
                    minWidth: 100,
                    slot: 'operate'
                }
            ]
        };
    },
    created() {
        if (this.projectChangeReadonly || this.readonly) {
            this.uploadTitle.pop();
        }
    },
    methods: {
        modalOk() {
            this.$refs['form'].validate(async valid => {
                if (!valid) {
                    return this.changeLoading();
                }

                let res = null;
                if (this.currentId) {
                    const params = Object.assign({}, this.formAttr, {
                        id: this.currentId,
                        records: this.records,
                        commodityId: this.commodityId,
                        expiryDate: new Date(this.formAttr.expiryDate).valueOf()
                    });
                    res = await materialUploadUpdate(params);
                } else {
                    if (!this.records.length) {
                        this.$Message.error('文件不可为空');
                        this.changeLoading();
                        return;
                    }
                    const params = Object.assign({}, this.formAttr, {
                        records: this.records,
                        commodityId: this.commodityId,
                        expiryDate: new Date(this.formAttr.expiryDate).valueOf()
                    });
                    res = await materialUploadAdd(params);
                }
                if (res.status === this.code) {
                    this.currentId = null;
                    this.todoOver(res.msg);
                    // this.$emit('updateTable');
                    this.modalClose();
                }
            });
        },
        dateChange(e) {
            this.formAttr.expiryDateStr = e;
        },
        radioChange(e) {
            this.$emit('updateTable', e);
        },
        modalCancel() {
            this.records = [];
            this.modalShowFlag = false;
            this.$emit('updateTable');
        },
        // 上传前置钩子
        handleBeforeUpload(file) {
            const curFile = this.fileData.filter(item => {
                return item.documentName === file.name;
            });
            if (curFile.length === 0) {
                this.uploadFile(file);
            } else {
                this.$Message.error('不要重复上传文件');
            }
            return false;
        },

        // 文件上传
        async uploadFile(file) {
            let formData = new FormData();
            formData.append('files', file);
            this.fileData.push({
                documentName: file.name
            });
            const res = await uploadFile(formData);
            if (res.status === this.code) {
                this.fileData = this.fileData.map(item => {
                    if (
                        item.documentName + '' ===
                        res.content[0].documentName + ''
                    ) {
                        item = Object.assign(item, res.content[0]);
                    }
                    return item;
                });
                this.records.push(res.content[0]);
            }
        },

        edit(row) {
            this.documentId = row.documentId;
            this.getFile();
            this.editTableData(row, '编辑物料');
            this.formAttr.expiryDate = getDate(row.expiryDate, 'long');
        },

        // 获取已上传的文件列表
        async getFile() {
            const params = {
                documentId: this.documentId
            };
            const res = await getRecordList(params);
            if (res.status === this.code) {
                this.fileData = res.content;
            }
        },

        // 文件删除
        async delFile(e) {
            if (e.id) {
                const params = {
                    id: e.id
                };
                const res = await delRecord(params);
                if (res.status === this.code) {
                    let index = null;
                    this.fileData.forEach((item, i) => {
                        if (item.id == e) {
                            index = i;
                        }
                    });
                    this.fileData.splice(index, 1);
                    this.$Message.success(res.msg);
                }
            } else {
                let index = null;
                this.fileData.forEach((item, i) => {
                    if (item.name == e.name) {
                        index = i;
                    }
                });
                this.fileData.splice(index, 1);
            }
        },

        // 文件假删除恢复
        async fileRevert(row) {
            const params = { id: row.id };
            const res = await changeFileRevert(params);
            if (res.status === this.code) {
                this.getFile();
            }
        },

        // 假删除恢复
       async resvert(row){
           const params = { id: row.id };
           const res=await licenseRevert(params);
           if(res.status===this.code){
               this.$emit('updateTable');
           }
       },

        async delInfo(row) {
            // 如果是旧数据，调用假删除
            if (row.metaId) {
                const params = {
                    id: row.id,
                    isChange:true
                };
                materialUploadDel(params)
                    .then(res => {
                        if (res.status === this.code) {
                            this.$emit('updateTable');
                        }
                    })
                    .catch(err => {
                        this.$Message.error(err);
                    });
            }
            else{
            this.$Modal.confirm({
                title: '是否确认删除',
                onOk: async () => {
                    const params = {
                        id: row.id
                    };
                    const res = await materialUploadDel(params);
                    if (res.status === this.code) {
                        this.todoOver(res.msg);
                        this.$emit('updateTable');
                    }
                }
            });
            }
        },

        // 关闭
        modalClose() {
            Object.keys(this.formAttr).forEach(item => {
                this.formAttr[item] = '';
            });
            this.fileData = [];
            this.records = [];
            this.modalFlag = false;
            this.currentId = null;
            this.$refs['form'].resetFields();
            this.$emit('updateTable');
        },
        add() {
            this.addItem('上传资料');
        },
        getDatePrive(params, type) {
            return getDate(params, type);
        }
    }
};
</script>

<style scoped>
.check-container {
    display: inline-block;
    min-width: 150px;
}
</style>
