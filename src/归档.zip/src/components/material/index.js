import baseInfoForm from './baseInfoForm.vue';
import packageInfo from './package.vue';
import upload from './upload.vue';

export const BaseInfoForm = baseInfoForm;
export const Package = packageInfo;
export const Upload = upload;
