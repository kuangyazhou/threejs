<template>
    <!-- <div>包装单位列表</div> -->
    <div class="package">
        <Card dis-hover class="mb20">
            <p slot="title">包单位列表</p>
            <div slot="extra" v-if="!projectChangeReadonly">
                <ButtonGroup>
                    <Button @click="addPackage" v-if="!readonly">新增</Button>
                </ButtonGroup>
            </div>
            <Table :border="true" :data="packageArr" :columns="tableTitle">
                <!-- 单位名称 -->
                <template slot-scope="{ row }" slot="unitName">
                    <span
                        :class="{
                            update:
                                isChange &&
                                findUpdate(oldPackageArr, row, 'unitId'),
                            add: isChange && !row.metaId,
                            deleted: isChange && row.isDeleted == 2
                        }"
                    >{{ row.unitName }}</span>
                </template>
                <!-- 单位编码 -->
                <template slot-scope="{ row }" slot="unitCode">
                    <span
                        :class="{
                            update:
                                isChange &&
                                findUpdate(oldPackageArr, row, 'unitCode'),
                            add: isChange && !row.metaId,
                            deleted: isChange && row.isDeleted == 2
                        }"
                    >{{ row.unitCode }}</span>
                </template>
                <!-- 是否标准单位 -->
                <template
                    slot-scope="{ row }"
                    slot="isStandard"
                    :class="{
                        update:
                            isChange &&
                            findUpdate(oldPackageArr, row, 'isStandard'),
                        add: isChange && !row.metaId,
                        deleted: isChange && row.isDeleted == 2
                }"
                >
                    <span v-if="row.isStandard">
                        <Tag color="success">是</Tag>
                    </span>
                    <span v-else>
                        <Tag color="default">否</Tag>
                    </span>
                </template>
                <!-- 是否默认 -->
                <template
                    slot-scope="{ row }"
                    slot="isDefault"
                    :class="{
                        update:
                            isChange &&
                            findUpdate(oldPackageArr, row, 'isDefault'),
                        add: isChange && !row.metaId,
                        deleted: isChange && row.isDeleted == 2}"
                >
                    <span v-if="row.isDefault">
                        <Tag color="success">是</Tag>
                    </span>
                    <span v-else>
                        <Tag color="default">否</Tag>
                    </span>
                </template>
                <!-- 转换系数 -->
                <template slot-scope="{ row }" slot="quotiety">
                    <span
                        :class="{
                            update:
                                isChange &&
                                findUpdate(oldPackageArr, row, 'quotiety'),
                            add: isChange && !row.metaId,
                            deleted: isChange && row.isDeleted == 2
                        }"
                    >{{ row.quotiety }}</span>
                </template>
                <!-- 状态 -->
                <template
                    slot-scope="{ row }"
                    slot="status"
                    :class="{
                        update:
                            isChange &&
                            findUpdate(oldPackageArr, row, 'status'),
                        add: isChange && !row.metaId,
                        deleted: isChange && row.isDeleted == 2
                }"
                >
                    <span v-if="row.status === 3">
                        <Tag color="success">有效</Tag>
                    </span>
                    <span v-else>
                        <Tag color="default">无效</Tag>
                    </span>
                </template>
                <template slot-scope="{ row }" slot="operate">
                    <Button
                        v-if="!row.isDefault"
                        @click="setDefault(row)"
                        type="info"
                        size="small"
                        class="mr6"
                    >默认</Button>
                    <Button
                        v-if="!row.isStandard"
                        @click="setStandard(row)"
                        type="primary"
                        size="small"
                        class="mr6"
                    >标准</Button>
                    <Button @click="edit(row)" class="mr6" type="primary" size="small">编辑</Button>
                    <Button @click="del(row)" v-if="row.isDeleted===1" type="error" size="small">删除</Button>
                    <Button
                        @click="revert(row)"
                        size="small"
                        type="success"
                        v-if="row.isDeleted===2"
                    >恢复</Button>
                </template>
            </Table>
        </Card>
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel"
        >
            <div class="erp-modal-content">
                <Form :model="formAttr" ref="formValidate" :rules="ruleValidate" :label-width="100">
                    <FormItem label="单位名称" prop="unitId">
                        <!-- <Input v-model="formAttr.unitName" placeholder="单位名称"></Input> -->
                        <Select v-model="formAttr.unitId">
                            <Option
                                v-for="item in unitArr"
                                :key="item.index"
                                :label="item.fieldValue"
                                :value="item.id"
                            ></Option>
                        </Select>
                    </FormItem>
                    <!-- <FormItem label="单位编码">
                        <Input v-model="formAttr.unitCode" disabled placeholder="单位编码"></Input>
                    </FormItem>-->
                    <FormItem label="转换系数" prop="quotiety">
                        <Input
                            v-model="formAttr.quotiety"
                            placeholder="转换系数"
                            :disabled="Boolean(formAttr.isStandard)"
                        ></Input>
                    </FormItem>
                    <FormItem label="状态">
                        <RadioGroup v-model="formAttr.status">
                            <Radio :label="3">有效</Radio>
                            <Radio :label="4">无效</Radio>
                        </RadioGroup>
                    </FormItem>
                </Form>
            </div>
        </Modal>
        <Modal
            title="设置标准单位"
            v-model="standardModal"
            :mask-closable="maskClosable"
            @on-ok="standardOk"
        >
            <!-- <Form :label-width="100">
                <FormItem label="标准单位"></FormItem>
                <FormItem label="转换系数设置"></FormItem>
            </Form>-->
            <p>标准单位 :{{ curStandard.unitName }}</p>
            <p>转换系数设置</p>
            <Form :label-width="100" :model="otherModel">
                <FormItem v-for="item in otherArr" :label="item.unitName" :key="item.index">
                    <Input v-model="otherModel[item.id]" placeholder="转换系数"></Input>
                </FormItem>
            </Form>
        </Modal>
    </div>
</template>

<script>
import modalMixin from '@/mixins/modalMixin';
import {
    packageAdd,
    packageUpdate,
    packageDel,
    packageDefault,
    packageStandard
} from '@/api/material/materialadd';

import { packageRevert } from '@/api/material/materialchange.js';

export default {
    mixins: [modalMixin],
    props: {
        packageArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        organizationId: {
            id: null
        },
        projectChangeReadonly: {
            type: Boolean,
            default: false
        },
        oldPackageArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        unitArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        commodityId: '',

        // 变更效果开启
        isChange: {
            type: Boolean,
            default: false
        },
        readonly: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            formAttr: {
                unitId: '',
                unitCode: '',
                commodityId: '',
                quotiety: '',
                status: '',
                isStandard: null
            },
            otherArr: [],
            otherModel: {},
            standardModal: false,
            modalPackage: false,
            curStandard: {},
            tableData: [],
            ruleValidate: {
                unitId: [
                    {
                        required: true,
                        message: '单位名称不可为空'
                    }
                ],
                quotiety: [
                    {
                        required: true,
                        message: '转换系数不可为空'
                    }
                ]
            },

            tableTitle: [
                {
                    title: '单位名称',
                    align: 'center',
                    minWidth: 120,
                    slot: 'unitName'
                },
                {
                    title: '单位编码',
                    align: 'center',
                    minWidth: 120,
                    slot: 'unitCode'
                },
                {
                    title: '是否标准单位',
                    align: 'center',
                    minWidth: 120,
                    slot: 'isStandard'
                },
                {
                    title: '默认',
                    align: 'center',
                    minWidth: 120,
                    slot: 'isDefault'
                },
                {
                    title: '转换系数',
                    align: 'center',
                    minWidth: 120,
                    slot: 'quotiety'
                },
                {
                    title: '状态',
                    align: 'center',
                    minWidth: 120,
                    slot: 'status'
                },
                {
                    title: '操作',
                    align: 'center',
                    minWidth: 160,
                    slot: 'operate'
                }
            ]
        };
    },
    created() {
        if (this.projectChangeReadonly || this.readonly) {
            this.tableTitle.pop();
        }
    },
    methods: {
        modalOk() {
            this.$refs['formValidate'].validate(async valid => {
                if (!valid) {
                    return this.changeLoading();
                }
                if (!Number.isInteger(Number(this.formAttr.quotiety))) {
                    this.$Message.error('转换系数只能为整数');
                    return this.changeLoading();
                }
                let res = null;
                const params = this.currentId
                    ? Object.assign({}, this.formAttr, {
                          id: this.currentId,
                          commodityId: this.commodityId
                      })
                    : Object.assign({}, this.formAttr, {
                          organizationId: this.organizationId.id,
                          commodityId: this.commodityId
                      });
                if (this.currentId) {
                    res = await packageUpdate(params);
                } else {
                    res = await packageAdd(params);
                }
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                    this.$emit('updateTable');
                    this.modalCancel();
                } else {
                    this.changeLoading();
                }
            });
        },
        addPackage() {
            this.addItem('新增物料');
        },
        // 设置默认
        async setDefault(row) {
            const parmas = {
                id: row.id
            };
            const res = await packageDefault(parmas);
            if (res.status === this.code) {
                this.todoOver(res.msg);
                this.$emit('updateTable');
            }
        },
        // 设置标准
        async setStandard(row) {
            this.curStandard = row;
            this.standardModal = true;
            this.otherArr = this.packageArr.filter(item => {
                return item.id != row.id;
            });

            // 更新data
            this.otherArr.forEach(item => {
                this.$set(this.otherModel, item.id, '');
            });
        },

        // 保存标准系数
        async standardOk() {
            let temp = [];
            Object.keys(this.otherModel).forEach(item => {
                temp.push({
                    id: Number(item),
                    quotiety: this.otherModel[item]
                });
            });
            // temp.every(item=>{
            //     if(Number.isInteger(item.quotiety)){

            //     }
            // })
            let isInt = temp.every(item => {
                return Number.isInteger(Number(item.quotiety));
            });
            if (!isInt) {
                this.$Message.error('转换系数只能为整数');
                return;
            }
            const params = {
                id: this.curStandard.id,
                existUnits: temp
            };
            const res = await packageStandard(params);
            if (res.status === this.code) {
                this.$Message.success(res.msg);
                this.standardModal = false;
                this.otherModel = {};
                this.$emit('updateTable');
            }
        },
        edit(row) {
            // console.log(row);
            this.commodityId = row.commodityId;
            this.editTableData(row, '编辑包装信息');
        },

        //假删除恢复
        // 假删除恢复
        async resvert(row) {
            const params = { id: row.id };
            const res = await packageRevert(params);
            if (res.status === this.code) {
                this.$emit('updateTable');
            }
        },

        // 删除逻辑
        del(row) {
            if (row.metaId) {
                const params = {
                    id: row.id,
                    isChange: true
                };
                packageDel(params)
                    .then(res => {
                        if (res.status === this.code) {
                            this.$emit('updateTable');
                        }
                    })
                    .catch(err => {
                        this.$Message.error(err);
                    });
            } else {
                this.$Modal.confirm({
                    title: `确认删除此条包装信息吗？`,
                    onOk: async () => {
                        const parmas = {
                            id: row.id
                        };
                        const res = await packageDel(parmas);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.$emit('updateTable');
                        }
                    }
                });
            }
        }
    }
};
</script>
