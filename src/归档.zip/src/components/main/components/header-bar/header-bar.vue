<template>
    <div class="header-bar">
        <sider-trigger
            :collapsed="collapsed"
            icon="md-menu"
            @on-change="handleCollpasedChange"
        ></sider-trigger>
        <custom-bread-crumb
            show-icon
            style="margin-left: 30px;"
            :list="breadCrumbList"
        ></custom-bread-crumb>
        <div class="custom-content-con">
            <slot></slot>
        </div>
        <Dropdown class="erp-change-wms"
                  @on-click="changeSystem"
        >
            <div class="title">
                ERP
                <Icon type="ios-arrow-down"></Icon>
            </div>
            <DropdownMenu slot="list">
                <DropdownItem name="erp">
                    ERP
                </DropdownItem>
                <DropdownItem name="wms">
                    WMS
                </DropdownItem>
            </DropdownMenu>
        </Dropdown>
    </div>
</template>
<script>
    import siderTrigger from './sider-trigger';
    import customBreadCrumb from './custom-bread-crumb';
    import './header-bar.less';

    export default {
        name: 'HeaderBar',
        components: {
            siderTrigger,
            customBreadCrumb
        },
        data () {
            return {
                systemMenuList: []
            };
        },
        props: {
            collapsed: Boolean
        },
        computed: {
            breadCrumbList () {
                return this.$store.state.app.breadCrumbList;
            }
        },
        methods: {
            handleCollpasedChange (state) {
                this.$emit('on-coll-change', state);
            },
            changeSystem (index) {
                if (index === 'wms') {
                    if (process.env.NODE_ENV === 'production') {
                        if (process.env.VUE_APP_FLAG === 'pro') {
                            window.open(`//172.16.0.35/wms/home`);
                        } else {
                            const hostname = window.location.hostname;
                            if (hostname.indexOf('erpmig') !== -1) {
                                window.open('//wmsmig.tyche.net.cn/home');
                            } else {
                                window.open(`//wmstest.tyche.net.cn/home`);
                            }
                        }
                    } else {
                        window.open(`http://localhost:8081/home`);
                    }
                }
            }
        }
    };
</script>
