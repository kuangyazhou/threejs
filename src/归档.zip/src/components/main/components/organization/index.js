import User from './organization.vue';

export default User;
