<template>
    <div class="organization-dropdown">
        <Dropdown
            v-if="organizationsList.length"
            @on-click="changeOrganization"
        >
            <div class="title">
                {{ organizationName }}
                <Icon type="ios-arrow-down"></Icon>
            </div>
            <DropdownMenu slot="list">
                <DropdownItem
                    v-for="(item, index) in organizationsList"
                    :key="item.organizationCode"
                    :name="index"
                >
                    {{ item.organizationName }}
                </DropdownItem>
            </DropdownMenu>
        </Dropdown>
    </div>
</template>

<script>
import './organization.less';
import { mapGetters, mapActions } from 'vuex';

export default {
    name: 'Organization',
    computed: {
        ...mapGetters([
            'organizationsList',
            'currentOrganization',
            'currentDepartment'
        ]),
        organizationName() {
            return this.currentOrganization.organizationName;
        }
    },
    methods: {
        ...mapActions(['changeCurrentOrganization']),
        // 点击切换组织
        changeOrganization(index) {
            const organization = this.organizationsList[index];
            this.changeCurrentOrganization(organization).then(() => {
                this.$router.push({
                    name: 'emptyPage'
                });
            });
        }
    }
};
</script>
