import ErrorStore from './error-store.vue';

export default ErrorStore;
