import baseInFoForm from './baseInfoForm.vue';
import machineManagement from './machineManagement.vue';
import machineProduction from './machineProduction.vue';
import uploadData from './upload.vue';
import contact from './contact.vue';

export const BaseInFoForm = baseInFoForm;
export const MachineManagement = machineManagement;
export const MachineProduction = machineProduction;
export const UploadData = uploadData;
export const Contact = contact;
