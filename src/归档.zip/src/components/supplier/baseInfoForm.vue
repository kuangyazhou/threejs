<template>
    <div class="base-info-form">
        <Card dis-hover>
            <h4
                class="info-title"
                v-if="formAttr.parentId && formAttr.parentSupplierName.length"
            >
                上级供应商：{{ formAttr.parentSupplierName }}
            </h4>
            <Form
                :model="formAttr"
                :rules="ruleValidate"
                ref="formValidate"
                :label-width="120"
            >
                <Row>
                    <Col span="8">
                        <FormItem
                            prop="supplierName"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.supplierName &&
                                    formAttr.supplierName !==
                                        oldFormAttr.supplierName
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.supplierName"
                                    >供应商名称</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="firstImport || formDisabled"
                                v-model="formAttr.supplierName"
                                placeholder="请输入供应商名称"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.supplierAbbreviation &&
                                    formAttr.supplierAbbreviation !==
                                        oldFormAttr.supplierAbbreviation
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.supplierAbbreviation"
                                    >供应商简称</Tooltip
                                    :disabled="!firstChange && !secondChange"
                                >
                            </template>
                            <Input
                                :disabled="
                                    secondChange || formDisabled
                                "
                                v-model="formAttr.supplierAbbreviation"
                                placeholder="请输入供应商简称"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem class="is-required">
                            <template slot="label">
                                <Tooltip disabled>供应商代码</Tooltip>
                            </template>
                            <Input
                                v-model="formAttr.supplierCode"
                                disabled
                            ></Input>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="8">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.supplierClassify &&
                                    formAttr.supplierClassify !==
                                        oldFormAttr.supplierClassify
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.supplierClassifyName"
                                    >供应商分类</Tooltip
                                >
                            </template>
                            <Select
                                v-model="formAttr.supplierClassify"
                                placeholder="请选择供应商分类"
                                :disabled="secondChange || formDisabled"
                            >
                                <Option
                                    v-for="(option,
                                    index) in supplierClassifyArr"
                                    :value="option.id"
                                    :label="option.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.supplierNature &&
                                    formAttr.supplierNature !==
                                        oldFormAttr.supplierNature
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.supplierNatureName"
                                    >供应商性质</Tooltip
                                >
                            </template>
                            <Select
                                v-model="formAttr.supplierNature"
                                placeholder="请选择供应商性质"
                                :disabled="secondChange || formDisabled"
                            >
                                <Option
                                    v-for="(option, index) in supplierNatureArr"
                                    :value="option.id"
                                    :label="option.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.supplierLevel &&
                                    formAttr.supplierLevel !==
                                        oldFormAttr.supplierLevel
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.supplierLevelName"
                                    >供应商等级</Tooltip
                                >
                            </template>
                            <Select
                                v-model="formAttr.supplierLevel"
                                placeholder="请选择供应商等级"
                                :disabled="secondChange || formDisabled"
                            >
                                <Option
                                    v-for="(option, index) in supplierLevelArr"
                                    :value="option.id"
                                    :label="option.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="8">
                        <FormItem class="is-required">
                            <template slot="label">
                                <Tooltip disabled>供应商状态</Tooltip>
                            </template>
                            <Select
                                v-model="formAttr.supplierStatus"
                                placeholder="首营"
                                :disabled="!secondChange || formDisabled"
                            >
                                <Option
                                    v-for="(option, index) in supplierStatusArr"
                                    :value="option.id"
                                    :label="option.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.unifiedSocialCreditCode &&
                                    formAttr.unifiedSocialCreditCode !==
                                        oldFormAttr.unifiedSocialCreditCode
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="
                                        oldFormAttr.unifiedSocialCreditCode
                                    "
                                    >统一社会信用码</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="
                                    firstSub || firstImport || formDisabled
                                "
                                v-model="formAttr.unifiedSocialCreditCode"
                                placeholder="请输入统一社会信用码"
                            >
                            </Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem class="is-required">
                            <template slot="label">
                                <Tooltip disabled>关联采购</Tooltip>
                            </template>
                            <Button
                                disabled
                                class="form-button-select"
                                icon="ios-arrow-down"
                                >请选择关联采购
                            </Button>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="8">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.supplierType &&
                                    formAttr.supplierType !==
                                        oldFormAttr.supplierType
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.supplierTypeName"
                                    >供应商种类</Tooltip
                                >
                            </template>
                            <Select
                                v-model="formAttr.supplierType"
                                placeholder="请选择供应商种类"
                                :disabled="
                                    firstSub || firstImport || formDisabled
                                "
                            >
                                <Option
                                    v-for="(option, index) in supplierTypeArr"
                                    :value="option.id"
                                    :label="option.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.supplierCategory &&
                                    formAttr.supplierCategory !==
                                        oldFormAttr.supplierCategory
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.supplierCategoryName"
                                    >供应商类别</Tooltip
                                >
                            </template>
                            <Select
                                v-model="formAttr.supplierCategory"
                                placeholder="请选择供应商类别"
                                :disabled="
                                    firstSub || firstImport || formDisabled
                                "
                            >
                                <Option
                                    v-for="(option,
                                    index) in supplierCategoryArr"
                                    :value="option.id"
                                    :label="option.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.specialtyGroup &&
                                    formAttr.specialtyGroup !==
                                        oldFormAttr.specialtyGroup
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.specialtyGroupName"
                                    >专业分组</Tooltip
                                >
                            </template>
                            <Select
                                v-model="formAttr.specialtyGroup"
                                placeholder="请选择专业分组"
                                :disabled="secondChange || formDisabled"
                            >
                                <Option
                                    v-for="(option, index) in specialtyGroupArr"
                                    :value="option.id"
                                    :label="option.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="8">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.bankName &&
                                    formAttr.bankName !== oldFormAttr.bankName
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.bankName"
                                    >开户银行</Tooltip
                                >
                            </template>
                            <AutoComplete
                                :disabled="secondChange || formDisabled"
                                v-model="formAttr.bankName"
                                @on-change="bankHandleSearch"
                                @on-select="afterSelectBank"
                                :filter-method="bankFilterMethod"
                                placeholder="请输入开户银行"
                            >
                                <Option
                                    v-for="item in bankList"
                                    :value="item.bankName"
                                    :key="item.id"
                                >
                                    <Row :gutter="6">
                                        <Col span="14">{{ item.bankName }}</Col>
                                        <Col span="10">{{ item.bankCode }}</Col>
                                    </Row>
                                </Option>
                            </AutoComplete>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.bankAccount &&
                                    formAttr.bankAccount !==
                                        oldFormAttr.bankAccount
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.bankAccount"
                                    >银行账号</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="secondChange || formDisabled"
                                v-model="formAttr.bankAccount"
                                placeholder="请输入银行账号"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.bankCode &&
                                    formAttr.bankCode !== oldFormAttr.bankCode
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="
                                        (!firstChange && !secondChange) ||
                                            formDisabled
                                    "
                                    :content="oldFormAttr.bankCode"
                                    >银行行号</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="secondChange || formDisabled"
                                v-model="formAttr.bankCode"
                                placeholder="请输入银行行号"
                            ></Input>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="8">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.payCondition &&
                                    formAttr.payCondition !==
                                        oldFormAttr.payCondition
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.payCondition"
                                    >付款条件</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="secondChange || formDisabled"
                                v-model="formAttr.payCondition"
                                placeholder="请输入付款条件"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.negotiator &&
                                    formAttr.negotiator !==
                                        oldFormAttr.negotiator
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.negotiator"
                                    >谈判人员</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="secondChange || formDisabled"
                                v-model="formAttr.negotiator"
                                placeholder="请输入谈判人员"
                            ></Input>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="12">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.supplierAddress &&
                                    formAttr.supplierAddress !==
                                        oldFormAttr.supplierAddress
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.supplierAddress"
                                    >供应商地址</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="formDisabled"
                                v-model="formAttr.supplierAddress"
                                placeholder="请输入供应商地址"
                            >
                            </Input>
                        </FormItem>
                    </Col>
                    <Col span="12">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.warehouseAddress &&
                                    formAttr.warehouseAddress !==
                                        oldFormAttr.warehouseAddress
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.warehouseAddress"
                                    >仓库地址</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="formDisabled"
                                v-model="formAttr.warehouseAddress"
                                placeholder="请输入仓库地址"
                            >
                            </Input>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="12">
                        <FormItem
                            class="is-required"
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.mainBrand &&
                                    formAttr.mainBrand !== oldFormAttr.mainBrand
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.mainBrand"
                                    >主营品牌</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="secondChange || formDisabled"
                                v-model="formAttr.mainBrand"
                                placeholder="请输入主营品牌"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="12">
                        <FormItem
                            :class="{
                                equal:
                                    firstChange &&
                                    formAttr.supplierDescription &&
                                    formAttr.supplierDescription !==
                                        oldFormAttr.supplierDescription
                            }"
                        >
                            <template slot="label">
                                <Tooltip
                                    :disabled="!firstChange && !secondChange"
                                    :content="oldFormAttr.supplierDescription"
                                    >备注</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="secondChange || formDisabled"
                                v-model="formAttr.supplierDescription"
                                :placeholder="(!Boolean(formAttr.supplierDescription) && (secondChange || formDisabled))?'':'请输入备注'"
                            ></Input>
                        </FormItem>
                    </Col>
                </Row>
            </Form>
        </Card>
    </div>
</template>

<script>
import {
    addSupplierApply,
    editSupplierApply,
    getBankList,
    addSupplierChange,
    editSupplierChange,
    addQcSupplierChange,
    editQcSupplierChange
} from '@/api/masterData/supplier';
import { resetObj } from '@/libs/tools';

export default {
    props: {
        supplierLevelArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        supplierNatureArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        supplierClassifyArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        specialtyGroupArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        supplierTypeArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        supplierCategoryArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        supplierStatusArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        oldFormAttr: {
            type: Object,
            default: () => {
                return {};
            }
        },
        newFormAttr: {
            type: Object,
            default: () => {
                return {};
            }
        },
        // 引入
        firstImport: {
            type: Boolean,
            default: () => {
                return false;
            }
        },
        // 子供应商
        firstSub: {
            type: Boolean,
            default: () => {
                return false;
            }
        },
        // 变更
        firstChange: {
            type: Boolean,
            default: () => {
                return false;
            }
        },
        // 质管变更
        secondChange: {
            type: Boolean,
            default: () => {
                return false;
            }
        },
        // 禁止编辑
        formDisabled: {
            type: Boolean,
            default: () => {
                return false;
            }
        }
    },
    data() {
        return {
            formAttr: {
                supplierName: '',
                supplierAbbreviation: '',
                supplierCode: '',
                supplierClassify: '',
                supplierNature: '',
                supplierLevel: '',
                unifiedSocialCreditCode: '',
                parentId: '',
                parentSupplierName: '',
                supplierAddress: '',
                warehouseAddress: '',
                supplierType: '',
                supplierCategory: '',
                specialtyGroup: '',
                payCondition: '',
                negotiator: '',
                bankName: '',
                bankAccount: '',
                bankCode: '',
                mainBrand: '',
                supplierDescription: '',
                isImport: '',
                supplierId: '',
                id: '',
                taskStatus: '',
                supplierStatus: ''
            },
            ruleValidate: {
                supplierName: [
                    {
                        required: true,
                        message: '客户名称不能为空',
                        trigger: 'blur'
                    }
                ]
            },
            code: 10000,
            bankList: [],
            bankTimer: null, // 银行自动填充防抖
            curBanks: '' // 自动选中的银行信息
        };
    },
    methods: {
        // 新增供应商中保存信息
        saveInfo() {
            this.$refs['formValidate'].validate(async valid => {
                if (!valid) {
                    return this.$emit('changeLoading');
                }
                if (this.bankValidate()) {
                    let res;
                    const isImport = this.firstImport ? 1 : 0;
                    const params = Object.assign({}, this.formAttr, {
                        isImport
                    });
                    if (this.formAttr.id) {
                        res = await editSupplierApply(params);
                    } else {
                        res = await addSupplierApply(params);
                    }
                    this.$emit('changeLoading');
                    if (res.status === this.code) {
                        this.$emit('changeCurrentId', {
                            id: res.content.id,
                            mainBrand: this.formAttr.mainBrand
                        });
                        this.$Message.success(res.msg);
                        this.$emit('getTableList');
                        this.formAttr = Object.assign({}, this.formAttr, {
                            id: res.content.id,
                            supplierCode: res.content.supplierCode
                        });
                    }
                } else {
                    this.$emit('changeLoading');
                }
            });
        },
        // 自动填充开户银行
        bankHandleSearch(value) {
            if (!value) return;
            if (this.bankTimer) clearTimeout(this.bankTimer);
            this.bankTimer = setTimeout(() => {
                this.searchBank(value);
            }, 400);
        },
        // 搜索银行信息
        async searchBank(val) {
            const params = {
                bankName: val
            };
            const res = await getBankList(params);
            if (res.status === this.code) {
                this.bankList = res.content;
                const curBanks = this.bankList.filter(item => {
                    return item.bankName === val;
                });
                if (curBanks.length === 1) {
                    this.curBanks = curBanks[0];
                    this.formAttr.bankName = this.curBanks.bankName;
                    this.formAttr.bankCode = this.curBanks.bankCode;
                }
            }
        },
        // 选中开会银行后
        afterSelectBank(value) {
            this.curBanks = this.bankList.filter(item => {
                return item.bankName === value;
            })[0];
            this.formAttr.bankName = this.curBanks.bankName;
            this.formAttr.bankCode = this.curBanks.bankCode;
            this.bankList = [];
        },
        // 筛选银行信息
        bankFilterMethod(value, option) {
            return option.toUpperCase().indexOf(value.toUpperCase()) !== -1;
        },
        // 银行必填校验
        bankValidate() {
            if (!this.formAttr.bankName && !this.formAttr.bankCode) {
                return true;
            } else if (this.formAttr.bankName && this.formAttr.bankCode) {
                if (this.formAttr.bankName === this.curBanks.bankName) {
                    if (this.formAttr.bankCode !== this.curBanks.bankCode) {
                        this.$Message.error('银行名称与行号不匹配');
                        return false;
                    } else {
                        return true;
                    }
                } else {
                    return true;
                }
            } else {
                this.$Message.error('银行信息补完整，请检查银行信息');
                return false;
            }
        },
        // 编辑供应商保存
        editSaveInfo() {
            this.$refs['formValidate'].validate(async valid => {
                if (!valid) {
                    return this.$emit('changeLoading');
                }
                if (this.bankValidate()) {
                    let res;
                    const params = Object.assign({}, this.formAttr);
                    if (this.formAttr.id) {
                        if (this.secondChange) {
                            res = await editQcSupplierChange(params);
                        } else {
                            res = await editSupplierChange(params);
                        }
                    } else {
                        if (this.secondChange) {
                            res = await addQcSupplierChange(params);
                        } else {
                            res = await addSupplierChange(params);
                        }
                    }
                    this.$emit('changeLoading');
                    if (res.status === this.code) {
                        this.$emit('changeCurrentId', {
                            id: res.content.id,
                            mainBrand: this.formAttr.mainBrand
                        });
                        this.$Message.success(res.msg);
                        this.$emit('getTableList');
                        this.formAttr = Object.assign({}, this.formAttr, {
                            id: res.content.id
                        });
                    }
                } else {
                    this.$emit('changeLoading');
                }
            });
        },
        // 重置表单
        resetBaseForm() {
            this.$refs['formValidate'].resetFields();
            this.bankList = [];
            resetObj(this.formAttr);
        }
    },
    watch: {
        newFormAttr: {
            handler(val) {
                for (let key in val) {
                    this.formAttr[key] = val[key];
                }
            },
            deep: true
        }
    }
};
</script>

<style scoped lang="less">
.info-title {
    padding-top: 10px;
    padding-bottom: 10px;
}
.is-required {
    /deep/ .ivu-form-item-label {
        padding: 0;
        &::before {
            content: '*';
            display: inline-block;
            margin-right: 4px;
            line-height: 1;
            font-family: SimSun;
            font-size: 12px;
            color: #ed4014;
        }
        .ivu-tooltip {
            padding: 10px 12px 10px 0;
        }
    }
}
.equal {
    /deep/ .ivu-form-item-label {
        color: blue;
    }
}
</style>
