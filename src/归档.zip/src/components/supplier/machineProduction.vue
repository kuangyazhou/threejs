<template>
    <div>
        <Row>
            <Col span="12">
                <Form :label-width="120">
                    <FormItem label="主营品牌">
                        <Input disabled v-model="mainBrand"></Input>
                    </FormItem>
                </Form>
            </Col>
        </Row>
        <Row :gutter="16">
            <Col span="6">
                <Card dis-hover class="class-container">
                    <CheckboxGroup v-model="selectMachine">
                        <div
                            v-for="(item, index) in machineCheckbox"
                            class="checkbox-container"
                            :key="index"
                            :class="{
                                del:
                                    firstChange &&
                                    oldSelectedMachine.includes(
                                        item.deviceClassifyId
                                    ) &&
                                    !selectMachine.includes(
                                        item.deviceClassifyId
                                    ),
                                add:
                                    firstChange &&
                                    isAdd(
                                        oldSelectedMachine,
                                        selectMachine,
                                        item.deviceClassifyId,
                                        'deviceClassifyId'
                                    )
                            }"
                        >
                            <Checkbox
                                :disabled="formDisabled"
                                :label="item.deviceClassifyId"
                                >{{
                                    `${item.deviceClassifyTypeName},${
                                        item.deviceClassifyCode
                                    }, ${item.deviceClassifyName}`
                                }}</Checkbox
                            >
                        </div>
                    </CheckboxGroup>
                </Card>
            </Col>
            <Col span="18">
                <Card dis-hover>
                    <div>
                        <Select
                            placeholder="请选择资料"
                            v-model="infoType"
                            class="select-container"
                        >
                            <Option
                                v-for="item in selectData"
                                :label="item.dataTypeName"
                                :value="item.dataType"
                                :key="item.index"
                            ></Option>
                        </Select>
                        <Button type="primary" @click="viewInfo">查看</Button>
                    </div>
                </Card>
                <Carousel v-model="value1" v-if="carouselData.length">
                    <CarouselItem
                        v-for="(item, index) in carouselData"
                        :key="index"
                        class="carousel-item"
                    >
                        <!-- 根据类型区分用pdf还是img展示 -->
                        <div
                            v-if="
                                item.documentName.includes('pdf') ||
                                    item.documentName.includes('PDF')
                            "
                        >
                            <object draggable="true" class="w100 h80">
                                <param
                                    name="SRC"
                                    :value="fileUrl + item.documentUrl"
                                />
                            </object>
                        </div>
                        <div v-else>
                            <img
                                class="w100 h80"
                                :src="fileUrl + item.documentUrl"
                            />
                        </div>
                    </CarouselItem>
                </Carousel>
            </Col>
        </Row>
    </div>
</template>

<script>
import {
    saveSupplierProductionInfo,
    getSupplierLicenseFile
} from '@/api/masterData/supplier';
import modalMixin from '@/mixins/modalMixin';
export default {
    mixins: [modalMixin],
    props: {
        // 器械种类
        machineCheckbox: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 选择资料下拉框
        selectData: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 已选择器械
        selectedMachine: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 变更前已选择器械
        oldSelectedMachine: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 实例id
        taskInstanceId: '',
        // 主营品牌
        mainBrand: {
            type: String,
            default: ''
        },
        // 变更
        firstChange: {
            type: Boolean,
            default: false
        },
        // 禁止编辑
        formDisabled: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            all: false,
            value1: 0,
            carouselData: [],
            infoType: [],
            code: 10000,
            selectMachine: []
        };
    },
    watch: {
        selectedMachine(val) {
            this.selectMachine = val;
        }
    },
    methods: {
        // 查看证照
        async viewInfo() {
            const params = {
                taskInstanceId: this.taskInstanceId,
                dataType: this.infoType
            };
            const res = await getSupplierLicenseFile(params);
            if (res.status === this.code) {
                const data = res.content;
                let temp = [];
                data.forEach(item => {
                    if (item.documentName) {
                        temp.push(item);
                    }
                });
                this.carouselData = temp;
            }
        },

        // 保存生产器械分类数据
        async saveData() {
            if (this.selectMachine.length === 0) {
                this.$Message.error('请勾选器械生产类型');
                this.$emit('changeLoading');
                return;
            }
            const params = {
                taskInstanceId: this.taskInstanceId,
                deviceClassifyList: this.selectMachine
            };
            const machine = await saveSupplierProductionInfo(params);
            if (machine.status === this.code) {
                this.$Message.success('器械生产信息保存成功');
                this.$emit('changeLoading');
            } else {
                this.$Message.error(machine.msg);
            }
        }
    }
};
</script>

<style scoped>
.check-container {
    display: inline-block;
    min-width: 100px;
}
.checkbox-container:not(:last-child) {
    margin-bottom: 8px;
}

.select-container {
    width: 180px;
    margin-right: 18px;
}

.class-container {
    /* max-height: 40vh; */
    overflow-y: auto;
}

.w100 {
    width: 100%;
}
.h80 {
    height: 80vh;
    min-height: 400px;
}
.del {
    color: red;
}
</style>
