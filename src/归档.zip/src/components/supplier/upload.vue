<template>
    <div class="upload">
        <Card dis-hover class="mb20">
            <div slot="extra">
                <ButtonGroup v-if="radioData.length && !firstSub">
                    <Button
                        v-if="!formDisabled"
                        @click="add"
                        icon="md-add"
                        class="z10"
                        >新增</Button
                    >
                </ButtonGroup>
            </div>
            <Row>
                <Col span="2">资料类型</Col>
                <Col span="20">
                    <RadioGroup
                        v-model="formAttr.dataType"
                        @on-change="radioChange"
                    >
                        <span class="check-container f16">
                            <Radio :label="Null">全部</Radio>
                        </span>
                        <span
                            class="check-container f16"
                            v-for="item in radioData"
                            :key="item.index"
                            :class="{ 'is-required': item.isMust }"
                        >
                            <Radio :label="item.dataType">{{
                                item.dataTypeName
                            }}</Radio>
                        </span>
                    </RadioGroup>
                </Col>
            </Row>
        </Card>
        <Table :border="true" :columns="uploadTitle" :data="uploadTable">
            <template slot-scope="{ row }" slot="dataTypeName">
                <span
                    :class="{
                        update:
                            firstChange &&
                            findUpdate(oldUploadTable, row, 'dataTypeName'),
                        add: firstChange && !row.metaId,
                        deleted: firstChange && row.isDeleted === 2
                    }"
                    >{{ row.dataTypeName }}</span
                >
            </template>
            <template slot-scope="{ row }" slot="licenseCode">
                <span
                    :class="{
                        update:
                            firstChange &&
                            findUpdate(oldUploadTable, row, 'licenseCode'),
                        add: firstChange && !row.metaId,
                        deleted: firstChange && row.isDeleted === 2
                    }"
                    >{{ row.licenseCode }}</span
                >
            </template>
            <template slot-scope="{ row }" slot="expiryDate">
                <span
                    :class="{
                        update:
                            firstChange &&
                            findUpdate(oldUploadTable, row, 'expiryDate'),
                        add: firstChange && !row.metaId,
                        deleted: firstChange && row.isDeleted === 2
                    }"
                    >{{ getDatePrive(row.expiryDate, 'long') }}</span
                >
            </template>
            <template slot-scope="{ row }" slot="statusName">
                <span
                    :class="{
                        update:
                            firstChange &&
                            findUpdate(oldUploadTable, row, 'statusName'),
                        add: firstChange && !row.metaId,
                        deleted: firstChange && row.isDeleted === 2
                    }"
                    >{{ row.statusName }}</span
                >
            </template>
            <template slot-scope="{ row }" slot="updateTime">
                <span
                    :class="{
                        update:
                            firstChange &&
                            findUpdate(oldUploadTable, row, 'updateTime'),
                        add: firstChange && !row.metaId,
                        deleted: firstChange && row.isDeleted === 2
                    }"
                    >{{ getDatePrive(row.updateTime, 'long') }}</span
                >
            </template>
            <template slot-scope="{ row }" slot="updateName">
                <span
                    :class="{
                        update:
                            firstChange &&
                            findUpdate(oldUploadTable, row, 'updateName'),
                        add: firstChange && !row.metaId,
                        deleted: firstChange && row.isDeleted === 2
                    }"
                    >{{ row.updateName }}</span
                >
            </template>
            <template slot-scope="{ row }" slot="operate">
                <Button
                    @click="editInfo(row)"
                    type="primary"
                    class="mr6"
                    size="small"
                    v-if="row.isDeleted === 1"
                    >编辑</Button
                >
                <Button
                    v-if="row.isDeleted === 1"
                    @click="delInfo(row)"
                    type="error"
                    size="small"
                    >删除</Button
                >
                <Button
                    size="small"
                    type="success"
                    @click="recoveryDel(row)"
                    v-if="row.isDeleted === 2"
                    >恢复</Button
                >
            </template>
        </Table>
        <!-- 上传新增弹框 -->
        <Modal
            v-model="modalShowFlag"
            width="700"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel"
        >
            <div class="erp-modal-content">
                <Form
                    :model="formAttr"
                    :rules="ruleValidate"
                    ref="formValidate"
                    :label-width="120"
                >
                    <FormItem label="资料类型" prop="dataType">
                        <Select
                            v-model="formAttr.dataType"
                            placeholder="请选择"
                            @on-change="judgeEdie"
                        >
                            <Option
                                v-for="item in radioData"
                                :value="item.dataType"
                                :key="item.index"
                                >{{ item.dataTypeName }}</Option
                            >
                        </Select>
                    </FormItem>
                    <FormItem label="证书编号" prop="licenseCode">
                        <Input
                            v-model="formAttr.licenseCode"
                            placeholder="证书编号"
                        ></Input>
                    </FormItem>
                    <FormItem label="有效日期" prop="expiryDateStr">
                        <DatePicker
                            :editable="false"
                            v-model="formAttr.expiryDateStr"
                            format="yyyy-MM-dd"
                            type="date"
                            placeholder="年/月/日"
                        ></DatePicker>
                    </FormItem>
                    <FormItem label="状态" v-if="firstChange && infoId">
                        <RadioGroup v-model="formAttr.status">
                            <Radio
                                v-for="item in statusList"
                                :label="item.value"
                                :key="item.id"
                            >
                                <span>{{ item.label }}</span>
                            </Radio>
                        </RadioGroup>
                    </FormItem>
                    <FormItem label="附件">
                        <Upload
                            type="select"
                            accept="image/*, .pdf"
                            multiple
                            action="''"
                            :before-upload="handleBeforeUpload"
                            class="mb10"
                        >
                            <Button icon="ios-cloud-upload-outline"
                                >选择</Button
                            >
                        </Upload>
                    </FormItem>
                </Form>
                <Table
                    class="upload-table"
                    border
                    :columns="fileTitle"
                    :data="fileData"
                >
                    <template slot-scope="{ row,index }" slot="index">
                    <span
                        :class="{
                            deleted: firstChange && row.isDeleted === 2
                        }"
                    >{{ index+ 1}}</span
                    >
                    </template>
                    <template slot-scope="{ row }" slot="documentName">
                    <span
                        :class="{
                            deleted: firstChange && row.isDeleted === 2
                        }"
                    >{{ row.documentName }}</span
                    >
                    </template>
                    <template slot-scope="{ row }" slot="status">
                    <span
                        v-if="row.documentUrl"
                        :class="{
                            deleted: firstChange && row.isDeleted === 2
                        }"
                    >已上传</span
                    >
                        <Spin v-else>
                            <Icon
                                type="ios-loading"
                                size="22"
                                style="color: #3399ff"
                            ></Icon>
                        </Spin>
                    </template>
                    <template slot-scope="{ row }" slot="operate">
                            <Button
                                class="mr5"
                                @click="handleView(row)"
                                type="success"
                                size="small"
                            >查看</Button>
                            <Button
                                v-if="row.isDeleted == 1"
                                @click="delFile(row)"
                                type="error"
                                size="small"
                            >删除</Button>
                            <Button
                                v-if="row.isDeleted == 2"
                                @click="fileRevert(row)"
                                type="success"
                                size="small"
                            >恢复</Button
                            >
                    </template>
                </Table>
            </div>
        </Modal>
    </div>
</template>

<script>
import modalMixin from '@/mixins/modalMixin';
import { uploadFile } from '@/api/upload';
import {
    addSupplierLicense,
    editSupplierLicense,
    delSupplierLicense,
    delOldSupplierLicense,
    revertOldSupplierLicense
} from '@/api/masterData/supplier';
import { delRecord, getRecordList } from '@/api/masterData/customer';
import {
    changeDelFile,
    changeFileRevert
} from '@/api/masterData/userchange';
import { getDate } from '@/libs/tools';
export default {
    mixins: [modalMixin],
    props: {
        // 资料数据
        radioData: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 已上传数据
        uploadTable: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 引入客户
        firstImport: {
            type: Boolean,
            default: false
        },
        // 子客户
        firstSub: {
            type: Boolean,
            default: false
        },
        // 实例id
        taskInstanceId: '',
        // 变更
        firstChange: {
            type: Boolean,
            default: false
        },
        // 变更前的资料列表
        oldUploadTable: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 禁止编辑
        formDisabled: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            fileData: [],
            records: [],
            infoId: '',
            formAttr: {
                dataType: '',
                licenseCode: '',
                expiryDateStr: '',
                documentId: '',
                status: ''
            },
            Null: '',
            ruleValidate: {
                dataType: [
                    {
                        required: true,
                        type: 'number',
                        message: '请选择资料类型'
                    }
                ],
                licenseCode: [{ required: true, message: '证书编号为必填项' }],
                expiryDateStr: [{ required: true, message: '有效日期为必填项' }]
            },
            uploadTitle: [
                {
                    title: '资料类型',
                    align: 'center',
                    minWidth: 100,
                    slot: 'dataTypeName'
                },
                {
                    title: '证书编号',
                    align: 'center',
                    minWidth: 100,
                    slot: 'licenseCode'
                },
                {
                    title: '有效日期',
                    align: 'center',
                    minWidth: 100,
                    slot: 'expiryDate'
                },
                {
                    title: '状态',
                    align: 'center',
                    minWidth: 100,
                    slot: 'statusName'
                },
                {
                    title: '上传日期',
                    align: 'center',
                    minWidth: 100,
                    slot: 'updateTime'
                },
                {
                    title: '上传人员',
                    align: 'center',
                    minWidth: 100,
                    slot: 'updateName'
                },
                {
                    title: '操作',
                    align: 'center',
                    minWidth: 100,
                    slot: 'operate'
                }
            ],
            fileTitle: [
                { title: '序号', align: 'center',slot: 'index', width: 60},
                { title: '文件名', slot: 'documentName', align: 'center' },
                { title: '状态', align: 'center', slot: 'status', width: 80 },
                {
                    title: '操作',
                    align: 'center',
                    slot: 'operate',
                    width: 120
                }
            ],
            curDataType: [],
            uploadThrottle: true,
            documentId: null,
            statusList: [
                {
                    id: 1,
                    value: 3,
                    label: '有效'
                },
                {
                    id: 2,
                    value: 4,
                    label: '无效'
                }
            ]
        };
    },
    created() {
        if (this.firstSub || this.formDisabled) {
            if (this.uploadTitle.length === 7) this.uploadTitle.pop();
        } else if (this.uploadTitle.length === 6) {
            this.uploadTitle.push({
                title: '操作',
                align: 'center',
                minWidth: 100,
                slot: 'operate'
            });
        }
    },
    methods: {
        add() {
            this.clearData();
            this.addItem('上传资料');
        },
        // 选择资料类型
        radioChange(e) {
            this.formAttr.dataType = Number(e);
            if (e < 0) {
                this.$emit('updateTable');
            } else {
                this.$emit('updateTable', e);
                this.curDataType = this.radioData.filter(item => {
                    return e === item.dataType;
                })[0];
            }
        },
        // 上传前置钩子
        handleBeforeUpload(file) {
            const curFile = this.fileData.filter(item => {
                return item.documentName === file.name;
            });
            if (curFile.length === 0) this.uploadFile(file);
            return false;
        },
        // 文件上传
        async uploadFile(file) {
            this.uploadThrottle = false;
            let formData = new FormData();
            formData.append('files', file);
            this.fileData.push({
                documentName: file.name
            });
            const res = await uploadFile(formData);
            if (res.status === this.code) {
                this.fileData = this.fileData.map(item => {
                    if (
                        item.documentName + '' ===
                        res.content[0].documentName + ''
                    ) {
                        item = Object.assign(item, res.content[0]);
                    }
                    return item;
                });
                this.records.push(res.content[0]);
                this.uploadThrottle = true;
            }
        },
        // 文件删除
        async delFile(e) {
            if (this.firstImport && this.curDataType.isOrganization) {
                this.$Message.error('引入的集团资料无法删除');
                return;
            }
            if (e.id) {
                const params = {
                    id: e.id
                };
                let res = null;
                if (e.metaId) {
                    res = await changeDelFile(params); //文件假删除
                    this.getFile();
                } else {
                    res = await delRecord(params); //原先的文件删除接口
                    //使用ducumentHash作为唯一判断
                    let index = null;
                    this.fileData.forEach((item, i) => {
                        if (item.ducumentHash == e.ducumentHash) {
                            index = i;
                        }
                    });
                    this.fileData.splice(index, 1);
                }
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                }
            } else {
                let index = null;
                this.fileData.forEach((item, i) => {
                    if (item.ducumentHash == e.ducumentHash) {
                        index = i;
                    }
                });
                this.fileData.splice(index, 1);
            }
        },
        // 文件假删除恢复
        async fileRevert(row) {
            const params = { id: row.id };
            const res = await changeFileRevert(params);
            if (res.status === this.code) {
                this.getFile();
            }
        },
        // 日期更改
        dateChange(e) {
            this.formAttr.expiryDateStr = e;
        },
        // 获取已上传的文件列表
        async getFile() {
            const params = {
                documentId: this.documentId
            };
            const res = await getRecordList(params);
            if (res.status === this.code) {
                this.fileData = res.content;
            }
        },
        // 编辑信息
         editInfo(row) {
            this.clearData();
            this.modalTitle = '编辑资料';
            if (row.documentId) {
                this.documentId = row.documentId;
                this.getFile();
            }
            Object.assign(this.formAttr, {
                dataType: row.dataType,
                licenseCode: row.licenseCode,
                expiryDateStr: getDate(row.expiryDate),
                documentId: row.documentId,
                status: row.status
            });
            this.infoId = row.id;
            this.curDataType = {
                dataType: row.dataType,
                isOrganization: row.isOrganization,
                isDeleted: row.isDeleted
            };
            this.modalShowFlag = true;
        },
        delInfo(row) {
            if (this.firstImport && row.isOrganization) {
                this.$Message.error('引入的集团资料无法删除');
                return;
            }
            this.$Modal.confirm({
                title: '是否确认删除',
                onOk: async () => {
                    const params = {
                        id: row.id
                    };
                    let res;
                    // 如果是旧数据，调用假删除
                    if (row.metaId) {
                        res = await delOldSupplierLicense(params);
                    }
                    // 如果是变更时新添加的数据，调用原来的删除方法
                    else {
                        res = await delSupplierLicense(params);
                    }
                    if (res.status === this.code) {
                        this.formAttr.dataType = '';
                        this.$emit('updateTable');
                        this.$Message.success(res.msg);
                    }
                }
            });
        },
        modalOk() {
            this.$refs['formValidate'].validate(async valid => {
                if (!valid) {
                    return this.changeLoading();
                }
                if (!this.uploadThrottle) {
                    this.$Message.error('文件上传中请稍等');
                    return this.changeLoading();
                }

                if (this.firstImport && this.curDataType.isOrganization) {
                    this.$Message.error('集团资料无法修改');
                    return this.changeLoading();
                }
                if (this.infoId === '') {
                    const params = Object.assign({}, this.formAttr, {
                        records: this.records,
                        taskInstanceId: this.taskInstanceId,
                        expiryDateStr: getDate(this.formAttr.expiryDateStr)
                    });
                    const res = await addSupplierLicense(params);
                    if (res.status === this.code) {
                        this.$Message.success(res.msg);
                        this.formAttr.dataType = '';
                        this.$emit('updateTable');
                        this.modalCancel();
                    } else {
                        this.changeLoading();
                    }
                } else {
                    const params = Object.assign({}, this.formAttr, {
                        taskInstanceId: this.taskInstanceId,
                        records: this.records,
                        id: this.infoId,
                        expiryDateStr: getDate(this.formAttr.expiryDateStr)
                    });
                    const res = await editSupplierLicense(params);
                    if (res.status === this.code) {
                        this.$Message.success(res.msg);
                        this.formAttr.dataType = '';
                        this.$emit('updateTable');
                        this.modalCancel();
                    } else {
                        this.changeLoading();
                    }
                }
            });
        },
        // 恢复假删除
        async recoveryDel(row) {
            const params = { id: row.id };
            const res = await revertOldSupplierLicense(params);
            if (res.status === this.code) {
                this.$Message.success(res.msg);
                this.$emit('updateTable');
            }
        },
        getDatePrive(params, type) {
            return getDate(params, type);
        },
        clearData() {
            this.fileData = [];
            this.records = [];
            this.infoId = '';
        },
        judgeEdie(val) {
            this.curDataType = this.radioData.filter(item => {
                return val === item.dataType;
            })[0];
        },
        // 预览图片
        handleView (item) {
            let fileUrl = this.fileUrl + item.documentUrl;
            window.open(fileUrl, '_blank');
        },
    }
};
</script>

<style scoped>
.check-container {
    display: inline-block;
    /*min-width: 150px;*/
    margin-right: 30px;
}
.erp-modal-content {
    padding-right: 20px;
}
.is-required::after {
    content: '*';
    display: inline-block;
    margin-left: 4px;
    line-height: 1.2;
    font-family: SimSun;
    font-size: 12px;
    color: #ed4014;
}
.upload-table {
    margin-top: -20px;
}
    .mr5{
        margin-right: 5px;
    }
</style>
