<template>
    <!--首营物料询价结果-->
    <div class="inquiry-result">
        <div class="result clearfix" style="margin: 20px 0;">
            <div class="result-title fl">结果类型</div>
            <div class="fl">
                <RadioGroup
                    v-model="inquiryResult.inquiryResult"
                    vertical
                >
                    <Radio :disabled="disabled" :label="2">
                        <span>新物料</span>
                    </Radio>
                    <Radio :disabled="disabled" :label="1">
                        <span class="inlineb">已存在物料</span>
                        <Input v-model="inquiryResult.commodityName" :disabled="disabled"></Input>
                    </Radio>
                    <Radio :disabled="disabled" :label="0">
                        <Icon type="social-windows"></Icon>
                        <span class="inlineb">被驳回</span>
                        <Input v-model="inquiryResult.rejectDescription" :disabled="disabled"></Input>
                    </Radio>
                </RadioGroup>
            </div>
        </div>
        <Table
            border
            @on-selection-change="selectionChange"
            :data="inquiryResult.items"
            :columns="inquiryResultTitle"
        ></Table>
    </div>
</template>

<script>

export default {
    props: {
        // 询价结果
        inquiryResult: {
            type: Object,
            default: () => {
                return {};
            }
        },
        disabled: {
            type: Boolean,
            default: false
        },
        inquiryResultTitle: {
            type: Array,
            default: () => []
        }
    },
    methods: {
        selectionChange (selection) {
            this.$emit('on-selection-change', selection)
        }
    }
};
</script>

<style scoped lang="less">
    .fl {
        float: left;
    }

    .result-title {
        line-height: 30px;
        margin-right: 30px;
        font-size: 14px;
    }

    .inlineb {
        display: inline-block;
        width: 120px;
    }

    /deep/ .result {
        .ivu-radio-wrapper {
            margin-bottom: 10px;
        }
    }
</style>
