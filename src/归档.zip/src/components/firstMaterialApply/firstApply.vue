<template>
    <!--首营物料信息-->
    <Form
        :model="formAttr"
        ref="formValidate"
        :rules="ruleValidate"
        :label-width="120"
    >
        <Row>
            <Col span="11">
                <FormItem prop="customerName" label="客户名称">
                    <Input
                        :disabled="disabled"
                        v-model="formAttr.customerName"
                        :placeholder="disabled ? '': '请输入客户名称'"
                    ></Input>
                </FormItem>
            </Col>
            <Col span="13">
                <FormItem prop="commodityName" label="物料名称">
                    <Input
                        :disabled="disabled"
                        v-model="formAttr.commodityName"
                        :placeholder="disabled ? '': '请输入物料名称'"
                    ></Input>
                </FormItem>
            </Col>
        </Row>
        <Row>
            <Col span="11">
                <FormItem prop="commodityBrand" label="物料品牌">
                    <Input
                        :disabled="disabled"
                        v-model="formAttr.commodityBrand"
                        :placeholder="disabled ? '': '请输入物料品牌'"
                    ></Input>
                </FormItem>
            </Col>
            <Col span="13">
                <FormItem
                    prop="commoditySpecializedGroupId"
                    label="专业分组"
                >
                    <Select
                        :disabled="disabled"
                        v-model="formAttr.commoditySpecializedGroupId"
                        :placeholder="disabled ? '': '请选择专业分组'"
                    >
                        <Option
                            :label="item.fieldValue"
                            :value="item.id"
                            v-for="(item, index) in customerNameArr"
                            :key="index"
                        ></Option>
                    </Select>
                </FormItem>
            </Col>
        </Row>

        <Row>
            <Col span="11">
                <FormItem label="仪器名称">
                    <Input
                        :disabled="disabled"
                        v-model="formAttr.instrumentName"
                        :placeholder="disabled ? '': '请输入仪器名称'"
                    ></Input>
                </FormItem>
            </Col>
            <Col span="13">
                <FormItem label="生产厂家">
                    <Input
                        :disabled="disabled"
                        v-model="formAttr.manufacturer"
                        :placeholder="disabled ? '': '请输入生产厂家'"
                    ></Input>
                </FormItem>
            </Col>
        </Row>

        <Row>
            <Col span="11">
                <FormItem label="出库方式">
                    <Select
                        :disabled="disabled"
                        v-model="formAttr.outboundMethodId"
                        :placeholder="disabled ? '': '请选择出库方式'"
                    >
                        <Option
                            :label="item.fieldValue"
                            :value="item.id"
                            v-for="(item,
                                    index) in outboundMethodNameArr"
                            :key="index"
                        ></Option>
                    </Select>
                </FormItem>
            </Col>
            <Col span="13">
                <FormItem label="发货方式">
                    <Select
                        :disabled="disabled"
                        v-model="formAttr.deliveryMethodId"
                        :placeholder="disabled ? '': '请选择发货方式'"
                    >
                        <Option
                            :label="item.fieldValue"
                            :value="item.id"
                            v-for="(item,
                                    index) in deliveryMethodNameArr"
                            :key="index"
                        ></Option>
                    </Select>
                </FormItem>
            </Col>
        </Row>

        <Row>
            <Col span="11">
                <FormItem prop="commoditySpec" label="物料规格">
                    <Input
                        :disabled="disabled"
                        v-model="formAttr.commoditySpec"
                        :placeholder="disabled ? '': '请输入物料规格'"
                    ></Input>
                </FormItem>
            </Col>
            <Col span="13">
                <FormItem label="货号">
                    <Input
                        :disabled="disabled"
                        v-model="formAttr.commodityNumber"
                        :placeholder="disabled ? '': '请输入货号'"
                    ></Input>
                </FormItem>
            </Col>
        </Row>
        <Row>
            <Col span="11">
                <FormItem label="物料单位">
                    <Input
                        :disabled="disabled"
                        v-model="formAttr.commodityUnitName"
                        :placeholder="disabled ? '': '请输入物料单位'"
                    ></Input>
                </FormItem>
            </Col>
            <Col span="13">
                <FormItem label="销售价格">
                    <InputNumber
                        :disabled="disabled"
                        :min="0"
                        v-model="formAttr.price"
                        :placeholder="disabled ? '': '请输入销售价格'"
                    ></InputNumber>
                </FormItem>
            </Col>
        </Row>
        <Row>
            <Col span="11">
                <FormItem label="年订单量">
                    <InputNumber
                        :disabled="disabled"
                        :min="0"
                        v-model="formAttr.yearOrderNumber"
                        :placeholder="disabled ? '': '请输入年订单量'"
                    ></InputNumber>
                </FormItem>
            </Col>
            <Col span="13">
                <FormItem label="年测试数">
                    <InputNumber
                        :disabled="disabled"
                        :min="0"
                        v-model="formAttr.yearTestNumber"
                        :placeholder="disabled ? '': '请输入年测试数'"
                    ></InputNumber>
                </FormItem>
            </Col>
        </Row>
        <Row>
            <Col span="11">
                <FormItem label="原供应商">
                    <Input
                        :disabled="disabled"
                        v-model="formAttr.metaSupplier"
                        :placeholder="disabled ? '': '请输入原供应商'"
                    ></Input>
                </FormItem>
            </Col>
            <Col span="13">
                <FormItem
                    prop="purchaseOrganizationId"
                    label="采购组织"
                >
                    <Select
                        :disabled="disabled"
                        v-model="formAttr.purchaseOrganizationId"
                        :placeholder="disabled ? '': '请选择采购组织'"
                    >
                        <Option
                            :label="item.purchaseOrganizationName"
                            :value="item.id"
                            v-for="(item,
                                    index) in purchaseOrganizationArr"
                            :key="index"
                        ></Option>
                    </Select>
                </FormItem>
            </Col>
        </Row>
        <FormItem label="录入摘要">
            <Input
                :disabled="disabled"
                v-model="formAttr.writeDescription"
                type="textarea"
                :placeholder="disabled ? '': '请录入摘要'"
            ></Input>
        </FormItem>
    </Form>
</template>

<script>

    import { resetObj } from '@/libs/tools';

    export default {
        props: {
            // 申请资料
            formAttr: {
                type: Object,
                default: () => {
                    return {};
                }
            },
            // 是否只读
            disabled: {
                type: Boolean,
                default: false
            },
            // 专业分组 dropdown list
            customerNameArr: {
                type: Array,
                default: () => []
            },
            // 出库方式 dropdown list
            outboundMethodNameArr: {
                type: Array,
                default: () => []
            },
            // 发货方式 dropdown list
            deliveryMethodNameArr: {
                type: Array,
                default: () => []
            },
            // 采购组织 dropdown list
            purchaseOrganizationArr: {
                type: Array,
                default: () => []
            },
            // 表单校验
            ruleValidate: {
                type: Object,
                default: () => {
                    return {
                        customerName: [
                            {
                                required: true,
                                message: '客户名称不能为空',
                                trigger: 'blur'
                            }
                        ],
                        commodityName: [
                            {
                                required: true,
                                message: '物料名称不能为空'
                            }
                        ],
                        commodityBrand: [
                            {
                                required: true,
                                message: '物料品牌不能为空'
                            }
                        ],
                        commoditySpecializedGroupId: [
                            {
                                required: true,
                                message: '专业分组不能为空',
                                type: 'number',
                                trigger: 'change'
                            }
                        ],
                        purchaseOrganizationId: [
                            {
                                required: true,
                                message: '采购组织不能为空',
                                type: 'number',
                                trigger: 'change'
                            }
                        ],
                        commoditySpec: [
                            {
                                required: true,
                                message: '物料规格不能为空'
                            }
                        ]
                    };
                }
            }
        },
        methods: {
            getForm () {
                return this.$refs.formValidate;
            },
            reset () {
                resetObj(this.formAttr);
                this.$refs.formValidate.resetFields();
            }
        }
    };
</script>

<style scoped lang="less">

</style>
