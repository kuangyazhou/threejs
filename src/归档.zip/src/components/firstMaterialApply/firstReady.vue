<template>
    <!--首营准备-->
    <div class="first-ready">
        <Form
            :model="formAttr"
            ref="formValidate"
            :label-width="80"
        >
            <Row :gutter="10">
                <Col span="10">
                    <FormItem label="客户">
                        <Input
                            disabled
                            v-model="formAttr.customerName"
                        ></Input>
                    </FormItem>
                </Col>
                <Col span="10">
                    <FormItem label="客户代码">
                        <Input
                            disabled
                            v-model="formAttr.customerCode"
                        ></Input>
                    </FormItem>
                </Col>
                <Col span="4">
                    <Button :disabled="disabled" @click="openCustomer">关联</Button>
                </Col>
            </Row>
            <Row :gutter="10">
                <Col span="10">
                    <FormItem label="物料名称">
                        <Input
                            disabled
                            v-model="formAttr.commodityName"
                        ></Input>
                    </FormItem>
                </Col>
                <Col span="10">
                    <FormItem label="物料代码">
                        <Input
                            disabled
                            v-model="formAttr.commodityCode"
                        ></Input>
                    </FormItem>
                </Col>
                <Col span="4">
                    <Button :disabled="disabled" @click="openMaterial">关联</Button>
                </Col>
            </Row>
        </Form>
        <Table
            border
            :data="formAttr.items"
            :columns="firstReadyTitle"
        ></Table>
<!--        客户弹窗-->
        <Modal
            v-model="modalShowFlag"
            width="700"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            footer-hide
        >
            <erp-table
                @on-page-no-change="pageNoChange"
                @on-page-size-change="pageSizeChange"
                :erpTableTitle="modalTableTitle"
                :erpTableData="modalTableData"
                :tableLoading="tableLoading"
                :current="tableComAttr.pageNo"
                :total="total"
                :showSizer='showSizer'
                :showElevator='showSizer'
            >
            </erp-table>
        </Modal>
    </div>
</template>

<script>
import ErpTable from '_c/erp-table';
import modalMixin from '@/mixins/modalMixin';
import { getCompanyUser } from '@/api/masterData/userselect';
import {
    firstCampRelationCustomer,
    firstCampRelationCommodity,
    getAllSupplierList,
    firstCampRelationSupplier
} from '@/api/purchaseManage/inquiryTask';
import {
    getCompanyMaterialList
} from '@/api/purchaseManage/channelPrice';
import { getDate} from '@/libs/tools';
export default {
    mixins: [ modalMixin ],
    components: {
        ErpTable
    },
    props: {
        formAttr: {
            type: Object,
            default: () => {
                return {};
            }
        },
        readonly: {
            type: Boolean,
            default: false
        }
    },
    data(){
        return {
            customerShowFlag: false, // 客户弹窗开关
            modalTableTitle: [],
            modalTableData: [],
            customerTableTitle: [
                {
                    title: '编号',
                    align: 'center',
                    minWidth: 100,
                    key: 'customerCode'
                },
                {
                    title: '名称',
                    align: 'center',
                    minWidth: 120,
                    key: 'customerName'
                },
                {
                    title: '分类',
                    align: 'center',
                    minWidth: 90,
                    key: 'customerClassifyName'
                },
                {
                    title: '类型',
                    align: 'center',
                    minWidth: 90,
                    key: 'customerTypeName'
                },
                {
                    title: '操作',
                    minWidth: 100,
                    align: 'center',
                    render: (h, params) => {
                        return h('div', [
                            h(
                                'Button',
                                {
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            this.relationCustomer(params.row.id);
                                        }
                                    }
                                },
                                '关联'
                            )
                        ]);
                    }
                }
            ], // 客户栏目
            materialTableTitle: [
                {
                    title: '名称',
                    align: 'center',
                    minWidth: 120,
                    key: 'commodityName'
                },
                {
                    title: '物料规格',
                    align: 'center',
                    minWidth: 90,
                    key: 'commoditySpec'
                },
                {
                    title: '物料品牌',
                    align: 'center',
                    minWidth: 90,
                    key: 'brandName'
                },
                {
                    title: '专业分组',
                    align: 'center',
                    minWidth: 90,
                    key: 'specializedGroup'
                },
                {
                    title: '操作',
                    minWidth: 100,
                    align: 'center',
                    render: (h, params) => {
                        return h('div', [
                            h(
                                'Button',
                                {
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            this.relationMaterial(params.row.commodityId);
                                        }
                                    }
                                },
                                '关联'
                            )
                        ]);
                    }
                }
            ], // 物料栏目
            supplierTableTitle: [
                {
                    title: '名称',
                    align: 'center',
                    minWidth: 120,
                    key: 'supplierName'
                },
                {
                    title: '统一社会信用码',
                    align: 'center',
                    minWidth: 130,
                    key: 'unifiedSocialCreditCode'
                },
                {
                    title: '供应商种类',
                    align: 'center',
                    minWidth: 100,
                    key: 'supplierTypeName'
                },
                {
                    title: '供应商类别',
                    align: 'center',
                    minWidth: 100,
                    key: 'supplierCategoryName'
                },
                {
                    title: '操作',
                    minWidth: 100,
                    align: 'center',
                    render: (h, params) => {
                        return h('div', [
                            h(
                                'Button',
                                {
                                    props: {
                                        type: 'primary',
                                        size: 'small'
                                    },
                                    on: {
                                        click: () => {
                                            this.relationSupplier(params.row.id);
                                        }
                                    }
                                },
                                '关联'
                            )
                        ]);
                    }
                }
            ], // 物料栏目
            tableComAttr: {
                pageNo: 1,
                pageSize: 10
            },
            total: 0,
            tableLoading: false,
            curDetailId: null,
            firstReadyTitle: [
                {
                    title: '供应商',
                    align: 'center',
                    minWidth: 120,
                    key: 'supplierName'
                },
                {
                    title: '代码',
                    align: 'center',
                    minWidth: 120,
                    key: 'supplierCode'
                },
                {
                    title: '包装单位 ',
                    align: 'center',
                    width: 80,
                    key: 'unitName'
                },
                {
                    title: '税率',
                    align: 'center',
                    width: 70,
                    key: 'taxRate'
                },
                {
                    title: '市场指导价',
                    align: 'center',
                    width: 98,
                    key: 'marketPrice'
                },
                {
                    title: '币种',
                    align: 'center',
                    width: 80,
                    key: 'currencyName'
                },
                {
                    title: '询价时间',
                    align: 'center',
                    minWidth: 120,
                    render: (h, params) => {
                        return h(
                            'span',
                            {},
                            getDate(params.row.inquiryTime, 'long')
                        );
                    }
                },
                {
                    title: '供应商选择',
                    type: 'selection',
                    align: 'center',
                    width: 60
                },
                {
                    title: '操作',
                    minWidth: 80,
                    align: 'center',
                    render: (h, params) => {
                        return h('div', [
                            h(
                                'Button',
                                {
                                    props: {
                                        size: 'small',
                                        disabled: this.readonly
                                    },
                                    on: {
                                        click: () => {
                                            this.curDetailId = params.row.id;
                                            this.openSupplier();
                                        }
                                    }
                                },
                                '关联'
                            )
                        ]);
                    }
                }
            ],
            modalType: 0, // 0客户弹窗1物料弹窗2供应商弹窗
            showSizer: false
        }
    },
    methods: {
        pageNoChange (value) {
            this.tableComAttr.pageNo = value;
            if(this.modalType === 0){
                this.getCustomerData();
            }else if(this.modalType === 1){
                this.getMaterialData();
            }else if(this.modalType === 2){
                this.getSupplierData();
            }
        },
        /**
         * 改变每页条数
         */
        pageSizeChange (value) {
            this.tableComAttr.pageNo = 1;
            this.tableComAttr.pageSize = value;
            if(this.modalType === 0){
                this.getCustomerData();
            }else if(this.modalType === 1){
                this.getMaterialData();
            }else if(this.modalType === 2){
                this.getSupplierData();
            }
        },
        // 打开客户弹窗
        openCustomer(){
            this.modalType = 0;
            this.tableComAttr.pageNo = 1;
            this.modalTableTitle = this.customerTableTitle;
            this.getCustomerData();
            this.addItem('关联客户');
        },
        // 获取客户列表
        async getCustomerData () {
            const params = Object.assign(
                {},
                this.tableComAttr);
            this.tableLoading = true;
            const res = await getCompanyUser(params);
            this.tableLoading = false;
            if (res.status === this.code) {
                this.modalTableData = res.content.list;
                this.total = res.content.total
            }
        },
        // 关联客户
        async relationCustomer (id) {
            const params = Object.assign({},
                {
                    customerId: id,
                    id: this.formAttr.id
                });
            const res = await firstCampRelationCustomer(params);
            if (res.status === this.code) {
                this.$Message.success(res.msg);
                this.$emit('changeFormInfo');
                this.modalShowFlag = false;
            }
        },
        // 打开物料弹窗
        openMaterial(){
            this.modalType = 1;
            this.tableComAttr.pageNo = 1;
            this.modalTableTitle = this.materialTableTitle;
            this.getMaterialData();
            this.addItem('关联物料');
        },
        // 获取物料列表
        async getMaterialData () {
            const params = Object.assign(
                {},
                this.tableComAttr);
            this.tableLoading = true;
            const res = await getCompanyMaterialList(params);
            this.tableLoading = false;
            if (res.status === this.code) {
                this.modalTableData = res.content.list;
                this.total = res.content.total
            }
        },
        // 关联物料
        async relationMaterial (id) {
            const params = Object.assign({},
                {
                    commodityId: id,
                    id: this.formAttr.id
                });
            const res = await firstCampRelationCommodity(params);
            if (res.status === this.code) {
                this.$Message.success(res.msg);
                this.$emit('changeFormInfo');
                this.modalShowFlag = false;
            }
        },
        // 打开供应商弹窗
        openSupplier(){
            this.tableComAttr.pageNo = 1;
            this.modalTableTitle = this.supplierTableTitle;
            this.getSupplierData();
            this.addItem('关联供应商');
        },
        // 获取供应商列表
        async getSupplierData () {
            const params = Object.assign(
                {},
                this.tableComAttr);
            this.tableLoading = true;
            const res = await getAllSupplierList(params);
            this.tableLoading = false;
            if (res.status === this.code) {
                this.modalTableData = res.content.list;
                this.total = res.content.total
            }
        },
        // 关联供应商
        async relationSupplier (id) {
            const params = Object.assign({},
                {
                    supplierId: id,
                    initCommodityHandleSupplierId: this.curDetailId
                });
            const res = await firstCampRelationSupplier(params);
            if (res.status === this.code) {
                this.$Message.success(res.msg);
                this.$emit('changeFormInfo');
                this.modalShowFlag = false;
            }
        },
    }
};
</script>

<style scoped lang="less">
    /deep/ .ivu-table-cell{
        padding: 4px;
    }
</style>
