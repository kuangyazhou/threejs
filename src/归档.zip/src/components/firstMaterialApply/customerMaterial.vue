<template>
    <!--客户物料-->
    <div class="first-ready">
        <Card dis-hover :bordered="false" class="wrapper-query">
            <p slot="title">
                <Icon type="md-list"></Icon>
                客户物料
            </p>
        <Form
            :model="formAttr"
            :label-width="100"
        >
            <Row :gutter="10">
                <Col span="12">
                    <FormItem label="销售组织">
                        <Input
                            disabled
                            v-model="formAttr.saleOrganizationName"
                        ></Input>
                    </FormItem>
                </Col>
                <Col span="12">
                    <FormItem label="客户">
                        <Input
                            disabled
                            v-model="formAttr.customerName"
                        ></Input>
                    </FormItem>
                </Col>
                <Col span="12">
                    <FormItem label="物料常用名称">
                        <Input
                            disabled
                            v-model="formAttr.commodityName"
                        ></Input>
                    </FormItem>
                </Col>
                <Col span="12">
                    <FormItem label="规格">
                        <Input
                            disabled
                            v-model="formAttr.commoditySpec"
                        ></Input>
                    </FormItem>
                </Col>
                <Col span="12">
                    <FormItem label="品牌">
                        <Input
                            disabled
                            v-model="formAttr.brandName"
                        ></Input>
                    </FormItem>
                </Col>
                <Col span="12">
                    <FormItem label="专业分组">
                        <Input
                            disabled
                            v-model="formAttr.specializedGroupName"
                        ></Input>
                    </FormItem>
                </Col>
                <Col span="12">
                    <FormItem label="状态">
                        <Input
                            disabled
                            v-model="formAttr.statusDescription"
                        ></Input>
                    </FormItem>
                </Col>
            </Row>
        </Form>
        </Card>
        <Card dis-hover :bordered="false">
            <p slot="title">
                <Icon type="md-list"></Icon>
                销售价格
            </p>
        <Table
            border
            :data="saleTableData"
            :columns="saleTableTitle"
        ></Table>
        </Card>
    </div>
</template>

<script>

export default {
    props: {
        formAttr: {
            type: Object,
            default: () => {
                return {};
            }
        },
        saleTableData: {
            type: Array,
            default: []
        }
    },
    data () {
        return {
            saleTableTitle: [
                {
                    title: '销售组织',
                    align: 'center',
                    minWidth: 100,
                    key: 'saleOrganizationName'
                },
                {
                    title: '客户',
                    align: 'center',
                    minWidth: 110,
                    key: 'customerName'
                },
                {
                    title: '物料常用名称',
                    align: 'center',
                    minWidth: 120,
                    key: 'commodityName'
                },
                {
                    title: '规格',
                    align: 'center',
                    minWidth: 90,
                    key: 'commoditySpec'
                },
                {
                    title: '品牌',
                    align: 'center',
                    minWidth: 90,
                    key: 'brandName'
                },
                {
                    title: '厂家',
                    align: 'center',
                    minWidth: 100,
                    key: 'manufacturerName'
                },
                {
                    title: '专业分组',
                    align: 'center',
                    minWidth: 100,
                    key: 'specializedGroupName'
                },
                {
                    title: '包装单位',
                    align: 'center',
                    minWidth: 100,
                    key: 'unitName'
                },
                {
                    title: '销售价格',
                    align: 'center',
                    minWidth: 100,
                    key: 'price'
                },
                {
                    title: '币种',
                    align: 'center',
                    minWidth: 90,
                    key: 'currencyName'
                },
                {
                    title: '状态',
                    align: 'center',
                    minWidth: 90,
                    key: 'statusDescription'
                }
            ]
        };
    }
};
</script>

<style scoped lang="less">

</style>
