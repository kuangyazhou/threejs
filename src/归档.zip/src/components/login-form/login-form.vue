<template>
    <div class="cp-login">
        <div class="title">登录</div>
        <Form
            ref="loginForm"
            :model="form"
            :rules="rules"
            @keydown.enter.native="handleSubmit"
        >
            <FormItem prop="userName">
                <Input v-model="form.userName" placeholder="请输入用户名">
                    <span slot="prepend">
                        <Icon :size="16" type="md-person"></Icon>
                    </span>
                </Input>
            </FormItem>
            <FormItem prop="password">
                <Input
                    type="password"
                    v-model="form.password"
                    placeholder="请输入密码"
                >
                    <span slot="prepend">
                        <Icon :size="16" type="md-lock"></Icon>
                    </span>
                </Input>
            </FormItem>
            <FormItem>
                <Button class="mt" @click="handleSubmit" type="primary" long
                    >登录</Button
                >
            </FormItem>
        </Form>
    </div>
</template>
<script>
export default {
    name: 'LoginForm',
    props: {
        userNameRules: {
            type: Array,
            default: () => {
                return [
                    { required: true, message: '账号不能为空', trigger: 'blur' }
                ];
            }
        },
        passwordRules: {
            type: Array,
            default: () => {
                return [
                    { required: true, message: '密码不能为空', trigger: 'blur' }
                ];
            }
        }
    },
    data() {
        return {
            form: {
                userName: 'admin',
                password: ''
            }
        };
    },
    computed: {
        rules() {
            return {
                userName: this.userNameRules,
                password: this.passwordRules
            };
        }
    },
    methods: {
        handleSubmit() {
            this.$refs.loginForm.validate(valid => {
                if (valid) {
                    this.$emit('on-success-valid', {
                        userName: this.form.userName,
                        password: this.form.password
                    });
                }
            });
        }
    }
};
</script>
<style lang="less">
.cp-login {
    .title {
        font-size: 32px;
        font-weight: bold;
        color: #1a53e5;
        margin-bottom: 60px;
    }
    .ivu-input-group-prepend,
    .ivu-input-group-append {
        background: transparent;
        border: none;
        border-bottom: 1px solid #333;
        border-radius: inherit;
    }
    .ivu-input-default {
        border: none;
        outline: #000c17;
        border-bottom: 1px solid #333;
        border-radius: inherit;
        font-size: 15px;
        &:hover {
            border: none;
            border-bottom: 1px solid #333;
        }
        &:focus {
            outline: none;
            border: none;
            box-shadow: none;
            border-bottom: 1px solid #333;
        }
    }
    .mt {
        margin-top: 70px;
        height: 36px;
        font-size: 15px;
        background: #1a53e5;
        &:active {
            box-shadow: 0 0 0 2px rgba(26, 83, 229, 0.2);
        }
    }
}
</style>
