<template>
    <!-- <div>
        上传资料
    </div>-->
    <div class="upload">
        <Card dis-hover class="mb20">
            <div slot="extra">
                <ButtonGroup v-if="uploadReadonly" class="z10">
                    <Button v-if="!firstFile" @click="addInfo" icon="md-add"
                        >新增</Button
                    >
                </ButtonGroup>
            </div>
            <Row>
                <Col span="2">资料类型</Col>
                <Col span="12">
                    <RadioGroup
                        @on-change="radioChange"
                        v-model="infoModel.dataType"
                    >
                        <span class="check-container f16">
                            <Radio :label="Null">全部</Radio>
                        </span>
                        <span
                            class="check-container f16"
                            v-for="item in radioData"
                            :key="item.index"
                            :class="{ 'is-required': item.isMust }"
                        >
                            <Radio :label="item.dataType">{{
                                item.dataTypeName
                            }}</Radio>
                        </span>
                    </RadioGroup>
                </Col>
            </Row>
        </Card>
        <Table :border="true" :columns="uploadTitle" :data="uploadTable">
            <template slot-scope="{ row }" slot="dataTypeName">
                <span
                    :class="{
                        update:
                            isChange &&
                            findUpdate(oldLicense, row, 'dataTypeName'),
                        add: isChange && !row.metaId,
                        deleted: isChange && row.isDeleted == 2
                    }"
                    >{{ row.dataTypeName }}</span
                >
            </template>
            <template slot-scope="{ row }" slot="licenseCode">
                <span
                    :class="{
                        update:
                            isChange &&
                            findUpdate(oldLicense, row, 'licenseCode'),
                        add: isChange && !row.metaId,
                        deleted: isChange && row.isDeleted == 2
                    }"
                    >{{ row.licenseCode }}</span
                >
            </template>
            <template slot-scope="{ row }" slot="expiryDate">
                <span
                    :class="{
                        update:
                            isChange &&
                            findUpdate(oldLicense, row, 'expiryDate'),
                        add: isChange && !row.metaId,
                        deleted: isChange && row.isDeleted == 2
                    }"
                    >{{ getDatePrive(row.expiryDate, 'long') }}</span
                >
            </template>
            <template slot-scope="{ row }" slot="statusName">
                <span
                    :class="{
                        update:
                            isChange &&
                            findUpdate(oldLicense, row, 'statusName'),
                        add: isChange && !row.metaId,
                        deleted: isChange && row.isDeleted == 2
                    }"
                    >{{ row.statusName }}</span
                >
            </template>
            <template slot-scope="{ row }" slot="updateTime">
                <span
                    :class="{
                        update:
                            isChange &&
                            findUpdate(oldLicense, row, 'updateTime'),
                        add: isChange && !row.metaId,
                        deleted: isChange && row.isDeleted == 2
                    }"
                    >{{ getDatePrive(row.updateTime, 'long') }}</span
                >
            </template>
            <template slot-scope="{ row }" slot="updateName">
                <span
                    :class="{
                        update:
                            isChange &&
                            findUpdate(oldLicense, row, 'updateName'),
                        add: isChange && !row.metaId,
                        deleted: isChange && row.isDeleted == 2
                    }"
                    >{{ row.updateName }}</span
                >
            </template>
            <template slot-scope="{ row }" slot="operate">
                <!-- <ButtonGroup> -->
                <Button
                    @click="editInfo(row)"
                    type="primary"
                    class="mr6"
                    size="small"
                    v-if="row.isDeleted == 1"
                    >{{ uploadReadonly ? '编辑' : '查看' }}</Button
                >
                <Button
                    v-if="uploadReadonly && row.isDeleted == 1"
                    @click="delInfo(row)"
                    type="error"
                    size="small"
                    >删除</Button
                >
                <Button
                    size="small"
                    type="success"
                    @click="resvert(row)"
                    v-if="row.isDeleted == 2"
                    >恢复</Button
                >
                <!-- </ButtonGroup> -->
            </template>
        </Table>
        <!-- 上传新增弹框 -->
        <Modal
            :title="infoId ? '编辑证照' : '新增证照'"
            :mask-closable="maskClosable"
            v-model="modalFlag"
            @on-cancel="modalClose"
        >
            <Form
                :model="infoModel"
                :rules="rules"
                :label-width="120"
                ref="form"
            >
                <FormItem label="资料类型">
                    <Select
                        v-model="infoModel.dataType"
                        placeholder="请选择"
                        :disabled="!uploadReadonly"
                    >
                        <Option
                            v-for="item in radioData"
                            :value="item.dataType"
                            :key="item.index"
                            >{{ item.dataTypeName }}</Option
                        >
                    </Select>
                </FormItem>
                <FormItem label="证书编号" prop="licenseCode">
                    <Input
                        v-model="infoModel.licenseCode"
                        placeholder="证书编号"
                        :disabled="!uploadReadonly"
                    ></Input>
                </FormItem>
                <FormItem label="有效日期" prop="expiryDateStr">
                    <DatePicker
                        :editable="false"
                        v-model="infoModel.expiryDateStr"
                        format="yyyy-MM-dd"
                        type="date"
                        placeholder="年/月/日"
                        @on-change="dateChange"
                        :disabled="!uploadReadonly"
                    ></DatePicker>
                </FormItem>
                <FormItem label="附件">
                    <!-- <div v-for="item in fileData" :key="item.index">
                        <span>{{ item.documentName }}</span>
                        <Button @click="delFile(item)" v-if="uploadReadonly"
                            >删除</Button
                        >
                    </div>-->
                    <Upload
                        type="select"
                        accept="image/*, .pdf"
                        multiple
                        action="''"
                        :before-upload="handleBeforeUpload"
                        v-if="uploadReadonly"
                        class="mb10"
                    >
                        <Button icon="ios-cloud-upload-outline">选择</Button>
                    </Upload>
                </FormItem>
            </Form>
            <Table border :columns="fileTitle" :data="fileData">
                <template slot-scope="{ row, index }" slot="index">
                    <span
                        :class="{
                            deleted: isChange && row.isDeleted == 2
                        }"
                        >{{ index }}</span
                    >
                </template>
                <template slot-scope="{ row }" slot="documentName">
                    <span
                        :class="{
                            deleted: isChange && row.isDeleted == 2
                        }"
                        >{{ row.documentName }}</span
                    >
                </template>

                <template slot-scope="{ row }" slot="status">
                    <span
                        v-if="row.documentUrl"
                        :class="{
                            deleted: isChange && row.isDeleted == 2
                        }"
                        >已上传</span
                    >
                    <Spin v-else>
                        <Icon
                            type="ios-loading"
                            size="22"
                            style="color: #3399ff"
                        ></Icon>
                    </Spin>
                </template>
                <template slot-scope="{ row }" slot="operate">
                    <ButtonGroup>
                        <Button
                            v-if="row.isDeleted == 1"
                            @click="delFile(row)"
                            type="error"
                            size="small"
                            >删除</Button
                        >
                        <Button
                            v-if="row.isDeleted == 2"
                            @click="fileRevert(row)"
                            type="success"
                            size="small"
                            >恢复</Button
                        >
                    </ButtonGroup>
                </template>
            </Table>
            <div slot="footer">
                <Button @click="modalClose">取消</Button>
                <Button type="primary" size="large" @click="confirm"
                    >确认</Button
                >
            </div>
        </Modal>
    </div>
</template>

<script>
import modalMixin from '@/mixins/modalMixin';
import { uploadFile } from '@/api/upload';
import {
    addCustomerLicense,
    saveCustomerLicense,
    delCustomerLicense,
    getRecordList,
    delRecord
} from '@/api/masterData/customer';
import {
    changeDelLicense,
    changeRevertLicense,
    changeDelFile,
    changeFileRevert
} from '@/api/masterData/userchange';
import { getDate } from '@/libs/tools';
export default {
    mixins: [modalMixin],
    props: {
        // 资料数据
        radioData: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 已上传数据
        uploadTable: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 只读&&编辑控制
        uploadReadonly: {
            type: Boolean,
            default: true
        },
        // 实例id
        taskInstanceId: '',
        firstFile: {
            type: Boolean,
            default: false
        },
        oldLicense: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 销售变更参数
        isChange: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            code: 10000,
            fileData: [],
            modalTitle: '',
            modalFlag: false,
            records: [],
            editRecord: [],
            infoId: '',
            Null: '',
            infoModel: {
                dataType: '',
                licenseCode: '',
                expiryDateStr: '',
                documentId: ''
            },
            documentId: '',
            rules: {
                licenseCode: [{ required: true, message: '证书编号为必填项' }],
                expiryDateStr: [
                    {
                        required: true,
                        message: '有效日期为必填项',
                        type: 'date'
                    }
                ]
            },
            uploadTitle: [
                {
                    title: '资料类型',
                    align: 'center',
                    minWidth: 100,
                    slot: 'dataTypeName'
                },
                {
                    title: '证书编号',
                    align: 'center',
                    minWidth: 100,
                    slot: 'licenseCode'
                },
                {
                    title: '有效日期',
                    align: 'center',
                    minWidth: 100,
                    slot: 'expiryDate'
                },
                {
                    title: '状态',
                    align: 'center',
                    minWidth: 100,
                    slot: 'statusName'
                },
                {
                    title: '上传日期',
                    align: 'center',
                    minWidth: 100,
                    slot: 'updateTime'
                },
                {
                    title: '上传人员',
                    align: 'center',
                    minWidth: 100,
                    slot: 'updateName'
                },
                {
                    title: '操作',
                    align: 'center',
                    minWidth: 100,
                    slot: 'operate'
                }
            ],
            fileTitle: [
                {
                    title: '序号',
                    align: 'center',
                    slot: 'index'
                },
                {
                    title: '文件名',
                    key: 'documentName',
                    align: 'center',
                    slot: 'documentName'
                },
                { title: '状态', align: 'center', slot: 'status' },
                {
                    title: '操作',
                    align: 'center',
                    slot: 'operate',
                    minWidth: 80
                }
            ]
        };
    },
    created() {
        if (this.firstFile) this.uploadTitle.pop();
        if (!this.uploadReadonly) this.fileTitle.pop();
    },
    methods: {
        addInfo() {
            this.modalFlag = true;
        },
        // 选择资料类型
        radioChange(e) {
            this.infoModel.dataType = e;
            if (e < 0) {
                this.$emit('updateTable');
            } else {
                this.$emit('updateTable', e);
            }
        },
        // 上传前置钩子
        handleBeforeUpload(file) {
            const curFile = this.fileData.filter(item => {
                return item.documentName === file.name;
            });
            if (curFile.length === 0) {
                this.uploadFile(file);
            } else {
                this.$Message.error('不要重复上传文件');
            }
            return false;
        },
        // 文件上传
        async uploadFile(file) {
            let formData = new FormData();
            formData.append('files', file);
            this.fileData.push({
                documentName: file.name
            });
            const res = await uploadFile(formData);
            if (res.status === this.code) {
                this.fileData = this.fileData.map(item => {
                    if (
                        item.documentName + '' ===
                        res.content[0].documentName + ''
                    ) {
                        item = Object.assign(item, res.content[0]);
                    }
                    return item;
                });
                this.records.push(res.content[0]);
                if (this.infoId) {
                    this.editRecord.push(res.content[0]);
                }
                // this.getFile();
            }
        },
        // 文件删除
        async delFile(e) {
            if (e.id) {
                const params = {
                    id: e.id
                };
                let res = null;
                if (e.metaId) {
                    res = await changeDelFile(params); //文件假删除
                    this.getFile();
                } else {
                    res = await delRecord(params); //原先的文件删除接口
                    //使用ducumentHash作为唯一判断
                    let index = null;
                    this.fileData.forEach((item, i) => {
                        if (item.ducumentHash == e.ducumentHash) {
                            index = i;
                        }
                    });
                    this.fileData.splice(index, 1);
                }
                if (res.status === this.code) {
                    this.$Message.success(res.msg);
                }
            } else {
                let index = null;
                this.fileData.forEach((item, i) => {
                    if (item.ducumentHash == e.ducumentHash) {
                        index = i;
                    }
                });
                this.fileData.splice(index, 1);
            }
        },
        // 文件假删除恢复
        async fileRevert(row) {
            const params = { id: row.id };
            const res = await changeFileRevert(params);
            if (res.status === this.code) {
                this.getFile();
            }
        },
        // 日期更改
        dateChange() {
            // this.infoModel.expiryDateStr = e;
        },
        // 编辑信息
        async editInfo(row) {
            this.fileData = [];
            if (row.documentId) {
                this.documentId = row.documentId;
                this.getFile();
            }
            this.infoModel.dataType = row.dataType;
            this.infoModel.licenseCode = row.licenseCode;
            this.infoModel.expiryDateStr = getDate(row.expiryDate);
            this.infoModel.documentId = row.documentId;
            this.infoId = row.id;
            this.modalFlag = true;
        },
        // 恢复假删除
        async resvert(row) {
            const params = { id: row.id };
            const res = await changeRevertLicense(params);
            if (res.status === this.code) {
                this.$emit('updateTable');
            }
        },
        // 获取已上传的文件列表
        async getFile() {
            const params = {
                documentId: this.documentId
            };
            const res = await getRecordList(params);
            if (res.status === this.code) {
                this.fileData = res.content;
            }
        },
        delInfo(row) {
            // 如果是旧数据，调用假删除
            if (row.metaId) {
                const params = {
                    id: row.id
                };
                changeDelLicense(params)
                    .then(res => {
                        if (res.status === this.code) {
                            this.$emit('updateTable');
                        }
                    })
                    .catch(err => {
                        this.$Message.error(err);
                    });
            }
            // 如果是变更时新添加的数据，调用原来的删除方法
            else {
                this.$Modal.confirm({
                    title: '是否确认删除',
                    onOk: async () => {
                        const params = {
                            id: row.id
                        };
                        const res = await delCustomerLicense(params);
                        if (res.status === this.code) {
                            this.infoModel.dataType = '';
                            this.$emit('updateTable');
                            this.$Message.success(res.msg || res.content);
                        }
                    }
                });
            }
        },
        // 关闭
        modalClose() {
            Object.keys(this.infoModel).forEach(item => {
                this.infoModel[item] = '';
            });
            this.fileData = [];
            this.editRecord = [];
            this.records = [];
            this.infoId = '';
            this.$refs['form'].resetFields();
            this.modalFlag = false;
            this.$emit('updateTable');
        },

        // 确认上传
        confirm() {
            this.$refs['form'].validate(async valid => {
                if (valid) {
                    if (this.infoId == '') {
                        const params = Object.assign({}, this.infoModel, {
                            records: this.records,
                            taskInstanceId: this.taskInstanceId,
                            expiryDateStr: getDate(this.infoModel.expiryDateStr)
                        });
                        const res = await addCustomerLicense(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.$emit('updateTable');
                            this.modalClose();
                        }
                    } else {
                        const params = Object.assign({}, this.infoModel, {
                            taskInstanceId: this.taskInstanceId,
                            records: this.editRecord,
                            id: this.infoId,
                            expiryDateStr: getDate(this.infoModel.expiryDateStr)
                        });
                        const res = await saveCustomerLicense(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.$emit('updateTable');
                            this.modalClose();
                        }
                    }
                }
            });
        },
        getDatePrive(params, type) {
            return getDate(params, type);
        }
    }
};
</script>

<style scoped>
.check-container {
    display: inline-block;
    min-width: 150px;
}

.is-required::after {
    content: '*';
    display: inline-block;
    margin-left: 4px;
    line-height: 1.2;
    font-family: SimSun;
    font-size: 12px;
    color: #ed4014;
}
</style>
