<template>
    <div>
        <Checkbox
            class="f16"
            v-model="all"
            :disabled="machineReadonly"
            @on-change="selectAll"
            >全选</Checkbox
        >
        <Card dis-hover class="mb10">
            <CheckboxGroup v-model="selectMaterial" @on-change="materialChange">
                <span
                    class="check-container f16"
                    v-for="item in materialCheckbox"
                    :key="item.index"
                    :class="{
                        del:
                            isChange &&
                            isDel(
                                oldMaterial,
                                selectMaterial,
                                item.id,
                                'commodityType'
                            ),
                        add:
                            isChange &&
                            isAdd(
                                oldMaterial,
                                selectMaterial,
                                item.id,
                                'commodityType'
                            )
                    }"
                >
                    <Checkbox :label="item.id" :disabled="machineReadonly">{{
                        item.fieldValue
                    }}</Checkbox>
                </span>
            </CheckboxGroup>
        </Card>
        <Row :gutter="16">
            <Col span="6">
                <Card class="mb10" dis-hover>
                    <CheckboxGroup
                        v-model="selectMachine"
                        :disabled="machineReadonly"
                    >
                        <div
                            v-for="item in machineCheckbox"
                            class="checkbox-container"
                            :key="item.index"
                            :class="{
                                del:
                                    isChange &&
                                    isDel(
                                        oldMachine,
                                        selectMachine,
                                        item.id,
                                        'deviceClassifyId'
                                    ),
                                add:
                                    isChange &&
                                    isAdd(
                                        oldMachine,
                                        selectMachine,
                                        item.id,
                                        'deviceClassifyId'
                                    )
                            }"
                        >
                            <Checkbox
                                :disabled="machineReadonly"
                                :label="item.deviceClassifyId"
                            >
                                {{
                                    `${item.deviceClassifyTypeName},
                                ${item.deviceClassifyCode},
                                ${item.deviceClassifyName}`
                                }}
                            </Checkbox>
                        </div>
                    </CheckboxGroup>
                </Card>
            </Col>
            <Col span="18">
                <Card dis-hover class="mb10">
                    <div>
                        <Select
                            placeholder="请选择资料"
                            v-model="infoType"
                            class="select-container"
                        >
                            <Option
                                v-for="item in selectData"
                                :label="item.dataTypeName"
                                :value="item.dataType"
                                :key="item.index"
                            ></Option>
                        </Select>
                        <Button type="primary" @click="viewInfo">查看</Button>
                    </div>
                </Card>
                <Carousel v-model="value1" v-if="carouselData.length">
                    <CarouselItem
                        v-for="(item, index) in carouselData"
                        :key="index"
                        class="carousel-item"
                    >
                        <!-- 根据类型区分用pdf还是img展示 -->
                        <div
                            v-if="
                                item.documentName.includes('pdf') ||
                                    item.documentName.includes('PDF')
                            "
                        >
                            <object draggable="true" class="w100 h80">
                                <param
                                    name="SRC"
                                    :value="fileUrl + item.documentUrl"
                                />
                            </object>
                        </div>
                        <div v-else>
                            <img
                                class="w100 h80"
                                :src="fileUrl + item.documentUrl"
                            />
                        </div>
                    </CarouselItem>
                </Carousel>
            </Col>
        </Row>
    </div>
</template>

<script>
import {
    saveMaterialType,
    saveSelectMachine,
    getLicenseUrl
} from '@/api/masterData/customer';
import modalMixin from '@/mixins/modalMixin';
export default {
    mixins: [modalMixin],
    props: {
        // 物料数据
        materialCheckbox: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 器械种类
        machineCheckbox: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 选择资料下拉框
        selectData: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 已选择器械
        selectedMachine: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 已选择物料
        selectedMaterial: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 只读&&编辑控制
        machineReadonly: {
            type: Boolean,
            default: false
        },
        // 实例id
        taskInstanceId: '',

        // 变更前物料类型
        oldMaterial: {
            type: Array,
            default: () => {
                return [];
            }
        },
        oldMachine: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 销售变更参数
        isChange: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            all: false,
            value1: 0,
            carouselData: [],
            infoType: [],
            code: 10000,
            selectMaterial: [],
            selectMachine: []
        };
    },
    watch: {
        selectedMachine(val) {
            this.selectMachine = val;
        },
        selectedMaterial(val) {
            this.selectMaterial = val;
        }
    },
    methods: {
        // 全选操作
        selectAll(e) {
            if (e) {
                let temp = [];
                this.materialCheckbox.forEach(item => {
                    temp.push(item.id);
                });
                this.selectMaterial = temp;
            } else {
                this.selectMaterial = [];
            }
        },
        // 取消全选
        materialChange(e) {
            if (e.length != this.materialCheckbox.length) {
                this.all = false;
            } else {
                this.all = true;
            }
        },
        // 查看证照
        async viewInfo() {
            const params = {
                taskInstanceId: this.taskInstanceId,
                dataType: this.infoType
            };
            const res = await getLicenseUrl(params);
            if (res.status === this.code) {
                const data = res.content;
                let temp = [];
                data.forEach(item => {
                    if (item.documentName) {
                        temp.push(item);
                    }
                });
                this.carouselData = temp;
            }
        },

        // 保存器械分类数据
        async saveData() {
            const materialparams = {
                taskInstanceId: this.taskInstanceId,
                commodityTypeList: this.selectMaterial
            };
            const machineparams = {
                taskInstanceId: this.taskInstanceId,
                deviceClassifyList: this.selectMachine
            };
            const material = await saveMaterialType(materialparams);
            const machine = await saveSelectMachine(machineparams);
            if (material.status === this.code) {
                this.$Message.success('物料保存成功');
                this.$emit('changeLoading');
            } else {
                this.$Message.error(material.msg);
            }
            if (machine.status === this.code) {
                this.$Message.success('器械分类保存成功');
                this.$emit('changeLoading');
            } else {
                this.$Message.error(machine.msg);
            }
        }
    }
};
</script>

<style scoped>
.check-container {
    display: inline-block;
    min-width: 100px;
}
.checkbox-container:not(:last-child) {
    margin-bottom: 8px;
}

.select-container {
    width: 180px;
    margin-right: 18px;
}

.class-container {
    /* max-height: 40vh; */
    overflow-y: auto;
}

.w100 {
    width: 100%;
}
.h80 {
    height: 80vh;
    min-height: 400px;
}

.del {
    color: red;
}
</style>
