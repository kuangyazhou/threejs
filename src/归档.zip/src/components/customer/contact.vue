<template>
    <div class="adress">
        <Card dis-hover>
            <p slot="title">
                <Icon type="md-list"></Icon>联系人列表
                <span></span>
            </p>
            <div slot="extra">
                <ButtonGroup v-if="concatReadonly" class="z10">
                    <Button @click="add" icon="md-add">新增</Button>
                </ButtonGroup>
            </div>
            <Table border :columns="addressTitle" :data="customerContactList">
                <template slot-scope="{ row }" slot="contactName">
                    <span
                        :class="{
                            update:
                                isChange &&
                                findUpdate(oldContact, row, 'contactName'),
                            add: isChange && !row.metaId,
                            deleted: isChange && row.isDeleted == 2
                        }"
                        >{{ row.contactName }}</span
                    >
                </template>
                <template slot-scope="{ row }" slot="contactPhone">
                    <span
                        :class="{
                            update:
                                isChange &&
                                findUpdate(oldContact, row, 'contactPhone'),
                            add: isChange && !row.metaId,
                            deleted: isChange && row.isDeleted == 2
                        }"
                        >{{ row.contactPhone }}</span
                    >
                </template>
                <template slot-scope="{ row }" slot="contactJob">
                    <span
                        :class="{
                            update:
                                isChange &&
                                findUpdate(oldContact, row, 'contactJob'),
                            add: isChange && !row.metaId,
                            deleted: isChange && row.isDeleted == 2
                        }"
                        >{{ row.contactJob }}</span
                    >
                </template>
                <template slot-scope="{ row }" slot="contactDepartment">
                    <span
                        :class="{
                            update:
                                isChange &&
                                findUpdate(
                                    oldContact,
                                    row,
                                    'contactDepartment'
                                ),
                            add: isChange && !row.metaId,
                            deleted: isChange && row.isDeleted == 2
                        }"
                        >{{ row.contactDepartment }}</span
                    >
                </template>
                <template slot-scope="{ row }" slot="statusName">
                    <span
                        :class="{
                            update:
                                isChange &&
                                findUpdate(oldContact, row, 'statusName'),
                            add: isChange && !row.metaId,
                            deleted: isChange && row.isDeleted == 2
                        }"
                        >{{ row.statusName }}</span
                    >
                </template>
                <template slot-scope="{ row }" slot="action">
                    <Button
                        type="primary"
                        size="small"
                        class="mr5"
                        @click="editTableData(row, '编辑联系人')"
                        v-if="row.isDeleted == 1"
                        >编辑</Button
                    >
                    <Button
                        v-if="row.isDeleted == 1"
                        type="error"
                        size="small"
                        @click="del(row)"
                        >删除</Button
                    >
                    <Button
                        size="small"
                        type="success"
                        @click="resvert(row)"
                        v-if="row.isDeleted == 2"
                        >恢复</Button
                    >
                </template>
            </Table>
        </Card>
        <!--新增地址-->
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel"
        >
            <div class="erp-modal-content">
                <Form
                    :model="formAttr"
                    :rules="ruleValidate"
                    ref="formValidate"
                    :label-width="120"
                >
                    <FormItem label="姓名" prop="contactName">
                        <Input
                            v-model="formAttr.contactName"
                            placeholder="请输入姓名"
                        ></Input>
                    </FormItem>
                    <FormItem label="职务" prop="contactJob">
                        <Input
                            v-model="formAttr.contactJob"
                            placeholder="请输入职务"
                        ></Input>
                    </FormItem>
                    <FormItem label="电话" prop="contactPhone">
                        <Input
                            v-model="formAttr.contactPhone"
                            placeholder="请输入电话"
                        ></Input>
                    </FormItem>
                    <FormItem label="部门" prop="contactDepartment">
                        <Input
                            v-model="formAttr.contactDepartment"
                            placeholder="请输入部门"
                        ></Input>
                    </FormItem>
                </Form>
            </div>
        </Modal>
    </div>
</template>

<script>
import modalMixin from '@/mixins/modalMixin';
import {
    addContact,
    updateContact,
    delContact
} from '@/api/masterData/customer';
import {
    changeDelContact,
    changeRevertContact
} from '@/api/masterData/userchange';
export default {
    mixins: [modalMixin],
    props: {
        customerContactList: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 实例id
        taskInstanceId: {
            type: Number,
            default: () => {
                return 0;
            }
        },
        // 只读&&编辑控制
        concatReadonly: {
            type: Boolean,
            default: true
        },
        oldContact: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 销售变更参数
        isChange: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            addressTitle: [
                {
                    title: '姓名',
                    align: 'center',
                    minWidth: 100,
                    slot: 'contactName'
                },
                {
                    title: '电话',
                    align: 'center',
                    minWidth: 100,
                    slot: 'contactPhone'
                },
                {
                    title: '职务',
                    align: 'center',
                    minWidth: 140,
                    slot: 'contactJob'
                },
                {
                    title: '部门',
                    align: 'center',
                    minWidth: 140,
                    slot: 'contactDepartment'
                },
                {
                    title: '状态',
                    align: 'center',
                    minWidth: 120,
                    slot: 'statusName'
                },
                {
                    title: '操作',
                    align: 'center',
                    minWidth: 120,
                    fixed: 'right',
                    slot: 'action'
                }
            ],
            formAttr: {
                contactName: '',
                contactJob: '',
                contactPhone: '',
                contactDepartment: ''
            },
            ruleValidate: {
                contactName: [
                    {
                        required: true,
                        message: '姓名不能为空',
                        trigger: 'blur'
                    }
                ],
                contactJob: [
                    {
                        required: true,
                        message: '职务不能为空',
                        trigger: 'blur'
                    }
                ],
                contactPhone: [
                    {
                        required: true,
                        message: '电话不能为空',
                        trigger: 'blur'
                    }
                ],
                contactDepartment: [
                    {
                        required: true,
                        message: '部门不能为空',
                        trigger: 'blur'
                    }
                ]
            }
        };
    },
    created() {
        if (!this.concatReadonly) {
            this.addressTitle.pop();
        }
    },
    methods: {
        // 新增编辑确认按钮
        modalOk() {
            this.$refs['formValidate'].validate(async valid => {
                if (!valid) {
                    return this.changeLoading();
                }
                let res;
                let params;
                if (this.currentId) {
                    params = Object.assign({}, this.formAttr, {
                        id: this.currentId,
                        taskInstanceId: this.taskInstanceId
                    });
                    res = await updateContact(params);
                } else {
                    params = Object.assign({}, this.formAttr, {
                        taskInstanceId: this.taskInstanceId
                    });
                    res = await addContact(params);
                }
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                    this.$emit('contactList');
                } else {
                    this.changeLoading();
                }
            });
        },
        add() {
            this.addItem('新增联系人');
        },

        // 恢复
        async resvert(row) {
            const params = { id: row.id };
            const res = await changeRevertContact(params);
            if (res.status === this.code) {
                this.$emit('contactList');
            }
        },

        // 删除
        del(row) {
            if (row.metaId) {
                const params = {
                    id: row.id
                };
                changeDelContact(params)
                    .then(res => {
                        if (res.status === this.code) {
                            this.$emit('contactList');
                        }
                    })
                    .catch(err => {
                        this.$Message.error(err);
                    });
            } else {
                this.$Modal.confirm({
                    title: `确认删除${row.contactName}吗？`,
                    onOk: async () => {
                        const params = {
                            id: row.id
                        };
                        const res = await delContact(params);
                        if (res.status === this.code) {
                            this.$Message.success(res.msg);
                            this.$emit('contactList');
                        }
                    }
                });
            }
        }
    }
};
</script>

<style scoped lang="less">
.mr5 {
    margin-right: 5px;
}
</style>
