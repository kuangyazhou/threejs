<template>
    <!-- <div>收货地址</div> -->
    <div class="adress">
        <Card dis-hover>
            <p slot="title">
                <Icon type="md-list"></Icon>收货地址列表
                <span></span>
            </p>
            <div slot="extra">
                <ButtonGroup v-if="addressReadonly" class="z10">
                    <Button @click="add" icon="md-add">新增</Button>
                </ButtonGroup>
            </div>
            <Table border :columns="addressTitle" :data="customerAddressList">
                <template slot-scope="{ row }" slot="receiveAddress">
                    <span
                        :class="{
                            default: row.isDefault,
                            update:
                                isChange &&
                                findUpdate(oldAdress, row, 'receiveAddress'),
                            add: isChange && !row.metaId,
                            deleted: isChange && row.isDeleted == 2
                        }"
                        >{{ row.receiveAddress }}</span
                    >
                </template>
                <template slot-scope="{ row }" slot="receiveName">
                    <span
                        :class="{
                            default: row.isDefault,
                            update:
                                isChange &&
                                findUpdate(oldAdress, row, 'receiveName'),
                            add: isChange && !row.metaId,
                            deleted: isChange && row.isDeleted == 2
                        }"
                        >{{ row.receiveName }}</span
                    >
                </template>
                <template slot-scope="{ row }" slot="receivePhone">
                    <span
                        :class="{
                            default: row.isDefault,
                            update:
                                isChange &&
                                findUpdate(oldAdress, row, 'receivePhone'),
                            add: isChange && !row.metaId,
                            deleted: isChange && row.isDeleted == 2
                        }"
                        >{{ row.receivePhone }}</span
                    >
                </template>
                <template slot-scope="{ row }" slot="remark">
                    <span
                        :class="{
                            default: row.isDefault,
                            update:
                                isChange &&
                                findUpdate(oldAdress, row, 'remark'),
                            add: isChange && !row.metaId,
                            deleted: isChange && row.isDeleted == 2
                        }"
                        >{{ row.remark }}</span
                    >
                </template>
                <template slot-scope="{ row }" slot="statusName">
                    <span
                        :class="{
                            default: row.isDefault,
                            update:
                                isChange &&
                                findUpdate(oldAdress, row, 'statusName'),
                            add: isChange && !row.metaId,
                            deleted: isChange && row.isDeleted == 2
                        }"
                        >{{ row.statusName }}</span
                    >
                </template>
                <template slot-scope="{ row }" slot="action">
                    <Button
                        type="info"
                        size="small"
                        class="mr5"
                        @click="setDefaultAddress(row)"
                        >默认</Button
                    >
                    <Button
                        type="primary"
                        size="small"
                        class="mr5"
                        @click="editTableData(row, '编辑收货地址')"
                        v-if="row.isDeleted == 1"
                        >编辑</Button
                    >
                    <Button
                        v-if="row.isDeleted == 1"
                        type="error"
                        size="small"
                        @click="del(row)"
                        >删除</Button
                    >
                    <Button
                        size="small"
                        type="success"
                        @click="resvert(row)"
                        v-if="row.isDeleted == 2"
                        >恢复</Button
                    >
                </template>
            </Table>
        </Card>
        <!--新增地址-->
        <Modal
            v-model="modalShowFlag"
            width="650"
            :title="modalTitle"
            :loading="modelLoading"
            :mask-closable="maskClosable"
            @on-ok="modalOk"
            @on-cancel="modalCancel"
        >
            <div class="erp-modal-content">
                <Form
                    :model="formAttr"
                    :rules="ruleValidate"
                    ref="formValidate"
                    :label-width="120"
                >
                    <FormItem label="收货人员" prop="receiveName">
                        <Input
                            v-model="formAttr.receiveName"
                            placeholder="请输入收货人员"
                        ></Input>
                    </FormItem>
                    <FormItem label="收货地址" prop="receiveAddress">
                        <Input
                            v-model="formAttr.receiveAddress"
                            placeholder="请输入收货地址"
                        ></Input>
                    </FormItem>
                    <FormItem label="收货电话" prop="receivePhone">
                        <Input
                            v-model="formAttr.receivePhone"
                            placeholder="请输入收货电话"
                        ></Input>
                    </FormItem>
                    <FormItem label="识别码" prop="identificationCode">
                        <Input v-model="formAttr.identificationCode" placeholder="请输入识别码"></Input>
                    </FormItem>
                    <FormItem label="备注">
                        <Input
                            v-model="formAttr.remark"
                            placeholder="请输入备注"
                        ></Input>
                    </FormItem>
                </Form>
            </div>
        </Modal>
    </div>
</template>

<script>
import modalMixin from '@/mixins/modalMixin';
import {
    addAddress,
    updateAddress,
    delAddress,
    setDefaultAddress
} from '@/api/masterData/customer';
import {
    changeDelAddress,
    changeRevertAddress
} from '@/api/masterData/userchange';
export default {
    mixins: [modalMixin],
    props: {
        // 地址表格数据
        customerAddressList: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 实例id
        taskInstanceId: {
            type: Number,
            default: () => {
                return 0;
            }
        },
        // 只读&&编辑控制
        addressReadonly: {
            type: Boolean,
            default: true
        },
        oldAdress: {
            type: Array,
            default: () => {
                return [];
            }
        },
        // 销售变更参数
        isChange: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            addressTitle: [
                {
                    title: '收货地址',
                    align: 'center',
                    minWidth: 180,
                    slot: 'receiveAddress'
                },
                {
                    title: '收货人员',
                    align: 'center',
                    minWidth: 120,
                    slot: 'receiveName'
                },
                {
                    title: '收货电话',
                    align: 'center',
                    minWidth: 120,
                    slot: 'receivePhone'
                },
                {
                    title: '备注',
                    align: 'center',
                    minWidth: 120,
                    slot: 'remark'
                },
                {
                    title: '状态',
                    align: 'center',
                    minWidth: 120,
                    slot: 'statusName'
                },
                {
                    title: '操作',
                    align: 'center',
                    minWidth: 120,
                    fixed: 'right',
                    slot: 'action'
                }
            ],
            formAttr: {
                receiveName: '',
                receiveAddress: '',
                receivePhone: '',
                identificationCode:'',
                remark: ''
            },
            ruleValidate: {
                receiveName: [
                    {
                        required: true,
                        message: '收货人员不能为空',
                        trigger: 'blur'
                    }
                ],
                receiveAddress: [
                    {
                        required: true,
                        message: '收货地址不能为空',
                        trigger: 'blur'
                    }
                ],
                identificationCode: [
                    {
                        required: true,
                        message: '识别码不能为空',
                    }
                ],
                receivePhone: [
                    {
                        required: true,
                        message: '收货电话不能为空',
                        trigger: 'blur'
                    }
                ]
            }
        };
    },
    created() {
        if (!this.addressReadonly) {
            this.addressTitle.pop();
        }
    },
    methods: {
        // 新增编辑确认按钮
        modalOk() {
            this.$refs['formValidate'].validate(async valid => {
                if (!valid) {
                    return this.changeLoading();
                }
                let res;
                let params;
                if (this.currentId) {
                    params = Object.assign({}, this.formAttr, {
                        id: this.currentId,
                        taskInstanceId: this.taskInstanceId
                    });
                    res = await updateAddress(params);
                } else {
                    params = Object.assign({}, this.formAttr, {
                        taskInstanceId: this.taskInstanceId
                    });
                    res = await addAddress(params);
                }
                if (res.status === this.code) {
                    this.todoOver(res.msg);
                    this.$emit('addressList');
                } else {
                    this.changeLoading();
                }
            });
        },
        add() {
            this.addItem('新增收货地址');
        },
        // 恢复假删除
        async resvert(row) {
            const params = { id: row.id };
            const res = await changeRevertAddress(params);
            if (res.status === this.code) {
                this.$emit('addressList');
            }
        },
        // 删除
        del(row) {
            if (row.metaId) {
                const params = {
                    id: row.id
                };
                changeDelAddress(params)
                    .then(res => {
                        if (res.status === this.code) {
                            this.$emit('addressList');
                        }
                    })
                    .catch(err => {
                        this.$Message.error(err);
                    });
            } else {
                if (row.id) {
                    this.$Modal.confirm({
                        title: `确认删除该地址吗？`,
                        onOk: async () => {
                            const params = {
                                id: row.id
                            };
                            const res = await delAddress(params);
                            if (res.status === this.code) {
                                this.$Message.success(res.msg);
                                this.$emit('addressList');
                            }
                        }
                    });
                }
            }
        },
        // 设置默认收货地址
        async setDefaultAddress(data) {
            const params = {
                id: data.id
            };
            const res = await setDefaultAddress(params);
            if (res.status === this.code) {
                this.$Message.success(res.msg);
                this.$emit('addressList');
            }
        }
    }
};
</script>

<style scoped lang="less">
.default {
    color: #348eed;
}
.mr5 {
    margin-right: 5px;
}
</style>
