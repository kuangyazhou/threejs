import baseInFoForm from './baseInfoForm.vue';
import machine from './machineClass.vue';
import uploadData from './upload.vue';
import receiveAddress from './adress.vue';
import contact from './contact.vue';

export const BaseInFoForm = baseInFoForm;
export const MachineClass = machine;
export const UploadData = uploadData;
export const ReceiveAddress = receiveAddress;
export const Contact = contact;
