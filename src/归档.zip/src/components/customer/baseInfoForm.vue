<template>
    <div class="base-info-form">
        <Card dis-hover>
            <h4
                class="info-title"
                v-if="formAttr.parentId && formAttr.parentName.length"
            >
                上级客户：{{ formAttr.parentName }}
            </h4>
            <Form
                :model="formAttr"
                :rules="ruleValidate"
                ref="formValidate"
                :label-width="120"
            >
                <h3 class="sep-title">业务信息</h3>
                <Row>
                    <Col span="16">
                        <FormItem
                            prop="customerName"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.customerName !=
                                        oldFormData.customerName
                            }"
                        >
                            <template slot="label">
                                <Tooltip :content="oldBaseInfo.customerName"
                                    >客户名称</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="firstImport || baseInfoReadOnly"
                                v-model="formAttr.customerName"
                                placeholder="请输入客户名称"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            label="客户编号"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.customerCode !=
                                        oldFormData.customerCode
                            }"
                        >
                            <Input
                                v-model="formAttr.customerCode"
                                disabled
                            ></Input>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="8">
                        <FormItem
                            label="客户区域"
                            prop="customerArea"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.customerArea !=
                                        oldFormData.customerArea
                            }"
                        >
                            <template slot="label" v-if="isChange">
                                <Tooltip
                                    :content="
                                        getLabel(
                                            customerAreaArr,
                                            oldFormData.customerArea
                                        )
                                    "
                                    >客户区域</Tooltip
                                >
                            </template>
                            <Select
                                v-model="formAttr.customerArea"
                                placeholder="请选择客户区域"
                                :disabled="baseInfoReadOnly || changeQuality"
                            >
                                <Option
                                    v-for="(option, index) in customerAreaArr"
                                    :value="option.id"
                                    :label="option.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            label="客户类型"
                            prop="customerType"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.customerType !=
                                        oldFormData.customerType
                            }"
                        >
                            <template slot="label" v-if="isChange">
                                <Tooltip
                                    :content="
                                        getLabel(
                                            customerTypeArr,
                                            oldBaseInfo.customerType
                                        )
                                    "
                                    >客户类型</Tooltip
                                >
                            </template>
                            <Select
                                v-model="formAttr.customerType"
                                placeholder="请选择客户类型"
                                :disabled="baseInfoReadOnly || changeQuality"
                            >
                                <Option
                                    v-for="(option, index) in customerTypeArr"
                                    :value="option.id"
                                    :label="option.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            label="客户分类"
                            prop="customerClassify"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.customerClassify !=
                                        oldFormData.customerClassify
                            }"
                        >
                            <template slot="label" v-if="isChange">
                                <Tooltip
                                    :content="
                                        getLabel(
                                            customerClassifyArr,
                                            oldBaseInfo.customerClassify
                                        )
                                    "
                                    >客户分类</Tooltip
                                >
                            </template>
                            <Select
                                v-model="formAttr.customerClassify"
                                placeholder="请选择客户分类"
                                :disabled="baseInfoReadOnly || changeQuality"
                            >
                                <Option
                                    v-for="(option,
                                    index) in customerClassifyArr"
                                    :value="option.id"
                                    :label="option.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="8">
                        <FormItem
                            label="合同账期"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.contractPaymentMonth !=
                                        oldFormData.contractPaymentMonth
                            }"
                        >
                            <template slot="label" v-if="isChange">
                                <Tooltip
                                    :content="oldBaseInfo.contractPaymentMonth"
                                    >合同账期</Tooltip
                                >
                            </template>
                            <Input
                                v-model="formAttr.contractPaymentMonth"
                                :placeholder="(baseInfoReadOnly || changeQuality)?'':'请输入合同账期'"
                                :disabled="baseInfoReadOnly || changeQuality"
                                type="number"
                            >
                                <span slot="append">月</span>
                            </Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            label="销售方式"
                            prop="saleMethod"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.saleMethod !=
                                        oldFormData.saleMethod
                            }"
                        >
                            <template slot="label" v-if="isChange">
                                <Tooltip
                                    :content="
                                        getLabel(
                                            saleMethodArr,
                                            oldBaseInfo.saleMethod
                                        )
                                    "
                                    >销售方式</Tooltip
                                >
                            </template>
                            <Select
                                v-model="formAttr.saleMethod"
                                placeholder="请选择销售方式"
                                :disabled="baseInfoReadOnly || changeQuality"
                            >
                                <Option
                                    v-for="(option, index) in saleMethodArr"
                                    :value="option.id"
                                    :label="option.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            label="销售模式"
                            prop="saleMode"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.saleMode != oldFormData.saleMode
                            }"
                        >
                            <template slot="label" v-if="isChange">
                                <Tooltip
                                    :content="
                                        getLabel(
                                            saleModeArr,
                                            oldBaseInfo.saleMode
                                        )
                                    "
                                    >销售模式</Tooltip
                                >
                            </template>
                            <Select
                                v-model="formAttr.saleMode"
                                placeholder="请选择销售模式"
                                :disabled="baseInfoReadOnly || changeQuality"
                            >
                                <Option
                                    v-for="(option, index) in saleModeArr"
                                    :value="option.id"
                                    :label="option.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="8">
                        <FormItem
                            label="销售部门"
                            prop="saleDepartment"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.saleDepartment !=
                                        oldFormData.saleDepartment
                            }"
                        >
                            <template slot="label" v-if="isChange">
                                <Tooltip
                                    :content="
                                        getLabel(
                                            saleDepartmentArr,
                                            oldBaseInfo.saleDepartment
                                        )
                                    "
                                    >销售部门</Tooltip
                                >
                            </template>
                            <Select
                                v-model="formAttr.saleDepartment"
                                placeholder="请选择销售部门"
                                :disabled="baseInfoReadOnly || changeQuality"
                            >
                                <Option
                                    v-for="(option, index) in saleDepartmentArr"
                                    :value="option.id"
                                    :label="option.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            label="客户等级"
                            prop="customerLevel"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.customerLevel !=
                                        oldFormData.customerLevel
                            }"
                        >
                            <template slot="label" v-if="isChange">
                                <Tooltip
                                    :content="
                                        getLabel(
                                            customerLevelArr,
                                            oldBaseInfo.customerLevel
                                        )
                                    "
                                    >客户等级</Tooltip
                                >
                            </template>
                            <Select
                                v-model="formAttr.customerLevel"
                                placeholder="请选择客户等级"
                                :disabled="baseInfoReadOnly || changeQuality"
                            >
                                <Option
                                    v-for="(option, index) in customerLevelArr"
                                    :value="option.id"
                                    :label="option.fieldValue"
                                    :key="index"
                                ></Option>
                            </Select>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            label="执业许可登记"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.licenseRegistrationCode !=
                                        oldFormData.licenseRegistrationCode
                            }"
                        >
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.customerLevel"
                                    >执业许可登记</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="
                                    firstImport || firstSub || baseInfoReadOnly
                                "
                                v-model="formAttr.licenseRegistrationCode"
                                :placeholder="(!Boolean(formAttr.licenseRegistrationCode) && (firstImport || firstSub || baseInfoReadOnly))?'':'请输入执业许可登记'"
                            ></Input>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="16">
                        <FormItem
                            label="客户地址"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.customerAddress !=
                                        oldFormData.customerAddress
                            }"
                        >
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.customerAddress"
                                    >客户地址</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="baseInfoReadOnly"
                                v-model="formAttr.customerAddress"
                                :placeholder="(!Boolean(formAttr.customerAddress) && (baseInfoReadOnly))?'':'请输入客户地址'"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            label="统一社会信用"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.unifiedSocialCreditCode !=
                                        oldFormData.unifiedSocialCreditCode
                            }"
                        >
                            <template slot="label" v-if="isChange">
                                <Tooltip
                                    :content="
                                        oldBaseInfo.unifiedSocialCreditCode
                                    "
                                    >统一社会信用</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="
                                    firstImport || firstSub || baseInfoReadOnly
                                "
                                v-model="formAttr.unifiedSocialCreditCode"
                                :placeholder="(!Boolean(formAttr.unifiedSocialCreditCode) && (firstImport || firstSub || baseInfoReadOnly))?'':'请输入统一社会信用'"
                            ></Input>
                        </FormItem>
                    </Col>
                </Row>
                <h3 class="sep-title">资质信息</h3>
                <Row>
                    <FormItem
                        label="单位税号"
                        :class="{
                            equal:
                                isChange &&
                                formAttr.dutyParagraph !=
                                    oldFormData.dutyParagraph
                        }"
                    >
                        <template slot="label" v-if="isChange">
                            <Tooltip :content="oldBaseInfo.dutyParagraph"
                                >单位税号</Tooltip
                            >
                        </template>
                        <Input
                            :disabled="baseInfoReadOnly || changeQuality"
                            v-model="formAttr.dutyParagraph"
                            :placeholder="(!Boolean(formAttr.dutyParagraph) && (baseInfoReadOnly || changeQuality))?'':'请输入单位税号'"
                        ></Input>
                    </FormItem>
                </Row>
                <Row>
                    <Col span="16">
                        <FormItem
                            label="开户银行"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.bankName != oldFormData.bankName
                            }"
                        >
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.bankName"
                                    >开户银行</Tooltip
                                >
                            </template>
                            <AutoComplete
                                v-model="formAttr.bankName"
                                @on-change="bankHandleSearch"
                                @on-select="afterSelectBank"
                                :filter-method="bankFilterMethod"
                                :placeholder="(!Boolean(formAttr.bankName) && (baseInfoReadOnly || changeQuality))?'':'请输入开户银行'"
                                :disabled="baseInfoReadOnly || changeQuality"
                            >
                                <Option
                                    v-for="(item, index) in bankList"
                                    :value="item.bankName"
                                    :key="index"
                                >
                                    <Row :gutter="6">
                                        <Col span="9">{{ item.bankName }}</Col>
                                        <Col span="9">{{ item.bankCode }}</Col>
                                        <Col span="6">{{ item.bankType }}</Col>
                                    </Row>
                                </Option>
                            </AutoComplete>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            label="银行账号"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.bankAccount !=
                                        oldFormData.bankAccount
                            }"
                        >
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.bankAccount"
                                    >银行账号</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="baseInfoReadOnly || changeQuality"
                                v-model="formAttr.bankAccount"
                                :placeholder="(!Boolean(formAttr.bankAccount) && (baseInfoReadOnly || changeQuality))?'':'请输入银行账号'"
                            ></Input>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <Col span="16">
                        <FormItem
                            label="银行行号"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.bankCode != oldFormData.bankCode
                            }"
                        >
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.bankCode"
                                    >银行行号</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="baseInfoReadOnly || changeQuality"
                                v-model="formAttr.bankCode"
                                :placeholder="(!Boolean(formAttr.bankCode) && (baseInfoReadOnly || changeQuality))?'':'请输入银行行号'"
                            ></Input>
                        </FormItem>
                    </Col>
                    <Col span="8">
                        <FormItem
                            label="银行类型"
                            :class="{
                                equal:
                                    isChange &&
                                    formAttr.bankType != oldFormData.bankType
                            }"
                        >
                            <template slot="label" v-if="isChange">
                                <Tooltip :content="oldBaseInfo.bankType"
                                    >银行类型</Tooltip
                                >
                            </template>
                            <Input
                                :disabled="baseInfoReadOnly || changeQuality"
                                v-model="formAttr.bankType"
                                :placeholder="(!Boolean(formAttr.bankType) && (baseInfoReadOnly || changeQuality))?'':'请输入银行类型'"
                            ></Input>
                        </FormItem>
                    </Col>
                </Row>
                <Row>
                    <FormItem
                        label="开票说明"
                        :class="{
                            equal:
                                isChange &&
                                formAttr.invoiceDescription !=
                                    oldFormData.invoiceDescription
                        }"
                    >
                        <template slot="label" v-if="isChange">
                            <Tooltip :content="oldBaseInfo.invoiceDescription"
                                >开票说明</Tooltip
                            >
                        </template>
                        <Input
                            :disabled="baseInfoReadOnly || changeQuality"
                            v-model="formAttr.invoiceDescription"
                            :placeholder="(!Boolean(formAttr.invoiceDescription) && (baseInfoReadOnly || changeQuality))?'':'请输入开票说明'"
                        ></Input>
                    </FormItem>
                </Row>
                <Row>
                    <FormItem
                        label="开票地址"
                        :class="{
                            equal:
                                isChange &&
                                formAttr.invoiceAddress !=
                                    oldFormData.invoiceAddress
                        }"
                    >
                        <template slot="label" v-if="isChange">
                            <Tooltip :content="oldBaseInfo.invoiceAddress"
                                >开票地址</Tooltip
                            >
                        </template>
                        <Input
                            :disabled="baseInfoReadOnly || changeQuality"
                            v-model="formAttr.invoiceAddress"
                            :placeholder="(!Boolean(formAttr.invoiceAddress) && (baseInfoReadOnly || changeQuality))?'':'请输入开票地址'"
                        ></Input>
                    </FormItem>
                </Row>
                <Row>
                    <FormItem
                        label="客户说明"
                        :class="{
                            equal:
                                isChange &&
                                formAttr.customerDescription !=
                                    oldFormData.customerDescription
                        }"
                    >
                        <template slot="label" v-if="isChange">
                            <Tooltip :content="oldBaseInfo.customerDescription"
                                >客户说明</Tooltip
                            >
                        </template>
                        <Input
                            :disabled="baseInfoReadOnly || changeQuality"
                            v-model="formAttr.customerDescription"
                            :placeholder="(!Boolean(formAttr.customerDescription) && (baseInfoReadOnly || changeQuality))?'':'请输入客户说明'"
                        ></Input>
                    </FormItem>
                </Row>
                <Row>
                    <FormItem
                        label="仓库地址"
                        :class="{
                            equal:
                                isChange &&
                                formAttr.warehouseAddress !=
                                    oldFormData.warehouseAddress
                        }"
                    >
                        <template slot="label" v-if="isChange">
                            <Tooltip :content="oldBaseInfo.warehouseAddress"
                                >仓库地址</Tooltip
                            >
                        </template>
                        <Input
                            :disabled="baseInfoReadOnly"
                            v-model="formAttr.warehouseAddress"
                            :placeholder="(!Boolean(formAttr.warehouseAddress) && baseInfoReadOnly)?'':'请输入仓库地址'"
                        ></Input>
                    </FormItem>
                </Row>
            </Form>
        </Card>
    </div>
</template>

<script>
import { saveCustomerInfo, getBankList } from '@/api/masterData/customer';
import { saveChangeData } from '@/api/masterData/userchange';

export default {
    props: {
        customerAreaArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        customerTypeArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        customerClassifyArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        saleMethodArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        saleModeArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        saleDepartmentArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        customerLevelArr: {
            type: Array,
            default: () => {
                return [];
            }
        },
        oldFormAttr: {
            type: Object,
            default: () => {
                return {};
            }
        },
        firstImport: {
            type: Boolean,
            default: () => {
                return false;
            }
        },
        firstSub: {
            type: Boolean,
            default: () => {
                return false;
            }
        },
        baseInfoReadOnly: {
            type: Boolean,
            default: false
        },
        // 销售变更参数
        isChange: {
            type: Boolean,
            default: false
        },
        // 销售变更-质管只读权限
        changeQuality: {
            type: Boolean,
            default: false
        },
        oldBaseInfo: {
            type: Object,
            default: () => {
                return {
                    customerName: '',
                    customerCode: '',
                    customerArea: '',
                    customerType: '',
                    customerClassify: '',
                    contractPaymentMonth: '',
                    saleMethod: '',
                    saleMode: '',
                    parentId: '',
                    parentName: '',
                    saleDepartment: '',
                    customerLevel: '',
                    licenseRegistrationCode: '',
                    customerAddress: '',
                    unifiedSocialCreditCode: '',
                    dutyParagraph: '',
                    bankName: '',
                    bankCode: '',
                    bankAccount: '',
                    bankType: '',
                    invoiceDescription: '',
                    invoiceAddress: '',
                    customerDescription: '',
                    warehouseAddress: '',
                    id: '',
                    customerId: ''
                };
            }
        }
    },
    data() {
        return {
            oldFormData: {},
            formAttr: {
                customerName: '',
                customerCode: '',
                customerArea: '',
                customerType: '',
                customerClassify: '',
                contractPaymentMonth: '',
                saleMethod: '',
                saleMode: '',
                parentId: '',
                parentName: '',
                saleDepartment: '',
                customerLevel: '',
                licenseRegistrationCode: '',
                customerAddress: '',
                unifiedSocialCreditCode: '',
                dutyParagraph: '',
                bankName: '',
                bankCode: '',
                bankAccount: '',
                bankType: '',
                invoiceDescription: '',
                invoiceAddress: '',
                customerDescription: '',
                warehouseAddress: '',
                id: '',
                customerId: ''
            },
            ruleValidate: {
                customerName: [
                    {
                        required: true,
                        message: '客户名称不能为空',
                        trigger: 'blur'
                    }
                ],
                customerArea: [
                    {
                        required: true,
                        type: 'number',
                        message: '客户区域不能为空',
                        trigger: 'change'
                    }
                ],
                customerType: [
                    {
                        required: true,
                        type: 'number',
                        message: '客户类型不能为空',
                        trigger: 'change'
                    }
                ],
                customerClassify: [
                    {
                        required: true,
                        type: 'number',
                        message: '客户分类不能为空',
                        trigger: 'change'
                    }
                ],
                saleMethod: [
                    {
                        required: true,
                        type: 'number',
                        message: '销售方式不能为空',
                        trigger: 'change'
                    }
                ],
                saleMode: [
                    {
                        required: true,
                        type: 'number',
                        message: '销售模式不能为空',
                        trigger: 'change'
                    }
                ],
                saleDepartment: [
                    {
                        required: true,
                        type: 'number',
                        message: '销售部门不能为空',
                        trigger: 'change'
                    }
                ],
                customerLevel: [
                    {
                        required: true,
                        type: 'number',
                        message: '客户等级不能为空',
                        trigger: 'change'
                    }
                ]
            },
            code: 10000,
            bankList: [],
            bankTimer: null, // 银行自动填充防抖
            curBanks: '' // 自动选中的银行信息
        };
    },
    methods: {
        // 保存信息
        saveInfo() {
            this.$refs['formValidate'].validate(async valid => {
                if (!valid) {
                    return this.$emit('changeLoading');
                }
                if(this.formAttr.contractPaymentMonth){
                    const judgePay = Number.isInteger(
                        Number(this.formAttr.contractPaymentMonth)
                    );
                    if (!judgePay) {
                        this.$Message.error('合同账期只能为整数');
                        this.$emit('changeLoading');
                        return this.$emit('changeLoading');
                    }
                }
                if (this.bankValidate()) {
                    const params = Object.assign({}, this.formAttr, {
                        isImport: this.firstImport ? 1 : 0
                    });
                    const res = await saveCustomerInfo(params);
                    this.$emit('changeLoading');
                    if (res.status === this.code) {
                        this.$emit('changeCurrentId', res.content.id);
                        this.$Message.success(res.msg);
                        this.$emit('getTableList');
                        this.formAttr = Object.assign({}, this.formAttr, {
                            id: res.content.id,
                            customerCode: res.content.customerCode
                        });
                    }
                } else {
                    this.$emit('changeLoading');
                }
            });
        },
        // 变更保存
        changeSave() {
            this.$refs['formValidate'].validate(async valid => {
                if (!valid) {
                    return this.$emit('changeLoading');
                }
                // const params = Object.assign({}, this.formAttr, {
                //     id: null
                // });
                const params = Object.assign({}, this.formAttr);
                const res = await saveChangeData(params);
                if (res.status === this.code) {
                    this.formAttr.id = res.content.id;
                    this.$emit('changeCurrentId', res.content.id);
                    this.$emit('isSave', true);
                    this.$Message.success('保存成功');
                }
            });
        },
        getLabel(arr, key) {
            let temp = null;
            // if (arr.length) {
            arr.forEach(item => {
                if (item.id === key) temp = item.fieldValue;
            });
            // }
            return temp;
        },
        // 自动填充开户银行
        bankHandleSearch(value) {
            if (this.bankTimer) clearTimeout(this.bankTimer);
            this.bankTimer = setTimeout(() => {
                this.searchBank(value);
            }, 400);
        },
        // 搜索银行信息
        async searchBank(val) {
            const params = {
                bankName: val
            };
            const res = await getBankList(params);
            if (res.status === this.code) {
                this.bankList = res.content;
                const curBanks = this.bankList.filter(item => {
                    return item.bankName === val;
                });
                if (curBanks.length === 1) {
                    this.curBanks = curBanks[0];
                    this.formAttr.bankName = this.curBanks.bankName;
                    this.formAttr.bankCode = this.curBanks.bankCode;
                    this.formAttr.bankType = this.curBanks.bankType;
                }
            }
        },
        // 选中开会银行后
        afterSelectBank(value) {
            this.curBanks = this.bankList.filter(item => {
                return item.bankName === value;
            })[0];
            this.formAttr.bankName = this.curBanks.bankName;
            this.formAttr.bankCode = this.curBanks.bankCode;
            this.formAttr.bankType = this.curBanks.bankType;
        },
        // 筛选银行信息
        bankFilterMethod(value, option) {
            return option.toUpperCase().indexOf(value.toUpperCase()) !== -1;
        },
        // 银行必填校验
        bankValidate() {
            if (
                !this.formAttr.bankName &&
                !this.formAttr.bankCode &&
                !this.formAttr.bankType
            ) {
                return true;
            } else if (
                this.formAttr.bankName &&
                this.formAttr.bankCode &&
                this.formAttr.bankType
            ) {
                if (this.formAttr.bankName !== this.curBanks.bankName) {
                    return true;
                } else {
                    if (
                        this.formAttr.bankName === this.curBanks.bankName &&
                        this.formAttr.bankCode === this.curBanks.bankCode
                    ) {
                        return true;
                    } else if (
                        this.formAttr.bankName === this.curBanks.bankName &&
                        this.formAttr.bankCode !== this.curBanks.bankCode
                    ) {
                        this.$Message.error('银行名称与行号不匹配');
                        return false;
                    }
                }
            } else {
                this.$Message.error('银行信息补完整，请检查银行信息');
                return false;
            }
        }
    },
    watch: {
        oldFormAttr: {
            handler(val) {
                this.oldFormData = val;
                for (let key in val) {
                    this.formAttr[key] = val[key];
                }
            },
            deep: true
        }
    }
};
</script>

<style scoped lang="less">
.info-title {
    padding-top: 10px;
    padding-bottom: 10px;
}

.equal {
    /deep/ .ivu-form-item-label {
        color: blue;
    }
}
</style>
